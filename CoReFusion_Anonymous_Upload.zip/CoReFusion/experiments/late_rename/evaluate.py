"""Paired renaming evaluation with the native, pinned DreamOn sampler.

Full: no gold name/length used in model input or window selection.
Late: oracle-confirmed target subtokens, exactly m remaining masks per window
(or fewer if the target has fewer tokens); an explicitly separate diagnostic.
All generation errors stay in the denominator. Original benchmarks are intact.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import random
import sys
import time

from .corruption import corrupt, tokenize_windows
from .runtime import MODEL_ID, REVISION, file_hash, load_model, load_tokenizer, read_jsonl, write_json
from .prepare_data import RecordError, normalized_fingerprint, valid_identifier


class GenerationLimit(RuntimeError):
    pass


def read_records(path):
    if Path(path).suffix == ".jsonl":
        records = read_jsonl(path)
        for record in records:
            if record.get("repository"):
                record["source_id"] = str(record["id"])
                record["id"] = json.dumps([record["repository"], str(record["id"])], separators=(",", ":"))
        return records
    with open(path, newline="") as stream:
        csv.field_size_limit(sys.maxsize)
        rows = list(csv.reader(stream))
    if not rows or any(len(row) != 3 for row in rows):
        raise ValueError("CSV must use ReFineID's headerless id,code_masked,target schema")
    return [dict(zip(("id", "code_masked", "target"), row)) for row in rows]


def extract_sites(sequence, window, tokenizer):
    """Exact token anchors; require the whole unchanged prefix/suffix to match.

    No regex that silently truncates a generated expression to an identifier.
    A generated special token remains visible and fails validity/EM.
    """
    anchors, start = [], 0
    for a, b in window.sites:
        anchors.append(window.ids[start:a])
        start = b
    anchors.append(window.ids[start:])
    if sequence[:len(anchors[0])] != anchors[0]:
        return [""] * len(window.sites), False
    cursor, predictions = len(anchors[0]), []
    for index, anchor in enumerate(anchors[1:]):
        if not anchor:
            raise ValueError("adjacent unseparated target sites are unsupported")
        final = index == len(anchors) - 2
        if final:
            hit = len(sequence) - len(anchor)
            if hit < cursor or sequence[hit:] != anchor:
                return predictions + [""] * (len(window.sites) - len(predictions)), False
        else:
            hit = next((p for p in range(cursor, len(sequence) - len(anchor) + 1)
                        if sequence[p:p + len(anchor)] == anchor), -1)
            if hit == -1:
                return predictions + [""] * (len(window.sites) - len(predictions)), False
        predictions.append(tokenizer.decode(sequence[cursor:hit], skip_special_tokens=False).strip())
        cursor = hit + len(anchor)
    return predictions, cursor == len(sequence)


def generate(model, tokenizer, ids, max_length, max_canvas, max_actions, temperature, seed):
    import torch
    base = model.get_base_model() if hasattr(model, "get_base_model") else model
    mask_count = ids.count(tokenizer.mask_token_id)
    canvas = min(max_canvas, max_length - (len(ids) - mask_count))
    if not mask_count or canvas < mask_count:
        raise ValueError("invalid mask/canvas budget")
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    trace = []
    def count_call(module, positional):
        if len(trace) >= max_actions:
            raise GenerationLimit(f"Exceeded {max_actions} model forwards")
        inputs = positional[0]
        active = positional[1][0, 0].any(-1)
        trace.append({"nfe": len(trace) + 1,
                      "remaining_masks": int(((inputs[0] == tokenizer.mask_token_id) & active).sum().item())})
    handle = base.register_forward_pre_hook(count_call)
    torch.cuda.synchronize()
    tick = time.monotonic()
    try:
        with torch.no_grad():
            output = base.diffusion_generate(
                torch.tensor([ids], device="cuda", dtype=torch.long),
                max_new_tokens=canvas, expand_budget=canvas * 2,
                temperature=temperature, top_p=.9, alg="entropy", alg_temp=0.,
                number_transfer_tokens=1, pad_delete_to_right=False,
                eos_token_id=tokenizer.eos_token_id, delete_token_id=tokenizer.eos_token_id,
                return_dict_in_generate=True, output_history=True)
        # sequences contains inactive padding. Last history is compact active
        # canvas, including post-expand/delete state, per upstream contract.
        sequence = output.history[-1].tolist() if output.history else list(ids)
        lengths = [len(ids)] + [len(state) for state in (output.history or [])]
        expansions = sum(max(0, right - left) for left, right in zip(lengths, lengths[1:]))
        deletions = sum(max(0, left - right) for left, right in zip(lengths, lengths[1:]))
        unresolved = sequence.count(tokenizer.mask_token_id)
        error = "unresolved_masks" if unresolved else None
    except GenerationLimit as exc:
        sequence, unresolved, error = [], None, str(exc)
        expansions = deletions = None
    finally:
        handle.remove()
    torch.cuda.synchronize()
    return sequence, {"nfe": len(trace), "seconds": time.monotonic() - tick,
                      "unresolved_masks": unresolved, "expansions": expansions, "deletions": deletions,
                      "error": error, "trace": trace}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data", default="data/test.csv")
    p.add_argument("--output", required=True, help="new output JSONL; summary/manifest beside it")
    p.add_argument("--model", default=MODEL_ID)
    p.add_argument("--revision", default=REVISION)
    p.add_argument("--adapter")
    p.add_argument("--mode", choices=("full", "late"), default="full")
    p.add_argument("--initial-masks", type=int, default=2)
    p.add_argument("--remaining", type=int, choices=(1, 2, 3), default=1)
    p.add_argument("--max-length", type=int, default=1024)
    p.add_argument("--max-sites", type=int, default=8)
    p.add_argument("--max-canvas", type=int, default=64)
    p.add_argument("--max-actions", type=int, default=512)
    p.add_argument("--temperature", type=float, default=.2)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--max-samples", type=int, default=0, help="0 = all, 20 = smoke")
    args = p.parse_args(argv)
    if not 1 <= args.initial_masks <= 16 or args.max_actions < 1 or args.max_samples < 0:
        p.error("invalid initial masks, actions or samples")
    out = Path(args.output)
    if any(path.exists() for path in (out, out.with_suffix(".summary.json"), out.with_suffix(".manifest.json"))):
        raise FileExistsError(out)
    records = read_records(args.data)
    if args.max_samples:
        records = records[:args.max_samples]
    if not records or len({str(r["id"]) for r in records}) != len(records):
        raise ValueError("records must have unique IDs and be nonempty")
    tokenizer = load_tokenizer(args.model, args.revision)
    model = load_model(args.model, args.revision, adapter=args.adapter)
    out.parent.mkdir(parents=True, exist_ok=True)
    adapter_hashes = None
    if args.adapter:
        adapter_hashes = {f.name: file_hash(f) for f in Path(args.adapter).iterdir()
                          if f.name in ("adapter_config.json", "adapter_model.safetensors", "adapter_model.bin")}
    write_json(out.with_suffix(".manifest.json"), {"arguments": vars(args),
        "data_sha256": file_hash(args.data), "adapter_hashes": adapter_hashes,
        "protocol": "native-dreamon-v1-exact-anchors", "full_uses_gold_input": False,
        "late_uses_oracle_confirmations": True, "n_samples": len(records)})
    totals = {"n": 0, "strict_correct": 0, "first_correct": 0, "site_correct": 0,
              "sites": 0, "valid_sites": 0, "consistent_samples": 0,
              "context_preserved_samples": 0, "error_samples": 0, "nfe": 0, "seconds": 0.}
    with out.open("x") as stream:
        for record in records:
            count = record["code_masked"].count("[MASK]")
            predictions, window_logs = [""] * count, []
            preserved, errors = True, 0
            try:
                token_record = dict(record)
                if args.mode == "full":
                    token_record["target_ids_override"] = [tokenizer.mask_token_id] * args.initial_masks
                windows = tokenize_windows(token_record, tokenizer, args.max_length, 64, args.max_sites)
                for wi, window in enumerate(windows):
                    sample_seed = (int.from_bytes(hashlib.sha256(
                        f"{args.seed}:{record['id']}:{wi}".encode()).digest()[:4], "big") % 2**31)
                    ids = window.ids
                    if args.mode == "late":
                        ids = corrupt(window, random.Random(sample_seed), tokenizer.mask_token_id,
                                      model.config.expand_token_id, tokenizer.eos_token_id,
                                      mode="late", remaining=args.remaining)["input_ids"]
                    sequence, log = generate(model, tokenizer, ids, args.max_length,
                        args.max_canvas, args.max_actions, args.temperature, sample_seed)
                    log["initial_remaining_masks"] = ids.count(tokenizer.mask_token_id)
                    found, context_ok = extract_sites(sequence, window, tokenizer)
                    log["context_preserved"] = context_ok
                    errors += int(bool(log["error"]))
                    preserved &= context_ok
                    for site, prediction in zip(window.site_indices, found):
                        predictions[site] = prediction
                    window_logs.append(log)
            except Exception as exc:
                # Failed samples are recorded with zero strict score; never dropped.
                errors += 1
                preserved = False
                window_logs.append({"error": f"{type(exc).__name__}: {exc}", "nfe": 0, "seconds": 0.})
            correct = [prediction == record["target"] for prediction in predictions]
            valid = [valid_identifier(x) for x in predictions]
            strict = bool(count and all(correct) and preserved and not errors)
            reconstructed = record["code_masked"].replace("[MASK]", record["target"])
            try:
                source_cluster = normalized_fingerprint(reconstructed)
            except RecordError:
                source_cluster = "raw:" + hashlib.sha256(reconstructed.encode()).hexdigest()
            row = {"id": str(record["id"]), "mode": args.mode, "initial_masks": args.initial_masks,
                   "source_cluster_id": source_cluster, "repository": record.get("repository"),
                   "remaining": args.remaining, "seed": args.seed, "target": record["target"],
                   "target_tokens": len(tokenizer.encode(record["target"], add_special_tokens=False)),
                   "site_predictions": predictions, "strict_em": strict,
                   "first_site_em": bool(correct and correct[0]),
                   "context_preserved": preserved, "error_count": errors,
                   "nfe": sum(log["nfe"] for log in window_logs),
                   "seconds": sum(log["seconds"] for log in window_logs), "windows": window_logs}
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
            stream.flush()
            totals["n"] += 1
            totals["strict_correct"] += int(strict)
            totals["first_correct"] += int(row["first_site_em"])
            totals["site_correct"] += sum(correct)
            totals["sites"] += count
            totals["valid_sites"] += sum(valid)
            totals["consistent_samples"] += int(bool(count and all(valid) and len(set(predictions)) == 1))
            totals["context_preserved_samples"] += int(preserved)
            totals["error_samples"] += int(errors > 0)
            totals["nfe"] += row["nfe"]
            totals["seconds"] += row["seconds"]
            print(f"{totals['n']}/{len(records)} id={record['id']} strict={strict} errors={errors}", flush=True)
    summary = dict(totals)
    summary.update(strict_em=totals["strict_correct"] / totals["n"],
                   first_site_em=totals["first_correct"] / totals["n"],
                   site_em=totals["site_correct"] / max(1, totals["sites"]),
                   mean_nfe=totals["nfe"] / totals["n"])
    write_json(out.with_suffix(".summary.json"), summary)
    print(json.dumps(summary), flush=True)
    if totals["error_samples"] == totals["n"]:
        raise SystemExit("Every sample failed; inspect output errors before scheduling a full run")


if __name__ == "__main__":
    main()
