"""Token-space states, independent of torch. Labels are *actions*, not AR text.

Context and confirmed target tokens receive -100 (except the broad-noise
control, which deliberately masks context too). The trainer aligns each
label at position p with DreamOn's raw logits at p-1, as its sampler does.
"""
from dataclasses import dataclass
import random
import math

IGNORE = -100
MODES = ("late", "full", "expand", "delete", "broad")
DEFAULT_MIXTURE = {"late": .55, "full": .15, "expand": .15, "delete": .15}


@dataclass
class Window:
    ids: list
    sites: list  # half-open token spans; all belong to one identifier
    site_indices: list


def tokenize_windows(record, tokenizer, max_length=1024, reserve=32, max_sites=8):
    """Tile all sites without exposing a partly cropped external identifier.

    Segments are encoded separately, exactly as existing DreamOn infilling.
    Window selection never depends on the identifier's spelling at evaluation:
    pass a placeholder target token list using target_ids_override there.
    """
    target_ids = record.get("target_ids_override")
    if target_ids is None:
        target_ids = tokenizer.encode(record["target"], add_special_tokens=False)
    if not target_ids or len(target_ids) > 16:
        raise ValueError("target must occupy 1..16 tokenizer tokens")
    parts = record["code_masked"].split("[MASK]")
    if len(parts) < 2:
        raise ValueError("record has no target sites")
    flat, spans = [], []
    for i, part in enumerate(parts):
        flat.extend(tokenizer.encode(part, add_special_tokens=False))
        if i < len(parts) - 1:
            start = len(flat)
            flat.extend(target_ids)
            spans.append((start, len(flat)))
    if any(x is None for x in (tokenizer.bos_token_id, tokenizer.eos_token_id)):
        raise ValueError("DreamOn BOS/EOS required")
    budget = max_length - reserve - 2
    if budget < 16 or max_sites < 1:
        raise ValueError("invalid context budget/max_sites")
    windows, first = [], 0
    while first < len(spans):
        last = first
        while (last + 1 < len(spans) and last - first + 1 < max_sites
               and spans[last + 1][1] - spans[first][0] <= budget):
            last += 1
        left_limit = spans[first - 1][1] if first else 0
        right_limit = spans[last + 1][0] if last + 1 < len(spans) else len(flat)
        spare = budget - (spans[last][1] - spans[first][0])
        left = max(left_limit, spans[first][0] - spare // 2)
        right = min(right_limit, left + budget)
        left = max(left_limit, right - budget)
        ids = [tokenizer.bos_token_id] + flat[left:right] + [tokenizer.eos_token_id]
        local = [(a - left + 1, b - left + 1) for a, b in spans[first:last + 1]]
        windows.append(Window(ids, local, list(range(first, last + 1))))
        first = last + 1
    return windows


def validate_mixture(mixture):
    if not mixture or set(mixture) - set(MODES):
        raise ValueError(f"mixture keys must be in {MODES}")
    if any(not math.isfinite(v) or v < 0 for v in mixture.values()) or sum(mixture.values()) <= 0:
        raise ValueError("mixture weights must be nonnegative with positive sum")
    return mixture


def corrupt(window, rng, mask_id, expand_id, delete_id, mode=None,
            mixture=None, remaining=None):
    """Create one compact inference-compatible state; no artificial time input.

    expand: replace 2+ consecutive target tokens with one unresolved action;
    delete: insert surplus slots, whose labels are EOS (DreamOn delete state).
    Confirmations are ground truth: these are controlled/oracle late states,
    not a claim that a real model has correctly confirmed its preceding steps.
    """
    mixture = validate_mixture(mixture or DEFAULT_MIXTURE)
    mode = mode or rng.choices(list(mixture), weights=list(mixture.values()), k=1)[0]
    requested = mode
    ids = list(window.ids)
    labels = [IGNORE] * len(ids)
    positions = [p for a, b in window.sites for p in range(a, b)]
    if not positions:
        raise ValueError("empty target")
    if mode == "expand":
        eligible = [(a, b) for a, b in window.sites if b - a >= 2]
        if not eligible:
            mode = "full"  # one-token identifiers cannot be expanded gold spans
        else:
            # Half of expansion states hide every occurrence, preventing an
            # always-visible duplicate from becoming a shortcut to the name.
            groups = eligible if rng.random() < .5 else [rng.choice(eligible)]
            for a, b in sorted(groups, reverse=True):
                if len(groups) == 1 and rng.random() < .5:
                    a = rng.randrange(a, b - 1)
                    b = rng.randint(a + 2, b)
                ids[a:b] = [mask_id]
                labels[a:b] = [expand_id]
    if mode == "delete":
        _, end = rng.choice(window.sites)
        count = remaining or rng.randint(1, 3)
        ids[end:end] = [mask_id] * count
        labels[end:end] = [delete_id] * count
    elif mode in ("late", "full", "broad"):
        if mode == "late":
            count = min(remaining or rng.randint(1, 3), len(positions))
            positions = rng.sample(positions, count)
        elif mode == "broad":
            candidates = list(range(1, len(ids) - 1))
            count = max(1, round(len(candidates) * rng.uniform(.05, .95)))
            positions = rng.sample(candidates, count)
        for p in positions:
            labels[p], ids[p] = ids[p], mask_id
    elif mode != "expand":
        raise ValueError(f"unknown mode: {mode}")
    assert len(ids) == len(labels) and any(x != IGNORE for x in labels)
    assert labels[0] == IGNORE and labels[-1] == IGNORE
    assert all(x == IGNORE or ids[p] == mask_id for p, x in enumerate(labels))
    return {"input_ids": ids, "labels": labels, "mode": mode,
            "requested_mode": requested, "masked_count": sum(x != IGNORE for x in labels),
            "mask_ratio": sum(x == mask_id for x in ids) / len(ids)}


def action_positions(labels):
    """Physical source logits and gold labels: compact first, shift second."""
    positions = [p for p, x in enumerate(labels) if x != IGNORE]
    if not positions or positions[0] == 0:
        raise ValueError("supervision must follow BOS")
    return [p - 1 for p in positions], [labels[p] for p in positions]
