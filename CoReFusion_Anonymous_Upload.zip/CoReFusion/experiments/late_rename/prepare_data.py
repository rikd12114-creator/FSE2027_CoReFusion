#!/usr/bin/env python3
"""Prepare leakage-screened, repository-disjoint renaming training data.

Only the Python standard library is required. Input JSONL must provide explicit
repository and record IDs, and either code_masked/target or code/target/target_spans.
Spans are Python character offsets, not bytes or tokenizer offsets. Every lexical
occurrence of the target spelling must be masked; provide scope-resolved examples
upstream when a spelling refers to multiple bindings.

This is conservative exact lexical/template screening, not clone detection or a
Java binding resolver. Whitespace and comments are ignored for fingerprints;
string literals are preserved. Structurally edited or alpha-renamed clones can
still evade the filter. Audit source repositories and clone families upstream.
"""

from __future__ import annotations

import argparse
import ast
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import tempfile
import unicodedata


MASK = "[MASK]"
JAVA_RESERVED = set("""abstract assert boolean break byte case catch char class
const continue default do double else enum extends final finally float for goto
if implements import instanceof int interface long native new package private
protected public return short static strictfp super switch synchronized this
throw throws transient try void volatile while true false null _""".split())
PLACEHOLDER_TARGET = re.compile(r"(?:MASK(?:_?\d+)?|__+(?:mask|masked|placeholder|target|identifier)__+)", re.I)
DEFAULT_HOLDOUTS = (
    "data/test.csv", "data/test_filtered_1024.csv", "data/Developer/Test-Dev.csv"
)


class RecordError(ValueError):
    """A rejected input record, with a stable machine-readable reason."""

    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)


def _identifier_start(char: str) -> bool:
    return bool(char) and (char in "_$" or unicodedata.category(char) in {"Lu", "Ll", "Lt", "Lm", "Lo", "Nl", "Sc", "Pc"})


def _identifier_part(char: str) -> bool:
    return _identifier_start(char) or bool(char) and unicodedata.category(char) in {"Mn", "Mc", "Nd", "Cf"}


def valid_identifier(name: object) -> bool:
    return isinstance(name, str) and bool(name) and _identifier_start(name[0]) and all(_identifier_part(c) for c in name[1:]) and name not in JAVA_RESERVED


def lexical_tokens(code: str) -> list[tuple[str, str, int, int]]:
    """Return Java-like tokens, omitting comments; preserve literals verbatim.

    Unicode escape preprocessing and full Java grammar are intentionally outside
    this scanner's scope. Escape-obfuscated identifier input is rejected below.
    """
    tokens = []
    i = 0
    while i < len(code):
        start = i
        if code[i].isspace():
            i += 1
            continue
        if code.startswith("//", i):
            end = code.find("\n", i + 2)
            i = len(code) if end < 0 else end + 1
            continue
        if code.startswith("/*", i):
            end = code.find("*/", i + 2)
            if end < 0:
                raise RecordError("unterminated_comment")
            i = end + 2
            continue
        if code.startswith(MASK, i):
            i += len(MASK)
            tokens.append(("mask", MASK, start, i))
            continue
        if code.startswith('"""', i):
            i += 3
            while i < len(code):
                if code[i] == "\\":
                    i += 2
                elif code.startswith('"""', i):
                    i += 3
                    break
                else:
                    i += 1
            else:
                raise RecordError("unterminated_literal")
            tokens.append(("literal", code[start:i], start, i))
            continue
        if code[i] in "\"'":
            quote = code[i]
            i += 1
            while i < len(code):
                if code[i] == "\\":
                    i += 2
                elif code[i] == quote:
                    i += 1
                    break
                else:
                    i += 1
            else:
                raise RecordError("unterminated_literal")
            tokens.append(("literal", code[start:i], start, i))
            continue
        if _identifier_start(code[i]):
            i += 1
            while i < len(code) and _identifier_part(code[i]):
                i += 1
            tokens.append(("identifier", code[start:i], start, i))
            continue
        i += 1
        tokens.append(("punctuation", code[start:i], start, i))
    return tokens


def normalized_fingerprint(code: str) -> str:
    normalized = [(kind, token) for kind, token, _, _ in lexical_tokens(code)]
    payload = json.dumps(normalized, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def normalize_repository(repository: object) -> str:
    if not isinstance(repository, str) or not repository.strip():
        raise RecordError("missing_repository")
    value = repository.strip().replace("\\", "/").rstrip("/")
    value = re.sub(r"^(?:https?://|git@)(?:www\.)?github\.com[:/]", "", value, flags=re.I)
    value = re.sub(r"\.git$", "", value, flags=re.I).lower()
    if value in {"unknown", "none", "null", "n/a", "na", "default", "unassigned", "?"}:
        raise RecordError("missing_repository")
    return value


def repository_alias(repository: str) -> str:
    # Developer benchmark stores owner-repo_<commit>, rather than owner/repo.
    # Flattening can over-exclude ambiguous hyphenated names, never under-exclude
    # those known benchmark aliases. Prefer canonical owner/repo input metadata.
    return normalize_repository(repository).replace("/", "-")


def _mask_spans(code: str, spans: list[tuple[int, int]]) -> str:
    for start, end in reversed(spans):
        code = code[:start] + MASK + code[end:]
    return code


def canonicalize_record(raw: dict) -> dict:
    if not isinstance(raw, dict):
        raise RecordError("record_not_object")
    repository = normalize_repository(raw.get("repository"))
    record_id = raw.get("id")
    if not isinstance(record_id, str) or not record_id.strip():
        raise RecordError("missing_id")
    target = raw.get("target")
    if not valid_identifier(target):
        raise RecordError("invalid_target_identifier")
    if PLACEHOLDER_TARGET.fullmatch(target):
        raise RecordError("placeholder_target")
    code_masked = raw.get("code_masked")
    if code_masked is None:
        code = raw.get("code")
        spans = raw.get("target_spans")
        if not isinstance(code, str) or not code.strip():
            raise RecordError("missing_code")
        if MASK in code:
            raise RecordError("raw_code_already_masked")
        if not isinstance(spans, list) or not spans:
            raise RecordError("missing_target_spans")
        checked = []
        for span in spans:
            if not isinstance(span, (list, tuple)) or len(span) != 2 or any(type(v) is not int for v in span):
                raise RecordError("invalid_target_span")
            start, end = span
            if not (0 <= start < end <= len(code)) or code[start:end] != target:
                raise RecordError("span_target_mismatch")
            checked.append((start, end))
        checked.sort()
        if any(left[1] > right[0] for left, right in zip(checked, checked[1:])):
            raise RecordError("overlapping_target_spans")
        expected = [(start, end) for kind, text, start, end in lexical_tokens(code) if kind == "identifier" and text == target]
        if checked != expected:
            raise RecordError("spans_must_cover_all_target_identifiers")
        code_masked = _mask_spans(code, checked)
    if not isinstance(code_masked, str) or not code_masked.strip():
        raise RecordError("missing_code_masked")
    # Java processes Unicode escapes before lexing, so this lightweight scanner
    # cannot safely identify target bindings or comments in such source.
    if re.search(r"\\u+[0-9a-fA-F]{4}", code_masked):
        raise RecordError("java_unicode_escape_requires_upstream_parsing")
    tokens = lexical_tokens(code_masked)
    mask_tokens = [token for token in tokens if token[0] == "mask"]
    if not mask_tokens:
        raise RecordError("no_identifier_masks")
    if len(mask_tokens) != code_masked.count(MASK):
        raise RecordError("mask_in_comment_or_literal")
    for _, _, start, end in mask_tokens:
        if (start and _identifier_part(code_masked[start - 1])) or (end < len(code_masked) and _identifier_part(code_masked[end])):
            raise RecordError("mask_not_identifier_boundary")
    if any(kind == "identifier" and text == target for kind, text, _, _ in tokens):
        raise RecordError("unmasked_target_identifier")
    result = {"id": record_id.strip(), "repository": repository, "code_masked": code_masked, "target": target}
    if "source_path" in raw:
        if not isinstance(raw["source_path"], str):
            raise RecordError("invalid_source_path")
        result["source_path"] = raw["source_path"]
    return result


def record_fingerprints(record: dict) -> tuple[str, str]:
    template = normalized_fingerprint(record["code_masked"])
    reconstructed = normalized_fingerprint(record["code_masked"].replace(MASK, record["target"]))
    return template, reconstructed


def _developer_repository(row: dict) -> str | None:
    for field in ("repository", "repo"):
        if row.get(field):
            return normalize_repository(row[field])
    source = row.get("extractedFrom", "").replace("\\", "/")
    match = re.search(r"/test-set-developer-repos(?:-json)?/([^/]+)", source)
    if match:
        return re.sub(r"_[0-9a-f]{7,40}$", "", match.group(1), flags=re.I).lower()
    return None


def _holdout_records(path: Path):
    """Read existing benchmark schemas without modifying source files."""
    if path.suffix.lower() == ".jsonl":
        with path.open(encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                row = json.loads(line)
                if not isinstance(row, dict):
                    raise ValueError(f"Holdout record is not an object: {path}")
                if "code_masked" not in row:
                    # Raw span examples still receive the same strict checks.
                    row = canonicalize_record({"id": "holdout", "repository": "holdout", **row})
                yield row
        return
    if path.suffix.lower() != ".csv":
        raise ValueError(f"Holdout must be CSV or JSONL: {path}")
    csv.field_size_limit(sys.maxsize)
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle)
        first = next(reader, None)
        if first is None:
            return
        if "methodBody" in first and "Target-Var" in first:
            header = first
            for cells in reader:
                row = dict(zip(header, cells))
                code = row.get("methodBody", "")
                targets = ast.literal_eval(row["Target-Var"])
                if not isinstance(targets, dict) or not targets:
                    raise ValueError(f"Malformed Developer benchmark targets: {path}")
                repository = _developer_repository(row)
                for target in targets:
                    if not valid_identifier(target):
                        raise ValueError(f"Invalid Developer benchmark target: {path}")
                    spans = [(start, end) for kind, text, start, end in lexical_tokens(code) if kind == "identifier" and text == target]
                    if not spans:
                        raise ValueError(f"Developer benchmark target absent from method: {path}")
                    yield {"code_masked": _mask_spans(code, spans), "target": target, "repository": repository}
        elif "code_masked" in first and "target" in first:
            for cells in reader:
                yield dict(zip(first, cells))
        else:
            import itertools
            for cells in itertools.chain([first], reader):
                if len(cells) != 3:
                    raise ValueError(f"Expected headerless [id, code_masked, target] CSV: {path}")
                yield {"id": cells[0], "code_masked": cells[1], "target": cells[2]}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def collect_holdout(paths: list[Path]) -> tuple[dict, list[dict]]:
    if not paths:
        raise ValueError("At least one nonempty benchmark holdout is mandatory")
    index = {"templates": set(), "reconstructed": set(), "repositories": set()}
    manifest = []
    for path in paths:
        path = Path(path).resolve()
        count = 0
        known_repository_rows = 0
        for row in _holdout_records(path):
            code = row.get("code_masked")
            if not isinstance(code, str) or MASK not in code or not valid_identifier(row.get("target")):
                raise ValueError(f"Malformed holdout code/target: {path}")
            template, reconstructed = record_fingerprints(row)
            index["templates"].add(template)
            index["reconstructed"].add(reconstructed)
            if row.get("repository"):
                index["repositories"].add(repository_alias(row["repository"]))
                known_repository_rows += 1
            count += 1
        if count == 0:
            raise ValueError(f"Empty benchmark holdout: {path}")
        manifest.append({"path": str(path), "sha256": sha256_file(path), "records": count, "rows_with_repository": known_repository_rows})
    return index, manifest


def prepare_dataset(input_paths: list[Path], output_dir: Path, holdout_paths: list[Path], validation_fraction: float = 0.1, seed: int = 42) -> dict:
    """Validate, decontaminate, deduplicate, group-split and stage output data."""
    output_dir = Path(output_dir).resolve()
    if output_dir.exists():
        raise ValueError(f"Refusing to overwrite existing output directory: {output_dir}")
    if not 0 < validation_fraction < 1:
        raise ValueError("validation_fraction must be strictly between 0 and 1")
    if not input_paths:
        raise ValueError("At least one input JSONL path is required")
    holdout, holdout_manifest = collect_holdout(holdout_paths)
    held_hashes = {row["sha256"] for row in holdout_manifest}
    counts = Counter()
    candidates = []
    input_manifest = []
    for path in input_paths:
        path = Path(path).resolve()
        file_hash = sha256_file(path)
        if file_hash in held_hashes:
            raise ValueError(f"Training input is a benchmark holdout (matching SHA-256): {path}")
        if path.suffix.lower() != ".jsonl":
            raise ValueError(f"Training input must be explicit repository-labelled JSONL: {path}")
        rows = 0
        with path.open(encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                rows += 1
                try:
                    row = canonicalize_record(json.loads(line))
                    template, reconstructed = record_fingerprints(row)
                except json.JSONDecodeError:
                    counts["invalid_json"] += 1
                    continue
                except RecordError as error:
                    counts[error.reason] += 1
                    continue
                if repository_alias(row["repository"]) in holdout["repositories"]:
                    counts["benchmark_repository_overlap"] += 1
                elif template in holdout["templates"]:
                    counts["benchmark_masked_template_overlap"] += 1
                elif reconstructed in holdout["reconstructed"]:
                    counts["benchmark_reconstructed_code_overlap"] += 1
                else:
                    candidates.append((row, template, reconstructed))
        input_manifest.append({"path": str(path), "sha256": file_hash, "records": rows})
    # Conflicting labels on the same masked template are rejected as a group.
    template_targets = defaultdict(set)
    for row, template, _ in candidates:
        template_targets[template].add(row["target"])
    seen_templates, seen_codes, seen_ids = set(), set(), set()
    records = []
    for row, template, reconstructed in sorted(candidates, key=lambda item: (item[0]["repository"], item[0]["id"], item[1], item[2])):
        identity = (row["repository"], row["id"])
        if len(template_targets[template]) > 1:
            counts["conflicting_template_targets"] += 1
        elif template in seen_templates:
            counts["duplicate_masked_template"] += 1
        elif reconstructed in seen_codes:
            counts["duplicate_reconstructed_code"] += 1
        elif identity in seen_ids:
            counts["duplicate_record_id"] += 1
        else:
            records.append(row)
            seen_templates.add(template)
            seen_codes.add(reconstructed)
            seen_ids.add(identity)
    repositories = sorted({row["repository"] for row in records}, key=lambda repo: (hashlib.sha256(f"{seed}\0{repo}".encode()).hexdigest(), repo))
    if len(repositories) < 2:
        raise ValueError(f"Need at least two nonempty repository groups after filtering; found {len(repositories)}. Skipped: {dict(sorted(counts.items()))}")
    validation_count = min(len(repositories) - 1, max(1, round(len(repositories) * validation_fraction)))
    validation_repositories = set(repositories[:validation_count])
    splits = {
        "train": [row for row in records if row["repository"] not in validation_repositories],
        "validation": [row for row in records if row["repository"] in validation_repositories],
    }
    manifest = {
        "schema_version": 1,
        "seed": seed,
        "validation_fraction_by_repository": validation_fraction,
        "inputs": input_manifest,
        "holdouts": holdout_manifest,
        "skipped": dict(sorted(counts.items())),
        "input_records": sum(row["records"] for row in input_manifest),
        "accepted_records": len(records),
        "splits": {},
        "screening": {
            "normalization": "Java-like lexical tokens; remove whitespace/comments, preserve literal content",
            "checks": ["known benchmark repository aliases", "benchmark masked template", "benchmark reconstructed code", "global exact/template deduplication", "repository-disjoint train/validation"],
            "limitations": ["No general near-duplicate or alpha-renamed clone detection", "No Java scope or binding resolution", "Unknown benchmark repository metadata cannot exclude entire repositories", "Template masking must come from a trusted scope-aware upstream extractor"],
        },
    }
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{output_dir.name}.", dir=output_dir.parent))
    try:
        for split, rows in splits.items():
            path = staging / f"{split}.jsonl"
            with path.open("w", encoding="utf-8") as handle:
                for row in rows:
                    handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
            manifest["splits"][split] = {"path": path.name, "sha256": sha256_file(path), "records": len(rows), "repositories": sorted({row["repository"] for row in rows})}
        (staging / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        # mkdir with exist_ok=False makes even a concurrent empty output directory
        # an explicit refusal; outputs are then moved into our own directory.
        output_dir.mkdir(exist_ok=False)
        for path in staging.iterdir():
            shutil.move(str(path), str(output_dir / path.name))
    finally:
        shutil.rmtree(staging)
    return manifest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", type=Path, nargs="+", required=True, help="Repository-labelled canonical or character-span JSONL (never benchmark CSV)")
    parser.add_argument("--output-dir", type=Path, required=True, help="New directory for train.jsonl, validation.jsonl and manifest.json; must not exist")
    parser.add_argument("--holdout", type=Path, nargs="+", help="Additional mandatory holdout CSV/JSONL paths; bundled benchmark holdouts are always included")
    parser.add_argument("--validation-fraction", type=float, default=0.1, help="Fraction of repository groups assigned to validation, default 0.1")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args(argv)
    project_root = Path(__file__).resolve().parents[2]
    holdouts = list(dict.fromkeys([*(project_root / path for path in DEFAULT_HOLDOUTS), *(args.holdout or [])]))
    try:
        manifest = prepare_dataset(args.input, args.output_dir, holdouts, args.validation_fraction, args.seed)
    except (ValueError, OSError, csv.Error, SyntaxError) as error:
        parser.exit(2, f"error: {error}\n")
    print(json.dumps({"output_dir": str(args.output_dir.resolve()), "accepted_records": manifest["accepted_records"], "splits": {key: value["records"] for key, value in manifest["splits"].items()}, "skipped": manifest["skipped"]}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
