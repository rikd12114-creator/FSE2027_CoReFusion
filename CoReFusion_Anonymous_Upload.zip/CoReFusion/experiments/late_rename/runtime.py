"""Pinned DreamOn loading and sparse, correctly aligned output projection."""
import hashlib
import json
from pathlib import Path

MODEL_ID = "Dream-org/DreamOn-v0-7B"
REVISION = "57e0e4115c97899e3e859b00eae26f54f9cf3872"
LORA_MODULES = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
TOKENIZER_CONTRACT = {
    "bos_token_id": 151665,
    "mask_token_id": 151666,
    "expand_token_id": 151667,
    "eos_token_id": 151643,
}


def file_hash(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_jsonl(path):
    with open(path) as stream:
        return [json.loads(line) for line in stream if line.strip()]


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def validate_tokenizer_contract(tokenizer):
    """Require DreamOn's distinct prompt boundary and action token IDs.

    The tokenizer BOS is 151665 while the model config's generation BOS may be
    151643.  Checking only the model config would therefore miss a mismatched
    tokenizer and could silently shift every prepared sequence.
    """
    observed = {
        "bos_token_id": tokenizer.bos_token_id,
        "mask_token_id": tokenizer.mask_token_id,
        "expand_token_id": tokenizer.convert_tokens_to_ids("<|expand|>"),
        "eos_token_id": tokenizer.eos_token_id,
    }
    literal_ids = {
        "bos_token_id": tokenizer.convert_tokens_to_ids("<|beginoftext|>"),
        "mask_token_id": tokenizer.convert_tokens_to_ids("<|mask|>"),
        "expand_token_id": tokenizer.convert_tokens_to_ids("<|expand|>"),
        "eos_token_id": tokenizer.convert_tokens_to_ids("<|endoftext|>"),
    }
    if observed != TOKENIZER_CONTRACT or literal_ids != TOKENIZER_CONTRACT:
        raise ValueError(
            "Tokenizer does not match the pinned DreamOn token contract: "
            f"attributes={observed}, literal_tokens={literal_ids}"
        )
    return dict(observed)


def load_tokenizer(model_path=MODEL_ID, revision=REVISION):
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        model_path, revision=revision, trust_remote_code=True)
    validate_tokenizer_contract(tokenizer)
    return tokenizer


def load_model(model_path=MODEL_ID, revision=REVISION, adapter=None, train=False, rank=16):
    import torch
    from transformers import AutoModel
    from peft import LoraConfig, PeftModel, get_peft_model
    if not torch.cuda.is_available():
        raise RuntimeError("7B training/evaluation requires a CUDA GPU; use the CPU unit tests locally")
    if not torch.cuda.is_bf16_supported():
        raise RuntimeError("This recipe requires a bf16-capable GPU")
    model = AutoModel.from_pretrained(
        model_path, revision=revision, trust_remote_code=True,
        torch_dtype=torch.bfloat16, attn_implementation="sdpa", low_cpu_mem_usage=True)
    model.config.use_cache = False
    if (model.config.mask_token_id, model.config.expand_token_id, model.config.eos_token_id) != (
            TOKENIZER_CONTRACT["mask_token_id"], TOKENIZER_CONTRACT["expand_token_id"],
            TOKENIZER_CONTRACT["eos_token_id"]):
        raise ValueError("Model does not match the pinned DreamOn token/architecture contract")
    model.to("cuda")
    if adapter:
        model = PeftModel.from_pretrained(model, adapter, is_trainable=train)
    elif train:
        model = get_peft_model(model, LoraConfig(
            r=rank, lora_alpha=2 * rank, lora_dropout=.05,
            target_modules=LORA_MODULES, bias="none"))
    if train:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        model.enable_input_require_grads()
        model.train()
    else:
        model.eval()
    return model


def selected_logits(model, ids, positions):
    """Project only supervised positions, avoiding B*L*152064 training logits.

    PEFT injects LoRA into the decoder's linear modules; calling that decoder
    directly still applies its adapters. Tests compare with the full forward.
    Single sequence per microbatch means there is no padding. Valid boundary
    tokens remain mutually visible even when EOS shares the padding ID.
    """
    import torch
    base = model.get_base_model() if hasattr(model, "get_base_model") else model
    device = next(base.parameters()).device
    inputs = torch.tensor([ids], dtype=torch.long, device=device)
    length = len(ids)
    attention = torch.ones((1, 1, length, length), dtype=torch.bool, device=device)
    positions_ids = torch.arange(length, device=device).unsqueeze(0)
    hidden = base.model(input_ids=inputs, attention_mask=attention,
                        position_ids=positions_ids, use_cache=False, return_dict=True)[0]
    return base.lm_head(hidden[0, positions, :])


def state_loss(model, state):
    import torch
    import torch.nn.functional as F
    from .corruption import action_positions
    source_positions, targets = action_positions(state["labels"])
    logits = selected_logits(model, state["input_ids"], source_positions)
    labels = torch.tensor(targets, dtype=torch.long, device=logits.device)
    loss = F.cross_entropy(logits.float(), labels, reduction="mean")
    correct = (logits.argmax(-1) == labels).sum().item()
    return loss, correct, len(targets)
