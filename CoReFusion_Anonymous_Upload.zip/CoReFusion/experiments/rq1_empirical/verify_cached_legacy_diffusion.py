"""Verify four original dLLM snapshots against their pinned Hub file hashes.

This only reads existing local cache files. It never downloads weights and
writes a receipt only after all files and indexed shards match the Hub commit.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path

from huggingface_hub import HfApi

from .verify_cached_legacy_native import file_digests, hub_cache_name, required_cached_files


MODELS: dict[str, tuple[str, str, int, str]] = {
    "dreamcoder-7b": (
        "Dream-org/Dream-Coder-v0-Instruct-7B", "5d9e88c723af9045f362748b5284bdf43d9c501e", 4, "safetensors"),
    "diffucoder-7b-base": (
        "apple/DiffuCoder-7B-Base", "a2c33054cbe99b9ab7af074f09b1d13943157ff1", 4, "safetensors"),
    "dreamon-7b": (
        "Dream-org/DreamOn-v0-7B", "57e0e4115c97899e3e859b00eae26f54f9cf3872", 4, "safetensors"),
    "diffusiongemma-26b-a4b": (
        "google/diffusiongemma-26B-A4B-it", "0f28bc42f588fbd8f71e08102b1c3960298a1358", 11, "safetensors"),
}


def verify_snapshot(model: str, cache: Path, api: HfApi) -> dict:
    model_id, revision, shard_count, weight_format = MODELS[model]
    snapshot = cache / hub_cache_name(model_id) / "snapshots" / revision
    if not snapshot.is_dir() or snapshot.name != revision:
        raise FileNotFoundError(f"Exact original dLLM snapshot missing: {snapshot}")
    files = required_cached_files(snapshot, shard_count=shard_count, weight_format=weight_format)
    info = api.model_info(model_id, revision=revision, files_metadata=True)
    if info.sha != revision or info.private:
        raise ValueError("Hub returned another or private dLLM revision")
    official = {item.rfilename: item for item in info.siblings}
    if {path.name for path in files} - set(official):
        raise ValueError("Cached snapshot has files absent from the pinned public Hub commit")
    checked = []
    for path in files:
        sibling = official[path.name]
        if not isinstance(sibling.size, int) or path.stat().st_size != sibling.size:
            raise ValueError(f"Pinned dLLM file size mismatch: {path.name}")
        sha256, git_sha1 = file_digests(path)
        if sibling.lfs is not None:
            if sha256 != sibling.lfs.sha256:
                raise ValueError(f"Official LFS SHA-256 mismatch: {path.name}")
            verification = "official_lfs_sha256"
        elif git_sha1 == sibling.blob_id:
            verification = "official_git_blob_sha1"
        else:
            raise ValueError(f"Official Git blob SHA-1 mismatch: {path.name}")
        checked.append({"path": path.name, "size": sibling.size,
                        "sha256": sha256, "verified_against": verification})
        print(f"verified {model} {path.name} {sibling.size}", flush=True)
    return {
        "verified": True, "model_id": model_id, "revision": revision,
        "model_path": str(snapshot.resolve()),
        "source": "existing_huggingface_cache_snapshot",
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
        "files": checked, "total_bytes": sum(item["size"] for item in checked),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=sorted(MODELS), required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    if args.receipt.exists():
        raise FileExistsError(f"Refusing to overwrite verified dLLM receipt: {args.receipt}")
    receipt = verify_snapshot(args.model, args.cache, HfApi())
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    temp = args.receipt.with_name(args.receipt.name + ".tmp")
    if temp.exists():
        raise FileExistsError(f"Stale dLLM receipt temp file: {temp}")
    with temp.open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temp.replace(args.receipt)
    print(json.dumps({"model": args.model, "receipt": str(args.receipt),
                      "files": len(receipt["files"]), "verified": True}, sort_keys=True))


if __name__ == "__main__":
    main()
