"""Paired native fixed-canvas dLLM S1: keep every site's own output.

Each 1,024-token window denoises all visible two-token masks together. The
original window planner owns every visible site exactly once; overlapping
windows never transfer a prediction. No site is propagated or repaired.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
import fcntl
import hashlib
import json
import os
from pathlib import Path
import random
import time
from typing import Any

from experiments.refineid_comparison.data import build_masked_windows
from .legacy_diffusion_s1 import NativeDiffusionBackend, NativeDiffusionConfig, extract_fixed_name
from .legacy_native_s1 import sha256_file
from .policy import valid_identifier
from .schema import CONTEXT_CHARS, MARKER, RenameTask, load_tasks, visible_code
from .verify_cached_legacy_diffusion import MODELS


VERSION = "s1-native-fixed2-multisite-windowed-v1"
MODE = "s1_native_multisite_independent_sites"
MASK_TOKENS = 2
NATIVE_CONTEXT = 1024
SEED = 42
DECODING = {"max_new_tokens": 1, "steps": 64, "temperature": 0.3,
            "top_p": 0.95, "alg": "entropy", "alg_temp": 0.0}
FIXED = frozenset(("dreamcoder-7b", "diffucoder-7b-base"))


def _digest(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _patch(code: str, names: list[str]) -> str:
    parts = code.split(MARKER)
    if len(parts) != len(names) + 1:
        raise ValueError("Site count and replacement count differ")
    return "".join(part + (names[i] if i < len(names) else "") for i, part in enumerate(parts))


def _window_seed(task_key: str, window_index: int) -> int:
    return int.from_bytes(hashlib.sha256(f"{SEED}:{task_key}:{window_index}".encode()).digest()[:4], "big")


def _site_metrics(task: RenameTask, predictions: list[str | None], errors: list[str | None]) -> dict[str, Any]:
    valid = [name is not None and valid_identifier(name, task.language) and error is None
             for name, error in zip(predictions, errors)]
    covered = sum(valid)
    complete = covered == task.sites
    names = [name for name in predictions if name is not None]
    return {
        "expected_sites": task.sites, "visible_sites": task.sites - errors.count("outside_common_visible_code"),
        "covered_sites": covered, "complete_site_coverage": complete,
        "consistent_nonempty": bool(complete and len(set(names)) == 1),
        "exact_sites": sum(ok and name == task.reference_name for ok, name in zip(valid, predictions)),
        "all_sites_exact": bool(complete and all(name == task.reference_name for name in predictions)),
        "error_sites": sum(error is not None for error in errors),
    }


def generate_sites(backend: NativeDiffusionBackend, *, task_key: str, language: str,
                   masked_visible_code: str, expected_sites: int) -> dict[str, Any]:
    """Call only the pinned model's native in-place sampler, once per window."""
    visible_sites = masked_visible_code.count(MARKER)
    if not 1 <= visible_sites <= expected_sites:
        raise ValueError("Visible source has an invalid number of original target markers")
    plan = build_masked_windows(masked_visible_code, backend.tokenizer,
                                mask_length=MASK_TOKENS, max_length=NATIVE_CONTEXT)
    if plan["occurrences"] != visible_sites:
        raise AssertionError("Native window planner lost a visible site")
    predictions: list[str | None] = [None] * expected_sites
    errors: list[str | None] = ["outside_common_visible_code"] * expected_sites
    raw_names: list[str | None] = [None] * expected_sites
    site_token_ids: list[list[int] | None] = [None] * expected_sites
    outputs: list[dict[str, Any]] = []
    owned_all: list[int] = []
    for window in plan["windows"]:
        idx = window["index"]
        owned = window["owned_site_indices"]
        owned_all.extend(owned)
        ids = window["input_ids"]
        seed = _window_seed(task_key, idx)
        random.seed(seed)
        backend.torch.manual_seed(seed)
        backend.torch.cuda.manual_seed_all(seed)
        started = time.perf_counter()
        batch = backend.torch.tensor([ids], dtype=backend.torch.long, device=backend.device)
        with backend.torch.inference_mode():
            result = backend.model.diffusion_generate(
                batch, attention_mask=backend.torch.ones_like(batch), **DECODING)
        sequence = result.sequences[0] if hasattr(result, "sequences") else result[0]
        generated = sequence.tolist() if hasattr(sequence, "tolist") else list(sequence)
        elapsed = time.perf_counter() - started
        mask_id = backend.tokenizer.mask_token_id
        context_unchanged = (len(generated) == len(ids) + 1 and
                             all(token == generated[pos] for pos, token in enumerate(ids)
                                 if token != mask_id))
        outputs.append({
            "window_index": idx, "owned_site_indices": owned,
            "visible_site_indices": window["visible_site_indices"],
            "input_ids_sha256": _digest(ids), "output_ids_sha256": _digest(generated),
            "output_ids": generated, "window_seed": seed,
            "input_tokens": len(ids), "output_tokens": len(generated),
            "context_unchanged": context_unchanged, "elapsed_s": elapsed,
        })
        if len(owned) != len(window["owned_token_spans"]):
            raise AssertionError("Native window owned-site/span mapping changed")
        for site, span in zip(owned, window["owned_token_spans"]):
            name, raw, error = extract_fixed_name(ids, generated, span, backend.tokenizer, language)
            predictions[site], raw_names[site], errors[site] = name, raw, error
            site_token_ids[site] = generated[span[0]:span[1]]
    if sorted(owned_all) != list(range(visible_sites)):
        raise AssertionError("Native window ownership did not partition all visible sites")
    return {
        "site_predictions": predictions, "site_errors": errors, "site_raw_content": raw_names,
        "site_token_ids": site_token_ids,
        "visible_sites": visible_sites, "window_plan": plan, "window_outputs": outputs,
        "native_sampler_calls": len(outputs), "gpu": backend.torch.cuda.get_device_name(backend.device),
    }


def run(model_slug: str, model_dir: Path, receipt: Path, receipt_sha: str,
        source: Path, dataset: str, language: str, output: Path, max_tasks: int | None) -> dict[str, Any]:
    if model_slug not in FIXED:
        raise ValueError("Paired multisite control supports the two pinned fixed-canvas dLLMs only")
    if output.exists():
        raise FileExistsError("Paired native multisite output is write-once")
    tasks = load_tasks(source, dataset=dataset, language=language)
    if max_tasks is not None:
        if (dataset != "stack_v3_refineid_dev_20260924" or language != "Java" or max_tasks != 2):
            raise ValueError("Only the declared first-two-row Java developer smoke can be sliced")
        tasks = tasks[:max_tasks]
    elif len(tasks) != 1000:
        raise ValueError("Formal frozen Stack-v3 cohort must contain exactly 1,000 tasks")
    model_id, revision, _, _ = MODELS[model_slug]
    cfg = NativeDiffusionConfig(model_slug, model_id, revision, str(model_dir), str(receipt), receipt_sha)
    output.mkdir(parents=True, exist_ok=False)
    run_path, predictions_path = output / "run.json", output / "predictions.jsonl"
    source_dir = Path(__file__).parent
    contract = {
        "schema_version": 1, "mode": MODE, "version": VERSION,
        "source_path": str(source.resolve()), "source_sha256": sha256_file(source),
        "dataset": dataset, "language": language, "task_keys": [task.key for task in tasks],
        "task_identity_sha256": _digest([(t.key, t.code_masked, t.reference_name) for t in tasks]),
        "common_visible_code_char_limit": CONTEXT_CHARS,
        "native_context_tokens": NATIVE_CONTEXT, "mask_tokens_per_site": MASK_TOKENS,
        "outside_common_crop_policy": "null site prediction; remain in denominator",
        "window_policy": "all visible 2-mask sites denoised per native window; each site owned once; no propagation",
        "model_slug": model_slug, "model_id": model_id, "revision": revision,
        "model_receipt_sha256": receipt_sha, "seed": SEED,
        "window_seed_policy": "sha256(seed,task_key,window_index) first 32 bits",
        "decoding": DECODING, "runtime_precision": "torch.bfloat16",
        "source_code_sha256": {name: sha256_file(source_dir / name) for name in (
            "legacy_diffusion_multisite_s1.py", "legacy_diffusion_s1.py", "legacy_native_s1.py",
            "schema.py", "policy.py")},
        "window_planner_sha256": sha256_file(source_dir.parent / "refineid_comparison/data.py"),
    }
    run_path.write_text(json.dumps(contract, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    backend = NativeDiffusionBackend(cfg)
    contract["runtime"] = {"torch": backend.torch.__version__,
                           "cuda_runtime": backend.torch.version.cuda,
                           "gpu": backend.torch.cuda.get_device_name(backend.device),
                           "mask_token_id": backend.tokenizer.mask_token_id}
    run_path.write_text(json.dumps(contract, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    records: list[dict[str, Any]] = []
    with (output / ".writer.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        with predictions_path.open("w", encoding="utf-8") as stream:
            for task in tasks:
                visible = visible_code(task)
                generated = generate_sites(backend, task_key=task.key, language=task.language,
                                           masked_visible_code=visible, expected_sites=task.sites)
                predictions, errors = generated["site_predictions"], generated["site_errors"]
                metrics = _site_metrics(task, predictions, errors)
                patch = (_patch(task.code_masked, [name for name in predictions if name is not None])
                         if metrics["complete_site_coverage"] else None)
                row = {
                    "task_key": task.key, "dataset": task.dataset, "language": task.language,
                    "id": task.task_id, "reference_name": task.reference_name,
                    "expected_sites": task.sites, "visible_code_sha256": hashlib.sha256(visible.encode()).hexdigest(),
                    **generated, "metrics": metrics,
                    "patch_sha256": hashlib.sha256(patch.encode()).hexdigest() if patch is not None else None,
                }
                stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
                stream.flush(); os.fsync(stream.fileno())
                records.append(row)
    summary = {
        "planned_tasks": len(tasks), "completed_tasks": len(records),
        "expected_sites": sum(task.sites for task in tasks),
        "covered_sites": sum(row["metrics"]["covered_sites"] for row in records),
        "all_sites_exact_tasks": sum(row["metrics"]["all_sites_exact"] for row in records),
        "consistent_nonempty_tasks": sum(row["metrics"]["consistent_nonempty"] for row in records),
        "tasks_with_site_error": sum(row["metrics"]["error_sites"] > 0 for row in records),
        "native_sampler_calls": sum(row["native_sampler_calls"] for row in records),
        "run_sha256": sha256_file(run_path), "predictions_sha256": sha256_file(predictions_path),
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-slug", required=True, choices=sorted(FIXED))
    parser.add_argument("--model-dir", required=True, type=Path)
    parser.add_argument("--model-receipt", required=True, type=Path)
    parser.add_argument("--model-receipt-sha256", required=True)
    parser.add_argument("--data", required=True, type=Path)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--language", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--max-tasks", type=int)
    args = parser.parse_args()
    print(json.dumps(run(args.model_slug, args.model_dir, args.model_receipt,
                         args.model_receipt_sha256, args.data, args.dataset,
                         args.language, args.output, args.max_tasks), sort_keys=True))


if __name__ == "__main__":
    main()
