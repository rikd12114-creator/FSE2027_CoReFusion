"""Application policy and reference recovery metrics for S1 tasks."""

from __future__ import annotations

import keyword
import re
from dataclasses import dataclass

from .schema import MARKER, RenameTask
from experiments.paper_revision_20260917.protocol import JAVA_RESERVED, id_part, id_start

_ECMASCRIPT_RESERVED = set((
    "await break case catch class const continue debugger default delete do else enum "
    "export extends false finally for function if import in instanceof new null return "
    "super switch this throw true try typeof var void while with yield let static implements "
    "interface package private protected public"
).split())
_COMMON_RESERVED = {
    "go": set(("break default func interface select case defer go map struct chan else goto "
               "package switch const fallthrough if range type continue for import return var").split()),
    "rust": set(("as async await break const continue crate dyn else enum extern false fn "
                 "for if impl in let loop match mod move mut pub ref return self Self static "
                 "struct super trait true type unsafe use where while").split()),
    "cpp": set(("alignas alignof and and_eq asm auto bitand bitor bool break case catch char "
                "char8_t char16_t char32_t class compl concept const consteval constexpr constinit "
                "const_cast continue co_await co_return co_yield decltype default delete do double "
                "dynamic_cast else enum explicit export extern false float for friend goto if inline "
                "int long mutable namespace new noexcept not not_eq nullptr operator or or_eq private "
                "protected public register reinterpret_cast requires return short signed sizeof "
                "static static_assert static_cast struct switch template this thread_local throw true "
                "try typedef typeid typename union unsigned using virtual void volatile wchar_t while "
                "xor xor_eq").split()),
}


def valid_identifier(name: str | None, language: str) -> bool:
    if not name or name in {"MASK", "HOLE", "__CF_INVALID__"}:
        return False
    lang = language.casefold()
    if lang in {"c++", "cxx", "cc"}:
        lang = "cpp"
    if lang == "java":
        return name not in JAVA_RESERVED and id_start(name[0]) and all(id_part(c) for c in name[1:])
    if lang == "python":
        return name.isidentifier() and not keyword.iskeyword(name)
    if lang in {"javascript", "typescript"}:
        return bool(re.fullmatch(r"[A-Za-z_$][A-Za-z0-9_$]*", name)) and name not in _ECMASCRIPT_RESERVED
    if lang in _COMMON_RESERVED:
        return bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name)) and name not in _COMMON_RESERVED[lang]
    raise ValueError(f"Unsupported language: {language}")


def parse_plain_identifier(raw: str, language: str) -> str | None:
    """A strict plain-text answer: no JSON/prose, no searching for a later name."""
    candidate = raw.strip()
    return candidate if valid_identifier(candidate, language) else None


@dataclass(frozen=True)
class AppliedRename:
    task_key: str
    predicted_name: str | None
    patched_code: str | None
    expected_sites: int
    predicted_sites: int
    valid_name: bool
    complete_site_coverage: bool
    consistent_nonempty: bool
    name_exact: bool
    all_sites_exact: bool
    error: str | None


def apply_once(task: RenameTask, name: str | None, *, error: str | None = None) -> AppliedRename:
    """Propagate one decision only to supplied sites; never search by spelling."""
    valid = valid_identifier(name, task.language) if name is not None else False
    if error is None and not valid:
        error = "invalid_identifier"
    patched = task.code_masked.replace(MARKER, name) if valid and not error else None
    predicted_sites = task.sites if patched is not None else 0
    exact = bool(patched is not None and name == task.reference_name)
    return AppliedRename(
        task_key=task.key,
        predicted_name=name,
        patched_code=patched,
        expected_sites=task.sites,
        predicted_sites=predicted_sites,
        valid_name=valid,
        complete_site_coverage=bool(patched is not None and MARKER not in patched),
        consistent_nonempty=bool(patched is not None),
        name_exact=exact,
        all_sites_exact=exact,
        error=error,
    )
