"""The S1 single-symbol task contract; references never enter model requests."""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
import sys

MARKER = "[MASK]"
CONTEXT_CHARS = 16000


@dataclass(frozen=True)
class RenameTask:
    dataset: str
    language: str
    task_id: str
    code_masked: str
    reference_name: str

    def __post_init__(self) -> None:
        if not all((self.dataset, self.language, self.task_id, self.reference_name)):
            raise ValueError("Empty task identity or reference")
        if MARKER not in self.code_masked:
            raise ValueError("Task has no target site")

    @property
    def key(self) -> str:
        return f"{self.dataset}:{self.language}:{self.task_id}"

    @property
    def sites(self) -> int:
        return self.code_masked.count(MARKER)


def load_tasks(csv_path: str | Path, *, dataset: str, language: str) -> list[RenameTask]:
    """Load the existing unheaded id,code_masked,target CSV without newline rewriting."""
    csv.field_size_limit(sys.maxsize)
    with Path(csv_path).open("r", encoding="utf-8", newline="") as stream:
        rows = list(csv.reader(stream))
    if not rows:
        raise ValueError("Empty task dataset")
    if any(len(row) != 3 for row in rows):
        raise ValueError("Expected three CSV columns")
    tasks = [RenameTask(dataset, language, *row) for row in rows]
    if len({task.key for task in tasks}) != len(tasks):
        raise ValueError("Duplicate task identity")
    return tasks


def visible_code(task: RenameTask, *, limit: int = CONTEXT_CHARS) -> str:
    """Deterministic first-site crop; all methods receive the same code chars."""
    if limit < len(MARKER):
        raise ValueError("Context limit is too short for target marker")
    code = task.code_masked
    if len(code) <= limit:
        return code
    site = code.index(MARKER)
    before = (limit - len(MARKER)) // 2
    start = max(0, min(site - before, len(code) - limit))
    snippet = code[start:start + limit]
    if MARKER not in snippet:
        raise AssertionError("Context crop omitted selected marker")
    return snippet


def build_messages(task: RenameTask, *, output_format: str = "plain") -> list[dict[str, str]]:
    """Use only the masked source; `reference_name` is deliberately inaccessible."""
    if output_format not in {"plain", "json"}:
        raise ValueError("Unsupported output format")
    output_rule = (
        "Return only the identifier spelling, with no explanation, quotes, code fence, or surrounding code."
        if output_format == "plain" else
        'Return a JSON object exactly like {"names":{"target":"identifier"}} with one replacement name.'
    )
    instruction = (
        f"Suggest one meaningful {task.language} identifier for the symbol marked "
        "[MASK] in the supplied code. Every [MASK] denotes the same symbol. "
        f"The rename will be applied at all marked sites. {output_rule}"
    )
    return [
        {"role": "system", "content": instruction},
        {"role": "user", "content": f"Masked {task.language} source:\n{visible_code(task)}"},
    ]
