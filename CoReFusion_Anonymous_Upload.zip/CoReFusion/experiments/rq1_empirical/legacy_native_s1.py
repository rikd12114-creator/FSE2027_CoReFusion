"""Native-FIM / small-CodeT5 S1 controls on the frozen seven-language tasks.

This is a separate model-input protocol from the chat S1 backend. It shares
task IDs, visible-source selection, one-name propagation and independent
scoring, while retaining each checkpoint's pretraining sentinel interface.
Historical predictions are never imported as fresh results.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import re
import time
from typing import Any

from experiments.paper_revision_20260917.protocol import FIM, id_part, id_start
from .policy import valid_identifier
from .runner import run_campaign
from .schema import MARKER, load_tasks

NATIVE_PROMPT_VERSION = "s1-native-fim-or-t5-first-hole-v2"
FIM_TYPES = frozenset(FIM)
SUPPORTED_ENGINES = frozenset(("fim", "t5"))


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


@dataclass(frozen=True)
class NativeConfig:
    model_id: str
    revision: str
    model_dir: str
    engine: str
    model_type: str | None
    native_context_tokens: int
    receipt_path: str
    receipt_sha256: str
    max_input_tokens: int = 8192
    max_new_tokens: int = 48
    seed: int = 42

    def __post_init__(self) -> None:
        if self.engine not in SUPPORTED_ENGINES:
            raise ValueError("Only native FIM and small sentinel-CodeT5 are supported here")
        if self.engine == "fim" and self.model_type not in FIM_TYPES:
            raise ValueError("Unknown native FIM tokenizer family")
        if self.engine == "t5" and self.model_type is not None:
            raise ValueError("T5 model_type must be omitted")
        if not self.model_id or len(self.revision) != 40 or not self.model_dir:
            raise ValueError("Pinned model ID, 40-character revision and snapshot required")
        if self.native_context_tokens < 128 or self.max_input_tokens < 128 or self.max_new_tokens < 1:
            raise ValueError("Invalid input/output token budget")
        if not self.receipt_path or len(self.receipt_sha256) != 64:
            raise ValueError("Verified model receipt and SHA-256 required")


def _message_source(messages: list[dict[str, str]]) -> tuple[str, str, str]:
    if len(messages) != 2 or messages[0].get("role") != "system" or messages[1].get("role") != "user":
        raise ValueError("Expected the S1 system/user task contract")
    instruction = messages[0]["content"]
    header, separator, source = messages[1]["content"].partition(" source:\n")
    if not separator or not header.startswith("Masked ") or source.count(MARKER) < 1:
        raise ValueError("Missing masked source or target marker")
    language = header.removeprefix("Masked ")
    if f"meaningful {language} identifier" not in instruction:
        raise ValueError("Language/instruction mismatch")
    return instruction, language, source


def _crop_ids(prefix: list[int], suffix: list[int], budget: int) -> tuple[list[int], list[int]]:
    if budget < 1:
        raise ValueError("No code-token capacity after native wrapper")
    left = min(len(prefix), budget // 2)
    right = min(len(suffix), budget - left)
    left = min(len(prefix), budget - right)
    return prefix[-left:] if left else [], suffix[:right]


def build_native_input(
    messages: list[dict[str, str]], tokenizer: Any, *, engine: str,
    model_type: str | None, input_budget: int,
) -> dict[str, Any]:
    """Keep a balanced first-site token neighborhood; never silently truncate."""
    instruction, language, source = _message_source(messages)
    prefix, suffix = source.split(MARKER, 1)
    comment = "# " if language == "Python" else "// "
    # The FIM family in the 9/17 experiment accepted a comment instruction.
    # The original CodeT5 implementation used sentinel-only source. That
    # native input is retained here; neither family has chat roles.
    instruction_ids = tokenizer.encode(comment + instruction + "\n", add_special_tokens=False) if engine == "fim" else []
    p = tokenizer.encode(prefix, add_special_tokens=False)
    s = tokenizer.encode(suffix, add_special_tokens=False)
    if engine == "fim":
        if model_type not in FIM:
            raise ValueError("Unsupported FIM family")
        special = [tokenizer.convert_tokens_to_ids(token) for token in FIM[model_type]]
        if any(item is None or item == tokenizer.unk_token_id for item in special):
            raise ValueError("Pinned tokenizer lacks a native FIM sentinel")
        bos = ([tokenizer.bos_token_id] if model_type in {"codellama", "deepseek", "codegemma"} else [])
        if any(item is None for item in bos):
            raise ValueError("Native BOS token missing")
        fixed = len(bos) + len(instruction_ids) + 3
        left, right = _crop_ids(p, s, input_budget - fixed)
        ids = bos + [special[0]] + instruction_ids + left + [special[1]] + right + [special[2]]
    elif engine == "t5":
        sentinel = tokenizer.convert_tokens_to_ids("<extra_id_0>")
        if sentinel is None or sentinel == tokenizer.unk_token_id:
            raise ValueError("Pinned CodeT5 tokenizer lacks <extra_id_0>")
        fixed = len(instruction_ids) + 1 + int(tokenizer.eos_token_id is not None)
        left, right = _crop_ids(p, s, input_budget - fixed)
        ids = instruction_ids + left + [sentinel] + right
        if tokenizer.eos_token_id is not None:
            ids.append(tokenizer.eos_token_id)
    else:
        raise ValueError("CodeT5p prefix-only and dLLM require separate native interfaces")
    if len(ids) > input_budget:
        raise AssertionError("Native prompt construction exceeded budget")
    return {
        "input_ids": ids,
        "language": language,
        "instruction_visible_to_model": bool(instruction_ids),
        "visible_target_markers": 1 + tokenizer.decode(right, skip_special_tokens=False).count(MARKER),
        "source_target_markers_in_char_crop": source.count(MARKER),
        "prefix_tokens_original": len(p), "suffix_tokens_original": len(s),
        "prefix_tokens_retained": len(left), "suffix_tokens_retained": len(right),
        "native_input_sha256": hashlib.sha256(json.dumps(ids, separators=(",", ":")).encode()).hexdigest(),
    }


def _anchored_name(text: str, language: str) -> str | None:
    raw = text.lstrip(" \t\r\n\f")
    if not raw or raw[0] == "\ufffd":
        return None
    if language in {"JavaScript", "TypeScript"}:
        match = re.match(r"[A-Za-z_$][A-Za-z0-9_$]*", raw)
        candidate = match.group(0) if match else None
    elif language in {"Go", "Rust", "C++"}:
        match = re.match(r"[A-Za-z_][A-Za-z0-9_]*", raw)
        candidate = match.group(0) if match else None
    else:
        if not id_start(raw[0]):
            return None
        end = 1
        while end < len(raw) and id_part(raw[end]):
            end += 1
        candidate = raw[:end]
    return candidate if candidate and valid_identifier(candidate, language) else None


def parse_native_output(raw: str, *, engine: str, language: str) -> str | None:
    if engine == "t5":
        marker = "<extra_id_0>"
        if marker not in raw:
            return None
        raw = raw.split(marker, 1)[1]
        raw = re.split(r"<extra_id_\d+>|</s>|<pad>", raw, maxsplit=1)[0]
    return _anchored_name(raw, language)


def name_span_is_complete(raw: str, *, engine: str, language: str) -> bool:
    """A first name may be complete even if later decoder text hits its cap."""
    if engine == "t5":
        if "<extra_id_0>" not in raw:
            return False
        span = raw.split("<extra_id_0>", 1)[1]
        return bool(re.search(r"<extra_id_\d+>|</s>|<pad>", span))
    name = _anchored_name(raw, language)
    if name is None:
        return False
    start = len(raw) - len(raw.lstrip(" \t\r\n\f"))
    return len(raw) > start + len(name)


class NativeBackend:
    def __init__(self, config: NativeConfig):
        import torch
        from transformers import AutoModelForCausalLM, AutoModelForSeq2SeqLM, AutoTokenizer

        snapshot = Path(config.model_dir).resolve()
        if not snapshot.is_dir() or snapshot.name != config.revision or not (snapshot / "config.json").is_file():
            raise ValueError("Snapshot path must be the pinned revision directory")
        if sha256_file(config.receipt_path) != config.receipt_sha256:
            raise ValueError("Verified model receipt SHA-256 mismatch")
        receipt = json.loads(Path(config.receipt_path).read_text(encoding="utf-8"))
        if (receipt.get("verified") is not True or receipt.get("model_id") != config.model_id
                or receipt.get("revision") != config.revision
                or Path(receipt.get("model_path", "")).resolve() != snapshot):
            raise ValueError("Verified model receipt identity mismatch")
        if not isinstance(receipt.get("files"), list) or not receipt["files"]:
            raise ValueError("Verified model receipt has no file inventory")
        for item in receipt["files"]:
            file = snapshot / item["path"]
            if not file.is_file() or file.stat().st_size != item["size"]:
                raise ValueError("Pinned model file missing or changed size")
        if not torch.cuda.is_available():
            raise RuntimeError("Native legacy S1 requires a CUDA GPU")
        self.config = config
        self.torch = torch
        self.tokenizer = AutoTokenizer.from_pretrained(snapshot, local_files_only=True, trust_remote_code=False)
        klass = AutoModelForCausalLM if config.engine == "fim" else AutoModelForSeq2SeqLM
        self.model = klass.from_pretrained(
            snapshot, local_files_only=True, trust_remote_code=False,
            dtype=torch.bfloat16, device_map="auto",
        ).eval()
        placements = set(str(device) for device in getattr(self.model, "hf_device_map", {}).values())
        if any(value in {"cpu", "disk"} for value in placements):
            raise RuntimeError("Pinned model offloaded to CPU/disk")
        self.device = next(self.model.parameters()).device
        torch.manual_seed(config.seed)
        torch.cuda.manual_seed_all(config.seed)

    def decoding_kwargs(self) -> dict[str, Any]:
        """Greedy legacy default; sampled reruns override this isolated hook."""
        return {"do_sample": False}

    def generate(self, messages: list[dict[str, str]], *, expected_group_ids: list[str], request_id: str) -> dict[str, Any]:
        if expected_group_ids != ["target"]:
            raise ValueError("Native S1 backend accepts one group only")
        started = time.perf_counter()
        config = self.config
        budget = min(config.max_input_tokens, config.native_context_tokens)
        if config.engine == "fim":
            budget -= config.max_new_tokens
        try:
            prompt = build_native_input(messages, self.tokenizer, engine=config.engine,
                                        model_type=config.model_type, input_budget=budget)
        except ValueError as exc:
            return {"status": "error", "names": {}, "content": None,
                    "error": f"native_prompt_error:{exc}", "request_id": request_id,
                    "elapsed_s": time.perf_counter() - started}
        input_ids = self.torch.tensor([prompt["input_ids"]], device=self.device)
        attention_mask = self.torch.ones_like(input_ids)
        eos = [self.tokenizer.eos_token_id] if self.tokenizer.eos_token_id is not None else []
        if config.engine == "fim":
            for spelling in ("<|end_of_middle|>", "<|endoftext|>", "<file_sep>", "<｜end▁of▁sentence｜>"):
                item = self.tokenizer.convert_tokens_to_ids(spelling)
                if item is not None and item != self.tokenizer.unk_token_id and item not in eos:
                    eos.append(item)
        generation = {
            "max_new_tokens": config.max_new_tokens, **self.decoding_kwargs(),
            "pad_token_id": self.tokenizer.pad_token_id if self.tokenizer.pad_token_id is not None else self.tokenizer.eos_token_id,
        }
        if eos:
            generation["eos_token_id"] = eos
        with self.torch.inference_mode():
            output = self.model.generate(input_ids=input_ids, attention_mask=attention_mask, **generation)
        if config.engine == "fim":
            new_ids = output[0, len(prompt["input_ids"]):].tolist()
            raw = self.tokenizer.decode(new_ids, skip_special_tokens=False, clean_up_tokenization_spaces=False)
            name_source = self.tokenizer.decode(new_ids, skip_special_tokens=True, clean_up_tokenization_spaces=False)
        else:
            all_ids = output[0].tolist()
            new_ids = all_ids[1:]
            raw = self.tokenizer.decode(all_ids, skip_special_tokens=False, clean_up_tokenization_spaces=False)
            name_source = raw
        truncated = (len(new_ids) >= config.max_new_tokens and
                     (not new_ids or new_ids[-1] not in eos) and
                     not name_span_is_complete(name_source, engine=config.engine, language=prompt["language"]))
        name = None if truncated else parse_native_output(name_source, engine=config.engine, language=prompt["language"])
        return {
            "status": "ok" if name else "error", "names": {"target": name} if name else {},
            "content": raw, "error": None if name else ("truncated_generation" if truncated else "invalid_native_name_output"),
            "model": config.model_id, "revision": config.revision, "engine": config.engine,
            "native_prompt_version": NATIVE_PROMPT_VERSION,
            "native_input_sha256": prompt["native_input_sha256"],
            "instruction_visible_to_model": prompt["instruction_visible_to_model"],
            "input_tokens": len(prompt["input_ids"]), "output_tokens": len(new_ids),
            "source_target_markers_in_char_crop": prompt["source_target_markers_in_char_crop"],
            "visible_target_markers": prompt["visible_target_markers"],
            "prefix_tokens_original": prompt["prefix_tokens_original"],
            "suffix_tokens_original": prompt["suffix_tokens_original"],
            "prefix_tokens_retained": prompt["prefix_tokens_retained"],
            "suffix_tokens_retained": prompt["suffix_tokens_retained"],
            "request_id": request_id, "elapsed_s": time.perf_counter() - started,
            "gpu": self.torch.cuda.get_device_name(self.device),
        }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--language", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--model-id", required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--model-dir", required=True)
    parser.add_argument("--engine", choices=sorted(SUPPORTED_ENGINES), required=True)
    parser.add_argument("--model-type", choices=sorted(FIM_TYPES))
    parser.add_argument("--native-context-tokens", type=int, required=True)
    parser.add_argument("--model-receipt", required=True)
    parser.add_argument("--model-receipt-sha256", required=True)
    parser.add_argument("--max-input-tokens", type=int, default=8192)
    parser.add_argument("--max-new-tokens", type=int, default=48)
    parser.add_argument("--max-tasks", type=int)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.max_tasks is not None and args.max_tasks < 1:
        parser.error("--max-tasks must be positive")
    tasks = load_tasks(args.data, dataset=args.dataset, language=args.language)
    if args.max_tasks is not None:
        tasks = tasks[:args.max_tasks]
    config = NativeConfig(
        model_id=args.model_id, revision=args.revision, model_dir=args.model_dir,
        engine=args.engine, model_type=args.model_type,
        native_context_tokens=args.native_context_tokens,
        receipt_path=args.model_receipt, receipt_sha256=args.model_receipt_sha256,
        max_input_tokens=args.max_input_tokens, max_new_tokens=args.max_new_tokens,
    )
    backend = NativeBackend(config)
    spec = {**asdict(config), "output_format": "plain",
            "actual_model_prompt_version": NATIVE_PROMPT_VERSION,
            "runner_prompt_version_meaning": "S1 task-message envelope, not the model's native token sequence",
            "native_input_policy": "first-marker native FIM or T5 sentinel; balanced tokenizer-token crop; one generation then supplied-site propagation",
            "decoding": {"do_sample": False, "temperature": None, "top_p": None},
            "instruction_policy": "FIM code comment; CodeT5 sentinel-only source; no chat roles",
            "extraction": "anchored initial identifier from native span; no regex search through prose",
            "runtime": {"torch": backend.torch.__version__,
                        "gpu": backend.torch.cuda.get_device_name(backend.device)}}
    result = run_campaign(tasks, backend, args.output, dataset_file=args.data,
                          backend_spec=spec, resume=args.resume)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
