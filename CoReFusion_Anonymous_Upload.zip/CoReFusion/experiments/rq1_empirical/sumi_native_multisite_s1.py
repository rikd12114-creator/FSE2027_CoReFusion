"""Sumi native uniform-diffusion all-site Java dev2, with frozen source anchors.

This development-only runner leaves four random-initialized native canvas tokens
at each visible identifier site. Every other original token is passed through
Sumi's ``frozen`` anchor interface, and the original sampler jointly denoises
the sites with full bidirectional attention. No first-site propagation or repair.
"""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import time
from pathlib import Path
from typing import Any

from experiments.refineid_comparison.data import build_masked_windows

from .legacy_native_s1 import sha256_file
from .policy import valid_identifier
from .schema import CONTEXT_CHARS, MARKER, RenameTask, load_tasks, visible_code

VERSION = "s1-native-sumi-fixed4-multisite-windowed-dev-v1"
MODE = "s1_native_sumi_multisite_independent_sites"
MODEL_ID = "tohoku-nlp/sumi-7b"
REVISION = "0d20f7becf84340b8a8d71a8dda577a502a5c8dd"
MODEL_LFS_SHA = "f7a548e291a472e17b3888dfb663df2b1da0bc8d6746853f3a2729b7fb4229d6"
MODEL_WEIGHT_BYTES = 15_535_125_952
NATIVE_CONTEXT = 2048
SITE_WIDTH = 4
SEED = 42
DECODING = {
    "sampler": "adaptive", "num_denoising_steps": 64,
    "temperature": 0.7, "tokens_per_step": 1,
    "anchor_eosbos": False, "trim_at_eos": False,
}


def digest(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def window_seed(task_key: str, window_index: int) -> int:
    return int.from_bytes(hashlib.sha256(
        f"{SEED}:{task_key}:{window_index}".encode()).digest()[:4], "big")


def frozen_canvas(window: dict, *, bos_id: int) -> tuple[list[tuple[int, int]], int]:
    """Map every non-site token to a native frozen anchor, with no reference text."""
    ids = window["input_ids"]
    if not ids or ids[0] != bos_id or len(ids) > NATIVE_CONTEXT:
        raise ValueError("Sumi window has an invalid native BOS/context budget")
    spans = window["visible_token_spans"]
    if len(spans) != len(window["visible_site_indices"]):
        raise ValueError("Sumi site/window span count mismatch")
    site_positions = set()
    for a, b in spans:
        if not 1 <= a < b <= len(ids) or b - a != SITE_WIDTH:
            raise ValueError("Sumi native site has an invalid fixed-width span")
        if any(ids[pos] is not None for pos in range(a, b)):
            raise ValueError("Sumi native site contains context instead of a random canvas")
        if any(pos in site_positions for pos in range(a, b)):
            raise ValueError("Sumi native sites overlap")
        site_positions.update(range(a, b))
    if not site_positions or any((ids[pos] is None) != (pos in site_positions)
                                 for pos in range(1, len(ids))):
        raise ValueError("Sumi native frozen/denoise partition is incomplete")
    anchors = [(pos, token) for pos, token in enumerate(ids[1:], 1)
               if pos not in site_positions]
    if len(anchors) + len(site_positions) + 1 != len(ids):
        raise AssertionError("Sumi frozen canvas dropped a position")
    return anchors, len(ids)


def site_metrics(task: RenameTask, names: list[str | None],
                 errors: list[str | None]) -> dict[str, Any]:
    valid = [name is not None and valid_identifier(name, task.language) and error is None
             for name, error in zip(names, errors)]
    covered = sum(valid)
    complete = covered == task.sites
    return {
        "expected_sites": task.sites,
        "visible_sites": task.sites - errors.count("outside_common_visible_code"),
        "covered_sites": covered, "complete_site_coverage": complete,
        "consistent_nonempty": bool(complete and len(set(names)) == 1),
        "exact_sites": sum(ok and name == task.reference_name
                           for ok, name in zip(valid, names)),
        "all_sites_exact": bool(complete and all(name == task.reference_name for name in names)),
        "error_sites": sum(error is not None for error in errors),
    }


def _patch(code: str, names: list[str]) -> str:
    parts = code.split(MARKER)
    if len(parts) != len(names) + 1:
        raise ValueError("Unrepaired patch has unexpected site count")
    return parts[0] + "".join(name + part for name, part in zip(names, parts[1:]))


def generate_sites(model: Any, tokenizer: Any, torch: Any, *, task: RenameTask) -> dict[str, Any]:
    visible = visible_code(task)
    visible_sites = visible.count(MARKER)
    if not 1 <= visible_sites <= task.sites:
        raise ValueError("Sumi visible code has an invalid target-site count")
    if tokenizer.mask_token_id is not None:
        raise ValueError("Pinned Sumi uses uniform random canvases, not a mask token")
    plan = build_masked_windows(visible, tokenizer, mask_length=SITE_WIDTH,
                                max_length=NATIVE_CONTEXT)
    if plan["occurrences"] != visible_sites:
        raise AssertionError("Sumi native window planner lost a visible site")
    names: list[str | None] = [None] * task.sites
    errors: list[str | None] = ["outside_common_visible_code"] * task.sites
    raw_names: list[str | None] = [None] * task.sites
    site_token_ids: list[list[int] | None] = [None] * task.sites
    site_window_indices: list[int | None] = [None] * task.sites
    outputs: list[dict[str, Any]] = []
    owned_all: list[int] = []
    for window in plan["windows"]:
        index = window["index"]
        anchors, denoise_end = frozen_canvas(window, bos_id=tokenizer.bos_token_id)
        seed = window_seed(task.key, index)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        prompt = torch.tensor([[tokenizer.bos_token_id]], dtype=torch.long, device="cuda")
        torch.cuda.reset_peak_memory_stats()
        started = time.perf_counter()
        with torch.inference_mode():
            result = model.generate(
                input_ids=prompt, max_new_tokens=denoise_end - 1,
                canvas_length=NATIVE_CONTEXT, frozen=anchors,
                denoise_end=[denoise_end], seed=seed, **DECODING,
            )
        elapsed = time.perf_counter() - started
        canvas_tensor = result.canvas
        if canvas_tensor is None or canvas_tensor.shape != (1, NATIVE_CONTEXT):
            raise ValueError("Sumi original sampler omitted its full native canvas")
        canvas = [int(value) for value in canvas_tensor[0].tolist()]
        context_unchanged = (canvas[0] == tokenizer.bos_token_id
                             and all(canvas[pos] == token for pos, token in anchors))
        if not context_unchanged:
            raise ValueError("Sumi original sampler changed frozen source context")
        outputs.append({
            "window_index": index, "visible_site_indices": window["visible_site_indices"],
            "owned_site_indices": window["owned_site_indices"],
            "frozen_anchors": [[pos, token] for pos, token in anchors],
            "frozen_anchors_sha256": digest(anchors),
            "denoise_end": denoise_end, "canvas_length": NATIVE_CONTEXT,
            "canvas_ids": canvas, "canvas_sha256": digest(canvas),
            "context_unchanged": context_unchanged,
            "window_seed": seed, "elapsed_s": elapsed,
            "native_forward_calls": DECODING["num_denoising_steps"],
            "gpu_peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        })
        offsets = {site: n for n, site in enumerate(window["visible_site_indices"])}
        for site in window["owned_site_indices"]:
            site_window_indices[site] = index
            a, b = window["visible_token_spans"][offsets[site]]
            token_ids = canvas[a:b]
            site_token_ids[site] = token_ids
            if any(token in tokenizer.all_special_ids for token in token_ids):
                raw_names[site] = tokenizer.decode(token_ids, skip_special_tokens=False,
                                                   clean_up_tokenization_spaces=False)
                errors[site] = "special_native_site_output"
                continue
            raw = tokenizer.decode(token_ids, skip_special_tokens=False,
                                   clean_up_tokenization_spaces=False)
            raw_names[site] = raw
            candidate = raw.strip()
            if valid_identifier(candidate, task.language):
                names[site], errors[site] = candidate, None
            else:
                errors[site] = "invalid_native_name_output"
        owned_all.extend(window["owned_site_indices"])
    if sorted(owned_all) != list(range(visible_sites)):
        raise AssertionError("Sumi native windows did not own each visible site exactly once")
    return {
        "site_predictions": names, "site_errors": errors,
        "site_raw_content": raw_names, "site_token_ids": site_token_ids,
        "site_window_indices": site_window_indices,
        "visible_sites": visible_sites, "window_plan": plan, "window_outputs": outputs,
        "native_sampler_calls": len(outputs), "gpu": torch.cuda.get_device_name(0),
    }


def run(model_dir: Path, receipt: Path, receipt_sha: str,
        source: Path, output: Path) -> dict[str, Any]:
    import torch
    import transformers
    from transformers import AutoModelForMaskGeneration, AutoTokenizer

    if output.exists():
        raise FileExistsError("Sumi native multisite dev output is write-once")
    if transformers.__version__ != "5.8.1":
        raise ValueError("Sumi native model requires isolated Transformers 5.8.1")
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise ValueError("Exactly one GPU is required for Sumi native dev")
    if "A40" not in torch.cuda.get_device_name(0) or not torch.cuda.is_bf16_supported():
        raise ValueError("Sumi dev protocol requires one BF16-capable A40")
    if sha256_file(receipt) != receipt_sha:
        raise ValueError("Sumi pinned model receipt SHA mismatch")
    info = json.loads(receipt.read_text(encoding="utf-8"))
    if (info.get("verified") is not True or info.get("model_id") != MODEL_ID
            or info.get("revision") != REVISION
            or Path(info.get("model_dir", "")).resolve() != model_dir.resolve()
            or info.get("weight_bytes") != MODEL_WEIGHT_BYTES
            or info.get("weight_sha256") != MODEL_LFS_SHA):
        raise ValueError("Sumi pinned model identity/weight receipt mismatch")
    if sha256_file(model_dir / "model.safetensors") != MODEL_LFS_SHA:
        raise ValueError("Sumi weight SHA mismatch before loading")
    tasks = load_tasks(source, dataset="stack_v3_refineid_dev_20260924", language="Java")[:2]
    if len(tasks) != 2 or [task.task_id for task in tasks] != ["0", "1"]:
        raise ValueError("Sumi dev smoke requires the first two independent Java holdout tasks")
    output.mkdir(parents=True, exist_ok=False)
    code_dir = Path(__file__).parent
    contract = {
        "schema_version": 1, "mode": MODE, "version": VERSION,
        "source_path": str(source.resolve()), "source_sha256": sha256_file(source),
        "dataset": "stack_v3_refineid_dev_20260924", "language": "Java",
        "task_keys": [task.key for task in tasks],
        "task_identity_sha256": digest([(t.key, t.code_masked, t.reference_name) for t in tasks]),
        "common_visible_code_char_limit": CONTEXT_CHARS,
        "native_context_tokens": NATIVE_CONTEXT, "site_width_tokens": SITE_WIDTH,
        "window_policy": "all visible fixed-four random slots jointly denoised; exact frozen source anchors; each site owned once",
        "outside_common_crop_policy": "null site prediction; remain in denominator",
        "model_id": MODEL_ID, "revision": REVISION, "model_receipt_sha256": receipt_sha,
        "model_weight_sha256": MODEL_LFS_SHA, "seed": SEED,
        "window_seed_policy": "sha256(seed,task_key,window_index) first 32 bits",
        "decoding": DECODING, "runtime_precision": "torch.bfloat16",
        "source_code_sha256": {name: sha256_file(code_dir / name) for name in (
            "sumi_native_multisite_s1.py", "schema.py", "policy.py")},
        "window_planner_sha256": sha256_file(code_dir.parent / "refineid_comparison/data.py"),
    }
    (output / "run.json").write_text(json.dumps(contract, indent=2, sort_keys=True) + "\n")
    tokenizer = AutoTokenizer.from_pretrained(model_dir, trust_remote_code=True,
                                               local_files_only=True)
    model = AutoModelForMaskGeneration.from_pretrained(
        model_dir, trust_remote_code=True, local_files_only=True,
        dtype=torch.bfloat16).to("cuda").eval()
    contract["runtime"] = {
        "gpu": torch.cuda.get_device_name(0), "gpu_memory_bytes": torch.cuda.get_device_properties(0).total_memory,
        "torch": torch.__version__, "cuda_runtime": torch.version.cuda,
        "transformers": transformers.__version__, "bos_token_id": tokenizer.bos_token_id,
        "eos_token_id": tokenizer.eos_token_id, "pad_token_id": tokenizer.pad_token_id,
        "mask_token_id": tokenizer.mask_token_id,
    }
    (output / "run.json").write_text(json.dumps(contract, indent=2, sort_keys=True) + "\n")
    rows = []
    with (output / ".writer.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        with (output / "predictions.jsonl").open("w", encoding="utf-8") as stream:
            for task in tasks:
                generated = generate_sites(model, tokenizer, torch, task=task)
                metrics = site_metrics(task, generated["site_predictions"], generated["site_errors"])
                patch = (_patch(task.code_masked, [name for name in generated["site_predictions"]
                                                   if name is not None])
                         if metrics["complete_site_coverage"] else None)
                row = {
                    "task_key": task.key, "dataset": task.dataset, "language": task.language,
                    "id": task.task_id, "reference_name": task.reference_name,
                    "expected_sites": task.sites,
                    "visible_code_sha256": hashlib.sha256(visible_code(task).encode()).hexdigest(),
                    **generated, "metrics": metrics,
                    "patch_sha256": hashlib.sha256(patch.encode()).hexdigest() if patch is not None else None,
                }
                stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
                stream.flush(); os.fsync(stream.fileno())
                rows.append(row)
    summary = {
        "planned_tasks": 2, "completed_tasks": len(rows),
        "expected_sites": sum(task.sites for task in tasks),
        "covered_sites": sum(row["metrics"]["covered_sites"] for row in rows),
        "exact_sites": sum(row["metrics"]["exact_sites"] for row in rows),
        "all_sites_exact_tasks": sum(row["metrics"]["all_sites_exact"] for row in rows),
        "consistent_nonempty_tasks": sum(row["metrics"]["consistent_nonempty"] for row in rows),
        "tasks_with_site_error": sum(row["metrics"]["error_sites"] > 0 for row in rows),
        "native_sampler_calls": sum(row["native_sampler_calls"] for row in rows),
        "native_forward_calls": sum(w["native_forward_calls"]
                                    for row in rows for w in row["window_outputs"]),
        "run_sha256": sha256_file(output / "run.json"),
        "predictions_sha256": sha256_file(output / "predictions.jsonl"),
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-dir", required=True, type=Path)
    parser.add_argument("--model-receipt", required=True, type=Path)
    parser.add_argument("--model-receipt-sha256", required=True)
    parser.add_argument("--data", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(run(args.model_dir, args.model_receipt,
                         args.model_receipt_sha256, args.data, args.output), sort_keys=True))


if __name__ == "__main__":
    main()
