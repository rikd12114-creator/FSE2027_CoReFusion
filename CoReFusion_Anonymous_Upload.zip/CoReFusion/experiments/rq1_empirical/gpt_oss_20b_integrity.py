"""Verify the pinned, selectively downloaded gpt-oss-20b checkpoint.

The manifest records Hugging Face's Git blob IDs and LFS SHA-256 digests at
one immutable revision. A completed Slurm download alone is not a receipt.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


MODEL_ID = "openai/gpt-oss-20b"
REVISION = "6cee5e81ee83917806bbde320786a8fb61efebee"


def _digests(path: Path) -> tuple[int, str, str]:
    size = path.stat().st_size
    sha256 = hashlib.sha256()
    git_sha1 = hashlib.sha1(f"blob {size}\0".encode("ascii"))
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            sha256.update(chunk)
            git_sha1.update(chunk)
    return size, sha256.hexdigest(), git_sha1.hexdigest()


def verify(manifest_path: Path, model_dir: Path) -> dict:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("model_id") != MODEL_ID or manifest.get("revision") != REVISION:
        raise ValueError("Official checkpoint identity changed")
    files = manifest.get("files")
    if not isinstance(files, list) or len(files) != 13:
        raise ValueError("Expected exactly 13 selected official files")
    names = [row.get("path") for row in files]
    if len(set(names)) != len(names) or names != sorted(names):
        raise ValueError("Duplicate or unsorted official filenames")
    observed = []
    for row in files:
        name = row["path"]
        path = model_dir / name
        if path.is_symlink() or not path.is_file() or path.resolve().parent != model_dir.resolve():
            raise ValueError(f"Missing, linked, or nested checkpoint file: {name}")
        size, sha256, git_sha1 = _digests(path)
        if size != row["size"]:
            raise ValueError(f"Official file size mismatch: {name}")
        expected_lfs = row.get("lfs_sha256")
        expected_git = row.get("git_blob_sha1")
        if expected_lfs is not None and sha256 != expected_lfs:
            raise ValueError(f"Official LFS SHA-256 mismatch: {name}")
        if expected_git is not None and git_sha1 != expected_git:
            raise ValueError(f"Official Git blob mismatch: {name}")
        if (expected_lfs is None) == (expected_git is None):
            raise ValueError(f"Exactly one official digest is required: {name}")
        observed.append({"path": name, "size": size, "sha256": sha256,
                         "git_blob_sha1": git_sha1 if expected_git is not None else None})
    index = json.loads((model_dir / "model.safetensors.index.json").read_text(encoding="utf-8"))
    shards = {value for value in index["weight_map"].values()}
    expected_shards = {name for name in names if name.endswith(".safetensors")}
    if shards != expected_shards:
        raise ValueError("Model index does not match selected weight shards")
    return {"model_id": MODEL_ID, "revision": REVISION,
            "model_path": str(model_dir.resolve()), "verified": True,
            "official_manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
            "total_bytes": sum(row["size"] for row in observed),
            "files": observed, "status": "verified"}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--official-manifest", type=Path, required=True)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.official_manifest, args.model_dir)
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    with args.receipt.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "files": len(result["files"]),
                      "total_bytes": result["total_bytes"], "receipt": str(args.receipt)}))


if __name__ == "__main__":
    main()
