"""Native fixed/variable-canvas dLLM controls for the frozen Stack-v3 S1 task.

The model sees code and native mask tokens, not the AR chat instruction. A
single native sampler call yields one first-site name; the shared S1 policy
then applies that name at every supplied site. Gold names never enter input.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import random
import time
from typing import Any

from experiments.refineid_comparison.data import build_masked_windows
from .legacy_native_s1 import _crop_ids, _message_source, sha256_file
from .policy import valid_identifier
from .runner import run_campaign
from .schema import MARKER, load_tasks
from .verify_cached_legacy_diffusion import MODELS


FIXED_PROMPT_VERSION = "s1-native-fixed2-first-window-v1"
DREAMON_PROMPT_VERSION = "s1-native-dreamon-first-canvas-v1"
FIXED_MODELS = frozenset(("dreamcoder-7b", "diffucoder-7b-base"))


def input_digest(ids: list[int]) -> str:
    return hashlib.sha256(json.dumps(ids, separators=(",", ":")).encode("ascii")).hexdigest()


def _first_source(messages: list[dict[str, str]]) -> tuple[str, str]:
    _instruction, language, source = _message_source(messages)
    return language, source


def build_fixed_input(messages: list[dict[str, str]], tokenizer: Any) -> dict[str, Any]:
    """Use the original gold-free fixed-2 window planner, but call it once."""
    language, source = _first_source(messages)
    plan = build_masked_windows(source, tokenizer, mask_length=2, max_length=1024)
    window = plan["windows"][0]
    if 0 not in window["owned_site_indices"]:
        raise AssertionError("First native fixed window lost the first target site")
    site_offset = window["owned_site_indices"].index(0)
    span = window["owned_token_spans"][site_offset]
    return {
        "language": language, "input_ids": window["input_ids"],
        "first_span": span, "visible_target_markers": len(window["visible_site_indices"]),
        "source_target_markers_in_char_crop": source.count(MARKER),
        "native_input_sha256": input_digest(window["input_ids"]),
        "window_plan_sha256": plan["input_plan_sha256"],
        "first_window_content_start": window["content_token_start"],
        "first_window_content_end": window["content_token_end"],
        "full_file_canvas_tokens": plan["full_file_canvas_tokens"],
    }


def build_dreamon_input(
    messages: list[dict[str, str]], tokenizer: Any, *, native_context_tokens: int = 2048,
    max_canvas_tokens: int = 64,
) -> dict[str, Any]:
    """A single variable canvas at the first site, with a native token crop."""
    language, source = _first_source(messages)
    prefix, suffix = source.split(MARKER, 1)
    if any(tokenizer.convert_tokens_to_ids("<|mask|>") == item for item in (None, tokenizer.unk_token_id)):
        raise ValueError("DreamOn tokenizer lacks its native mask token")
    if tokenizer.bos_token_id is None or tokenizer.eos_token_id is None or tokenizer.mask_token_id is None:
        raise ValueError("DreamOn tokenizer lacks BOS/EOS/mask IDs")
    prefix_ids = tokenizer.encode(prefix, add_special_tokens=False)
    suffix_ids = tokenizer.encode(suffix, add_special_tokens=False)
    specials = set(tokenizer.all_special_ids)
    if any(token in specials for token in prefix_ids + suffix_ids):
        raise ValueError("Observed source contains a native special token")
    mask_tokens = 4
    code_budget = native_context_tokens - max_canvas_tokens - mask_tokens - 2
    left, right = _crop_ids(prefix_ids, suffix_ids, code_budget)
    ids = [tokenizer.bos_token_id] + left + [tokenizer.mask_token_id] * mask_tokens + right + [tokenizer.eos_token_id]
    if len(ids) + max_canvas_tokens > native_context_tokens:
        raise AssertionError("DreamOn native context budget exceeded")
    return {
        "language": language, "input_ids": ids,
        "prefix_ids": [tokenizer.bos_token_id] + left,
        "suffix_ids": right + [tokenizer.eos_token_id],
        "mask_tokens": mask_tokens,
        "source_target_markers_in_char_crop": source.count(MARKER),
        "visible_target_markers": 1,
        "prefix_tokens_original": len(prefix_ids),
        "suffix_tokens_original": len(suffix_ids),
        "prefix_tokens_retained": len(left),
        "suffix_tokens_retained": len(right),
        "native_input_sha256": input_digest(ids),
    }


def extract_fixed_name(original: list[int], generated: list[int], span: list[int], tokenizer: Any,
                       language: str) -> tuple[str | None, str, str | None]:
    if len(generated) != len(original) + 1:
        return None, "", "unexpected_fixed_sampler_output_size"
    mask_id = tokenizer.mask_token_id
    if any(token != generated[index] for index, token in enumerate(original) if token != mask_id):
        return None, "", "native_context_changed"
    a, b = span
    canvas = generated[a:b]
    if any(token in tokenizer.all_special_ids for token in canvas):
        return None, tokenizer.decode(canvas, skip_special_tokens=False), "unfilled_or_special_canvas"
    raw = tokenizer.decode(canvas, skip_special_tokens=False, clean_up_tokenization_spaces=False)
    candidate = raw.strip()
    return (candidate if valid_identifier(candidate, language) else None), raw, (
        None if valid_identifier(candidate, language) else "invalid_native_name_output")


def extract_dreamon_name(sequence: list[int], prompt: dict[str, Any], tokenizer: Any,
                         *, max_canvas_tokens: int = 64) -> tuple[str | None, str, str | None]:
    prefix = prompt["prefix_ids"]
    suffix = prompt["suffix_ids"]
    if sequence[:len(prefix)] != prefix:
        return None, "", "native_prefix_changed"
    matches = [index for index in range(len(prefix), len(sequence) - len(suffix) + 1)
               if sequence[index:index + len(suffix)] == suffix]
    if not matches:
        return None, "", "native_suffix_missing"
    suffix_start = matches[-1]
    canvas = sequence[len(prefix):suffix_start]
    if not 0 < len(canvas) <= max_canvas_tokens:
        return None, "", "native_canvas_length_invalid"
    if any(token in tokenizer.all_special_ids for token in canvas):
        return None, tokenizer.decode(canvas, skip_special_tokens=False), "unfilled_or_special_canvas"
    raw = tokenizer.decode(canvas, skip_special_tokens=False, clean_up_tokenization_spaces=False)
    candidate = raw.strip()
    valid = valid_identifier(candidate, prompt["language"])
    return candidate if valid else None, raw, None if valid else "invalid_native_name_output"


@dataclass(frozen=True)
class NativeDiffusionConfig:
    model_slug: str
    model_id: str
    revision: str
    model_dir: str
    receipt_path: str
    receipt_sha256: str
    seed: int = 42

    def __post_init__(self) -> None:
        if self.model_slug not in FIXED_MODELS | {"dreamon-7b"}:
            raise ValueError("This native backend supports fixed-canvas and DreamOn only")
        expected_id, expected_revision, _, _ = MODELS[self.model_slug]
        if self.model_id != expected_id or self.revision != expected_revision:
            raise ValueError("Checkpoint differs from the original pinned dLLM roster")
        if not self.model_dir or not self.receipt_path or len(self.receipt_sha256) != 64:
            raise ValueError("Pinned model snapshot and verified receipt are required")

    @property
    def sampler(self) -> str:
        return "fixed2" if self.model_slug in FIXED_MODELS else "dreamon_variable"


class NativeDiffusionBackend:
    def __init__(self, config: NativeDiffusionConfig):
        import torch
        from transformers import AutoModel, AutoTokenizer

        snapshot = Path(config.model_dir).resolve()
        if not snapshot.is_dir() or snapshot.name != config.revision or not (snapshot / "config.json").is_file():
            raise ValueError("Snapshot path must be the exact pinned dLLM revision directory")
        if sha256_file(config.receipt_path) != config.receipt_sha256:
            raise ValueError("Verified dLLM receipt SHA-256 mismatch")
        receipt = json.loads(Path(config.receipt_path).read_text(encoding="utf-8"))
        if (receipt.get("verified") is not True or receipt.get("model_id") != config.model_id
                or receipt.get("revision") != config.revision
                or Path(receipt.get("model_path", "")).resolve() != snapshot):
            raise ValueError("Verified dLLM receipt identity mismatch")
        files = receipt.get("files")
        if not isinstance(files, list) or not files:
            raise ValueError("Verified dLLM receipt has no file inventory")
        for item in files:
            file = snapshot / item["path"]
            if not file.is_file() or file.stat().st_size != item["size"]:
                raise ValueError("Pinned dLLM file missing or changed size")
        if not torch.cuda.is_available():
            raise RuntimeError("Native dLLM S1 requires a CUDA GPU")
        self.config = config
        self.torch = torch
        self.tokenizer = AutoTokenizer.from_pretrained(snapshot, local_files_only=True, trust_remote_code=True)
        self.model = AutoModel.from_pretrained(
            snapshot, local_files_only=True, trust_remote_code=True,
            torch_dtype=torch.bfloat16,
        ).to("cuda").eval()
        if not callable(getattr(self.model, "diffusion_generate", None)):
            raise RuntimeError("Pinned dLLM lacks its native diffusion_generate sampler")
        self.device = next(self.model.parameters()).device

    def generate(self, messages: list[dict[str, str]], *, expected_group_ids: list[str], request_id: str) -> dict[str, Any]:
        if expected_group_ids != ["target"]:
            raise ValueError("Native diffusion S1 accepts one identifier group only")
        started = time.perf_counter()
        cfg = self.config
        task_seed = int.from_bytes(hashlib.sha256(f"{cfg.seed}:{request_id}".encode()).digest()[:4], "big")
        random.seed(task_seed)
        self.torch.manual_seed(task_seed)
        self.torch.cuda.manual_seed_all(task_seed)
        try:
            prompt = (build_fixed_input(messages, self.tokenizer) if cfg.sampler == "fixed2"
                      else build_dreamon_input(messages, self.tokenizer))
        except ValueError as exc:
            return {"status": "error", "names": {}, "content": None,
                    "error": f"native_prompt_error:{exc}", "model": cfg.model_id,
                    "revision": cfg.revision, "sampler": cfg.sampler,
                    "request_id": request_id, "elapsed_s": time.perf_counter() - started}
        ids = self.torch.tensor([prompt["input_ids"]], dtype=self.torch.long, device=self.device)
        with self.torch.inference_mode():
            if cfg.sampler == "fixed2":
                result = self.model.diffusion_generate(
                    ids, attention_mask=self.torch.ones_like(ids), max_new_tokens=1,
                    steps=64, temperature=0.3, top_p=0.95, alg="entropy", alg_temp=0.0,
                )
            else:
                result = self.model.diffusion_generate(
                    ids, max_new_tokens=64, return_dict_in_generate=True,
                    output_history=False, temperature=0.2, top_p=0.9,
                    alg="entropy", alg_temp=0.0, number_transfer_tokens=1,
                )
        sequence = result.sequences[0] if hasattr(result, "sequences") else result[0]
        output_ids = sequence.tolist() if hasattr(sequence, "tolist") else list(sequence)
        if cfg.sampler == "fixed2":
            name, raw, error = extract_fixed_name(prompt["input_ids"], output_ids,
                                                  prompt["first_span"], self.tokenizer,
                                                  prompt["language"])
        else:
            name, raw, error = extract_dreamon_name(output_ids, prompt, self.tokenizer)
        return {
            "status": "ok" if name else "error", "names": {"target": name} if name else {},
            "content": raw, "error": error, "model": cfg.model_id,
            "revision": cfg.revision, "sampler": cfg.sampler,
            "native_prompt_version": (FIXED_PROMPT_VERSION if cfg.sampler == "fixed2" else DREAMON_PROMPT_VERSION),
            "native_input_sha256": prompt["native_input_sha256"],
            "instruction_visible_to_model": False,
            "input_tokens": len(prompt["input_ids"]),
            "output_sequence_tokens": len(output_ids),
            "source_target_markers_in_char_crop": prompt["source_target_markers_in_char_crop"],
            "visible_target_markers": prompt["visible_target_markers"],
            "request_id": request_id, "task_seed": task_seed,
            "elapsed_s": time.perf_counter() - started,
            "gpu": self.torch.cuda.get_device_name(self.device),
        }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--language", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--model-slug", choices=sorted(FIXED_MODELS | {"dreamon-7b"}), required=True)
    parser.add_argument("--model-dir", required=True)
    parser.add_argument("--model-receipt", required=True)
    parser.add_argument("--model-receipt-sha256", required=True)
    parser.add_argument("--max-tasks", type=int)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.max_tasks is not None and args.max_tasks < 1:
        parser.error("--max-tasks must be positive")
    model_id, revision, _, _ = MODELS[args.model_slug]
    cfg = NativeDiffusionConfig(
        model_slug=args.model_slug, model_id=model_id, revision=revision,
        model_dir=args.model_dir, receipt_path=args.model_receipt,
        receipt_sha256=args.model_receipt_sha256,
    )
    tasks = load_tasks(args.data, dataset=args.dataset, language=args.language)
    if args.max_tasks is not None:
        tasks = tasks[:args.max_tasks]
    backend = NativeDiffusionBackend(cfg)
    spec = {
        **asdict(cfg), "engine": "native_diffusion", "sampler": cfg.sampler,
        "native_context_tokens": 1024 if cfg.sampler == "fixed2" else 2048,
        "mask_tokens": 2 if cfg.sampler == "fixed2" else 4,
        "max_new_tokens": 1 if cfg.sampler == "fixed2" else 64,
        "diffusion_steps": 64 if cfg.sampler == "fixed2" else None,
        "decoding": ({"temperature": 0.3, "top_p": 0.95, "alg": "entropy", "alg_temp": 0.0}
                     if cfg.sampler == "fixed2" else
                     {"temperature": 0.2, "top_p": 0.9, "alg": "entropy", "alg_temp": 0.0,
                      "number_transfer_tokens": 1}),
        "output_format": "plain",
        "actual_model_prompt_version": (FIXED_PROMPT_VERSION if cfg.sampler == "fixed2" else DREAMON_PROMPT_VERSION),
        "runner_prompt_version_meaning": "S1 task-message envelope; model receives code-only native canvas",
        "native_input_policy": "one first-site native sampler call; return its name for supplied-site propagation",
    }
    summary = run_campaign(tasks, backend, args.output, dataset_file=args.data,
                           backend_spec=spec, resume=args.resume)
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
