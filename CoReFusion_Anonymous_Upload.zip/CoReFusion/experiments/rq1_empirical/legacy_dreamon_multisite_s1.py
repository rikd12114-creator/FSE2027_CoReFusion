"""Native DreamOn S1 control that denoises every visible target site in place.

Each window presents all of its visible sites as four native mask tokens. The
original window planner owns each site once; overlapping windows never pass a
prediction to another window. Variable-length canvases are recovered only
when the complete unmasked token segments have one ordered alignment with the
compact native output. No name is propagated or repaired.
"""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import random
import time
from itertools import pairwise
from pathlib import Path
from typing import Any

from experiments.refineid_comparison.data import build_masked_windows

from .legacy_diffusion_s1 import NativeDiffusionBackend, NativeDiffusionConfig
from .legacy_native_s1 import sha256_file
from .policy import valid_identifier
from .schema import CONTEXT_CHARS, MARKER, RenameTask, load_tasks, visible_code
from .verify_cached_legacy_diffusion import MODELS

VERSION = "s1-native-dreamon-variable-multisite-windowed-v1"
MODE = "s1_native_dreamon_multisite_independent_sites"
MODEL_SLUG = "dreamon-7b"
MASK_TOKENS = 4
NATIVE_CONTEXT = 2048
GROWTH_TOKENS = 60
INPUT_CONTEXT = NATIVE_CONTEXT - GROWTH_TOKENS
SEED = 42
DECODING = {
    "temperature": 0.2, "top_p": 0.9, "alg": "entropy", "alg_temp": 0.0,
    "number_transfer_tokens": 1, "pad_delete_to_right": False,
    "return_dict_in_generate": True, "output_history": True,
}


def _digest(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _patch(code: str, names: list[str]) -> str:
    parts = code.split(MARKER)
    if len(parts) != len(names) + 1:
        raise ValueError("Site count and replacement count differ")
    return "".join(part + (names[i] if i < len(names) else "") for i, part in enumerate(parts))


def _window_seed(task_key: str, window_index: int) -> int:
    return int.from_bytes(hashlib.sha256(f"{SEED}:{task_key}:{window_index}".encode()).digest()[:4], "big")


def _site_metrics(task: RenameTask, predictions: list[str | None],
                  errors: list[str | None]) -> dict[str, Any]:
    valid = [name is not None and valid_identifier(name, task.language) and error is None
             for name, error in zip(predictions, errors)]
    covered = sum(valid)
    complete = covered == task.sites
    names = [name for name in predictions if name is not None]
    return {
        "expected_sites": task.sites,
        "visible_sites": task.sites - errors.count("outside_common_visible_code"),
        "covered_sites": covered, "complete_site_coverage": complete,
        "consistent_nonempty": bool(complete and len(set(names)) == 1),
        "exact_sites": sum(ok and name == task.reference_name for ok, name in zip(valid, predictions)),
        "all_sites_exact": bool(complete and all(name == task.reference_name for name in predictions)),
        "error_sites": sum(error is not None for error in errors),
    }


def unmasked_segments(input_ids: list[int], spans: list[list[int]], mask_id: int) -> list[list[int]]:
    """Extract the exact N+1 frozen token segments between N mask canvases."""
    if not spans:
        raise ValueError("Native DreamOn window has no target sites")
    segments: list[list[int]] = []
    cursor = 0
    for start, end in spans:
        if not cursor <= start < end <= len(input_ids) or end - start != MASK_TOKENS:
            raise ValueError("Invalid native DreamOn mask span")
        if input_ids[start:end] != [mask_id] * MASK_TOKENS:
            raise ValueError("Native DreamOn mask span contains non-mask context")
        segment = input_ids[cursor:start]
        if mask_id in segment:
            raise ValueError("Unmapped native mask in frozen context")
        segments.append(segment)
        cursor = end
    tail = input_ids[cursor:]
    if mask_id in tail:
        raise ValueError("Unmapped native mask after final target site")
    segments.append(tail)
    return segments


def align_canvases(sequence: list[int], segments: list[list[int]]) -> tuple[list[list[int]] | None,
                                                                     list[list[int]] | None, str | None]:
    """Accept exactly one monotone alignment of all complete frozen segments.

    Candidate canvases may be empty; the caller reports them as invalid names.
    A repeated anchor is allowed only when all anchors together still have a
    unique ordered placement. An absent or ambiguous alignment is never guessed.
    """
    if len(segments) < 2 or not segments[0] or not segments[-1]:
        raise ValueError("Native DreamOn window needs nonempty BOS/EOS anchors")
    if any(not segment for segment in segments[1:-1]):
        return None, None, "unseparated_native_sites"
    prefix, suffix = segments[0], segments[-1]
    if sequence[:len(prefix)] != prefix:
        return None, None, "native_prefix_changed"
    if len(sequence) < len(prefix) + len(suffix) or sequence[-len(suffix):] != suffix:
        return None, None, "native_suffix_changed"
    suffix_start = len(sequence) - len(suffix)
    # end-position -> (number of alignments, unique internal anchor positions)
    states: dict[int, tuple[int, tuple[int, ...] | None]] = {len(prefix): (1, ())}
    for anchor in segments[1:-1]:
        next_states: dict[int, tuple[int, tuple[int, ...] | None]] = {}
        for start in range(len(prefix), suffix_start - len(anchor) + 1):
            if sequence[start:start + len(anchor)] != anchor:
                continue
            ways = 0
            sole_path: tuple[int, ...] | None = None
            for cursor, (count, path) in states.items():
                if cursor > start:
                    continue
                if ways == 0 and count == 1 and path is not None:
                    sole_path = path + (start,)
                else:
                    sole_path = None
                ways = min(2, ways + count)
                if ways == 2:
                    break
            if ways:
                next_states[start + len(anchor)] = (ways, sole_path if ways == 1 else None)
        states = next_states
        if not states:
            return None, None, "native_unmasked_segment_missing"
    total = 0
    unique_path: tuple[int, ...] | None = None
    for cursor, (count, path) in states.items():
        if cursor > suffix_start:
            continue
        if total == 0 and count == 1:
            unique_path = path
        else:
            unique_path = None
        total = min(2, total + count)
        if total == 2:
            break
    if total == 0:
        return None, None, "native_unmasked_segment_missing"
    if total != 1 or unique_path is None:
        return None, None, "ambiguous_native_site_alignment"
    starts = [len(prefix)]
    ends: list[int] = []
    for anchor_start, anchor in zip(unique_path, segments[1:-1]):
        ends.append(anchor_start)
        starts.append(anchor_start + len(anchor))
    ends.append(suffix_start)
    spans = [[a, b] for a, b in zip(starts, ends)]
    return [sequence[a:b] for a, b in spans], spans, None


def _token_ids(value: Any) -> list[int]:
    raw = value.tolist() if hasattr(value, "tolist") else list(value)
    if not isinstance(raw, list) or any(type(item) is not int for item in raw):
        raise ValueError("Native DreamOn sampler returned non-integer token IDs")
    return raw


def generate_sites(backend: NativeDiffusionBackend, *, task_key: str, language: str,
                   masked_visible_code: str, expected_sites: int) -> dict[str, Any]:
    """Run one native variable-length denoising call per complete-token window."""
    visible_sites = masked_visible_code.count(MARKER)
    if not 1 <= visible_sites <= expected_sites:
        raise ValueError("Visible source has an invalid number of target markers")
    tokenizer = backend.tokenizer
    mask_id = tokenizer.mask_token_id
    expand_id = tokenizer.convert_tokens_to_ids("<|expand|>")
    if (mask_id is None or expand_id is None or expand_id == tokenizer.unk_token_id
            or tokenizer.convert_tokens_to_ids("<|mask|>") != mask_id
            or tokenizer.bos_token_id is None or tokenizer.eos_token_id is None):
        raise ValueError("Pinned DreamOn tokenizer lacks native mask/expand/BOS/EOS tokens")
    plan = build_masked_windows(masked_visible_code, tokenizer,
                                mask_length=MASK_TOKENS, max_length=INPUT_CONTEXT)
    if plan["occurrences"] != visible_sites:
        raise AssertionError("Native DreamOn window planner lost a visible site")
    for window in plan["windows"]:
        window["unmasked_segments"] = unmasked_segments(
            window["input_ids"], window["visible_token_spans"], mask_id)
    plan["input_plan_sha256"] = _digest(plan["windows"])
    predictions: list[str | None] = [None] * expected_sites
    errors: list[str | None] = ["outside_common_visible_code"] * expected_sites
    raw_names: list[str | None] = [None] * expected_sites
    site_token_ids: list[list[int] | None] = [None] * expected_sites
    site_window_indices: list[int | None] = [None] * expected_sites
    outputs: list[dict[str, Any]] = []
    owned_all: list[int] = []
    for window in plan["windows"]:
        idx = window["index"]
        owned = window["owned_site_indices"]
        visible = window["visible_site_indices"]
        owned_all.extend(owned)
        ids = window["input_ids"]
        initial_masks = MASK_TOKENS * len(visible)
        max_new_tokens = initial_masks + GROWTH_TOKENS
        max_output_tokens = len(ids) - initial_masks + max_new_tokens
        if (len(ids) > INPUT_CONTEXT or ids.count(mask_id) != initial_masks
                or max_output_tokens > NATIVE_CONTEXT):
            raise AssertionError("DreamOn 2048-token native context budget exceeded")
        if len(window["visible_token_spans"]) != len(visible):
            raise AssertionError("Native window visible-site/span mapping changed")
        seed = _window_seed(task_key, idx)
        random.seed(seed)
        backend.torch.manual_seed(seed)
        backend.torch.cuda.manual_seed_all(seed)
        batch = backend.torch.tensor([ids], dtype=backend.torch.long, device=backend.device)
        nfe = 0

        def count_forward(_module: Any, _inputs: Any) -> None:
            nonlocal nfe
            nfe += 1

        hook = backend.model.register_forward_pre_hook(count_forward)
        started = time.perf_counter()
        try:
            with backend.torch.inference_mode():
                result = backend.model.diffusion_generate(
                    batch, max_new_tokens=max_new_tokens,
                    eos_token_id=tokenizer.eos_token_id,
                    delete_token_id=tokenizer.eos_token_id,
                    pad_token_id=tokenizer.eos_token_id,
                    mask_token_id=mask_id, expand_token_id=expand_id,
                    **DECODING,
                )
        finally:
            hook.remove()
        elapsed = time.perf_counter() - started
        history = getattr(result, "history", None)
        final_active = _token_ids(history[-1]) if history else None
        history_lengths = [len(ids)] + [len(state) for state in history] if history else []
        expansions = sum(max(0, b - a) for a, b in pairwise(history_lengths))
        deletions = sum(max(0, a - b) for a, b in pairwise(history_lengths))
        canvases: list[list[int]] | None = None
        canvas_spans: list[list[int]] | None = None
        if final_active is None:
            alignment_error = "native_history_missing"
        elif len(final_active) > NATIVE_CONTEXT:
            alignment_error = "native_context_budget_exceeded"
        else:
            canvases, canvas_spans, alignment_error = align_canvases(
                final_active, window["unmasked_segments"])
        outputs.append({
            "window_index": idx, "owned_site_indices": owned,
            "visible_site_indices": visible, "input_ids": ids,
            "unmasked_segments": window["unmasked_segments"],
            "input_ids_sha256": _digest(ids),
            "final_active_output_ids": final_active,
            "final_active_output_sha256": _digest(final_active) if final_active is not None else None,
            "canvas_spans": canvas_spans, "alignment_error": alignment_error,
            "context_unchanged": alignment_error is None,
            "window_seed": seed, "input_tokens": len(ids),
            "output_tokens": len(final_active) if final_active is not None else None,
            "initial_mask_tokens": initial_masks, "max_new_tokens": max_new_tokens,
            "max_output_tokens": max_output_tokens,
            "native_forward_calls": nfe, "history_states": len(history) if history else 0,
            "expansion_actions": expansions, "deletion_actions": deletions,
            "elapsed_s": elapsed,
        })
        visible_offsets = {site: offset for offset, site in enumerate(visible)}
        for site in owned:
            site_window_indices[site] = idx
            if alignment_error is not None:
                errors[site] = alignment_error
                continue
            assert canvases is not None
            canvas = canvases[visible_offsets[site]]
            site_token_ids[site] = canvas
            if not canvas:
                errors[site] = "empty_native_canvas"
                raw_names[site] = ""
                continue
            if any(token in tokenizer.all_special_ids for token in canvas):
                raw_names[site] = tokenizer.decode(canvas, skip_special_tokens=False,
                                                   clean_up_tokenization_spaces=False)
                errors[site] = "unfilled_or_special_canvas"
                continue
            raw = tokenizer.decode(canvas, skip_special_tokens=False,
                                   clean_up_tokenization_spaces=False)
            raw_names[site] = raw
            candidate = raw.strip()
            if valid_identifier(candidate, language):
                predictions[site] = candidate
                errors[site] = None
            else:
                errors[site] = "invalid_native_name_output"
    if sorted(owned_all) != list(range(visible_sites)):
        raise AssertionError("Native DreamOn windows did not own each visible site exactly once")
    return {
        "site_predictions": predictions, "site_errors": errors,
        "site_raw_content": raw_names, "site_token_ids": site_token_ids,
        "site_window_indices": site_window_indices,
        "visible_sites": visible_sites, "window_plan": plan, "window_outputs": outputs,
        "native_sampler_calls": len(outputs), "gpu": backend.torch.cuda.get_device_name(backend.device),
    }


def run(model_slug: str, model_dir: Path, receipt: Path, receipt_sha: str,
        source: Path, dataset: str, language: str, output: Path,
        max_tasks: int | None) -> dict[str, Any]:
    if model_slug != MODEL_SLUG:
        raise ValueError("This native variable-length multisite control supports pinned DreamOn only")
    if output.exists():
        raise FileExistsError("Native DreamOn multisite output is write-once")
    tasks = load_tasks(source, dataset=dataset, language=language)
    if max_tasks is not None:
        if (dataset != "stack_v3_refineid_dev_20260924" or language != "Java"
                or max_tasks not in (2, 100) or len(tasks) < max_tasks):
            raise ValueError("Only declared Java developer slices of 2 or 100 rows are allowed")
        tasks = tasks[:max_tasks]
    elif len(tasks) != 1000:
        raise ValueError("Formal frozen Stack-v3 cohort must contain exactly 1,000 tasks")
    model_id, revision, _, _ = MODELS[model_slug]
    cfg = NativeDiffusionConfig(model_slug, model_id, revision,
                                str(model_dir), str(receipt), receipt_sha)
    output.mkdir(parents=True, exist_ok=False)
    run_path, predictions_path = output / "run.json", output / "predictions.jsonl"
    source_dir = Path(__file__).parent
    contract = {
        "schema_version": 1, "mode": MODE, "version": VERSION,
        "source_path": str(source.resolve()), "source_sha256": sha256_file(source),
        "dataset": dataset, "language": language, "task_keys": [task.key for task in tasks],
        "task_identity_sha256": _digest([(t.key, t.code_masked, t.reference_name) for t in tasks]),
        "common_visible_code_char_limit": CONTEXT_CHARS,
        "native_context_tokens": NATIVE_CONTEXT, "native_input_limit": INPUT_CONTEXT,
        "mask_tokens_per_site": MASK_TOKENS, "aggregate_growth_tokens_per_window": GROWTH_TOKENS,
        "max_new_tokens_policy": "four times visible sites in window plus 60 aggregate growth tokens",
        "outside_common_crop_policy": "null site prediction; remain in denominator",
        "window_policy": "all visible 4-mask sites denoised per native window; each site owned once; no propagation",
        "alignment_policy": "unique monotone placement of every complete unmasked token segment; no repair",
        "model_slug": model_slug, "model_id": model_id, "revision": revision,
        "model_receipt_sha256": receipt_sha, "seed": SEED,
        "window_seed_policy": "sha256(seed,task_key,window_index) first 32 bits",
        "decoding": DECODING, "runtime_precision": "torch.bfloat16",
        "source_code_sha256": {name: sha256_file(source_dir / name) for name in (
            "legacy_dreamon_multisite_s1.py", "legacy_diffusion_s1.py", "legacy_native_s1.py",
            "schema.py", "policy.py")},
        "window_planner_sha256": sha256_file(source_dir.parent / "refineid_comparison/data.py"),
    }
    run_path.write_text(json.dumps(contract, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    backend = NativeDiffusionBackend(cfg)
    contract["runtime"] = {
        "torch": backend.torch.__version__, "cuda_runtime": backend.torch.version.cuda,
        "gpu": backend.torch.cuda.get_device_name(backend.device),
        "mask_token_id": backend.tokenizer.mask_token_id,
        "expand_token_id": backend.tokenizer.convert_tokens_to_ids("<|expand|>"),
        "eos_token_id": backend.tokenizer.eos_token_id,
        "bos_token_id": backend.tokenizer.bos_token_id,
    }
    run_path.write_text(json.dumps(contract, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    records: list[dict[str, Any]] = []
    with (output / ".writer.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        with predictions_path.open("w", encoding="utf-8") as stream:
            for task in tasks:
                visible = visible_code(task)
                generated = generate_sites(backend, task_key=task.key, language=task.language,
                                           masked_visible_code=visible, expected_sites=task.sites)
                predictions, errors = generated["site_predictions"], generated["site_errors"]
                metrics = _site_metrics(task, predictions, errors)
                patch = (_patch(task.code_masked, [name for name in predictions if name is not None])
                         if metrics["complete_site_coverage"] else None)
                row = {
                    "task_key": task.key, "dataset": task.dataset, "language": task.language,
                    "id": task.task_id, "reference_name": task.reference_name,
                    "expected_sites": task.sites,
                    "visible_code_sha256": hashlib.sha256(visible.encode()).hexdigest(),
                    **generated, "metrics": metrics,
                    "patch_sha256": hashlib.sha256(patch.encode()).hexdigest() if patch is not None else None,
                }
                stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
                stream.flush(); os.fsync(stream.fileno())
                records.append(row)
    summary = {
        "planned_tasks": len(tasks), "completed_tasks": len(records),
        "expected_sites": sum(task.sites for task in tasks),
        "covered_sites": sum(row["metrics"]["covered_sites"] for row in records),
        "all_sites_exact_tasks": sum(row["metrics"]["all_sites_exact"] for row in records),
        "consistent_nonempty_tasks": sum(row["metrics"]["consistent_nonempty"] for row in records),
        "tasks_with_site_error": sum(row["metrics"]["error_sites"] > 0 for row in records),
        "native_sampler_calls": sum(row["native_sampler_calls"] for row in records),
        "native_forward_calls": sum(window["native_forward_calls"]
                                    for row in records for window in row["window_outputs"]),
        "run_sha256": sha256_file(run_path), "predictions_sha256": sha256_file(predictions_path),
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-slug", required=True, choices=(MODEL_SLUG,))
    parser.add_argument("--model-dir", required=True, type=Path)
    parser.add_argument("--model-receipt", required=True, type=Path)
    parser.add_argument("--model-receipt-sha256", required=True)
    parser.add_argument("--data", required=True, type=Path)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--language", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--max-tasks", type=int)
    args = parser.parse_args()
    print(json.dumps(run(args.model_slug, args.model_dir, args.model_receipt,
                         args.model_receipt_sha256, args.data, args.dataset,
                         args.language, args.output, args.max_tasks), sort_keys=True))


if __name__ == "__main__":
    main()
