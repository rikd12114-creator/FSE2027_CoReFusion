"""Isolated CPU preflight and four-request GPT-OSS Harmony judge format smoke.

This is a synthetic format test, not a calibrated naming-quality evaluation.
It deliberately does not modify the shared multi-model judge runtime.
"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import traceback

from evaluation.rq1_empirical.aggregation import validate_judgment
from evaluation.rq1_empirical.judge_runtime import load_requests, select_requests

from .gpt_oss_20b_integrity import MODEL_ID, REVISION


REASONING_EFFORT = "low"
FINAL_MARKER = "<|channel|>final<|message|>"
RETURN_MARKER = "<|return|>"
SYNTHETIC_REQUESTS_SHA256 = "1cbda3feed4f998a22d256141d9e43d186cd3e36c22603ca93bc0edc574c983d"


def extract_harmony_final(raw: str) -> str:
    if FINAL_MARKER not in raw:
        raise ValueError("missing_harmony_final_channel")
    final = raw.rsplit(FINAL_MARKER, 1)[1].strip()
    if not final.endswith(RETURN_MARKER):
        raise ValueError("missing_harmony_return_marker")
    final = final[: -len(RETURN_MARKER)].strip()
    if not final.startswith("{") or not final.endswith("}"):
        raise ValueError("final_answer_not_bare_json")
    return final


def synthetic_requests(path: Path, selection_path: Path) -> list[dict]:
    requests = load_requests(path, SYNTHETIC_REQUESTS_SHA256)
    selection = json.loads(selection_path.read_text(encoding="utf-8"))
    chosen = select_requests(requests, selection, expected_hash=SYNTHETIC_REQUESTS_SHA256)
    if len(requests) != 4 or len(chosen) != 4:
        raise ValueError("This smoke requires exactly the four frozen synthetic requests")
    return chosen


def _messages(request: dict) -> list[dict[str, str]]:
    schema = json.dumps(request["response_schema"], sort_keys=True,
                        ensure_ascii=False, separators=(",", ":"))
    return [{"role": "system", "content": request["messages"][0]["content"]
             + "\nResponse schema: " + schema}, dict(request["messages"][1])]


def _encode(tokenizer, request: dict):
    import torch

    batch = tokenizer.apply_chat_template(
        _messages(request), tokenize=True, add_generation_prompt=True,
        reasoning_effort=REASONING_EFFORT, return_dict=True,
        return_tensors="pt",
    )
    ids = batch.get("input_ids") if hasattr(batch, "get") else None
    if not isinstance(ids, torch.Tensor) or ids.ndim != 2 or ids.shape[0] != 1:
        raise ValueError("Unexpected GPT-OSS chat-template encoding")
    return batch, int(ids.shape[-1])


def _read_receipt(path: Path, expected_sha256: str, model_dir: Path) -> dict:
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected_sha256:
        raise ValueError("Pinned checkpoint receipt SHA-256 changed")
    receipt = json.loads(path.read_text(encoding="utf-8"))
    if (receipt.get("model_id") != MODEL_ID or receipt.get("revision") != REVISION
            or receipt.get("verified") is not True
            or receipt.get("model_path") != str(model_dir.resolve())):
        raise ValueError("Checkpoint receipt identity differs")
    for item in receipt["files"]:
        file = model_dir / item["path"]
        if not file.is_file() or file.stat().st_size != item["size"]:
            raise ValueError(f"Checkpoint file changed after verification: {item['path']}")
    return receipt


def preflight(args: argparse.Namespace) -> None:
    from transformers import AutoTokenizer
    import transformers

    chosen = synthetic_requests(args.requests, args.selection)
    tokenizer = AutoTokenizer.from_pretrained(args.model_dir, local_files_only=True,
                                              trust_remote_code=False)
    rows = []
    for request in chosen:
        batch, tokens = _encode(tokenizer, request)
        rendered = tokenizer.decode(batch["input_ids"][0], skip_special_tokens=False,
                                    clean_up_tokenization_spaces=False)
        if "Reasoning: low" not in rendered or not rendered.endswith("<|start|>assistant"):
            raise ValueError("Pinned tokenizer did not render low-effort Harmony generation prefix")
        rows.append({"request_id": request["request_id"], "kind": request["kind"],
                     "input_tokens": tokens,
                     "rendered_sha256": hashlib.sha256(rendered.encode("utf-8")).hexdigest(),
                     "rendered_suffix": rendered[-100:]})
    result = {"status": "cpu_preflight_passed", "model_id": MODEL_ID,
              "revision": REVISION, "reasoning_effort": REASONING_EFFORT,
              "requests_sha256": SYNTHETIC_REQUESTS_SHA256,
              "transformers_version": transformers.__version__, "requests": rows}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "requests": len(rows),
                      "transformers_version": transformers.__version__}))


def gpu_smoke(args: argparse.Namespace) -> None:
    import torch
    import transformers
    from transformers import AutoModelForCausalLM, AutoTokenizer

    if not torch.cuda.is_available():
        raise RuntimeError("GPT-OSS synthetic smoke requires a CUDA GPU")
    chosen = synthetic_requests(args.requests, args.selection)
    _read_receipt(args.receipt, args.receipt_sha256, args.model_dir)
    args.output.mkdir(parents=True, exist_ok=False)
    configuration = {
        "model_id": MODEL_ID, "revision": REVISION,
        "model_receipt_sha256": args.receipt_sha256,
        "requests_sha256": SYNTHETIC_REQUESTS_SHA256,
        "reasoning_effort": REASONING_EFFORT, "decode": "greedy",
        "max_new_tokens": args.max_new_tokens, "max_total_tokens": args.max_total_tokens,
        "torch_version": torch.__version__, "transformers_version": transformers.__version__,
        "gpu": torch.cuda.get_device_name(0),
    }
    (args.output / "run_config.json").write_text(
        json.dumps(configuration, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    try:
        tokenizer = AutoTokenizer.from_pretrained(args.model_dir, local_files_only=True,
                                                  trust_remote_code=False)
        model = AutoModelForCausalLM.from_pretrained(
            args.model_dir, local_files_only=True, trust_remote_code=False,
            dtype="auto", device_map="auto",
        ).eval()
        raw_map = getattr(model, "hf_device_map", None)
        device_map = ({str(key): str(value) for key, value in raw_map.items()}
                      if isinstance(raw_map, dict) else None)
        parameters = list(model.parameters())
        buffers = list(model.buffers())
        placement = {
            "hf_device_map": device_map,
            "parameter_devices": dict(Counter(str(value.device) for value in parameters)),
            "buffer_devices": dict(Counter(str(value.device) for value in buffers)),
            "parameter_count": len(parameters),
            "buffer_count": len(buffers),
            "gpu_allocated_after_load_bytes": torch.cuda.memory_allocated(),
        }
        configuration["placement"] = placement
        (args.output / "run_config.json").write_text(
            json.dumps(configuration, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        if device_map and any(value.lower() in {"cpu", "disk", "meta"}
                              for value in device_map.values()):
            raise RuntimeError(f"Checkpoint explicitly offloaded: {placement}")
        if not parameters or any(value.device.type != "cuda" for value in parameters):
            raise RuntimeError(f"Checkpoint parameters are not all on CUDA: {placement}")
        if any(value.device.type != "cuda" for value in buffers):
            raise RuntimeError(f"Checkpoint buffers are not all on CUDA: {placement}")
        device = parameters[0].device
        counts = {"valid": 0, "invalid": 0, "over_budget": 0, "backend_error": 0}
        with (args.output / "attempts.jsonl").open("x", encoding="utf-8") as stream:
            for request in chosen:
                row = {"request_id": request["request_id"], "kind": request["kind"],
                       "raw": "", "response": None}
                try:
                    batch, prompt_tokens = _encode(tokenizer, request)
                    row["input_tokens"] = prompt_tokens
                    if prompt_tokens + args.max_new_tokens > args.max_total_tokens:
                        row["status"] = "over_budget"
                    else:
                        inputs = {key: value.to(device) for key, value in batch.items()
                                  if key in {"input_ids", "attention_mask"} and hasattr(value, "to")}
                        with torch.inference_mode():
                            generated = model.generate(
                                **inputs, max_new_tokens=args.max_new_tokens,
                                do_sample=False, pad_token_id=tokenizer.pad_token_id,
                            )
                        tail = generated[0, prompt_tokens:].tolist()
                        row["output_tokens"] = len(tail)
                        row["raw"] = tokenizer.decode(tail, skip_special_tokens=False,
                                                      clean_up_tokenization_spaces=False)
                        try:
                            final = extract_harmony_final(row["raw"])
                            row["response"] = validate_judgment(request["kind"], final)
                            row["status"] = "valid"
                        except (ValueError, json.JSONDecodeError) as exc:
                            row["status"] = "invalid"
                            row["error"] = f"{type(exc).__name__}: {exc}"
                except Exception as exc:
                    row["status"] = "backend_error"
                    row["error"] = f"{type(exc).__name__}: {exc}"
                    row["traceback"] = traceback.format_exc()
                counts[row["status"]] += 1
                stream.write(json.dumps(row, sort_keys=True, ensure_ascii=False) + "\n")
                stream.flush()
                os.fsync(stream.fileno())
        summary = {**configuration, "status": "synthetic_format_smoke_only",
                   "planned_requests": len(chosen), "counts": counts,
                   "peak_gpu_memory_bytes": torch.cuda.max_memory_allocated()}
        (args.output / "summary.json").write_text(
            json.dumps(summary, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"status": summary["status"], "counts": counts}))
    except Exception:
        (args.output / "failure.txt").write_text(traceback.format_exc(), encoding="utf-8")
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["preflight", "gpu-smoke"])
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--requests", type=Path, required=True)
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--receipt", type=Path)
    parser.add_argument("--receipt-sha256")
    parser.add_argument("--max-new-tokens", type=int, default=512)
    parser.add_argument("--max-total-tokens", type=int, default=8192)
    args = parser.parse_args()
    if args.command == "preflight":
        preflight(args)
    elif args.receipt is None or args.receipt_sha256 is None:
        parser.error("gpu-smoke requires a pinned receipt and its SHA-256")
    else:
        gpu_smoke(args)


if __name__ == "__main__":
    main()
