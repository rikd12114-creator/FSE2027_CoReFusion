"""Resumable, gold-free S1 generate-once-and-propagate evaluation.

The task reference is used only after generation. Backends receive masked
messages, a stable task key, and the expected output group name.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
import fcntl
import hashlib
import json
import os
from pathlib import Path
from typing import Any, Protocol

from .policy import apply_once
from .schema import CONTEXT_CHARS, RenameTask, build_messages, load_tasks

PROMPT_VERSION = "s1-once-charcrop-v2"


class NamingBackend(Protocol):
    def generate(self, messages: list[dict[str, str]], *, expected_group_ids: list[str], request_id: str) -> dict[str, Any]: ...


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


def _atomic_json(path: Path, value: Any) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temp.replace(path)


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8") as stream:
        lines = stream.readlines()
    if lines and not lines[-1].endswith("\n"):
        raise ValueError("Interrupted final JSONL record; inspect before resume")
    return [json.loads(line) for line in lines]


def _record(task: RenameTask, result: dict[str, Any], messages: list[dict[str, str]]) -> dict[str, Any]:
    if not isinstance(result, dict):
        raise TypeError("Backend result must be a dictionary")
    names = result.get("names") or {}
    if not isinstance(names, dict):
        names = {}
    raw_name = names.get("target")
    name = raw_name if isinstance(raw_name, str) else None
    backend_error = result.get("error")
    if result.get("status") == "ok":
        error = None
    elif isinstance(backend_error, dict):
        error = str(backend_error.get("code") or "backend_failed")
    else:
        error = str(backend_error or "backend_failed")
    applied = apply_once(task, name, error=error)
    return {
        "task_key": task.key,
        "dataset": task.dataset,
        "language": task.language,
        "id": task.task_id,
        "expected_sites": task.sites,
        "reference_name": task.reference_name,
        "prompt_sha256": _digest(messages),
        "raw_content": result.get("content"),
        "backend": {key: value for key, value in result.items() if key not in {"content", "names"}},
        "predicted_name": name,
        "site_predictions": [name] * task.sites if applied.complete_site_coverage else [],
        "patch_sha256": hashlib.sha256(applied.patched_code.encode()).hexdigest() if applied.patched_code is not None else None,
        "metrics": {key: value for key, value in asdict(applied).items() if key not in {"task_key", "patched_code", "predicted_name"}},
    }


def run_campaign(
    tasks: list[RenameTask], backend: NamingBackend, output_dir: str | Path,
    *, dataset_file: str | Path, backend_spec: dict[str, Any], resume: bool = False,
) -> dict[str, Any]:
    """Run exactly the supplied task cohort; `tasks` may be a declared pilot slice."""
    if not tasks or len({task.key for task in tasks}) != len(tasks):
        raise ValueError("Empty or duplicate task cohort")
    output_format = backend_spec.get("output_format", "plain")
    if output_format not in {"plain", "json"}:
        raise ValueError("Unsupported backend output format")
    dataset_path = Path(dataset_file).resolve()
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    contract = {
        "schema_version": 1,
        "mode": "s1_generate_once_propagate_all_supplied_sites",
        "prompt_version": PROMPT_VERSION,
        "context_char_limit": CONTEXT_CHARS,
        "source_path": str(dataset_path),
        "source_sha256": _sha(dataset_path),
        "task_keys": [task.key for task in tasks],
        "task_identity_sha256": _digest([(task.key, task.code_masked, task.reference_name) for task in tasks]),
        "backend_spec": backend_spec,
    }
    run_path = output / "run.json"
    records_path = output / "predictions.jsonl"
    lock_path = output / ".writer.lock"
    with lock_path.open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        if run_path.exists():
            if not resume:
                raise FileExistsError("Run exists; use --resume after checking its contract")
            if json.loads(run_path.read_text(encoding="utf-8")) != contract:
                raise ValueError("Resume contract changed")
        else:
            if records_path.exists():
                raise ValueError("Predictions exist without a contract")
            _atomic_json(run_path, contract)
        previous = _read_jsonl(records_path)
        if len(previous) > len(tasks):
            raise ValueError("Prediction count exceeds cohort")
        if [record["task_key"] for record in previous] != contract["task_keys"][:len(previous)]:
            raise ValueError("Invalid resume prefix")
        for task, record in zip(tasks, previous):
            if record.get("reference_name") != task.reference_name or record.get("expected_sites") != task.sites:
                raise ValueError("Resume source mismatch")
            expected = _record(task, {
                "status": "ok" if record["metrics"]["error"] is None else "error",
                "names": {"target": record.get("predicted_name")},
                "error": record["metrics"]["error"],
            }, build_messages(task, output_format=output_format))
            if expected["metrics"] != record["metrics"] or expected["prompt_sha256"] != record["prompt_sha256"]:
                raise ValueError("Resume score or prompt mismatch")
        with records_path.open("a", encoding="utf-8") as stream:
            for task in tasks[len(previous):]:
                messages = build_messages(task, output_format=output_format)
                try:
                    result = backend.generate(messages, expected_group_ids=["target"], request_id=task.key)
                except Exception as exc:
                    result = {"status": "error", "names": {}, "content": None,
                              "error": f"{type(exc).__name__}: {exc}"}
                record = _record(task, result, messages)
                stream.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
                stream.flush()
                os.fsync(stream.fileno())
                if record["metrics"]["error"] in {
                    "missing_api_key", "invalid_api_key", "budget_exhausted",
                    "budget_halted", "interrupted_request", "cost_reservation_exceeded",
                    "model_mismatch", "provider_mismatch",
                }:
                    raise RuntimeError(
                        f"Terminal backend condition after {task.key}: {record['metrics']['error']}"
                    )
        records = _read_jsonl(records_path)
        if len(records) != len(tasks):
            raise ValueError("Incomplete run after generation")
        summary = {
            "planned_tasks": len(tasks),
            "completed_tasks": len(records),
            "expected_sites": sum(task.sites for task in tasks),
            "error_tasks": sum(r["metrics"]["error"] is not None for r in records),
            "valid_name_tasks": sum(r["metrics"]["valid_name"] for r in records),
            "all_sites_exact_tasks": sum(r["metrics"]["all_sites_exact"] for r in records),
            "consistent_nonempty_tasks": sum(r["metrics"]["consistent_nonempty"] for r in records),
            "predictions_sha256": _sha(records_path),
            "contract_sha256": _sha(run_path),
        }
        _atomic_json(output / "summary.json", summary)
        return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--language", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--backend", choices=("hf", "openrouter"), default="hf")
    parser.add_argument("--model-dir", help="Pinned local HF snapshot")
    parser.add_argument("--model-id", required=True)
    parser.add_argument("--revision", help="Pinned local model revision")
    parser.add_argument("--model-receipt", help="Previously verified model file receipt")
    parser.add_argument("--model-receipt-sha256", help="SHA-256 of the pinned receipt")
    parser.add_argument("--max-tasks", type=int)
    parser.add_argument("--max-input-tokens", type=int, default=8192)
    parser.add_argument("--max-new-tokens", type=int, default=48)
    parser.add_argument("--thinking", action="store_true")
    parser.add_argument("--provider", help="Exact OpenRouter provider slug")
    parser.add_argument("--api-budget-usd", help="Total conservative API spend reservation")
    parser.add_argument("--api-max-request-cost-usd", help="Reservation for each API attempt")
    parser.add_argument("--api-max-task-cost-usd", help="Optional per-task reservation limit")
    parser.add_argument("--api-key-env", default="OPENROUTER_API_KEY")
    parser.add_argument("--api-timeout-s", type=float, default=60.0)
    parser.add_argument("--api-retries", type=int, default=2)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.max_tasks is not None and args.max_tasks < 1:
        parser.error("--max-tasks must be positive")
    tasks = load_tasks(args.data, dataset=args.dataset, language=args.language)
    if args.max_tasks:
        tasks = tasks[:args.max_tasks]
    if args.backend == "hf":
        if not args.model_dir or not args.revision:
            parser.error("HF backend needs --model-dir and --revision")
        from .hf_backend import HuggingFaceBackend, HuggingFaceConfig
        cfg = HuggingFaceConfig(
            model_id=args.model_id, revision=args.revision, model_dir=args.model_dir,
            max_input_tokens=args.max_input_tokens, max_new_tokens=args.max_new_tokens,
            thinking=args.thinking, receipt_path=args.model_receipt,
            receipt_sha256=args.model_receipt_sha256,
        )
        backend = HuggingFaceBackend(cfg)
    else:
        if not args.provider or not args.api_budget_usd or not args.api_max_request_cost_usd:
            parser.error("OpenRouter backend needs --provider, --api-budget-usd and --api-max-request-cost-usd")
        if args.thinking or args.model_dir or args.revision or args.model_receipt or args.model_receipt_sha256:
            parser.error("HF-only arguments cannot be used with OpenRouter backend")
        from .api_backend import OpenRouterBackend, OpenRouterConfig
        cfg = OpenRouterConfig(
            model=args.model_id, provider=args.provider, budget_usd=args.api_budget_usd,
            max_request_cost_usd=args.api_max_request_cost_usd,
            max_task_cost_usd=args.api_max_task_cost_usd, api_key_env=args.api_key_env,
            max_tokens=args.max_new_tokens, timeout_s=args.api_timeout_s,
            max_retries=args.api_retries,
        )
        if not os.environ.get(cfg.api_key_env, "").strip():
            parser.error(f"Environment variable {cfg.api_key_env} is required for paid API execution")
        backend = OpenRouterBackend(cfg, state_path=Path(args.output) / "api_state.json")
    backend_spec = asdict(cfg)
    backend_spec["output_format"] = "plain" if args.backend == "hf" else "json"
    if args.backend == "hf":
        import transformers
        backend_spec["runtime"] = {
            "torch": backend.torch.__version__,
            "transformers": transformers.__version__,
            "cuda_runtime": backend.torch.version.cuda,
            "gpu": backend.torch.cuda.get_device_name(backend.model_device),
            "model_config_sha256": backend.config_sha256,
            "model_receipt_verified": backend.receipt_verified,
        }
    summary = run_campaign(tasks, backend, args.output, dataset_file=args.data,
                           backend_spec=backend_spec, resume=args.resume)
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
