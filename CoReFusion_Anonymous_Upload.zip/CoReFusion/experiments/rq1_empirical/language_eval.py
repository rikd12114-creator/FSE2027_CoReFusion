"""Language-aware S1 rename evaluation for the seven frozen RQ1 languages.

All task-level lexical metrics retain the planned task denominator. Syntax
metrics use a fixed, reference-eligible subset and count failed predictions in
that subset as failures. A syntax tree does not establish symbol binding or
compilation; both fields remain ``None`` until separate evidence is supplied.

Stack v3 provenance stores character offsets in the original source. Its mask
builder inserts spaces around each marker, so candidate patches must be made
from the SHA-verified restored source, never by replacing markers in the CSV.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import ast
import hashlib
import importlib.metadata
import json
import keyword
from pathlib import Path
import platform
import unicodedata
from typing import Any, Mapping, Protocol, Sequence


MARKER = "[MASK]"
MASK_SLOT = f" {MARKER} "
_FORBIDDEN_OUTPUTS = {"MASK", "HOLE", "__CF_INVALID__"}
_ALIASES = {
    "java": "java", "python": "python", "py": "python",
    "javascript": "javascript", "js": "javascript",
    "typescript": "typescript", "ts": "typescript", "tsx": "typescript",
    "go": "go", "golang": "go", "rust": "rust", "rs": "rust",
    "c++": "cpp", "cpp": "cpp", "cxx": "cpp", "cc": "cpp",
}
_JAVA_RESERVED = set((
    "abstract assert boolean break byte case catch char class const continue default do "
    "double else enum extends final finally float for goto if implements import instanceof "
    "int interface long native new package private protected public return short static "
    "strictfp super switch synchronized this throw throws transient try void volatile while "
    "true false null _"
).split())
_ECMASCRIPT_RESERVED = set((
    "await break case catch class const continue debugger default delete do else enum export "
    "extends false finally for function if import in instanceof new null return super switch "
    "this throw true try typeof var void while with yield let static implements interface "
    "package private protected public eval arguments"
).split())
_GO_RESERVED = set((
    "break default func interface select case defer go map struct chan else goto package "
    "switch const fallthrough if range type continue for import return var"
).split())
_RUST_RESERVED = set((
    "as async await break const continue crate dyn else enum extern false fn for if impl in "
    "let loop match mod move mut pub ref return self Self static struct super trait true "
    "type unsafe use where while abstract become box do final macro override priv typeof "
    "unsized virtual yield try"
).split())
_CPP_RESERVED = set((
    "alignas alignof and and_eq asm auto bitand bitor bool break case catch char char8_t "
    "char16_t char32_t class compl concept const consteval constexpr constinit const_cast "
    "continue co_await co_return co_yield decltype default delete do double dynamic_cast "
    "else enum explicit export extern false float for friend goto if inline int long mutable "
    "namespace new noexcept not not_eq nullptr operator or or_eq private protected public "
    "register reinterpret_cast requires return short signed sizeof static static_assert "
    "static_cast struct switch template this thread_local throw true try typedef typeid "
    "typename union unsigned using virtual void volatile wchar_t while xor xor_eq"
).split())

# Unicode 15 Other_ID_Start/Continue code points, in addition to the general
# categories from UAX #31. The runtime Unicode database version is receipted.
_OTHER_ID_START = {0x1885, 0x1886, 0x2118, 0x212E, 0x309B, 0x309C}
_OTHER_ID_CONTINUE = {0x00B7, 0x0387, *range(0x1369, 0x1372), 0x19DA}


class TaskLike(Protocol):
    dataset: str
    language: str
    task_id: str
    code_masked: str
    reference_name: str


@dataclass(frozen=True)
class EvaluationTask:
    """Minimal adapter for the unheaded id, code_masked, target CSV rows."""

    dataset: str
    language: str
    task_id: str
    code_masked: str
    reference_name: str

    @property
    def key(self) -> str:
        return f"{self.dataset}:{self.language}:{self.task_id}"


@dataclass(frozen=True)
class _Reference:
    code: str
    spans: tuple[tuple[int, int], ...]  # Unicode character offsets
    source_kind: str


def canonical_language(language: str) -> str:
    try:
        return _ALIASES[language.casefold().strip()]
    except (AttributeError, KeyError) as exc:
        raise ValueError(f"Unsupported language: {language!r}") from exc


def _unicode_start(char: str) -> bool:
    return (unicodedata.category(char) in {"Lu", "Ll", "Lt", "Lm", "Lo", "Nl"}
            or ord(char) in _OTHER_ID_START)


def _unicode_continue(char: str) -> bool:
    return (_unicode_start(char) or unicodedata.category(char) in {"Mn", "Mc", "Nd", "Pc"}
            or ord(char) in _OTHER_ID_CONTINUE)


def valid_identifier(name: str | None, language: str, *, rust_edition: int = 2024) -> bool:
    """Check an unescaped, usable local/parameter spelling in a pinned language mode.

    Java uses Java identifier character categories; JS/TS use ECMAScript
    ID_Start/ID_Continue plus ``$``, ``_`` and joiners. Go uses Unicode
    letters/digits. Rust raw identifiers are accepted except the four forbidden
    path keywords. C++ implementation-reserved double underscores and leading
    underscore-uppercase spellings are excluded. Contextual legality and name
    collisions and binding capture require a separate resolution tool; parsing
    alone cannot check them.
    """
    lang = canonical_language(language)
    if not isinstance(name, str) or not name or name in _FORBIDDEN_OUTPUTS:
        return False
    try:
        name.encode("utf-8")
    except UnicodeEncodeError:
        return False
    if lang == "java":
        start = lambda c: c in "_$" or unicodedata.category(c) in {
            "Lu", "Ll", "Lt", "Lm", "Lo", "Nl", "Sc", "Pc"}
        part = lambda c: start(c) or unicodedata.category(c) in {"Mn", "Mc", "Nd", "Cf"}
        return name not in _JAVA_RESERVED and start(name[0]) and all(map(part, name[1:]))
    if lang == "python":
        if not name.isidentifier() or keyword.iskeyword(name) or name == "__debug__":
            return False
        try:
            ast.parse(f"{name} = None\n")
        except SyntaxError:  # includes assignment to __debug__
            return False
        return True
    if lang in {"javascript", "typescript"}:
        start = lambda c: c in "_$" or _unicode_start(c)
        part = lambda c: start(c) or _unicode_continue(c) or c in "\u200c\u200d"
        return (name not in _ECMASCRIPT_RESERVED and start(name[0])
                and all(map(part, name[1:])))
    if lang == "go":
        start = lambda c: c == "_" or unicodedata.category(c).startswith("L")
        part = lambda c: start(c) or unicodedata.category(c) == "Nd"
        return (name != "_" and name not in _GO_RESERVED and start(name[0])
                and all(map(part, name[1:])))
    if lang == "rust":
        if rust_edition not in {2015, 2018, 2021, 2024}:
            raise ValueError("Rust edition must be 2015, 2018, 2021 or 2024")
        raw = name.startswith("r#")
        base = name[2:] if raw else name
        if not base or base == "_" or not base.isidentifier():
            return False
        if raw:
            return base not in {"self", "Self", "super", "crate"}
        reserved = _RUST_RESERVED - {"async", "await", "dyn", "try"}
        if rust_edition >= 2018:
            reserved |= {"async", "await", "dyn", "try"}
        if rust_edition >= 2024:
            reserved.add("gen")
        return base not in reserved
    # C++ local/parameter names; leading underscore lowercase is permitted.
    return (name.isidentifier() and name not in _CPP_RESERVED and "__" not in name
            and not (len(name) > 1 and name[0] == "_" and name[1].isupper()))


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _checked_spans(raw: Any, target: str, site_count: int) -> tuple[tuple[int, int], ...]:
    if not isinstance(raw, list) or len(raw) != site_count:
        raise ValueError("target_spans count differs from masked site count")
    spans: list[tuple[int, int]] = []
    prior_end = 0
    for item in raw:
        if (not isinstance(item, list) or len(item) != 2
                or type(item[0]) is not int or type(item[1]) is not int):
            raise ValueError("target_span must contain two integer character offsets")
        start, end = item
        if start < prior_end or end - start != len(target):
            raise ValueError("target_spans overlap or have wrong target length")
        spans.append((start, end))
        prior_end = end
    return tuple(spans)


def _stack_reference(task: TaskLike, provenance: Mapping[str, Any]) -> _Reference:
    if not isinstance(provenance, Mapping):
        raise ValueError("provenance row is not an object")
    masked, target = task.code_masked, task.reference_name
    if (provenance.get("id") != str(task.task_id)
            or provenance.get("target") != target
            or canonical_language(provenance.get("language")) != canonical_language(task.language)
            or provenance.get("masked_sha256") != _sha(masked)
            or provenance.get("occurrence_count") != masked.count(MARKER)):
        raise ValueError("provenance identity, target, mask hash or site count mismatch")
    spans = _checked_spans(provenance.get("target_spans"), target, masked.count(MARKER))
    pieces: list[str] = []
    masked_cursor = original_cursor = 0
    for start, end in spans:
        gap = start - original_cursor
        if masked_cursor + gap > len(masked):
            raise ValueError("target_spans exceed masked source")
        pieces.append(masked[masked_cursor:masked_cursor + gap])
        masked_cursor += gap
        if masked[masked_cursor:masked_cursor + len(MASK_SLOT)] != MASK_SLOT:
            raise ValueError("masked source does not match space-delimited mask policy")
        masked_cursor += len(MASK_SLOT)
        pieces.append(target)
        original_cursor = end
    pieces.append(masked[masked_cursor:])
    restored = "".join(pieces)
    if _sha(restored) != provenance.get("original_sha256"):
        raise ValueError("restored source SHA-256 differs from provenance")
    if "size_bytes" in provenance and len(restored.encode("utf-8")) != provenance["size_bytes"]:
        raise ValueError("restored source byte count differs from provenance")
    if any(restored[start:end] != target for start, end in spans):
        raise ValueError("target_spans do not point to restored target")
    return _Reference(restored, spans, "stack_v3_sha_verified")


def _legacy_java_reference(task: TaskLike) -> _Reference:
    pieces: list[str] = []
    spans: list[tuple[int, int]] = []
    cursor = 0
    output_chars = 0
    while True:
        marker = task.code_masked.find(MARKER, cursor)
        if marker < 0:
            pieces.append(task.code_masked[cursor:])
            break
        prefix = task.code_masked[cursor:marker]
        pieces.extend((prefix, task.reference_name))
        output_chars += len(prefix)
        spans.append((output_chars, output_chars + len(task.reference_name)))
        output_chars += len(task.reference_name)
        cursor = marker + len(MARKER)
    if not spans:
        raise ValueError("masked source has no target marker")
    return _Reference("".join(pieces), tuple(spans), "legacy_java_reference_recovery_no_source_hash")


def _candidate_patch(reference: _Reference, target: str, candidate: str) -> _Reference:
    pieces: list[str] = []
    spans: list[tuple[int, int]] = []
    cursor = output_chars = 0
    for start, end in reference.spans:
        if reference.code[start:end] != target:
            raise ValueError("reference span no longer points to target")
        prefix = reference.code[cursor:start]
        pieces.extend((prefix, candidate))
        output_chars += len(prefix)
        spans.append((output_chars, output_chars + len(candidate)))
        output_chars += len(candidate)
        cursor = end
    pieces.append(reference.code[cursor:])
    return _Reference("".join(pieces), tuple(spans), reference.source_kind)


@lru_cache(maxsize=8)
def _parser(language: str) -> Any:
    from tree_sitter_language_pack import get_parser
    return get_parser(language)


def _byte_spans(code: str, spans: tuple[tuple[int, int], ...]) -> set[tuple[int, int]]:
    boundaries = [0]
    for char in code:
        boundaries.append(boundaries[-1] + len(char.encode("utf-8")))
    return {(boundaries[start], boundaries[end]) for start, end in spans}


def _inspect(code: str, spans: tuple[tuple[int, int], ...], grammar: str) -> dict[str, Any]:
    source = code.encode("utf-8")
    root = _parser(grammar).parse(source).root_node
    if root.has_error:
        return {"parseable": False, "all_target_nodes": False, "fingerprint": None}
    targets = _byte_spans(code, spans)
    found: set[tuple[int, int]] = set()
    digest = hashlib.sha256()
    stack = [(root, "")]
    while stack:
        node, field = stack.pop()
        digest.update(field.encode("utf-8") + b":" + node.type.encode("utf-8")
                      + b":" + str(node.is_named).encode("ascii") + b":"
                      + str(node.child_count).encode("ascii") + b";")
        if node.child_count:
            stack.extend((node.children[index], node.field_name_for_child(index) or "")
                         for index in range(node.child_count - 1, -1, -1))
            continue
        span = (node.start_byte, node.end_byte)
        if span in targets and node.type in {"identifier", "type_identifier"}:
            found.add(span)
            value = b"<TARGET>"
        else:
            value = source[node.start_byte:node.end_byte]
        digest.update(str(len(value)).encode() + b":" + value)
    return {"parseable": True, "all_target_nodes": found == targets,
            "fingerprint": digest.hexdigest()}


def _reference_inspection(reference: _Reference, language: str) -> tuple[str, dict[str, Any]]:
    grammar = canonical_language(language)
    result = _inspect(reference.code, reference.spans, grammar)
    if grammar == "typescript" and not result["parseable"]:
        tsx = _inspect(reference.code, reference.spans, "tsx")
        if tsx["parseable"]:
            return "tsx", tsx
    return grammar, result


def evaluate_task(task: TaskLike, predicted_name: str | None, *,
                  provenance: Mapping[str, Any] | None = None,
                  backend_error: str | None = None,
                  rust_edition: int = 2024) -> dict[str, Any]:
    """Score one planned S1 task; a missing or failed prediction remains a row."""
    language = canonical_language(task.language)
    if not all((task.dataset, str(task.task_id), task.reference_name)):
        raise ValueError("Task identity and reference must be nonempty")
    expected_sites = task.code_masked.count(MARKER)
    if not expected_sites:
        raise ValueError("Task has no masked target sites")
    key = f"{task.dataset}:{task.language}:{task.task_id}"
    name_valid = valid_identifier(predicted_name, language, rust_edition=rust_edition)
    usable = name_valid and backend_error is None
    error = backend_error or (None if name_valid else "invalid_or_missing_identifier")
    record: dict[str, Any] = {
        "task_key": key, "dataset": task.dataset, "language": task.language,
        "id": str(task.task_id), "expected_sites": expected_sites,
        "language_mode": (f"rust_{rust_edition}" if language == "rust" else
                          "ecmascript_strict_module" if language in {"javascript", "typescript"} else
                          "java_9_plus" if language == "java" else
                          "cpp_20_plus_keyword_policy" if language == "cpp" else
                          "python_runtime" if language == "python" else "go_spec"),
        "predicted_name": predicted_name,
        "raw_identifier_lexically_valid": name_valid,
        "valid_identifier": bool(usable),
        "predicted_sites": expected_sites if usable else 0,
        "complete_site_coverage": bool(usable),
        "name_exact": bool(usable and predicted_name == task.reference_name),
        "all_sites_exact": bool(usable and predicted_name == task.reference_name),
        "error": error, "reference_source_kind": None, "reference_restore_error": None,
        "reference_sha256": None,
        "reference_parseable": None, "all_reference_sites_identifier": None,
        "parse_eligible": None, "parse_eligibility_reason": None,
        "parse_grammar": None, "patch_parse_success": None,
        "patch_structure_preserved": None, "patch_sha256": None,
        "binding_eligible": None, "binding_preserved": None,
        "compile_eligible": None, "compile_preserved": None,
    }
    try:
        if language == "java" and task.dataset == "refineid" and provenance is None:
            reference = _legacy_java_reference(task)
        elif provenance is None:
            raise ValueError("Stack v3 syntax evaluation requires provenance")
        else:
            reference = _stack_reference(task, provenance)
    except (KeyError, TypeError, ValueError, UnicodeError) as exc:
        record["reference_restore_error"] = str(exc)
        record["parse_eligibility_reason"] = "reference_restore_failed"
        return record
    record["reference_source_kind"] = reference.source_kind
    record["reference_sha256"] = _sha(reference.code)
    patch = None
    if usable:
        assert isinstance(predicted_name, str)
        patch = _candidate_patch(reference, task.reference_name, predicted_name)
        record["patch_sha256"] = _sha(patch.code)
    try:
        grammar, inspected = _reference_inspection(reference, language)
    except (ImportError, OSError) as exc:
        record["parse_eligibility_reason"] = "parser_unavailable"
        record["reference_restore_error"] = f"{type(exc).__name__}: {exc}"
        return record
    record["parse_grammar"] = grammar
    record["reference_parseable"] = inspected["parseable"]
    record["all_reference_sites_identifier"] = inspected["all_target_nodes"]
    if not inspected["parseable"]:
        record["parse_eligible"] = False
        record["parse_eligibility_reason"] = "reference_parse_error"
        return record
    if not inspected["all_target_nodes"]:
        record["parse_eligible"] = False
        record["parse_eligibility_reason"] = "reference_site_not_identifier"
        return record
    record["parse_eligible"] = True
    record["parse_eligibility_reason"] = "eligible"
    # Eligibility is a property of the reference, independent of model output.
    # Failure on an eligible task is False, never NA or silently removed.
    record["patch_parse_success"] = False
    record["patch_structure_preserved"] = False
    if not usable:
        return record
    assert patch is not None
    inspected_patch = _inspect(patch.code, patch.spans, grammar)
    record["patch_parse_success"] = inspected_patch["parseable"]
    record["patch_structure_preserved"] = bool(
        inspected_patch["parseable"] and inspected_patch["all_target_nodes"]
        and inspected_patch["fingerprint"] == inspected["fingerprint"])
    return record


def evaluate_campaign(tasks: Sequence[TaskLike], predictions: Mapping[str, str | None], *,
                      provenance_by_key: Mapping[str, Mapping[str, Any]] | None = None,
                      errors_by_key: Mapping[str, str] | None = None,
                      rust_edition: int = 2024, enforce_runtime_receipt: bool = True) -> dict[str, Any]:
    """Return one record per planned task and rates with explicit denominators."""
    if enforce_runtime_receipt:
        expected = json.loads(Path(__file__).with_name("dependency_receipt.json").read_text(encoding="utf-8"))
        actual = dependency_receipt()
        if actual != expected:
            raise RuntimeError(f"Language-evaluation runtime differs from pinned receipt: {actual}")
    if not tasks:
        raise ValueError("Planned task cohort is empty")
    keys = [f"{task.dataset}:{task.language}:{task.task_id}" for task in tasks]
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate task keys in planned cohort")
    if set(predictions) - set(keys):
        raise ValueError("Predictions contain task keys outside planned cohort")
    if errors_by_key and set(errors_by_key) - set(keys):
        raise ValueError("Backend errors contain task keys outside planned cohort")
    provenance_by_key = provenance_by_key or {}
    errors_by_key = errors_by_key or {}
    records = [evaluate_task(task, predictions.get(key),
                             provenance=provenance_by_key.get(key),
                             backend_error=errors_by_key.get(key) or (
                                 "missing_prediction" if key not in predictions else None),
                             rust_edition=rust_edition)
               for task, key in zip(tasks, keys)]
    total = len(records)
    eligible = [record for record in records if record["parse_eligible"] is True]
    syntax_unknown = sum(record["parse_eligible"] is None for record in records)
    def rate(numerator: int, denominator: int) -> float | None:
        return numerator / denominator if denominator else None
    summary = {
        "planned_tasks": total, "scored_tasks": total,
        "parser_runtime": dependency_receipt(),
        "expected_sites": sum(record["expected_sites"] for record in records),
        "missing_prediction_tasks": sum(key not in predictions for key in keys),
        "error_tasks": sum(record["error"] is not None for record in records),
        "valid_identifier": {"numerator": sum(record["valid_identifier"] for record in records),
                             "denominator": total},
        "raw_identifier_lexically_valid": {
            "numerator": sum(record["raw_identifier_lexically_valid"] for record in records),
            "denominator": total},
        "complete_site_coverage": {"numerator": sum(record["complete_site_coverage"] for record in records),
                                   "denominator": total},
        "all_sites_exact": {"numerator": sum(record["all_sites_exact"] for record in records),
                            "denominator": total},
        "parse_eligibility": {
            "eligible_tasks": len(eligible), "planned_tasks": total,
            "coverage": rate(len(eligible), total) if syntax_unknown == 0 else None,
            "eligibility_unknown_tasks": syntax_unknown,
            "parser_unavailable_tasks": sum(
                record["parse_eligibility_reason"] == "parser_unavailable"
                for record in records),
            "reference_restore_failed_tasks": sum(
                record["parse_eligibility_reason"] == "reference_restore_failed"
                for record in records),
            "reference_parse_error_tasks": sum(
                record["parse_eligibility_reason"] == "reference_parse_error"
                for record in records),
            "reference_site_not_identifier_tasks": sum(
                record["parse_eligibility_reason"] == "reference_site_not_identifier"
                for record in records),
        },
        "patch_parse_success": {
            "numerator": sum(record["patch_parse_success"] is True for record in eligible),
            "denominator": len(eligible),
            "rate": rate(sum(record["patch_parse_success"] is True for record in eligible),
                         len(eligible)) if syntax_unknown == 0 else None,
        },
        "patch_structure_preserved": {
            "numerator": sum(record["patch_structure_preserved"] is True for record in eligible),
            "denominator": len(eligible),
            "rate": rate(sum(record["patch_structure_preserved"] is True for record in eligible),
                         len(eligible)) if syntax_unknown == 0 else None,
        },
        "binding_preserved": {"numerator": None, "denominator": None, "rate": None},
        "compile_preserved": {"numerator": None, "denominator": None, "rate": None},
    }
    for metric in ("valid_identifier", "raw_identifier_lexically_valid",
                   "complete_site_coverage", "all_sites_exact"):
        summary[metric]["rate"] = rate(summary[metric]["numerator"], total)
    return {"records": records, "summary": summary}


def dependency_receipt() -> dict[str, Any]:
    """Record the runtime used for a syntax evaluation, including Unicode data."""
    def version(name: str) -> str | None:
        try:
            return importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            return None
    return {
        "python": platform.python_version(),
        "unicode_database": unicodedata.unidata_version,
        "tree_sitter": version("tree-sitter"),
        "tree_sitter_language_pack": version("tree-sitter-language-pack"),
        "grammar_selection": "typescript then tsx on reference parse failure; fixed for patch",
    }
