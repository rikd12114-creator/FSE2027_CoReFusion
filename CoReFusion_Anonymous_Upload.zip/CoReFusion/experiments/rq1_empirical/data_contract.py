"""Audit and freeze the seven RQ1 S1 test inputs without changing them.

Run from the repository root with the Stack v3 environment, for example::

    .venv-stack-v3/bin/python -m experiments.rq1_empirical.data_contract

The output contains hashes and provenance pointers, not source text or labels.
An identical input/configuration produces identical JSON bytes. A nonzero exit
means that the written report contains one or more failures.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from itertools import combinations
import csv
import hashlib
import json
from pathlib import Path
import sys
from typing import Any


MASK = "[MASK]"
MASK_SLOT = f" {MASK} "
DEFAULT_CONFIG = Path("configs/rq1_empirical/datasets.json")
DEFAULT_OUTPUT = Path("results/rq1_empirical/audit/data_manifest.json")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _canonical_hash(value: Any) -> str:
    data = json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return sha256_bytes(data.encode("utf-8"))


def restore_stack_snapshot(masked: str, target: str, spans: list[list[int]]) -> str:
    """Exactly invert build.mask_spans using original character offsets.

    This never normalizes line endings or trims the whitespace inserted by the
    builder. Replacing ``[MASK]`` alone would leave artificial spaces behind.
    """
    if not spans or not isinstance(target, str) or not target:
        raise ValueError("missing target or target spans")
    output: list[str] = []
    original_cursor = masked_cursor = 0
    for span in spans:
        if (not isinstance(span, list) or len(span) != 2
                or type(span[0]) is not int or type(span[1]) is not int):
            raise ValueError("target span must be a pair of integer character offsets")
        start, end = span
        if start < original_cursor or end - start != len(target):
            raise ValueError("overlapping, unsorted, or wrong-length target span")
        gap = start - original_cursor
        output.append(masked[masked_cursor:masked_cursor + gap])
        masked_cursor += gap
        if masked[masked_cursor:masked_cursor + len(MASK_SLOT)] != MASK_SLOT:
            raise ValueError("masked text does not match target spans and mask policy")
        masked_cursor += len(MASK_SLOT)
        output.append(target)
        original_cursor = end
    output.append(masked[masked_cursor:])
    restored = "".join(output)
    if len(spans) != masked.count(MASK):
        raise ValueError("span count differs from masked site count")
    return restored


def _failure(report: dict, *, code: str, message: str, dataset: str | None = None,
             language: str | None = None, record_id: str | None = None) -> None:
    item: dict[str, str] = {"code": code, "message": message}
    for name, value in (("dataset", dataset), ("language", language), ("id", record_id)):
        if value is not None:
            item[name] = value
    report["failures"].append(item)


def _safe_input_path(root: Path, relative: str) -> Path:
    path = root / relative
    if path.resolve() != root.resolve() and root.resolve() not in path.resolve().parents:
        raise ValueError(f"input path escapes repository root: {relative}")
    return path


def _read_csv(path: Path) -> list[list[str]]:
    # newline="" is required: ordinary text-mode universal-newline handling
    # would turn embedded CRLF source into LF and invalidate original_sha256.
    csv.field_size_limit(sys.maxsize)
    with path.open("r", encoding="utf-8", newline="") as stream:
        return list(csv.reader(stream))


def _read_provenance(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        rows = [json.loads(line) for line in stream]
    if any(not isinstance(row, dict) for row in rows):
        raise ValueError("provenance contains a non-object JSON line")
    return rows


def _check_file(report: dict, dataset: dict, root: Path, relative: str,
                expected_sha256: str, label: str) -> Path | None:
    try:
        path = _safe_input_path(root, relative)
        actual = sha256_file(path)
    except (OSError, ValueError) as error:
        _failure(report, code="missing_or_unsafe_file", message=f"{relative}: {error}",
                 dataset=dataset["dataset"], language=dataset["language"])
        return None
    dataset["files"][label] = {"path": relative, "sha256": actual,
                               "pinned_sha256": expected_sha256,
                               "matches_pin": actual == expected_sha256}
    if actual != expected_sha256:
        _failure(report, code="pinned_sha256_mismatch", message=relative,
                 dataset=dataset["dataset"], language=dataset["language"])
    return path


def _audit_release_package(report: dict, summary: dict, root: Path,
                           release_dir: str, validate_release: bool) -> dict | None:
    dataset, language = summary["dataset"], summary["language"]
    manifest_path = _check_file(report, summary, root, f"{release_dir}/manifest.json",
                                summary["release_manifest_sha256"], "release_manifest")
    provenance_path = _check_file(report, summary, root, f"{release_dir}/provenance.jsonl",
                                  summary["provenance_sha256"], "provenance")
    if manifest_path is None or provenance_path is None:
        return None
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not isinstance(manifest, dict):
            raise ValueError("release manifest is not an object")
        summary["upstream_dataset"] = manifest.get("upstream_dataset")
        summary["upstream_revision"] = manifest.get("upstream_revision")
        summary["source_sampling"] = manifest.get("source_sampling")
        if manifest.get("language") != language:
            raise ValueError("release manifest language differs from frozen config")
        declared_files = manifest.get("files")
        if not isinstance(declared_files, dict):
            raise ValueError("release manifest files must be an object")
        for name, expected in declared_files.items():
            member = _safe_input_path(root, f"{release_dir}/{name}")
            actual = sha256_file(member)
            summary["files"][name] = {"path": f"{release_dir}/{name}",
                                      "sha256": actual, "declared_sha256": expected,
                                      "matches_declaration": actual == expected}
            if actual != expected:
                _failure(report, code="release_member_sha256_mismatch",
                         message=f"{release_dir}/{name}", dataset=dataset, language=language)
        sampling = manifest.get("source_sampling")
        if not isinstance(sampling, dict) or sampling.get("source_mode") != "official_pinned_parquet":
            raise ValueError("release source mode is not official_pinned_parquet")
        if validate_release:
            from experiments.stack_v3_refineid.release import validate_package
            validation = validate_package(_safe_input_path(root, release_dir))
            summary["package_validation"] = {"status": "passed", "result": validation}
        else:
            summary["package_validation"] = {"status": "not_run"}
    except (OSError, ValueError, KeyError, ImportError) as error:
        summary["package_validation"] = {"status": "failed", "reason": str(error)}
        _failure(report, code="release_package_invalid", message=str(error),
                 dataset=dataset, language=language)
        return None
    try:
        return {"manifest": manifest, "rows": _read_provenance(provenance_path)}
    except (OSError, UnicodeError, ValueError) as error:
        _failure(report, code="provenance_unreadable", message=str(error),
                 dataset=dataset, language=language)
        return None


def audit_datasets(root: Path, config: dict, *, config_path: str,
                   config_sha256: str, validate_releases: bool = True) -> dict:
    """Return a deterministic report; preserve every failure in `failures`."""
    report: dict[str, Any] = {
        "schema_version": 1,
        "config": {"path": config_path, "sha256": config_sha256},
        "task_key_fields": ["dataset", "language", "id"],
        "datasets": [], "tasks": [], "overlap": {}, "checks": {}, "failures": [],
        "limitations": {
            "legacy_java": "No per-row source provenance, original-source hash, original character spans, or verified pre-rename version is supplied. CSV format and masked-site counts can be checked, but symbol binding, full-token masking, parse/build success, and developer preference cannot be inferred.",
            "stack_v3": "Source snapshots provide original names and reversible mask spans, but syntax/spelling selection does not prove one compiler binding or an observed rename event.",
            "leakage": "Exact content/repository overlap is audited here. Near-clone and training-corpus contamination checks are still outstanding; absence of overlaps would not prove no pretraining exposure.",
            "development_split": "No independent repo-disjoint development/calibration split is included in these frozen test files. It must be sourced separately before prompt/model selection."
        },
    }
    if config.get("schema_version") != 1 or not isinstance(config.get("datasets"), list):
        _failure(report, code="bad_config", message="expected schema_version=1 and datasets list")
        report["status"] = "failed"
        return report

    seen_keys: set[tuple[str, str, str]] = set()
    repo_languages: dict[str, set[str]] = defaultdict(set)
    repo_rows: dict[str, int] = defaultdict(int)
    content_languages: dict[str, set[str]] = defaultdict(set)
    source_hash_languages: dict[str, set[str]] = defaultdict(set)
    normalized_source_languages: dict[str, set[str]] = defaultdict(set)
    source_restore_passed = 0
    source_restore_attempted = 0
    for spec in config["datasets"]:
        if not isinstance(spec, dict):
            _failure(report, code="bad_dataset_spec", message="dataset spec is not an object")
            continue
        dataset, language = spec.get("dataset"), spec.get("language")
        if not isinstance(dataset, str) or not isinstance(language, str):
            _failure(report, code="bad_dataset_spec", message="missing dataset/language")
            continue
        release_dir = spec.get("release_dir")
        csv_relative = f"{release_dir}/test.csv" if release_dir else spec.get("csv")
        summary: dict[str, Any] = {
            "dataset": dataset, "language": language, "csv": csv_relative,
            "reference_semantics": spec.get("reference_semantics"),
            "expected_rows": spec.get("expected_rows"),
            "expected_sites": spec.get("expected_sites"),
            "files": {}, "rows": 0, "sites": 0,
            "source_restore": "checked" if release_dir else "unavailable",
            "binding_verified": False,
        }
        if release_dir:
            summary["provenance_sha256"] = spec.get("provenance_sha256")
            summary["release_manifest_sha256"] = spec.get("release_manifest_sha256")
        report["datasets"].append(summary)
        if not isinstance(csv_relative, str) or not isinstance(spec.get("csv_sha256"), str):
            _failure(report, code="bad_dataset_spec", message="missing CSV path/hash",
                     dataset=dataset, language=language)
            continue
        csv_path = _check_file(report, summary, root, csv_relative,
                               spec["csv_sha256"], "test_csv")
        package = None
        if release_dir:
            package = _audit_release_package(report, summary, root, release_dir,
                                             validate_releases)
        if csv_path is None:
            continue
        try:
            csv_rows = _read_csv(csv_path)
        except (OSError, UnicodeError, csv.Error) as error:
            _failure(report, code="csv_unreadable", message=str(error),
                     dataset=dataset, language=language)
            continue
        summary["rows"] = len(csv_rows)
        if len(csv_rows) != spec.get("expected_rows"):
            _failure(report, code="row_count_mismatch", message=f"got {len(csv_rows)}",
                     dataset=dataset, language=language)
        provenance_rows = package["rows"] if package else []
        if release_dir and len(provenance_rows) != len(csv_rows):
            _failure(report, code="provenance_count_mismatch",
                     message=f"{len(provenance_rows)} provenance rows for {len(csv_rows)} CSV rows",
                     dataset=dataset, language=language)
        provenance_ids: set[str] = set()
        for row_index, row in enumerate(csv_rows):
            if len(row) != 3:
                _failure(report, code="bad_csv_row", message=f"row {row_index}: {len(row)} columns",
                         dataset=dataset, language=language)
                continue
            record_id, masked, target = row
            key = (dataset, language, record_id)
            if key in seen_keys:
                _failure(report, code="duplicate_task_key", message=f"row {row_index}",
                         dataset=dataset, language=language, record_id=record_id)
            seen_keys.add(key)
            if record_id != str(row_index):
                _failure(report, code="nonsequential_id", message=f"row {row_index}",
                         dataset=dataset, language=language, record_id=record_id)
            sites = masked.count(MASK)
            summary["sites"] += sites
            if sites == 0 or not target or any(character.isspace() for character in target):
                _failure(report, code="invalid_mask_or_target", message=f"row {row_index}",
                         dataset=dataset, language=language, record_id=record_id)
            if target and target in masked:
                _failure(report, code="visible_reference_name", message=f"row {row_index}",
                         dataset=dataset, language=language, record_id=record_id)
            task = {"dataset": dataset, "language": language, "id": record_id,
                    "csv_row_index": row_index, "sites": sites,
                    "row_sha256": _canonical_hash(row),
                    "masked_sha256": sha256_bytes(masked.encode("utf-8")),
                    "reference_sha256": sha256_bytes(target.encode("utf-8"))}
            if release_dir and row_index < len(provenance_rows):
                provenance = provenance_rows[row_index]
                pid = provenance.get("id")
                if not isinstance(pid, str):
                    _failure(report, code="invalid_provenance_id", message=f"row {row_index}",
                             dataset=dataset, language=language, record_id=record_id)
                elif pid in provenance_ids:
                    _failure(report, code="duplicate_provenance_id", message=f"row {row_index}",
                             dataset=dataset, language=language, record_id=str(pid))
                if isinstance(pid, str):
                    provenance_ids.add(pid)
                if pid != record_id or provenance.get("target") != target:
                    _failure(report, code="provenance_alignment", message=f"row {row_index}",
                             dataset=dataset, language=language, record_id=record_id)
                if provenance.get("masked_sha256") != task["masked_sha256"]:
                    _failure(report, code="provenance_masked_sha256", message=f"row {row_index}",
                             dataset=dataset, language=language, record_id=record_id)
                if provenance.get("occurrence_count") != sites:
                    _failure(report, code="provenance_site_count", message=f"row {row_index}",
                             dataset=dataset, language=language, record_id=record_id)
                if package and (provenance.get("source_dataset") != package["manifest"].get("upstream_dataset")
                                or provenance.get("source_revision") != package["manifest"].get("upstream_revision")
                                or provenance.get("language") != language):
                    _failure(report, code="provenance_source_mismatch", message=f"row {row_index}",
                             dataset=dataset, language=language, record_id=record_id)
                source = {name: provenance.get(name) for name in (
                    "repo_path", "commit_id", "file_path", "content_id", "original_sha256")}
                task["source"] = source
                repo = provenance.get("repo_path")
                if isinstance(repo, str) and repo:
                    canonical_repo = repo.casefold()
                    repo_languages[canonical_repo].add(language)
                    repo_rows[canonical_repo] += 1
                else:
                    _failure(report, code="missing_repository", message=f"row {row_index}",
                             dataset=dataset, language=language, record_id=record_id)
                content_id = provenance.get("content_id")
                if isinstance(content_id, str) and content_id:
                    content_languages[content_id].add(language)
                else:
                    _failure(report, code="missing_content_id", message=f"row {row_index}",
                             dataset=dataset, language=language, record_id=record_id)
                source_restore_attempted += 1
                try:
                    restored = restore_stack_snapshot(masked, target,
                                                       provenance.get("target_spans"))
                    restored_hash = sha256_bytes(restored.encode("utf-8"))
                    if restored_hash != provenance.get("original_sha256"):
                        raise ValueError("restored source differs from original_sha256")
                    if len(restored.encode("utf-8")) != provenance.get("size_bytes"):
                        raise ValueError("restored source differs from size_bytes")
                except (TypeError, ValueError) as error:
                    _failure(report, code="source_restore_failed", message=str(error),
                             dataset=dataset, language=language, record_id=record_id)
                else:
                    source_restore_passed += 1
                    source_hash_languages[restored_hash].add(language)
                    normalized_source_hash = sha256_bytes("".join(restored.split()).encode("utf-8"))
                    normalized_source_languages[normalized_source_hash].add(language)
                    task["source"]["restored_sha256"] = restored_hash
            report["tasks"].append(task)
        if summary["sites"] != spec.get("expected_sites"):
            _failure(report, code="site_count_mismatch", message=f"got {summary['sites']}",
                     dataset=dataset, language=language)
        summary["restored_rows"] = (sum(1 for task in report["tasks"]
                                        if task["dataset"] == dataset and task["language"] == language
                                        and task.get("source", {}).get("restored_sha256"))
                                    if release_dir else None)

    release_languages = sorted({item["language"] for item in report["datasets"]
                                if item["source_restore"] == "checked"})
    if not any(item["language"] == "Java" and item["source_restore"] == "unavailable"
               for item in report["datasets"]):
        report["limitations"].pop("legacy_java", None)
    overlaps = {repo: sorted(languages) for repo, languages in repo_languages.items()
                if len(languages) > 1}
    pairwise: dict[str, int] = defaultdict(int)
    for languages in overlaps.values():
        for left, right in combinations(languages, 2):
            pairwise[f"{left}|{right}"] += 1
    report["overlap"] = {
        "scope": f"{len(release_languages)} source-backed Stack v3 languages: {', '.join(release_languages)}",
        "repository_normalization": "Unicode casefold of repo_path; exact path retained in per-task source",
        "unique_repository_paths": len(repo_languages),
        "repositories_in_multiple_languages": len(overlaps),
        "rows_in_multi_language_repositories": sum(repo_rows[repo] for repo in overlaps),
        "pairwise_repository_counts": dict(sorted(pairwise.items())),
        "multi_language_repositories": overlaps,
        "content_ids_in_multiple_languages": sum(len(languages) > 1 for languages in content_languages.values()),
        "exact_source_sha256_in_multiple_languages": sum(len(languages) > 1 for languages in source_hash_languages.values()),
        "whitespace_stripped_sha256_in_multiple_languages": sum(
            len(languages) > 1 for languages in normalized_source_languages.values()),
        "near_clone_detection": "not_run",
    }
    report["checks"] = {
        "dataset_count": len(report["datasets"]),
        "task_count": len(report["tasks"]),
        "unique_task_keys": len(seen_keys),
        "masked_sites": sum(dataset["sites"] for dataset in report["datasets"]),
        "snapshot_restore_attempted": source_restore_attempted,
        "snapshot_restore_passed": source_restore_passed,
        "failure_count": len(report["failures"]),
    }
    report["status"] = "passed" if not report["failures"] else "failed"
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    root = args.repo_root.resolve()
    config_path = args.config if args.config.is_absolute() else root / args.config
    output_path = args.output if args.output.is_absolute() else root / args.output
    config = json.loads(config_path.read_text(encoding="utf-8"))
    report = audit_datasets(root, config, config_path=str(config_path.relative_to(root)),
                            config_sha256=sha256_file(config_path))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
                           encoding="utf-8")
    print(json.dumps({"status": report["status"], "checks": report["checks"],
                      "output": str(output_path)}, sort_keys=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
