"""Verify existing pinned native-FIM / CodeT5 snapshots against Hub hashes.

No weights are downloaded. A receipt is written only after every cached file
matches the pinned public commit and all shards named by the index are present.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path

from huggingface_hub import HfApi


# Exact revisions are from the original 2026-09-17 cached-snapshot receipt.
MODELS: dict[str, tuple[str, str, int, str]] = {
    "codellama-7b-base": (
        "codellama/CodeLlama-7b-hf", "6c284d1468fe6c413cf56183e69b194dcfa27fe6", 2, "safetensors"),
    "codellama-13b-base": (
        "codellama/CodeLlama-13b-hf", "8da65ff4ee20f74ecd107ca9d54f9f121b279860", 3, "safetensors"),
    "starcoder2-3b-base": (
        "bigcode/starcoder2-3b", "733247c55e3f73af49ce8e9c7949bf14af205928", 1, "safetensors"),
    "starcoder2-7b-base": (
        "bigcode/starcoder2-7b", "bb9afde76d7945da5745592525db122d4d729eb1", 3, "safetensors"),
    "deepseek-coder-1p3b-base": (
        "deepseek-ai/deepseek-coder-1.3b-base", "c919139c3a9b4070729c8b2cca4847ab29ca8d94", 1, "pytorch_bin"),
    "deepseek-coder-6p7b-base": (
        "deepseek-ai/deepseek-coder-6.7b-base", "ce2207a8bfef3ee92bd7dd4cc31c52cfa0046912", 2, "safetensors"),
    "qwen25-coder-1p5b-base": (
        "Qwen/Qwen2.5-Coder-1.5B", "df3ce67c0e24480f20468b6ef2894622d69eb73b", 1, "safetensors"),
    "qwen25-coder-3b-base": (
        "Qwen/Qwen2.5-Coder-3B", "09d9bc5d376b0cfa0100a0694ea7de7232525803", 2, "safetensors"),
    "qwen25-coder-7b-base": (
        "Qwen/Qwen2.5-Coder-7B", "0396a76181e127dfc13e5c5ec48a8cee09938b02", 4, "safetensors"),
    "qwen25-coder-14b-base": (
        "Qwen/Qwen2.5-Coder-14B", "f2ad5164aade432d6d56c24bb71589184d5d613d", 6, "safetensors"),
    "starcoder2-15b-base": (
        "bigcode/starcoder2-15b", "46d44742909c03ac8cee08eb03fdebce02e193ec", 14, "safetensors"),
    "codegemma-2b-base": (
        "google/codegemma-2b", "e7583edabd3dd48a9c705974a9456852f1205ab1", 2, "safetensors"),
    "codegemma-7b-base": (
        "google/codegemma-7b", "2ec970089fe8f083d10d1ce6bac30538ac4badaa", 4, "safetensors"),
    "codet5-small": (
        "Salesforce/codet5-small", "b1ee9570c289f21b5922b9c768a1ce12957bf968", 1, "pytorch_bin"),
    "codet5-base": (
        "Salesforce/codet5-base", "02cd2d31bb7c6d0e4d91156167b2de044989c733", 1, "pytorch_bin"),
    "codet5-large": (
        "Salesforce/codet5-large", "4ca0fb4dc19d81c35a7dffe4356d8a6236a687b4", 1, "pytorch_bin"),
    "codet5p-2b": (
        "Salesforce/codet5p-2b", "0083d4d638746e6c9ee3dbd504e6dd68738e3c87", 1, "pytorch_bin"),
    "codet5p-6b": (
        "Salesforce/codet5p-6b", "e546267d1d0134b99f37dbbae0c65e1aa8e30ce2", 2, "pytorch_bin_sharded"),
    "codet5p-16b": (
        "Salesforce/codet5p-16b", "c3c152ddccf996eaf06f1cef9acdd88a134d1032", 5, "pytorch_bin_sharded"),
}


def hub_cache_name(model_id: str) -> str:
    return "models--" + model_id.replace("/", "--")


def file_digests(path: Path) -> tuple[str, str]:
    size = path.stat().st_size
    sha256 = hashlib.sha256()
    git_sha1 = hashlib.sha1(f"blob {size}\0".encode("ascii"))
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            sha256.update(block)
            git_sha1.update(block)
    return sha256.hexdigest(), git_sha1.hexdigest()


def required_cached_files(snapshot: Path, *, shard_count: int, weight_format: str) -> list[Path]:
    files = sorted(path for path in snapshot.iterdir() if path.is_file())
    names = {path.name for path in files}
    if not {"config.json", "tokenizer_config.json"} <= names or not (
        "tokenizer.json" in names or {"vocab.json", "merges.txt"} <= names
    ):
        raise ValueError("Pinned snapshot lacks config or tokenizer")
    if weight_format == "safetensors":
        if shard_count == 1 and "model.safetensors" in names:
            shards = {"model.safetensors"}
            if "model.safetensors.index.json" in names:
                raise ValueError("Unexpected index for a single safetensors file")
        else:
            shards = {name for name in names if name.startswith("model-") and name.endswith(".safetensors")}
            if "model.safetensors.index.json" not in names or len(shards) != shard_count:
                raise ValueError("Pinned snapshot lacks all safetensors shards")
            index = json.loads((snapshot / "model.safetensors.index.json").read_text(encoding="utf-8"))
            if set(index["weight_map"].values()) != shards:
                raise ValueError("Shard index and cached safetensors shards differ")
    elif weight_format == "pytorch_bin":
        if shard_count != 1 or "pytorch_model.bin" not in names:
            raise ValueError("Pinned PyTorch snapshot lacks the original weight file")
    elif weight_format == "pytorch_bin_sharded":
        shards = {name for name in names if name.startswith("pytorch_model-") and name.endswith(".bin")}
        if "pytorch_model.bin.index.json" not in names or len(shards) != shard_count:
            raise ValueError("Pinned PyTorch snapshot lacks all sharded weight files")
        index = json.loads((snapshot / "pytorch_model.bin.index.json").read_text(encoding="utf-8"))
        if set(index["weight_map"].values()) != shards:
            raise ValueError("Shard index and cached PyTorch shards differ")
    else:
        raise ValueError("Unrecognized pinned weight format")
    return files


def verify_snapshot(model: str, cache: Path, api: HfApi) -> dict:
    model_id, revision, shard_count, weight_format = MODELS[model]
    snapshot = cache / hub_cache_name(model_id) / "snapshots" / revision
    if not snapshot.is_dir() or snapshot.name != revision:
        raise FileNotFoundError(f"Exact pinned snapshot missing: {snapshot}")
    files = required_cached_files(snapshot, shard_count=shard_count, weight_format=weight_format)
    info = api.model_info(model_id, revision=revision, files_metadata=True)
    if info.sha != revision or info.private:
        raise ValueError("Model revision is not the pinned public checkpoint")
    official = {item.rfilename: item for item in info.siblings}
    if {path.name for path in files} - set(official):
        raise ValueError("Cached snapshot contains a file absent from the pinned public revision")
    verified = []
    for path in files:
        sibling = official[path.name]
        if not isinstance(sibling.size, int) or path.stat().st_size != sibling.size:
            raise ValueError(f"Official file size mismatch: {path.name}")
        actual_sha256, actual_git_sha1 = file_digests(path)
        if sibling.lfs is not None:
            if actual_sha256 != sibling.lfs.sha256:
                raise ValueError(f"Official LFS SHA-256 mismatch: {path.name}")
            verification = "official_lfs_sha256"
        elif actual_git_sha1 == sibling.blob_id:
            verification = "official_git_blob_sha1"
        else:
            raise ValueError(f"Official Git blob SHA-1 mismatch: {path.name}")
        verified.append({"path": path.name, "size": sibling.size,
                         "sha256": actual_sha256, "verified_against": verification})
        print(f"verified {path.name} {sibling.size}", flush=True)
    return {
        "verified": True,
        "model_id": model_id,
        "revision": revision,
        "hub_gated_access": info.gated,
        "model_path": str(snapshot.resolve()),
        "source": "existing_huggingface_cache_snapshot",
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
        "files": verified,
        "total_bytes": sum(item["size"] for item in verified),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=sorted(MODELS), required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    if args.receipt.exists():
        raise FileExistsError(f"Verified receipt already exists: {args.receipt}")
    receipt = verify_snapshot(args.model, args.cache, HfApi())
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    temp = args.receipt.with_name(args.receipt.name + ".tmp")
    if temp.exists():
        raise FileExistsError(f"Stale receipt temp file: {temp}")
    with temp.open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temp.replace(args.receipt)
    print(json.dumps({"model_id": receipt["model_id"], "verified": True,
                      "files": len(receipt["files"]), "receipt": str(args.receipt)}, sort_keys=True))


if __name__ == "__main__":
    main()
