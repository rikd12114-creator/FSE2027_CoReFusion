"""Pinned local Hugging Face text-generation backend for the RQ1 S1 runner."""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .policy import parse_plain_identifier


@dataclass(frozen=True)
class HuggingFaceConfig:
    model_id: str
    revision: str
    model_dir: str
    max_input_tokens: int = 8192
    max_new_tokens: int = 48
    thinking: bool = False
    seed: int = 42
    receipt_path: str | None = None
    receipt_sha256: str | None = None

    def __post_init__(self) -> None:
        if not self.model_id or not self.model_dir or len(self.revision) != 40:
            raise ValueError("Model ID, pinned snapshot directory, and 40-char revision are required")
        if self.max_input_tokens < 128 or self.max_new_tokens < 1:
            raise ValueError("Invalid token budget")
        if bool(self.receipt_path) != bool(self.receipt_sha256):
            raise ValueError("Model receipt path and SHA-256 must be supplied together")


class HuggingFaceBackend:
    """One generation per task. No reference name enters the model input."""

    def __init__(self, config: HuggingFaceConfig):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        path = Path(config.model_dir).resolve()
        if not path.is_dir() or not (path / "config.json").exists():
            raise FileNotFoundError(f"Model snapshot missing config.json: {path}")
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA GPU required for the local model backend")
        self.config = config
        self.torch = torch
        self.path = path
        self.config_sha256 = hashlib.sha256((path / "config.json").read_bytes()).hexdigest()
        self.snapshot_path_matches_revision = path.name == config.revision
        self.receipt_verified = False
        if config.receipt_path:
            receipt_bytes = Path(config.receipt_path).read_bytes()
            if hashlib.sha256(receipt_bytes).hexdigest() != config.receipt_sha256:
                raise ValueError("Pinned model receipt SHA-256 changed")
            receipt = json.loads(receipt_bytes)
            if (not receipt.get("verified") or receipt.get("model_id") != config.model_id
                    or receipt.get("revision") != config.revision
                    or Path(receipt.get("model_path", "")).resolve() != path):
                raise ValueError("Pinned model receipt identity mismatch")
            for item in receipt.get("files", []):
                file_path = path / item["path"]
                if not file_path.is_file() or file_path.stat().st_size != item["size"]:
                    raise ValueError(f"Pinned model file missing/changed size: {item['path']}")
            self.receipt_verified = True
        self.tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True, trust_remote_code=False)
        self.model = AutoModelForCausalLM.from_pretrained(
            path, local_files_only=True, trust_remote_code=False,
            dtype=torch.bfloat16, attn_implementation="sdpa", device_map="auto",
        ).eval()
        placements = set(str(device) for device in getattr(self.model, "hf_device_map", {}).values())
        if any(device in {"cpu", "disk"} for device in placements):
            raise RuntimeError("GPU allocation insufficient: model was offloaded to CPU/disk")
        self.model_device = next(self.model.parameters()).device
        torch.manual_seed(config.seed)
        torch.cuda.manual_seed_all(config.seed)

    def generate(self, messages: list[dict[str, str]], *, expected_group_ids: list[str], request_id: str) -> dict[str, Any]:
        started = time.perf_counter()
        if expected_group_ids != ["target"]:
            raise ValueError("Current HF backend supports S1 single-target tasks only")
        language = messages[0]["content"].split("meaningful ", 1)[1].split(" identifier", 1)[0]
        tokenizer = self.tokenizer
        try:
            prompt_ids = tokenizer.apply_chat_template(
                messages, tokenize=True, add_generation_prompt=True,
                enable_thinking=self.config.thinking,
            )
        except Exception as exc:
            raise RuntimeError(f"Chat template failed for pinned model: {exc}") from exc
        if len(prompt_ids) + self.config.max_new_tokens > self.config.max_input_tokens:
            return {
                "status": "error", "names": {}, "content": None,
                "error": "prompt_exceeds_token_budget", "input_tokens": len(prompt_ids),
                "max_input_tokens": self.config.max_input_tokens,
                "elapsed_s": time.perf_counter() - started,
            }
        inputs = self.torch.tensor([prompt_ids], device=self.model_device)
        attention_mask = self.torch.ones_like(inputs)
        options: dict[str, Any] = {
            "max_new_tokens": self.config.max_new_tokens,
            "pad_token_id": tokenizer.pad_token_id if tokenizer.pad_token_id is not None else tokenizer.eos_token_id,
        }
        if self.config.thinking:
            options.update(do_sample=True, temperature=0.6, top_p=0.95)
        else:
            options.update(do_sample=True, temperature=0.7, top_p=0.8)
        with self.torch.inference_mode():
            generated = self.model.generate(input_ids=inputs, attention_mask=attention_mask, **options)
        tail = generated[0, len(prompt_ids):].tolist()
        raw = tokenizer.decode(tail, skip_special_tokens=False, clean_up_tokenization_spaces=False)
        content = raw.rsplit("</think>", 1)[-1]
        for marker in ("<|im_end|>", "<|endoftext|>", "<|eot_id|>"):
            content = content.replace(marker, "")
        name = parse_plain_identifier(content, language)
        truncated = len(tail) >= self.config.max_new_tokens and (
            not tail or tail[-1] != tokenizer.eos_token_id
        )
        if truncated:
            name = None
        return {
            "status": "ok" if name else "error", "names": {"target": name} if name else {},
            "content": raw, "error": None if name else ("truncated_generation" if truncated else "invalid_name_output"),
            "input_tokens": len(prompt_ids), "output_tokens": len(tail),
            "model": self.config.model_id, "revision": self.config.revision,
            "config_sha256": self.config_sha256,
            "snapshot_path_matches_revision": self.snapshot_path_matches_revision,
            "model_receipt_verified": self.receipt_verified,
            "gpu": self.torch.cuda.get_device_name(self.model_device),
            "thinking": self.config.thinking,
            "request_id": request_id,
            "elapsed_s": time.perf_counter() - started,
            "process_peak_cuda_allocated_bytes": self.torch.cuda.max_memory_allocated(self.model_device),
            "process_peak_cuda_reserved_bytes": self.torch.cuda.max_memory_reserved(self.model_device),
        }
