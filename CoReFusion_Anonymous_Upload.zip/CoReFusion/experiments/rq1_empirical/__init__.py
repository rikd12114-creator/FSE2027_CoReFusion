"""Versioned RQ1 identifier naming study."""
