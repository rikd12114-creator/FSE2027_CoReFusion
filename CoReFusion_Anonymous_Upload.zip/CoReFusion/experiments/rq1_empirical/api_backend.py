"""Pinned, non-streaming OpenRouter generation with conservative spend accounting.

No request or credential lookup happens at import/construction. Supply a mock
``transport`` for offline tests. Production keys are read only from ``api_key_env``.
Use one backend/state file per run; threads sharing a backend are serialized. A
state file is single-writer (not a distributed budget store).

``max_request_cost_usd`` is a caller-supplied conservative reservation, NOT a
server-enforced bill ceiling. Unknown costs (including timeouts and HTTP errors)
retain the reservation; an actual charge above it halts subsequent requests.
Use an account-side credit limit as well when a hard billing cap is required.
Persisted in-flight requests are never replayed automatically: a timeout/crash
cannot prove that the provider did not generate and charge for the request.

Protocol sources (consulted 2026-09-24):
https://openrouter.ai/docs/guides/routing/provider-selection
https://openrouter.ai/docs/guides/features/structured-outputs
https://openrouter.ai/docs/cookbook/administration/usage-accounting
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math
import os
from pathlib import Path
import re
import threading
import time
from typing import Any, Callable, Mapping, Sequence
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _hash(value: Any) -> str:
    return hashlib.sha256(_json(value).encode()).hexdigest()


def _money(value: Any) -> Decimal:
    if isinstance(value, bool):
        raise ValueError("money must be a finite nonnegative decimal")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError("money must be a finite nonnegative decimal") from None
    if not result.is_finite() or result < 0:
        raise ValueError("money must be a finite nonnegative decimal")
    return result


@dataclass(frozen=True)
class OpenRouterConfig:
    model: str
    provider: str
    budget_usd: str | float
    max_request_cost_usd: str | float
    max_task_cost_usd: str | float | None = None
    base_url: str = "https://openrouter.ai/api/v1"
    api_key_env: str = "OPENROUTER_API_KEY"
    max_tokens: int = 256
    temperature: float = 0.0
    top_p: float = 1.0
    seed: int | None = None
    reasoning: dict[str, Any] | None = None
    timeout_s: float = 60.0
    max_retries: int = 2
    backoff_initial_s: float = 1.0
    backoff_max_s: float = 30.0
    min_interval_s: float = 0.0
    expected_response_provider: str | None = None
    # Optional provider price ceilings, in USD/million tokens (request is USD).
    provider_max_price: dict[str, float] | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.model, str) or not self.model.strip() or self.model != self.model.strip():
            raise ValueError("an exact model ID is required")
        if self.model in {"openrouter/auto", "auto"} or self.model.endswith((":free", ":nitro", ":floor", ":online")):
            raise ValueError("automatic/routing model variants are not pinned model IDs")
        if not isinstance(self.provider, str) or not self.provider.strip() or self.provider != self.provider.strip():
            raise ValueError("an exact provider slug is required")
        url = urlsplit(self.base_url)
        if url.scheme != "https" or not url.hostname or url.username or url.password or url.query or url.fragment:
            raise ValueError("base_url must be HTTPS without credentials, query, or fragment")
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", self.api_key_env):
            raise ValueError("api_key_env must name an environment variable")
        budget, reserve = _money(self.budget_usd), _money(self.max_request_cost_usd)
        if reserve <= 0 or reserve > budget:
            raise ValueError("a positive request reservation within the total budget is required")
        if self.max_task_cost_usd is not None and _money(self.max_task_cost_usd) < reserve:
            raise ValueError("task budget must cover at least one request reservation")
        if type(self.max_tokens) is not int or self.max_tokens < 1:
            raise ValueError("max_tokens must be positive")
        if type(self.max_retries) is not int or not 0 <= self.max_retries <= 10:
            raise ValueError("max_retries must be between zero and ten")
        for name in ("timeout_s", "backoff_initial_s", "backoff_max_s", "min_interval_s", "temperature", "top_p"):
            value = getattr(self, name)
            if isinstance(value, bool) or not math.isfinite(value) or value < 0:
                raise ValueError(f"{name} must be finite and nonnegative")
        if self.timeout_s <= 0 or self.top_p <= 0 or self.top_p > 1 or self.temperature > 2:
            raise ValueError("invalid timeout or sampling parameters")
        if self.seed is not None and type(self.seed) is not int:
            raise ValueError("seed must be an integer")
        if self.reasoning is not None and not isinstance(self.reasoning, dict):
            raise ValueError("reasoning must be an explicit parameter object")
        if self.provider_max_price is not None:
            if not self.provider_max_price or set(self.provider_max_price) - {"prompt", "completion", "request"}:
                raise ValueError("unsupported provider price ceiling")
            for value in self.provider_max_price.values():
                _money(value)
        _json(asdict(self))  # Reject non-JSON or nonfinite nested parameters.


@dataclass
class HTTPResponse:
    status_code: int
    body: str | bytes | dict[str, Any]
    headers: Mapping[str, str] = field(default_factory=dict)


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # Never forward Authorization to a redirected destination.


def urllib_transport(*, url: str, headers: Mapping[str, str], payload: dict, timeout_s: float) -> HTTPResponse:
    request = Request(url, data=_json(payload).encode(), headers=dict(headers), method="POST")
    try:
        with build_opener(_NoRedirect()).open(request, timeout=timeout_s) as response:
            return HTTPResponse(response.status, response.read(), dict(response.headers))
    except HTTPError as error:
        return HTTPResponse(error.code, error.read(), dict(error.headers))


class NameOutputError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def _reject_nonfinite(value):
    raise ValueError("nonfinite JSON number")


def parse_name_output(content: str, expected_group_ids: Sequence[str]) -> dict[str, str]:
    """Parse exact group coverage; language-specific identifier checks are separate.

    Canonical form is ``{"names": {"group-id": "name"}}``. For one group only,
    ``{"name": "name"}`` is also accepted. Markdown/prose is not repaired.
    """
    try:
        value = json.loads(content, object_pairs_hook=_unique_object, parse_constant=_reject_nonfinite)
    except (ValueError, TypeError):
        raise NameOutputError("invalid_json", "response content is not unique-key JSON") from None
    if isinstance(value, dict) and set(value) == {"name"} and len(expected_group_ids) == 1:
        names = {expected_group_ids[0]: value["name"]}
    elif isinstance(value, dict) and set(value) == {"names"} and isinstance(value["names"], dict):
        names = value["names"]
    else:
        raise NameOutputError("invalid_name_schema", "expected a names mapping")
    if set(names) != set(expected_group_ids):
        raise NameOutputError("group_coverage_mismatch", "response groups differ from requested groups")
    for name in names.values():
        if not isinstance(name, str) or not name or len(name) > 512 or any(c.isspace() for c in name):
            raise NameOutputError("invalid_name_value", "name must be a nonempty single spelling of at most 512 characters")
    return names


def _schema(groups: Sequence[str]) -> dict:
    return {"type": "object", "properties": {"names": {
        "type": "object", "properties": {group: {"type": "string"} for group in groups},
        "required": list(groups), "additionalProperties": False,
    }}, "required": ["names"], "additionalProperties": False}


def _redact(value: Any, secret: str) -> Any:
    if isinstance(value, str):
        return value.replace(secret, "[REDACTED]") if secret else value
    if isinstance(value, dict):
        return {_redact(k, secret): _redact(v, secret) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(v, secret) for v in value]
    return value


class OpenRouterBackend:
    """One durable, auditable generation stream; constructed without network access.

    ``transport`` takes keyword ``url, headers, payload, timeout_s`` and returns
    ``HTTPResponse``. ``environ`` is injectable for tests. Successful/error results
    are cached by request ID plus full payload hash, including the schema. The
    runner should use stable, namespaced request IDs and supply ``state_path``.
    """
    def __init__(self, config: OpenRouterConfig, *, transport: Callable = urllib_transport,
                 sleep: Callable = time.sleep, monotonic: Callable = time.monotonic,
                 environ: Mapping[str, str] | None = None, state_path: str | Path | None = None):
        self.config = config
        self.transport, self.sleep, self.monotonic = transport, sleep, monotonic
        self.environ = os.environ if environ is None else environ
        self.state_path = Path(state_path) if state_path is not None else None
        self.config_sha256 = _hash(asdict(config))
        self._lock = threading.RLock()
        self._last_attempt_at = None
        self._state = {"version": 1, "config_sha256": self.config_sha256,
                       "accounted_cost_usd": "0", "halted": False, "requests": {}, "tasks": {}}
        if self.state_path is not None and self.state_path.exists():
            self.restore_state(json.loads(self.state_path.read_text(encoding="utf-8")))

    def export_state(self) -> dict:
        with self._lock:
            return deepcopy(self._state)

    def restore_state(self, state: dict) -> None:
        with self._lock:
            if state.get("version") != 1 or state.get("config_sha256") != self.config_sha256:
                raise ValueError("API resume configuration mismatch")
            if (not isinstance(state.get("requests"), dict) or not isinstance(state.get("tasks"), dict)
                    or type(state.get("halted")) is not bool):
                raise ValueError("invalid API state")
            _money(state.get("accounted_cost_usd"))
            for amount in state["tasks"].values():
                _money(amount)
            _json(state)
            self._state = deepcopy(state)

    def _save(self) -> None:
        if self.state_path is not None:
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.state_path.with_name(self.state_path.name + ".tmp")
            with temporary.open("w", encoding="utf-8") as stream:
                stream.write(_json(self._state) + "\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.state_path)

    def _payload(self, messages: Sequence[dict], groups: Sequence[str]) -> dict:
        if not messages or any(not isinstance(m, dict) or not isinstance(m.get("content"), str)
                               or m.get("role") not in {"system", "user", "assistant"} for m in messages):
            raise ValueError("messages must contain text system/user/assistant messages")
        if not groups or any(not isinstance(g, str) or not g for g in groups) or len(set(groups)) != len(groups):
            raise ValueError("expected_group_ids must be nonempty unique strings")
        provider = {"only": [self.config.provider], "order": [self.config.provider],
                    "allow_fallbacks": False, "require_parameters": True}
        if self.config.provider_max_price is not None:
            provider["max_price"] = deepcopy(self.config.provider_max_price)
        payload = {"model": self.config.model, "messages": deepcopy(list(messages)),
                   "provider": provider, "stream": False, "max_tokens": self.config.max_tokens,
                   "temperature": self.config.temperature, "top_p": self.config.top_p,
                   "response_format": {"type": "json_schema", "json_schema": {
                       "name": "identifier_names", "strict": True, "schema": _schema(groups)}}}
        if self.config.seed is not None:
            payload["seed"] = self.config.seed
        if self.config.reasoning is not None:
            payload["reasoning"] = deepcopy(self.config.reasoning)
        return payload

    def generate(self, messages: Sequence[dict], *, expected_group_ids: Sequence[str] = ("target",),
                 request_id: str, task_id: str | None = None) -> dict:
        """Generate once (plus bounded retries).

        Pass the same ``task_id`` across group calls or agent turns to share a
        task budget. It defaults to ``request_id`` for one-call direct inference.
        """
        with self._lock:
            if _hash(asdict(self.config)) != self.config_sha256:
                raise ValueError("API configuration changed after construction")
            if not isinstance(request_id, str) or not request_id:
                raise ValueError("a stable nonempty request_id is required")
            task_id = request_id if task_id is None else task_id
            if not isinstance(task_id, str) or not task_id:
                raise ValueError("task_id must be a nonempty string")
            payload = self._payload(messages, expected_group_ids)
            digest = _hash(payload)
            previous = self._state["requests"].get(request_id)
            if previous is not None:
                if previous["payload_sha256"] != digest or previous.get("task_id") != task_id:
                    raise ValueError("request_id reused with a different prompt/schema/parameters")
                if previous.get("result") is not None:
                    result = deepcopy(previous["result"])
                    result["cache_hit"] = True
                    return result
                return self._error_result(request_id, digest, "interrupted_request",
                                          "persisted in-flight request requires manual reconciliation; no automatic replay")
            if self._state["halted"]:
                return self._error_result(request_id, digest, "budget_halted", "a previous request exceeded its cost reservation")
            # Only this point reads the configured environment variable.
            key = self.environ.get(self.config.api_key_env)
            if not isinstance(key, str) or not key.strip():
                return self._error_result(request_id, digest, "missing_api_key", "configured API key environment variable is unset")
            if any(c.isspace() for c in key):
                return self._error_result(request_id, digest, "invalid_api_key", "API key contains whitespace")
            result = self._error_result(request_id, digest, "unstarted", "request has not started")
            result.update({"prompt_sha256": _hash(list(messages)),
                           "schema_sha256": _hash(payload["response_format"]),
                           "task_id": task_id,
                           "started_at": datetime.now(timezone.utc).isoformat()})
            record = {"payload_sha256": digest, "task_id": task_id, "result": None, "attempts": result["attempts"]}
            self._state["requests"][request_id] = record
            started = self.monotonic()
            reservation = _money(self.config.max_request_cost_usd)
            task_limit = _money(self.config.max_task_cost_usd if self.config.max_task_cost_usd is not None else self.config.budget_usd)
            task_cost = _money(self._state["tasks"].get(task_id, "0"))
            prior_task_cost = task_cost
            for index in range(self.config.max_retries + 1):
                accounted = _money(self._state["accounted_cost_usd"])
                if accounted + reservation > _money(self.config.budget_usd) or task_cost + reservation > task_limit:
                    result["error"] = {"code": "budget_exhausted", "message": "insufficient budget for a conservative request reservation"}
                    break
                self._state["accounted_cost_usd"] = str(accounted + reservation)
                task_cost += reservation
                self._state["tasks"][task_id] = str(task_cost)
                attempt = {"index": index, "status_code": None, "reported_cost_usd": None,
                           "accounted_cost_usd": str(reservation), "cost_status": "reserved_unknown",
                           "error": None, "raw_response": None}
                result["attempts"].append(attempt)
                self._save()  # Persist a charge reservation before the side effect.
                if self._last_attempt_at is not None:
                    delay = self.config.min_interval_s - (self.monotonic() - self._last_attempt_at)
                    if delay > 0:
                        self.sleep(delay)
                self._last_attempt_at = self.monotonic()
                retry = False
                retry_after = 0.0
                try:
                    response = self.transport(url=self.config.base_url.rstrip("/") + "/chat/completions",
                                              headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"},
                                              payload=deepcopy(payload), timeout_s=self.config.timeout_s)
                    if not isinstance(response, HTTPResponse):
                        raise TypeError("transport must return HTTPResponse")
                    attempt["status_code"] = response.status_code
                    body = response.body.decode("utf-8") if isinstance(response.body, bytes) else response.body
                    try:
                        data = json.loads(body, object_pairs_hook=_unique_object, parse_constant=_reject_nonfinite) if isinstance(body, str) else body
                        if not isinstance(data, dict):
                            raise ValueError("response must be an object")
                        _json(data)
                    except (ValueError, TypeError):
                        data = None
                    # Invalid JSON is retained as text, including mock dicts with NaN.
                    raw = data if data is not None else (body if isinstance(body, str) else str(body))
                    attempt["raw_response"] = _redact(raw, key)
                    usage = data.get("usage") if isinstance(data, dict) else None
                    cost = None
                    if isinstance(usage, dict) and usage.get("cost") is not None:
                        try:
                            cost = _money(usage["cost"])
                        except ValueError:
                            pass  # Malformed/missing cost is never treated as zero.
                    if cost is not None:
                        self._state["accounted_cost_usd"] = str(_money(self._state["accounted_cost_usd"]) - reservation + cost)
                        task_cost += cost - reservation
                        self._state["tasks"][task_id] = str(task_cost)
                        attempt.update(reported_cost_usd=str(cost), accounted_cost_usd=str(cost), cost_status="reported")
                        if cost > reservation:
                            self._state["halted"] = True
                    if data is not None:
                        result.update({"response_id": data.get("id"), "returned_model": data.get("model"),
                                       "returned_provider": data.get("provider"), "usage": _redact(usage, key),
                                       "cost_usd": str(cost) if cost is not None else None})
                    if self._state["halted"]:
                        attempt["error"] = {"code": "cost_reservation_exceeded", "message": "reported charge exceeded the configured request reservation; backend halted"}
                    elif response.status_code != 200:
                        attempt["error"] = {"code": "http_error", "message": f"HTTP {response.status_code}"}
                        retry = response.status_code == 429 or 500 <= response.status_code <= 599
                        try:
                            retry_after = max(0.0, float(next((v for k, v in response.headers.items() if k.lower() == "retry-after"), "0")))
                            if not math.isfinite(retry_after):
                                retry_after = 0.0
                        except (TypeError, ValueError):
                            retry_after = 0.0
                    elif data is None:
                        attempt["error"] = {"code": "invalid_response_json", "message": "HTTP body is not a JSON object"}
                    else:
                        self._parse_response(data, result, expected_group_ids)
                except NameOutputError as error:
                    attempt["error"] = {"code": error.code, "message": str(error)}
                except (TimeoutError, URLError, OSError) as error:
                    attempt["error"] = {"code": "transport_error", "message": type(error).__name__}
                    retry = True
                except (UnicodeError, TypeError, ValueError, KeyError) as error:
                    attempt["error"] = {"code": "invalid_response", "message": type(error).__name__}
                if attempt["error"] is not None:
                    result.update(status="error", error=attempt["error"])
                self._save()
                if not retry or index >= self.config.max_retries:
                    break
                delay = min(self.config.backoff_max_s, max(retry_after, self.config.backoff_initial_s * (2 ** index)))
                self.sleep(delay)
            result.update(latency_s=self.monotonic() - started, task_accounted_cost_usd=str(task_cost),
                          request_accounted_cost_usd=str(task_cost - prior_task_cost),
                          run_accounted_cost_usd=self._state["accounted_cost_usd"])
            result = _redact(result, key)
            record["result"] = deepcopy(result)
            self._save()
            return result

    def _parse_response(self, data: dict, result: dict, groups: Sequence[str]) -> None:
        if data.get("error") is not None:
            raise NameOutputError("api_error", "API returned an error object")
        returned_model, returned_provider = data.get("model"), data.get("provider")
        if returned_model is not None and returned_model != self.config.model:
            raise NameOutputError("model_mismatch", "returned model differs from frozen model ID")
        expected = self.config.expected_response_provider or self.config.provider
        normalize = lambda value: re.sub(r"[^a-z0-9]", "", value.lower())
        if returned_provider is not None and (not isinstance(returned_provider, str) or normalize(returned_provider) != normalize(expected)):
            raise NameOutputError("provider_mismatch", "returned provider differs from frozen provider")
        choices = data.get("choices")
        if not isinstance(choices, list) or len(choices) != 1 or not isinstance(choices[0], dict):
            raise NameOutputError("invalid_response_schema", "expected exactly one response choice")
        choice = choices[0]
        message = choice.get("message")
        if not isinstance(message, dict):
            raise NameOutputError("invalid_response_schema", "response message is missing")
        result.update(content=message.get("content"), finish_reason=choice.get("finish_reason"))
        if choice.get("finish_reason") != "stop":
            code = "truncated_output" if choice.get("finish_reason") == "length" else "incomplete_output"
            raise NameOutputError(code, "response did not finish with stop")
        if message.get("refusal") or not isinstance(message.get("content"), str):
            raise NameOutputError("missing_content", "response has no usable text content")
        names = parse_name_output(message["content"], groups)
        result.update(status="ok", error=None, names=names)

    def _error_result(self, request_id: str, digest: str, code: str, message: str) -> dict:
        return {"status": "error", "request_id": request_id, "payload_sha256": digest,
                "config_sha256": self.config_sha256, "requested_model": self.config.model,
                "requested_provider": self.config.provider, "returned_model": None,
                "returned_provider": None, "response_id": None, "content": None,
                "names": None, "usage": None, "cost_usd": None, "attempts": [],
                "cache_hit": False, "error": {"code": code, "message": message}}
