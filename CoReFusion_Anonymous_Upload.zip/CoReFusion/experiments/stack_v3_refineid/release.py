"""Validate and publish one Stack v3 ReFineID-format language release.

The package is five files: a headerless 1,000-row ``test.csv`` with
``id,code_masked,target`` columns, an equivalent ``test.parquet`` for the Hub
viewer, an ID-aligned ``provenance.jsonl``, a dataset card, and a manifest.
The default CLI action is local validation only.
``--push`` creates or updates a *public* Hub dataset and verifies a fresh,
anonymous readback at the immutable upload commit. Source code and credentials
are never printed by this module.
"""

from __future__ import annotations

import argparse
import csv
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import tempfile


FILES = frozenset({"README.md", "test.csv", "test.parquet", "provenance.jsonl", "manifest.json"})
HASHED_FILES = FILES - {"manifest.json"}
ROW_COUNT = 1_000
UPSTREAM_DATASET = "HuggingFaceCode/stack-v3-train"
UPSTREAM_REVISION = "8f3f25d86e44fd691428131efd17af75d4716499"
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_COMMIT = re.compile(r"[0-9a-f]{40}\Z")
_REPO = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]*/[A-Za-z0-9][A-Za-z0-9_.-]*\Z")


class ReleaseValidationError(ValueError):
    """The package or remote readback fails the release contract."""


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ReleaseValidationError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _declared_hash(value: object, filename: str) -> str:
    """Accept either a plain digest or a manifest entry with ``sha256``."""
    digest = value.get("sha256") if isinstance(value, dict) else value
    _require(isinstance(digest, str) and bool(_SHA256.fullmatch(digest)),
             f"invalid SHA-256 in manifest for {filename}")
    return digest


def _nonempty_description(value: object) -> bool:
    return isinstance(value, (str, dict, list)) and bool(value)


def _validate_manifest(root: Path) -> dict:
    try:
        manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    except (ValueError, UnicodeError) as error:
        raise ReleaseValidationError("manifest.json must be UTF-8 JSON") from error
    _require(isinstance(manifest, dict), "manifest.json must contain an object")
    _require(isinstance(manifest.get("language"), str) and bool(manifest["language"].strip()),
             "manifest language must be nonempty")
    _require(manifest.get("upstream_dataset") == UPSTREAM_DATASET,
             f"upstream_dataset must be {UPSTREAM_DATASET}")
    _require(manifest.get("upstream_revision") == UPSTREAM_REVISION,
             f"upstream_revision must be the pinned {UPSTREAM_REVISION}")
    _require(type(manifest.get("row_count")) is int and manifest["row_count"] == ROW_COUNT,
             f"manifest row_count must be {ROW_COUNT}")
    for field in ("source_sampling", "extraction_policy"):
        _require(_nonempty_description(manifest.get(field)), f"manifest {field} must be nonempty")
    _require(isinstance(manifest["source_sampling"], dict)
             and manifest["source_sampling"].get("source_mode") == "official_pinned_parquet",
             "public release requires source_sampling.source_mode=official_pinned_parquet")
    timestamp = manifest.get("generation_timestamp")
    _require(isinstance(timestamp, str) and bool(timestamp.strip()),
             "manifest generation_timestamp must be an ISO 8601 timestamp")
    try:
        parsed = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
    except ValueError as error:
        raise ReleaseValidationError("invalid generation_timestamp") from error
    _require(parsed.tzinfo is not None, "generation_timestamp must include a timezone")
    declared_files = manifest.get("files")
    _require(isinstance(declared_files, dict) and set(declared_files) == HASHED_FILES,
             "manifest files must list README.md, test.csv, test.parquet, and provenance.jsonl only")
    for name in HASHED_FILES:
        expected = _declared_hash(declared_files[name], name)
        _require(sha256_file(root / name) == expected, f"SHA-256 mismatch for {name}")
    return manifest


def _validate_csv(path: Path) -> tuple[list[tuple[str, str, str]], int]:
    csv.field_size_limit(sys.maxsize)
    sites = 0
    rows: list[tuple[str, str, str]] = []
    with path.open(newline="", encoding="utf-8") as stream:
        for index, row in enumerate(csv.reader(stream)):
            _require(index < ROW_COUNT, f"test.csv has more than {ROW_COUNT} rows")
            _require(len(row) == 3, f"test.csv:{index + 1}: expected three columns")
            record_id, code_masked, target = row
            _require(record_id == str(index), f"test.csv:{index + 1}: expected id {index}")
            _require(bool(code_masked.strip()) and "[MASK]" in code_masked,
                     f"test.csv:{index + 1}: missing masked code or [MASK] site")
            _require(bool(target) and target == target.strip() and not any(c.isspace() for c in target),
                     f"test.csv:{index + 1}: target must be one nonempty identifier spelling")
            rows.append((record_id, code_masked, target))
            sites += code_masked.count("[MASK]")
    _require(len(rows) == ROW_COUNT, f"test.csv must have exactly {ROW_COUNT} rows")
    return rows, sites


def _validate_parquet(path: Path, csv_rows: list[tuple[str, str, str]]) -> None:
    import pyarrow as pa
    import pyarrow.parquet as pq

    try:
        table = pq.read_table(path)
    except (OSError, pa.ArrowException) as error:
        raise ReleaseValidationError("test.parquet could not be read") from error
    columns = ["id", "code_masked", "target"]
    _require(table.column_names == columns, "test.parquet must have id, code_masked, target columns in order")
    _require(all(field.type == pa.string() for field in table.schema),
             "test.parquet columns must all have the Arrow string type")
    _require(table.num_rows == ROW_COUNT, f"test.parquet must have exactly {ROW_COUNT} rows")
    for index, (parquet_row, csv_row) in enumerate(zip(table.to_pylist(), csv_rows)):
        _require(tuple(parquet_row[name] for name in columns) == csv_row,
                 f"test.parquet:{index + 1}: row differs from test.csv")


def _validate_readme(path: Path) -> None:
    import yaml

    text = path.read_text(encoding="utf-8")
    _require(bool(text.strip()), "README.md is empty")
    match = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|\Z)", text, re.S)
    _require(match is not None, "README.md must have YAML front matter")
    try:
        metadata = yaml.safe_load(match.group(1))
    except yaml.YAMLError as error:
        raise ReleaseValidationError("README.md has invalid YAML front matter") from error
    _require(isinstance(metadata, dict) and isinstance(metadata.get("configs"), list),
             "README.md must declare dataset configs")
    default_configs = [entry for entry in metadata["configs"]
                       if isinstance(entry, dict) and entry.get("config_name") == "default"]
    _require(len(default_configs) == 1, "README.md must declare one default config")
    files = default_configs[0].get("data_files")
    _require(isinstance(files, list) and len(files) == 1
             and isinstance(files[0], dict) and files[0].get("split") == "test"
             and files[0].get("path") == "test.parquet",
             "README.md default/test split must point only to test.parquet")


def _validate_provenance(path: Path, csv_rows: list[tuple[str, str, str]], manifest: dict) -> None:
    count = 0
    with path.open(encoding="utf-8") as stream:
        for index, line in enumerate(stream):
            _require(index < ROW_COUNT, f"provenance.jsonl has more than {ROW_COUNT} rows")
            try:
                row = json.loads(line)
            except ValueError as error:
                raise ReleaseValidationError(f"provenance.jsonl:{index + 1}: invalid JSON") from error
            _require(isinstance(row, dict) and type(row.get("id")) is str
                     and row["id"] == str(index),
                     f"provenance.jsonl:{index + 1}: expected object with id {index}")
            _, code_masked, target = csv_rows[index]
            _require(row.get("target") == target,
                     f"provenance.jsonl:{index + 1}: target differs from test.csv")
            _require(type(row.get("occurrence_count")) is int
                     and row["occurrence_count"] == code_masked.count("[MASK]"),
                     f"provenance.jsonl:{index + 1}: occurrence_count differs from test.csv")
            _require(row.get("masked_sha256") == hashlib.sha256(code_masked.encode("utf-8")).hexdigest(),
                     f"provenance.jsonl:{index + 1}: masked_sha256 differs from test.csv")
            _require(row.get("source_dataset") == manifest["upstream_dataset"]
                     and row.get("source_revision") == manifest["upstream_revision"],
                     f"provenance.jsonl:{index + 1}: source dataset or revision differs from manifest")
            _require(row.get("license_type") == "permissive"
                     and isinstance(row.get("detected_licenses"), list)
                     and bool(row["detected_licenses"]),
                     f"provenance.jsonl:{index + 1}: missing permissive license provenance")
            count += 1
    _require(count == ROW_COUNT, f"provenance.jsonl must have exactly {ROW_COUNT} rows")


def validate_package(dataset_dir: Path) -> dict:
    """Validate bytes, format, row alignment and pinned source metadata locally."""
    root = Path(dataset_dir)
    _require(root.is_dir() and not root.is_symlink(), "dataset directory is missing or a symlink")
    for name in FILES:
        path = root / name
        _require(path.is_file() and not path.is_symlink(), f"missing or unsafe release file: {name}")
    manifest = _validate_manifest(root)
    _validate_readme(root / "README.md")
    csv_rows, sites = _validate_csv(root / "test.csv")
    _validate_parquet(root / "test.parquet", csv_rows)
    _validate_provenance(root / "provenance.jsonl", csv_rows, manifest)
    return {
        "validated": True,
        "language": manifest["language"],
        "upstream_dataset": UPSTREAM_DATASET,
        "upstream_revision": UPSTREAM_REVISION,
        "rows": ROW_COUNT,
        "mask_sites": sites,
        "files": {name: sha256_file(root / name) for name in sorted(FILES)},
    }


def _repository_info(api, repo_id: str, *, revision: str | None = None):
    try:
        arguments = {"repo_id": repo_id, "repo_type": "dataset"}
        if revision is not None:
            arguments["revision"] = revision
        return api.repo_info(**arguments)
    except Exception as error:
        if revision is None and getattr(getattr(error, "response", None), "status_code", None) == 404:
            return None
        raise


def verify_remote_package(dataset_dir: Path, *, repo_id: str, revision: str,
                          public_api=None, download_file=None, dataset_loader=None) -> dict:
    """Anonymously read back the exact public release at a full commit SHA."""
    _require(isinstance(repo_id, str) and bool(_REPO.fullmatch(repo_id)),
             "repo_id must be namespace/name")
    _require(isinstance(revision, str) and bool(_COMMIT.fullmatch(revision)),
             "revision must be a full 40-character commit SHA")
    local = validate_package(dataset_dir)
    if public_api is None or download_file is None:
        from huggingface_hub import HfApi, hf_hub_download
        public_api = public_api or HfApi(token=False)
        download_file = download_file or hf_hub_download
    if dataset_loader is None:
        from datasets import load_dataset
        dataset_loader = load_dataset
    info = _repository_info(public_api, repo_id, revision=revision)
    _require(getattr(info, "sha", None) == revision, "Hub returned a different commit")
    _require(getattr(info, "private", None) is False,
             "remote dataset is private or public visibility could not be verified")
    siblings = getattr(info, "siblings", None)
    _require(siblings is not None, "Hub did not return the remote file inventory")
    names = {entry.rfilename for entry in siblings}
    _require(FILES <= names and not (names - FILES - {".gitattributes"}),
             "remote commit must contain exactly the five release files and optional .gitattributes")
    with tempfile.TemporaryDirectory(prefix="stack-v3-refineid-readback-") as temporary:
        temp = Path(temporary)
        downloaded = temp / "package"
        downloaded.mkdir()
        for name in sorted(FILES):
            cached = download_file(repo_id=repo_id, filename=name, repo_type="dataset",
                                   revision=revision, token=False, force_download=True,
                                   cache_dir=str(temp / "hub-cache"))
            shutil.copyfile(cached, downloaded / name)
            _require(sha256_file(downloaded / name) == local["files"][name],
                     f"remote/local SHA-256 mismatch for {name}")
        remote = validate_package(downloaded)
        _require(remote["rows"] == local["rows"] and remote["mask_sites"] == local["mask_sites"],
                 "remote row or [MASK] count differs")
        try:
            loaded = dataset_loader(repo_id, revision=revision, split="test", token=False,
                                    cache_dir=str(temp / "datasets-cache"),
                                    download_mode="force_redownload")
        except Exception as error:
            raise ReleaseValidationError(
                f"public datasets.load_dataset failed ({type(error).__name__})") from error
        _require(len(loaded) == ROW_COUNT, "datasets.load_dataset did not return 1000 test rows")
        _require(getattr(loaded, "column_names", None) == ["id", "code_masked", "target"],
                 "datasets.load_dataset returned unexpected columns")
    return {"verified": True, "public": True, "repo_id": repo_id, "revision": revision,
            "rows": ROW_COUNT, "language": local["language"], "files": local["files"],
            "datasets_load_verified": True,
            "url": f"https://huggingface.co/datasets/{repo_id}/tree/{revision}"}


def _commit_revision(commit) -> str:
    revision = getattr(commit, "oid", None)
    if not isinstance(revision, str) or not _COMMIT.fullmatch(revision):
        url = getattr(commit, "commit_url", "")
        revision = url.rsplit("/", 1)[-1] if isinstance(url, str) else None
    _require(isinstance(revision, str) and bool(_COMMIT.fullmatch(revision)),
             "upload did not return a full immutable commit SHA")
    return revision


def publish_package(dataset_dir: Path, *, repo_id: str | None = None, push: bool = False,
                    api=None, public_api=None, download_file=None, dataset_loader=None) -> dict:
    """Dry-run by default; ``push=True`` uploads then verifies public readback."""
    if repo_id is not None:
        _require(bool(_REPO.fullmatch(repo_id)), "repo_id must be namespace/name")
    _require(not push or repo_id is not None, "--push requires --repo-id")
    local = validate_package(dataset_dir)
    if not push:
        return {**local, "pushed": False, "repo_id": repo_id}
    if api is None:
        from huggingface_hub import HfApi
        api = HfApi()
    # Only the validated, frozen five-file snapshot can cross the upload boundary.
    with tempfile.TemporaryDirectory(prefix="stack-v3-refineid-upload-") as temporary:
        staged = Path(temporary)
        for name in FILES:
            shutil.copyfile(Path(dataset_dir) / name, staged / name, follow_symlinks=False)
        snapshot = validate_package(staged)
        _require(snapshot["files"] == local["files"], "release changed during staging")
        info = _repository_info(api, repo_id)
        if info is None:
            api.create_repo(repo_id=repo_id, repo_type="dataset", private=False, exist_ok=False)
            info = _repository_info(api, repo_id)
        _require(getattr(info, "private", None) is False,
                 "destination dataset is private or public visibility could not be verified")
        existing = getattr(info, "siblings", None)
        if existing is not None:
            names = {entry.rfilename for entry in existing}
            _require(not (names - FILES - {".gitattributes"}),
                     "destination contains unrelated files; refusing to mix releases")
        commit = api.upload_folder(repo_id=repo_id, repo_type="dataset", folder_path=str(staged),
                                   allow_patterns=sorted(FILES),
                                   commit_message=f"Publish validated Stack v3 {snapshot['language']} ReFineID benchmark")
        revision = _commit_revision(commit)
        verified = verify_remote_package(staged, repo_id=repo_id, revision=revision,
                                         public_api=public_api, download_file=download_file,
                                         dataset_loader=dataset_loader)
    return {**local, "pushed": True, "public": True, "repo_id": repo_id,
            "revision": revision, "remote_verified": verified["verified"],
            "datasets_load_verified": verified["datasets_load_verified"], "url": verified["url"]}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-dir", type=Path, required=True)
    parser.add_argument("--repo-id", help="Public Hugging Face dataset namespace/name")
    parser.add_argument("--push", action="store_true", help="Upload the validated package and verify it anonymously")
    parser.add_argument("--verify-revision", help="Verify an existing public release at a full commit SHA")
    args = parser.parse_args(argv)
    if args.push and args.verify_revision:
        parser.error("--push and --verify-revision are mutually exclusive")
    if args.verify_revision and not args.repo_id:
        parser.error("--verify-revision requires --repo-id")
    try:
        if args.verify_revision:
            report = verify_remote_package(args.dataset_dir, repo_id=args.repo_id,
                                           revision=args.verify_revision)
        else:
            report = publish_package(args.dataset_dir, repo_id=args.repo_id, push=args.push)
    except (ReleaseValidationError, OSError, UnicodeError, csv.Error) as error:
        parser.exit(1, f"error: {error}\n")
    except Exception as error:
        # Network-library exceptions can contain signed URLs or credential hints.
        parser.exit(1, f"error: Hub operation failed ({type(error).__name__}); details withheld\n")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
