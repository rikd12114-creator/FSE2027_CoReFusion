"""Conservative, spelling-based Java identifier examples from complete methods.

This is a syntax-tree extractor, not a Java compiler or a binding resolver. A
sample masks every identifier token with one spelling within the method. Only
names backed by a parameter/local declaration are eligible. Ambiguous duplicate
declarations, member/type/method-name collisions, and occurrences outside a
local's lexical scope are rejected. Comments and literals are never occurrences.

All public offsets are Python string offsets (Unicode code points), even though
tree-sitter reports UTF-8 byte offsets. The caller owns model tokenization.
"""

from __future__ import annotations

from collections import defaultdict
from functools import lru_cache
import re
from typing import Any, Iterator


class JavaSourceRejected(ValueError):
    """Source cannot safely be processed; ``reason`` is stable for manifests."""

    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)


_UNICODE_ESCAPE = re.compile(r"\\u+[0-9a-fA-F]{4}")
_METHODS = {"method_declaration", "constructor_declaration"}
_NESTED_SCOPES = {
    "class_declaration", "interface_declaration", "enum_declaration",
    "record_declaration", "annotation_type_declaration", "class_body",
    "lambda_expression",
}
_DECLARATIONS = {
    "variable_declarator", "formal_parameter", "catch_formal_parameter", "instanceof_expression",
    "enhanced_for_statement", "resource", "type_parameter",
    "class_declaration", "interface_declaration", "enum_declaration",
    "record_declaration", "annotation_type_declaration", "enum_constant",
    "method_declaration", "constructor_declaration",
}
_BLOCK_SCOPES = {"block", "constructor_body", "switch_block"}


def _walk(node: Any) -> Iterator[Any]:
    stack = [node]
    while stack:
        current = stack.pop()
        yield current
        stack.extend(reversed(current.named_children))


@lru_cache(maxsize=1)
def _java_language() -> Any:
    try:
        from tree_sitter import Language
        import tree_sitter_java
    except ImportError as exc:
        raise ImportError(
            "Java extraction requires tree-sitter and tree-sitter-java; "
            "install experiments/stack_v2_java/requirements.txt"
        ) from exc
    return Language(tree_sitter_java.language())


def _is_field(node: Any, parent: Any, name: str) -> bool:
    return parent.child_by_field_name(name) == node


def _declaration_name(node: Any) -> bool:
    parent = node.parent
    return bool(parent and parent.type in _DECLARATIONS and _is_field(node, parent, "name"))


def _candidate_kind(node: Any, method: Any) -> str | None:
    parent = node.parent
    if not parent or not _is_field(node, parent, "name"):
        return None
    if parent.type == "formal_parameter" and parent.parent == method.child_by_field_name("parameters"):
        return "formal_parameter"
    if parent.type == "variable_declarator":
        declaration = parent.parent
        if declaration.type == "local_variable_declaration":
            return "local_variable"
        if declaration.type == "spread_parameter" and declaration.parent == method.child_by_field_name("parameters"):
            return "formal_parameter"
    if parent.type == "enhanced_for_statement":
        return "local_variable"
    return None


def _scope_for(node: Any, method: Any, kind: str) -> Any:
    if kind == "formal_parameter":
        return method
    if node.parent.type == "enhanced_for_statement":
        return node.parent
    declaration = node.parent.parent
    if declaration.parent.type == "for_statement":
        return declaration.parent
    scope = declaration.parent
    while scope is not None and scope != method:
        if scope.type in _BLOCK_SCOPES:
            return scope
        scope = scope.parent
    return method


def _is_variable_reference(node: Any) -> bool:
    """Exclude syntactic roles that unambiguously name something other than a variable."""
    if node.type != "identifier":
        return False
    parent = node.parent
    if parent is None or _declaration_name(node):
        return False
    if parent.type == "method_invocation" and _is_field(node, parent, "name"):
        return False
    if parent.type == "field_access" and _is_field(node, parent, "field"):
        return False
    if parent.type in {
        "scoped_identifier", "scoped_type_identifier", "method_reference",
        "labeled_statement", "break_statement", "continue_statement",
        "annotation", "marker_annotation", "element_value_pair",
        "inferred_parameters", "type_pattern", "record_pattern_component",
    }:
        return False
    return True


def extract_samples(code: str, *, min_occurrences: int = 2) -> list[dict[str, Any]]:
    """Return deterministic, declaration-backed masking candidates.

    Each result includes ``code`` (a complete method or constructor), ``target``,
    snippet-relative ``target_spans``, and source-relative ``file_target_spans``.
    Both span lists contain half-open ``[start, end]`` Unicode character offsets.
    ``snippet_start``/``snippet_end`` locate the snippet in the supplied file.

    A syntax error anywhere in the file rejects the file. Java Unicode escapes
    are rejected even inside literals/comments: Java processes eligible escapes
    before lexing, which otherwise invalidates both token meanings and offsets.
    Methods containing nested types, anonymous classes, or lambdas are omitted
    conservatively. No type checking or compilation is performed.
    """
    if not isinstance(code, str):
        raise TypeError("code must be a string")
    if isinstance(min_occurrences, bool) or not isinstance(min_occurrences, int) or min_occurrences < 2:
        raise ValueError("min_occurrences must be an integer >= 2")
    if _UNICODE_ESCAPE.search(code):
        raise JavaSourceRejected("java_unicode_escape")
    try:
        source = code.encode("utf-8")
    except UnicodeEncodeError as exc:
        raise JavaSourceRejected("invalid_unicode") from exc

    from tree_sitter import Parser

    tree = Parser(_java_language()).parse(source)
    if tree.root_node.has_error:
        raise JavaSourceRejected("parse_error")

    # Only token boundaries are read from this map; continuation-byte entries
    # intentionally remain absent to catch a broken parser/boundary assumption.
    byte_to_char = {0: 0}
    byte_offset = 0
    for char_offset, char in enumerate(code, start=1):
        byte_offset += len(char.encode("utf-8"))
        byte_to_char[byte_offset] = char_offset

    def span(node: Any) -> list[int]:
        return [byte_to_char[node.start_byte], byte_to_char[node.end_byte]]

    def spelling(node: Any) -> str:
        return source[node.start_byte:node.end_byte].decode("utf-8")

    results = []
    for method in _walk(tree.root_node):
        if method.type not in _METHODS:
            continue
        body = method.child_by_field_name("body")
        if body is None:
            continue
        nodes = list(_walk(method))
        if any(node != method and (node.type in _NESTED_SCOPES or node.type in _METHODS) for node in nodes):
            continue
        occurrences: dict[str, list[Any]] = defaultdict(list)
        declarations: dict[str, list[Any]] = defaultdict(list)
        candidates: list[tuple[Any, str]] = []
        for node in nodes:
            if node.type not in {"identifier", "type_identifier"}:
                continue
            name = spelling(node)
            occurrences[name].append(node)
            if _declaration_name(node):
                declarations[name].append(node)
            kind = _candidate_kind(node, method)
            if kind is not None:
                candidates.append((node, kind))

        snippet_start, snippet_end = span(method)
        for declaration, kind in candidates:
            target = spelling(declaration)
            matching = occurrences[target]
            if target == "_" or len(matching) < min_occurrences or len(declarations[target]) != 1:
                continue
            scope = _scope_for(declaration, method, kind)
            valid = True
            for occurrence in matching:
                if occurrence == declaration:
                    continue
                if not _is_variable_reference(occurrence):
                    valid = False
                    break
                # Parameter uses must be in the body, not method annotations or
                # other parameter declarations. Local uses must follow their
                # declaration and remain inside the containing lexical scope.
                start = body.start_byte if kind == "formal_parameter" else declaration.end_byte
                if occurrence.start_byte < start or occurrence.end_byte > scope.end_byte:
                    valid = False
                    break
                if declaration.parent.type == "enhanced_for_statement":
                    loop_body = declaration.parent.child_by_field_name("body")
                    if occurrence.start_byte < loop_body.start_byte:
                        valid = False
                        break
            if not valid:
                continue
            file_spans = [span(node) for node in matching]
            declaration_span = span(declaration)
            name_node = method.child_by_field_name("name")
            results.append({
                "code": code[snippet_start:snippet_end],
                "target": target,
                "target_spans": [[start - snippet_start, end - snippet_start] for start, end in file_spans],
                "file_target_spans": file_spans,
                "snippet_start": snippet_start,
                "snippet_end": snippet_end,
                "target_declaration_span": [value - snippet_start for value in declaration_span],
                "identifier_kind": kind,
                "method_name": spelling(name_node),
                "snippet_node_type": method.type,
                "occurrence_count": len(file_spans),
                "span_unit": "unicode_codepoints",
                "binding_policy": "spelling-based; not compiler-resolved",
            })
    return results
