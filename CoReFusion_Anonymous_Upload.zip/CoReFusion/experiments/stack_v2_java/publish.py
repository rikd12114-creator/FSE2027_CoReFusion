"""Dataset validation helpers used by the core identifier preprocessing code.

Publication and upload entrypoints are excluded from this source-only edition.
Character spans use Python offsets; token spans are half-open.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

from experiments.late_rename.prepare_data import lexical_tokens, normalize_repository, valid_identifier


ALLOWED_FILES = frozenset({"README.md", "manifest.json", "train.jsonl", "validation.jsonl"})
HASHED_FILES = ALLOWED_FILES - {"manifest.json"}
SPLITS = ("train", "validation")
DREAMON_MASK_TOKEN = "<|mask|>"
DREAMON_MASK_ID = 151666
DREAMON_BOS_ID = 151665
DREAMON_EOS_ID = 151643


class ValidationError(ValueError):
    """The release does not satisfy its manifest or training-data contract."""


def _require(condition, message):
    if not condition:
        raise ValidationError(message)


def sha256_file(path):
    """Hash large releases without retaining their JSONL bytes in memory."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _integers(value, name, *, allow_ignore=False):
    _require(isinstance(value, list) and bool(value), f"{name} must be a nonempty integer list")
    _require(all(type(x) is int and (x >= 0 or allow_ignore and x == -100) for x in value),
             f"{name} contains invalid token ids")
    return value


def _spans(value, length, name):
    _require(isinstance(value, list) and bool(value), f"{name} must be nonempty")
    end = -1
    for span in value:
        _require(isinstance(span, list) and len(span) == 2 and all(type(x) is int for x in span),
                 f"{name} must contain integer pairs")
        start, stop = span
        _require(0 <= start < stop <= length and start >= end, f"{name} are invalid or overlap")
        end = stop
    return value


def _replace_spans(code, spans, replacement):
    for start, end in reversed(spans):
        code = code[:start] + replacement + code[end:]
    return code


def validate_row(row, mask_token, mask_token_id, *, bos_token_id=None, eos_token_id=None):
    """Check supervision and loss scope without downloading a tokenizer.

    This checks structural consistency, not that an arbitrary tokenizer would
    produce the recorded ids. The builder records the pinned tokenizer revision.
    """
    _require(isinstance(row, dict), "row must be an object")
    for field in ("id", "repository", "code", "code_masked", "code_masked_template", "target"):
        _require(isinstance(row.get(field), str) and bool(row[field].strip()), f"missing {field}")
    _require(valid_identifier(row["target"]), "invalid target identifier")
    _require(isinstance(row.get("source"), dict) and bool(row["source"]), "missing source provenance")
    _require(row.get("corruption") == "all_identifier_tokens", "wrong corruption mode")
    code = row["code"]
    _require("[MASK]" not in code and mask_token not in code, "original code already contains mask text")
    _require(not re.search(r"\\u+[0-9a-fA-F]{4}", code), "Java Unicode escapes require upstream parsing")
    char_spans = _spans(row.get("target_spans"), len(code), "target_spans")
    expected_spans = [[start, end] for kind, text, start, end in lexical_tokens(code)
                      if kind == "identifier" and text == row["target"]]
    _require(char_spans == expected_spans, "target_spans must cover every lexical target identifier")
    _require(type(row.get("num_occurrences")) is int and row["num_occurrences"] == len(char_spans),
             "num_occurrences mismatch")
    target_ids = _integers(row.get("target_token_ids"), "target_token_ids")
    _require(mask_token_id not in target_ids, "target contains a mask token")
    _require(row["code_masked_template"] == _replace_spans(code, char_spans, "[MASK]"),
             "code_masked_template differs outside target spans")
    _require(row["code_masked"] == _replace_spans(code, char_spans, mask_token * len(target_ids)),
             "code_masked must contain one model mask per target subtoken")
    inputs = _integers(row.get("input_ids"), "input_ids")
    gold = _integers(row.get("gold_input_ids"), "gold_input_ids")
    labels = _integers(row.get("labels"), "labels", allow_ignore=True)
    _require(len(inputs) == len(gold) == len(labels), "input/gold/label lengths differ")
    _require(mask_token_id not in gold, "gold_input_ids contain a mask token")
    for position, boundary_id, name in ((0, bos_token_id, "BOS"), (-1, eos_token_id, "EOS")):
        if boundary_id is not None:
            _require(inputs[position] == gold[position] == boundary_id and labels[position] == -100,
                     f"invalid {name} boundary or boundary supervision")
    token_spans = _spans(row.get("target_token_spans"), len(inputs), "target_token_spans")
    _require(len(token_spans) == len(char_spans), "character/token occurrence counts differ")
    masked_positions = set()
    for start, end in token_spans:
        _require(start > 0, "supervised tokens must follow BOS")
        _require(gold[start:end] == target_ids, "target token span does not match ground truth")
        masked_positions.update(range(start, end))
    if "num_mask_tokens" in row:
        _require(type(row["num_mask_tokens"]) is int and row["num_mask_tokens"] == len(masked_positions),
                 "num_mask_tokens mismatch")
    for position, (source_id, gold_id, label) in enumerate(zip(inputs, gold, labels)):
        if position in masked_positions:
            _require(source_id == mask_token_id and label == gold_id,
                     f"incorrect target supervision at token {position}")
        else:
            _require(source_id == gold_id and label == -100,
                     f"context must remain unchanged and ignored at token {position}")
    return normalize_repository(row["repository"])


def validate_dataset(dataset_dir):
    """Verify the exact release inventory, SHA-256, row counts, and split hygiene."""
    root = Path(dataset_dir)
    _require(root.is_dir() and not root.is_symlink(), "dataset directory is missing or a symlink")
    entries = list(root.iterdir())
    _require({path.name for path in entries} == ALLOWED_FILES,
             "release directory must contain exactly README.md, manifest.json, train.jsonl, validation.jsonl")
    _require(all(path.is_file() and not path.is_symlink() for path in entries),
             "release files must be regular files; directories and symlinks are forbidden")
    try:
        manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    except (ValueError, UnicodeError) as exc:
        raise ValidationError("manifest.json is not valid UTF-8 JSON") from exc
    _require(isinstance(manifest, dict) and type(manifest.get("schema_version")) is int
             and manifest["schema_version"] == 1, "unsupported manifest schema_version")
    files = manifest.get("files")
    _require(isinstance(files, dict) and set(files) == HASHED_FILES,
             "manifest files must inventory README.md, train.jsonl, validation.jsonl")
    for name in sorted(HASHED_FILES):
        metadata = files[name]
        _require(isinstance(metadata, dict) and isinstance(metadata.get("sha256"), str)
                 and re.fullmatch(r"[0-9a-f]{64}", metadata["sha256"]), f"invalid SHA-256 for {name}")
        actual = sha256_file(root / name)
        _require(actual == metadata["sha256"], f"SHA-256 mismatch for {name}")
    tokenizer = manifest.get("tokenizer")
    _require(isinstance(tokenizer, dict), "missing tokenizer metadata")
    mask_token, mask_id = tokenizer.get("mask_token"), tokenizer.get("mask_token_id")
    _require(mask_token == DREAMON_MASK_TOKEN and type(mask_id) is int and mask_id == DREAMON_MASK_ID,
             "tokenizer mask token/id do not match pinned DreamOn")
    for key, expected in (("bos_token_id", DREAMON_BOS_ID), ("eos_token_id", DREAMON_EOS_ID)):
        if key in tokenizer:
            _require(type(tokenizer[key]) is int and tokenizer[key] == expected,
                     f"tokenizer {key} does not match pinned DreamOn")
    _require(bool((root / "README.md").read_text(encoding="utf-8").strip()), "empty dataset card")
    ids, repositories, fingerprints, counts = set(), {}, {}, {}
    declared_sources = manifest.get("source_datasets", [])
    contains_fixture = isinstance(declared_sources, list) and "synthetic-test-fixture" in declared_sources
    for split in SPLITS:
        name = split + ".jsonl"
        expected_rows = files[name].get("rows")
        _require(type(expected_rows) is int and expected_rows >= 0, f"invalid row count for {name}")
        count = 0
        with (root / name).open(encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                try:
                    row = json.loads(line)
                    repository = validate_row(row, mask_token, mask_id,
                                              bos_token_id=tokenizer.get("bos_token_id"),
                                              eos_token_id=tokenizer.get("eos_token_id"))
                    contains_fixture |= row["source"].get("dataset") == "synthetic-test-fixture"
                    _require(row["id"] not in ids, "duplicate row id")
                    ids.add(row["id"])
                    _require(repositories.get(repository, split) == split, "repository appears in both splits")
                    repositories[repository] = split
                    fingerprint = hashlib.sha256(row["code"].encode("utf-8")).hexdigest()
                    _require(fingerprints.get(fingerprint, split) == split, "identical code appears in both splits")
                    fingerprints[fingerprint] = split
                    count += 1
                except (ValueError, KeyError, TypeError) as exc:
                    raise ValidationError(f"{name}:{line_number}: {exc}") from exc
        _require(count == expected_rows, f"row count mismatch for {name}: expected {expected_rows}, found {count}")
        counts[split] = count
    _require(counts["train"] > 0, "training split is empty")
    return {"validated": True, "rows": counts, "files": sorted(ALLOWED_FILES), "manifest": manifest,
            "contains_synthetic_test_fixture": contains_fixture}


