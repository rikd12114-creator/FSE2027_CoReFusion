"""CPU-only, pinned DreamOn tokenizer and full-identifier recovery states."""
from __future__ import annotations

from experiments.late_rename.runtime import MODEL_ID, REVISION


def load_tokenizer(*, local_files_only=False):
    # This checkpoint uses the built-in Qwen2 tokenizer. Never load model weights
    # or execute remote model code during data preparation.
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID, revision=REVISION, trust_remote_code=False,
        use_fast=True, local_files_only=local_files_only,
    )
    expected = {"mask_token_id": 151666, "bos_token_id": 151665,
                "eos_token_id": 151643, "mask_token": "<|mask|>"}
    for name, value in expected.items():
        if getattr(tokenizer, name) != value:
            raise ValueError(f"Pinned DreamOn tokenizer mismatch: {name}")
    if tokenizer.convert_tokens_to_ids("<|expand|>") != 151667:
        raise ValueError("Pinned DreamOn expand token mismatch")
    return tokenizer


def replace_spans(code, spans, replacement):
    for start, end in reversed(spans):
        code = code[:start] + replacement + code[end:]
    return code


def encode_sample(sample, tokenizer, *, max_length=1024, max_target_tokens=16):
    """Segment encoding matches upstream multisite infilling, without cropping.

    Gold length is supplied at every occurrence: this is a controlled synthetic
    final-recovery state, not an actual sampled last step or unknown-length task.
    Labels at j must be scored by DreamOn raw logits at j-1.
    """
    code, target, spans = sample["code"], sample["target"], sample["target_spans"]
    if not spans or any(code[a:b] != target for a, b in spans):
        raise ValueError("invalid_target_spans")
    if any(a < 0 or a >= b or b > len(code) for a, b in spans):
        raise ValueError("invalid_target_spans")
    if any(b > c for (_, b), (c, _) in zip(spans, spans[1:])):
        raise ValueError("overlapping_target_spans")
    if "[MASK]" in code or any(token in code for token in tokenizer.all_special_tokens):
        raise ValueError("source_contains_reserved_token")
    target_ids = tokenizer.encode(target, add_special_tokens=False)
    if not 1 <= len(target_ids) <= max_target_tokens:
        raise ValueError("target_token_length")
    if tokenizer.decode(target_ids, clean_up_tokenization_spaces=False) != target:
        raise ValueError("target_token_roundtrip")
    gold, token_spans, cursor = [tokenizer.bos_token_id], [], 0
    for start, end in spans:
        gold.extend(tokenizer.encode(code[cursor:start], add_special_tokens=False))
        token_start = len(gold)
        gold.extend(target_ids)
        token_spans.append([token_start, len(gold)])
        cursor = end
    gold.extend(tokenizer.encode(code[cursor:], add_special_tokens=False))
    gold.append(tokenizer.eos_token_id)
    if len(gold) > max_length:
        raise ValueError("snippet_exceeds_token_budget")
    if tokenizer.decode(gold[1:-1], clean_up_tokenization_spaces=False) != code:
        raise ValueError("code_token_roundtrip")
    inputs, labels = list(gold), [-100] * len(gold)
    for start, end in token_spans:
        inputs[start:end] = [tokenizer.mask_token_id] * (end - start)
        labels[start:end] = gold[start:end]
    actual_masked = replace_spans(code, spans, tokenizer.mask_token * len(target_ids))
    if tokenizer.decode(inputs[1:-1], clean_up_tokenization_spaces=False) != actual_masked:
        raise ValueError("masked_token_roundtrip")
    return {
        "code_masked": actual_masked,
        "code_masked_template": replace_spans(code, spans, "[MASK]"),
        "input_ids": inputs, "labels": labels, "gold_input_ids": gold,
        "target_token_ids": target_ids, "target_token_spans": token_spans,
        "num_occurrences": len(spans), "num_mask_tokens": len(spans) * len(target_ids),
        "corruption": "all_identifier_tokens",
    }
