"""Audited numerical/seed/storage corrections around pinned upstream trainers.

The original repository remains unchanged. Runtime method source, a unified
diff, and hashes are stored in the new run. This is explicitly a corrected
upstream-framework experiment, not a byte-identical author-source execution.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import importlib
import inspect
import json
import os
from pathlib import Path
import random
import re
import subprocess
import sys
import textwrap

from .training import MODELS, acquire_export_lock, check_parameters, file_hash, require_finite, write_json

COMMITS = {"dreamon": "8a0a54918412eda9402a327646f7f067f7160ec8",
           "dreamcoder": "79d43878c55ba4e7474d5e0b6057d110b43acfcd"}
MASK_STATISTICS = {}


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise ValueError(f"Pinned upstream patch anchor must occur exactly once: {old!r}")
    return source.replace(old, new)


def patch_loss_source(source):
    mask_audit = ("_protocol_record_masks(self, loss_mask.reshape(labels.shape[0], -1).sum(-1), do_backward, "
                  "((shift_labels == self.tokenizer.eos_token_id) & loss_mask).reshape(labels.shape[0], -1).sum(-1))")
    if "eos_loss = eos_loss.sum() / eos_count" in source:
        anchor = "if self.config.diffusion.weight_eos and self.config.data.max_delete > 0:"
        indent = re.search(r"(?m)^([ \t]*)" + re.escape(anchor), source).group(1)
        source = replace_once(source, anchor,
            mask_audit + "\n" + indent + anchor)
        indent = re.search(r"(?m)^([ \t]*)eos_loss = eos_loss.sum\(\) / eos_count", source).group(1)
        source = replace_once(source, "eos_loss = eos_loss.sum() / eos_count",
            "_protocol_record_zero_delete(self, eos_count)\n" + indent +
            "eos_loss = eos_loss.sum() / max(1, eos_count)")
        source = replace_once(source,
            "loss = (non_eos_loss + eos_loss) / (non_eos_count + 1)",
            "loss = (non_eos_loss + eos_loss) / max(1, non_eos_count + int(eos_count > 0))")
    else:
        indent = re.search(r"(?m)^([ \t]*)valid_token_this_rank = torch.sum\(loss_mask\)", source).group(1)
        source = replace_once(source, "valid_token_this_rank = torch.sum(loss_mask)",
            "valid_token_this_rank = torch.sum(loss_mask)\n"
            + indent + mask_audit)
    source = replace_once(source, "/ valid_token_this_rank", "/ valid_token_this_rank.clamp_min(1)")
    indent = re.search(r"(?m)^([ \t]*)if do_backward:", source).group(1)
    return replace_once(source, "if do_backward:",
        "_protocol_require_finite(loss, 'native loss before backward')\n" + indent + "if do_backward:")


def patch_training_source(source):
    indent = re.search(r"(?m)^([ \t]*)self.optimizer.step\(\)", source).group(1)
    source = replace_once(source, "self.optimizer.step()",
        "_protocol_require_finite(grad_norm, 'native gradient norm')\n"
        + indent + "_protocol_check_gradients(self.fsdp_model)\n"
        + indent + "self.optimizer.step()\n"
        + indent + "_protocol_check_parameters(self.fsdp_model, 'native post-update')")
    return source


def accumulate_mask_statistics(phase, counts, eos_counts):
    if len(counts) != len(eos_counts) or any(not 0 <= eos <= count for count, eos in zip(counts, eos_counts)):
        raise ValueError("Native per-sequence mask/EOS counts are inconsistent")
    stats = MASK_STATISTICS.setdefault(phase, {"microbatches": 0, "examples": 0,
        "mask_tokens_sum": 0, "mask_tokens_min_per_example": None, "mask_tokens_max_per_example": 0,
        "zero_mask_examples": 0, "zero_mask_microbatches": 0, "eos_label_tokens_sum": 0,
        "non_eos_label_tokens_sum": 0, "zero_eos_examples": 0})
    stats["microbatches"] += 1
    stats["examples"] += len(counts)
    stats["mask_tokens_sum"] += sum(counts)
    minimum = min(counts)
    stats["mask_tokens_min_per_example"] = minimum if stats["mask_tokens_min_per_example"] is None else min(minimum, stats["mask_tokens_min_per_example"])
    stats["mask_tokens_max_per_example"] = max(max(counts), stats["mask_tokens_max_per_example"])
    stats["zero_mask_examples"] += sum(count == 0 for count in counts)
    stats["zero_mask_microbatches"] += int(sum(counts) == 0)
    stats["eos_label_tokens_sum"] += sum(eos_counts)
    stats["non_eos_label_tokens_sum"] += sum(counts) - sum(eos_counts)
    stats["zero_eos_examples"] += sum(count == 0 for count in eos_counts)


def record_masks(trainer, count, do_backward, eos_count):
    # do_backward is false in both original training_step and validation_step;
    # model.training gives the correct phase here.
    phase = "train" if trainer.fsdp_model.training else "validation"
    counts = count.detach().reshape(-1).cpu().tolist()
    eos_counts = eos_count.detach().reshape(-1).cpu().tolist()
    accumulate_mask_statistics(phase, counts, eos_counts)
    if sum(counts) == 0:
        event = {"event": "zero_sampled_masks", "phase": phase,
                 "rank": int(os.environ.get("RANK", "0")), "action": "zero contribution, denominator clamped to one"}
        path = Path(trainer.config.trainer.default_local_dir) / f"numerical-events-rank{event['rank']}.jsonl"
        with path.open("a") as stream:
            stream.write(json.dumps(event) + "\n")
        print(json.dumps(event), flush=True)


def record_zero_delete(trainer, count):
    if count == 0:
        event = {"event": "zero_delete_labels", "phase": "train" if trainer.fsdp_model.training else "validation",
                 "rank": int(os.environ.get("RANK", "0")), "action": "ordinary weighted masked-token mean"}
        path = Path(trainer.config.trainer.default_local_dir) / f"numerical-events-rank{event['rank']}.jsonl"
        with path.open("a") as stream:
            stream.write(json.dumps(event) + "\n")


def check_gradients(model):
    for name, parameter in model.named_parameters():
        if parameter.grad is not None:
            require_finite(parameter.grad, f"native gradient {name}")


def inference_checkpoint(trainer, step):
    import torch
    from torch.distributed.fsdp import FullyShardedDataParallel as FSDP, FullStateDictConfig, StateDictType
    final_step = int(trainer.config.trainer.total_training_steps)
    if step not in (500, final_step):
        return
    output = Path(trainer.config.trainer.default_local_dir)
    destination = output / f"checkpoint-{step:06d}"
    if destination.exists():
        return
    check_parameters(trainer.fsdp_model, "native pre-export")
    export_lock = acquire_export_lock(output, trainer.device_mesh.get_rank(), trainer.config.model.lora_rank == 0)
    with FSDP.state_dict_type(trainer.fsdp_model, StateDictType.FULL_STATE_DICT,
                             FullStateDictConfig(offload_to_cpu=True, rank0_only=True)):
        state = trainer.fsdp_model.state_dict()
    if trainer.device_mesh.get_rank() == 0:
        adaptation = "lora" if trainer.config.model.lora_rank > 0 else "full"
        for key, value in state.items():
            require_finite(value, f"native export {key}")
        if adaptation == "full":
            state = {key: value.to(torch.bfloat16) if value.is_floating_point() else value for key, value in state.items()}
        else:
            # The stock loader uses a local snapshot path. Persist the canonical
            # identity and revision needed by the independent adapter evaluator.
            profile = MODELS[os.environ["CF_PROTOCOL_MODEL"]]
            trainer.model.peft_config["default"].base_model_name_or_path = profile["model_id"]
            trainer.model.peft_config["default"].revision = profile["revision"]
        temporary = output / (destination.name + ".incomplete")
        temporary.mkdir()
        trainer.model.save_pretrained(temporary, state_dict=state, safe_serialization=True, max_shard_size="5GB")
        trainer.tokenizer.save_pretrained(temporary)
        run = json.loads((output / "native-run.json").read_text())
        weights = list(temporary.glob("*.safetensors"))
        if not weights:
            raise RuntimeError("Native checkpoint has no safetensors")
        write_json(temporary / "checkpoint.json", {"optimizer_step": step, "step": step,
            "examples_seen": step * run["global_batch_size"], "model": run["model"],
            "profile": MODELS[run["model"]], "objective": "native", "training_type": adaptation,
            "seed": run["seed"], "source_data": run["source_data"], "data_sha256": run["data_sha256"],
            "weight_sha256": {path.name: file_hash(path) for path in weights},
            "finite_weights": True, "export_precision": "bf16" if adaptation == "full" else "fp32 adapters",
            "resume_supported": False, "selection_status": "unselected",
            "framework": "corrected pinned upstream trainer", "corrections": run["corrections"]})
        temporary.rename(destination)
    del state
    torch.distributed.barrier()
    if export_lock is not None:
        export_lock.close()


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--model", choices=MODELS, required=True)
    p.add_argument("--upstream", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--global-batch-size", type=int, default=16)
    p.add_argument("--data", required=True)
    p.add_argument("overrides", nargs=argparse.REMAINDER)
    args = p.parse_args(argv)
    MASK_STATISTICS.clear()
    repo = Path(args.upstream).resolve()
    observed = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
    if observed != COMMITS[args.model]:
        raise ValueError("Upstream commit does not match pinned contract")
    subprocess.run(["git", "-c", "core.fileMode=false", "-C", str(repo), "diff", "--exit-code", "HEAD"], check=True)
    entry = "src.trainer.fsdp_sft_expand_trainer" if args.model == "dreamon" else "src.trainer.fsdp_sft_trainer"
    sys.path.insert(0, str(repo if args.model == "dreamon" else repo / "instruct"))
    module = importlib.import_module(entry)
    cls = module.FSDPSFTTrainer
    before = {name: textwrap.dedent(inspect.getsource(getattr(cls, name))) for name in
              ("_compute_loss_and_backward", "training_step", "_build_model_optimizer")}
    after = {"_compute_loss_and_backward": patch_loss_source(before["_compute_loss_and_backward"]),
             "training_step": patch_training_source(before["training_step"]),
             "_build_model_optimizer": replace_once(before["_build_model_optimizer"],
                 "self.total_steps = self.steps_per_epoch * self.config.trainer.total_epochs",
                 "self.total_steps = int(self.config.trainer.total_training_steps or (self.steps_per_epoch * self.config.trainer.total_epochs))")}
    module.__dict__.update(_protocol_require_finite=require_finite, _protocol_record_masks=record_masks,
                          _protocol_record_zero_delete=record_zero_delete,
                          _protocol_check_gradients=check_gradients, _protocol_check_parameters=check_parameters)
    for name, source in after.items():
        namespace = {}
        exec(compile(source, f"<corrected-upstream:{name}>", "exec"), module.__dict__, namespace)
        setattr(cls, name, namespace[name])
    cls.save_checkpoint = inference_checkpoint
    original_init = cls.__init__

    def seeded_init(self, *positional, **keywords):
        import numpy as np
        import torch
        rank_seed = args.seed + int(os.environ.get("RANK", "0"))
        random.seed(rank_seed)
        np.random.seed(rank_seed)
        torch.manual_seed(rank_seed)
        torch.cuda.manual_seed_all(rank_seed)
        original_init(self, *positional, **keywords)
        gpu = torch.cuda.get_device_name()
        if "RTX PRO 6000" not in gpu.upper():
            raise RuntimeError(f"Native hardware contract failed: {gpu}")
        # Separate data-loader worker RNG from LoRA initialization RNG. Reset
        # forward corruption RNG after model initialization in both arms.
        for offset, loader in enumerate((self.train_dataloader, self.val_dataloader)):
            loader.generator = torch.Generator().manual_seed(args.seed + 1000 + offset)
            loader.sampler.seed = args.seed
        random.seed(rank_seed)
        np.random.seed(rank_seed)
        torch.manual_seed(rank_seed)
        torch.cuda.manual_seed_all(rank_seed)
        check_parameters(self.fsdp_model, "native initial")
        parameter_counts = torch.tensor([sum(p.numel() for p in self.model.parameters()),
            sum(p.numel() for p in self.model.parameters() if p.requires_grad)], device="cuda", dtype=torch.int64)
        torch.distributed.all_reduce(parameter_counts)
        if self.device_mesh.get_rank() == 0:
            manifest_path = Path(self.config.trainer.default_local_dir) / "native-run.json"
            manifest = json.loads(manifest_path.read_text())
            manifest.update(total_parameters=int(parameter_counts[0]), trainable_parameters=int(parameter_counts[1]),
                            gpu=gpu, scheduler_horizon=self.total_steps, torch_version=torch.__version__)
            write_json(manifest_path, manifest)
            print(json.dumps({"event": "native_seed_applied", "seed": args.seed,
                              "scheduler_horizon": self.total_steps, "trainable_parameters": int(parameter_counts[1])}), flush=True)

    cls.__init__ = seeded_init
    output = Path(args.output)
    rank = int(os.getenv("RANK", "0"))
    if rank == 0:
        if output.exists() and any(output.iterdir()):
            raise FileExistsError(output)
        output.mkdir(parents=True, exist_ok=True)
        source_data = {split: str(Path(args.data) / filename) for split, filename in
                       (("train", "train_data.parquet"), ("selection_validation", "eval_data.parquet"))}
        overrides = args.overrides[1:] if args.overrides[:1] == ["--"] else args.overrides
        manifest = {"model": args.model, "upstream_commit": observed, "seed": args.seed,
            "runner_revision": "formal_v2_mask_counts",
            "global_batch_size": args.global_batch_size, "source_data": source_data,
            "data_sha256": {key: file_hash(value) for key, value in source_data.items()},
            "upstream_file_sha256": file_hash(module.__file__), "bootstrap_sha256": file_hash(__file__),
            "overrides": overrides, "original_files_modified": False,
            "corrections": ["clamp sampled-mask denominator to one only at zero; count events",
                "DreamOn official weight_eos=true: zero-delete branch uses ordinary weighted mean; count zero-delete events",
                "abort on nonfinite loss/gradient/norm/weights", "apply Python/NumPy/torch, sampler, and independent worker seeds",
                "compose unchanged original Hydra config by absolute directory for imported-module compatibility",
                "scheduler horizon equals declared optimizer steps", "inference-only bf16 full exports at step 500/final; no resume"]}
        write_json(output / "native-run.json", manifest)
        for name in before:
            (output / f"original-{name}.py.txt").write_text(before[name])
            (output / f"corrected-{name}.py.txt").write_text(after[name])
        patch = "".join("".join(difflib.unified_diff(before[name].splitlines(True), after[name].splitlines(True),
                         fromfile=f"upstream/{name}", tofile=f"corrected/{name}")) for name in before)
        (output / "native-corrections.diff").write_text(patch)
    os.environ["CF_PROTOCOL_MODEL"] = args.model
    overrides = args.overrides[1:] if args.overrides[:1] == ["--"] else args.overrides
    sys.argv = [entry, *overrides]
    succeeded = False
    try:
        # The upstream config folder has no __init__.py. Invoking an imported
        # @hydra.main searches a package, whereas upstream python -m searches
        # the filesystem. Compose the exact same YAML/overrides by absolute
        # directory and invoke the unchanged undecorated original main.
        from hydra import compose, initialize_config_dir
        with initialize_config_dir(config_dir=str(Path(module.__file__).parent / "config"), version_base=None):
            config = compose(config_name="sft_trainer", overrides=overrides)
        module.main.__wrapped__(config)
        succeeded = True
    finally:
        if output.is_dir():
            write_json(output / f"numerical-mask-summary-rank{rank}.json", {
                "rank": rank, "run_completed": succeeded, "statistics": MASK_STATISTICS,
                "unit": "actual sampled mask slots per example before native loss; EOS are deletion actions only for DreamOn",
                "mean_per_example": {phase: row["mask_tokens_sum"] / row["examples"] for phase, row in MASK_STATISTICS.items() if row["examples"]}})
    if rank == 0:
        steps = int(next(x.split("=", 1)[1] for x in overrides if x.startswith("trainer.total_training_steps=")))
        write_json(output / "completion.json", {"status": "training_complete_unselected",
                                                "model": args.model, "seed": args.seed,
                                                "completed_steps": steps, "examples_seen": steps * args.global_batch_size})


if __name__ == "__main__":
    main()
