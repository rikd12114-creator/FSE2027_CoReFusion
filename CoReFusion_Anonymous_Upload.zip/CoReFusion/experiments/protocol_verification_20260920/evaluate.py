"""Matched base/LoRA/full inference and prespecified mask/canvas ablations.

Controlled windows freeze visible context using a four-slot reference per site.
Legacy windows reproduce the historical two-slot tiler. Neither policy derives
non-oracle masks, budgets, windows or sampling seeds from target text/length.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import csv
import hashlib
import json
from pathlib import Path
import sys
import time

from experiments.late_rename.corruption import Window, tokenize_windows
from experiments.late_rename.evaluate import extract_sites
from experiments.late_rename.prepare_data import normalized_fingerprint, valid_identifier
from experiments.protocol_verification_20260920.ablations import digest, file_hash, read_jsonl


def read_records(path, phase):
    if Path(path).suffix == ".csv":
        if phase != "test":
            raise ValueError("Legacy test CSV cannot select checkpoints")
        csv.field_size_limit(sys.maxsize)
        with Path(path).open(newline="") as stream:
            values = list(csv.reader(stream))
        if any(len(row)!=3 for row in values):
            raise ValueError("CSV must use the headerless id,masked_code,target schema")
        rows = [dict(zip(("id", "code_masked", "target"), r)) for r in values]
    else:
        rows = read_jsonl(path)
    out = []
    for raw in rows:
        row = dict(raw)
        if phase == "validation" and (row.get("split", "validation") not in ("validation", "selection_validation")
                                       or "test" in Path(path).name):
            raise ValueError("Test data cannot select checkpoints")
        row["code_masked"] = row.get("code_masked_template", row["code_masked"])
        count = row["code_masked"].count("[MASK]")
        if not count:
            raise ValueError("Missing mask sites")
        if "target_by_site" not in row:
            row.update(target_by_site=[row["target"]] * count,
                       identifier_by_site=["identifier_0"] * count,
                       targets={"identifier_0": row["target"]}, focal_identifier="identifier_0")
        if len(row["target_by_site"]) != count or len(row["identifier_by_site"]) != count:
            raise ValueError("Identifier/site metadata does not align")
        if any(row["targets"].get(g) != target for g, target in
               zip(row["identifier_by_site"], row["target_by_site"])):
            raise ValueError("Gold identifier groups do not match sites")
        if row.get("repository"):
            row["id"] = json.dumps([row["repository"], str(row["id"])], separators=(",", ":"))
        else:
            row["id"] = str(row["id"])
        if "source_cluster_id" not in row:
            parts = row["code_masked"].split("[MASK]")
            code = parts[0] + "".join(target + suffix for target, suffix in zip(row["target_by_site"], parts[1:]))
            row["source_cluster_id"] = normalized_fingerprint(code)
        out.append(row)
    if not out or len({r["id"] for r in out}) != len(out):
        raise ValueError("Require nonempty records and unique IDs")
    return out


def input_windows(code_masked, tokenizer, *, initial_masks, max_length=1024,
                  window_policy="controlled", oracle_widths=None):
    """Input planner deliberately accepts no targets except explicit oracle mode."""
    if initial_masks not in (1, 2, 4):
        raise ValueError("Prespecified initial masks are 1, 2, 4")
    if window_policy not in ("controlled", "legacy"):
        raise ValueError("Unknown window policy")
    if oracle_widths is not None and (len(oracle_widths) != code_masked.count("[MASK]")
            or any(type(x) is not int or not 1 <= x <= 16 for x in oracle_widths)):
        raise ValueError("Oracle widths must align with sites and occupy 1..16 slots")
    reference = 16 if oracle_widths is not None else 4 if window_policy == "controlled" else initial_masks
    max_sites = 4 if window_policy == "controlled" else 8
    masked = {"code_masked": code_masked, "target_ids_override": [tokenizer.mask_token_id] * reference}
    windows = tokenize_windows(masked, tokenizer, max_length, 64, max_sites)
    special = set(tokenizer.all_special_ids)
    output = []
    for window in windows:
        ids, spans, cursor, context = [], [], 0, []
        for (start, end), site in zip(window.sites, window.site_indices):
            segment = window.ids[cursor:start]
            # BOS/EOS occur only at actual boundaries; context special literals
            # must never be treated as extra targets by the native sampler.
            checked = segment[1:] if cursor == 0 else segment
            if any(token in special for token in checked):
                raise ValueError("Observed source contains a native special token")
            context.append(segment)
            ids.extend(segment)
            width = oracle_widths[site] if oracle_widths is not None else initial_masks
            spans.append((len(ids), len(ids) + width))
            ids.extend([tokenizer.mask_token_id] * width)
            cursor = end
        segment = window.ids[cursor:]
        if any(token in special for token in segment[:-1]):
            raise ValueError("Observed source contains a native special token")
        context.append(segment)
        ids.extend(segment)
        if len(ids) > max_length:
            raise ValueError("Window exceeds model context budget")
        output.append((Window(ids, spans, window.site_indices), digest(context)))
    return output


def score(row, predictions, preserved, errors):
    if len(predictions) != len(row["target_by_site"]):
        raise ValueError("Prediction count changed original denominator")
    correct = [p == t for p, t in zip(predictions, row["target_by_site"])]
    groups = defaultdict(list)
    for index, group in enumerate(row["identifier_by_site"]):
        groups[group].append(index)
    group_results = {group: {"sites": len(indices),
            "all_sites_exact": all(correct[i] for i in indices) and preserved and not errors,
            "consistent": all(valid_identifier(predictions[i]) for i in indices)
                          and len({predictions[i] for i in indices}) == 1,
            "first_prediction": predictions[indices[0]]}
                     for group, indices in groups.items()}
    unique = [value["first_prediction"] for value in group_results.values() if value["consistent"]]
    return {"strict_em": bool(all(correct) and preserved and not errors),
            "focal_em": bool(group_results[row["focal_identifier"]]["all_sites_exact"]),
            "site_correct": sum(correct), "sites": len(correct),
            "valid_sites": sum(valid_identifier(p) for p in predictions),
            "identifier_metrics": group_results,
            "cross_identifier_collision": len(unique) != len(set(unique)),
            "context_preserved": preserved, "errors": errors}


def native_generate(model, tokenizer, ids, spec, seed):
    """Pinned sampler with independently fixed expansion-action budget.

    The historical helper derives expand_budget=2*canvas. Holding it at 128
    isolates canvas16/32/64 from this second stopping parameter. At cap64 this
    is exactly the historical sampler setting.
    """
    import torch
    from experiments.late_rename.evaluate import GenerationLimit
    base = model.get_base_model() if hasattr(model,"get_base_model") else model
    masks = ids.count(tokenizer.mask_token_id)
    canvas = min(spec["max_canvas"], spec["max_length"] - (len(ids)-masks))
    if not masks or canvas < masks:
        raise ValueError("Invalid initial masks/canvas")
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    trace = []
    def count_call(module, positional):
        if len(trace) >= spec["max_actions"]:
            raise GenerationLimit(f"Exceeded {spec['max_actions']} model forwards")
        active = positional[1][0,0].any(-1)
        trace.append({"nfe":len(trace)+1,
                      "remaining_masks":int(((positional[0][0]==tokenizer.mask_token_id)&active).sum().item())})
    handle = base.register_forward_pre_hook(count_call)
    torch.cuda.synchronize()
    start = time.monotonic()
    try:
        with torch.no_grad():
            output = base.diffusion_generate(torch.tensor([ids],device="cuda",dtype=torch.long),
                max_new_tokens=canvas, expand_budget=spec["expansion_budget"],
                temperature=spec["temperature"],top_p=.9,alg="entropy",alg_temp=0.,
                number_transfer_tokens=1,pad_delete_to_right=False,
                eos_token_id=tokenizer.eos_token_id,delete_token_id=tokenizer.eos_token_id,
                return_dict_in_generate=True,output_history=True)
        sequence = output.history[-1].tolist() if output.history else list(ids)
        lengths = [len(ids)]+[len(state) for state in (output.history or [])]
        expansions = sum(max(0,b-a) for a,b in zip(lengths,lengths[1:]))
        deletions = sum(max(0,a-b) for a,b in zip(lengths,lengths[1:]))
        unresolved = sequence.count(tokenizer.mask_token_id)
        error = "unresolved_masks" if unresolved else None
    except GenerationLimit as exc:
        sequence, unresolved, error = [], None, str(exc)
        expansions = deletions = None
    finally:
        handle.remove()
    torch.cuda.synchronize()
    return sequence,{"nfe":len(trace),"seconds":time.monotonic()-start,"error":error,
                     "trace":trace,"unresolved_masks":unresolved,"expansions":expansions,
                     "deletions":deletions,"canvas_budget":canvas,
                     "expansion_budget":spec["expansion_budget"]}


def evaluate_record(model, row, tokenizer, spec):
    import torch
    predictions, logs, errors = [""] * len(row["target_by_site"]), [], []
    preserved = True
    try:
        widths = ([len(tokenizer.encode(t, add_special_tokens=False)) for t in row["target_by_site"]]
                  if spec["oracle_length"] else None)
        windows = input_windows(row["code_masked"], tokenizer, initial_masks=spec["initial_masks"],
                               max_length=spec["max_length"], window_policy=spec["window_policy"],
                               oracle_widths=widths)
        for index, (window, context_hash) in enumerate(windows):
            seed = int.from_bytes(hashlib.sha256(f"{spec['seed']}:{row['id']}:{index}".encode()).digest()[:4], "big") % 2**31
            if spec["model"] == "dreamon":
                if window.ids.count(tokenizer.mask_token_id) > spec["max_canvas"]:
                    raise ValueError("Initial total masks exceed global canvas cap")
                sequence, log = native_generate(model, tokenizer, window.ids, spec, seed)
            else:
                from experiments.fixed_identifier.evaluate import predict
                torch.cuda.synchronize()
                start = time.monotonic()
                sequence, forwards = predict(model, window.ids, tokenizer.mask_token_id, steps=spec["steps"])
                torch.cuda.synchronize()
                log = {"nfe": forwards, "seconds": time.monotonic() - start,
                       "error": "unresolved_masks" if tokenizer.mask_token_id in sequence else None}
            found, ok = extract_sites(sequence, window, tokenizer)
            preserved &= ok
            if log.get("error"):
                errors.append(log["error"])
            for site, prediction in zip(window.site_indices, found):
                predictions[site] = prediction
            context_count = len(window.ids) - sum(b-a for a,b in window.sites)
            log.update(context_sha256=context_hash, input_plan_sha256=digest(window.ids),
                       site_indices=window.site_indices, initial_mask_tokens=sum(b-a for a,b in window.sites),
                       identifier_groups=[row["identifier_by_site"][site] for site in window.site_indices],
                       visible_identifier_count=len({row["identifier_by_site"][site] for site in window.site_indices}),
                       final_generated_tokens=len(sequence)-context_count if ok else None,
                       context_preserved=ok)
            logs.append(log)
    except Exception as exc:
        preserved = False
        errors.append(f"{type(exc).__name__}: {exc}")
    return {"id": row["id"], "repository": row.get("repository"),
            "source_cluster_id": row["source_cluster_id"], "condition": row.get("condition", "legacy_same_identifier"),
            "site_predictions": predictions, "target_by_site": row["target_by_site"],
            "identifier_by_site": row["identifier_by_site"],
            "gold_token_lengths": [len(tokenizer.encode(t, add_special_tokens=False)) for t in row["target_by_site"]],
            "all_target_sites_one_window": len(logs)==1 and len(logs[0]["site_indices"])==len(predictions),
            "joint_multi_identifier_windows": sum(log["visible_identifier_count"]>1 for log in logs),
            "forward_passes": sum(w["nfe"] for w in logs), "seconds": sum(w["seconds"] for w in logs),
            "windows": logs, **score(row, predictions, preserved, errors)}


def summarize(rows):
    if not rows:
        raise ValueError("Empty evaluation")
    n = len(rows)
    return {"n": n, "strict_em": sum(r["strict_em"] for r in rows)/n,
            "focal_em": sum(r["focal_em"] for r in rows)/n,
            "site_em": sum(r["site_correct"] for r in rows)/sum(r["sites"] for r in rows),
            "error_samples": sum(bool(r["errors"]) for r in rows),
            "context_preservation": sum(r["context_preserved"] for r in rows)/n,
            "mean_forward_passes": sum(r["forward_passes"] for r in rows)/n,
            "mean_seconds": sum(r["seconds"] for r in rows)/n}


def load_model(model, checkpoint):
    if checkpoint and not (Path(checkpoint)/"adapter_config.json").exists():
        from experiments.native_finetune.evaluate import load_full_model
        return load_full_model(model, checkpoint)
    if model == "dreamon":
        from experiments.variable_identifier.runtime import load_model as load
        return load(adapter=checkpoint)
    from experiments.fixed_identifier.runtime import load_model as load
    return load(model, adapter=checkpoint)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=("dreamon", "dreamcoder"), required=True)
    parser.add_argument("--checkpoint")
    parser.add_argument("--data", required=True)
    parser.add_argument("--output", required=True, help="new JSONL file")
    parser.add_argument("--phase", choices=("validation", "test"), required=True)
    parser.add_argument("--initial-masks", type=int, choices=(1,2,4), default=4)
    parser.add_argument("--max-canvas", type=int, choices=(16,32,64), default=64)
    parser.add_argument("--grid", help="comma-separated initial:cap pairs; loads weights once")
    parser.add_argument("--window-policy", choices=("controlled", "legacy"), default="controlled")
    parser.add_argument("--oracle-length", action="store_true", help="Dream-Coder diagnostic only")
    parser.add_argument("--max-length", type=int, default=1024)
    parser.add_argument("--max-actions", type=int, default=512)
    parser.add_argument("--expansion-budget", type=int, default=128)
    parser.add_argument("--temperature", type=float, default=.2)
    parser.add_argument("--steps", type=int, default=1)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--max-samples", type=int, default=0, help="deterministic prefix smoke only")
    args = parser.parse_args(argv)
    if args.oracle_length and args.model != "dreamcoder":
        parser.error("Gold-length input is a separately labelled Dream-Coder diagnostic")
    if args.max_actions < 1 or args.expansion_budget < 1 or args.steps < 1 or args.max_samples < 0:
        parser.error("Invalid action, step or sample budget")
    grid = [tuple(map(int, pair.split(":"))) for pair in args.grid.split(",")] if args.grid else [(args.initial_masks,args.max_canvas)]
    if any(k not in (1,2,4) or cap not in (16,32,64) for k,cap in grid) or len(set(grid)) != len(grid):
        parser.error("Grid must contain unique k:cap pairs with k=1/2/4 and cap=16/32/64")
    if args.model == "dreamcoder" and len({k for k,cap in grid}) != len(grid):
        parser.error("Dream-Coder canvas is fixed by k; cap variants would duplicate identical inputs")
    if args.oracle_length and len(grid)!=1:
        parser.error("Oracle diagnostic has a single gold-derived initialization")
    path = Path(args.output)
    manifest_path, summary_path = path.with_suffix(".manifest.json"), path.with_suffix(".summary.json")
    if any(p.exists() for p in (path,manifest_path,summary_path)):
        raise FileExistsError(path)
    rows = read_records(args.data, args.phase)
    if args.max_samples:
        rows = rows[:args.max_samples]
    from experiments.native_finetune.evaluate import load_tokenizer, PROFILES
    tokenizer = load_tokenizer(args.model)
    checkpoint_files = ({p.name: file_hash(p) for p in Path(args.checkpoint).iterdir()
                         if p.is_file() and (p.suffix in (".json",".safetensors") or p.name.startswith("pytorch_model"))}
                        if args.checkpoint else None)
    model = load_model(args.model, args.checkpoint)
    path.parent.mkdir(parents=True, exist_ok=True)
    manifest = {"arguments": vars(args), "grid": grid, "data_sha256": file_hash(args.data),
                "profile": PROFILES[args.model], "checkpoint_hashes": checkpoint_files,
                "source_sha256": {name: file_hash(Path(__file__).parents[1]/name) for name in (
                    "protocol_verification_20260920/evaluate.py", "protocol_verification_20260920/ablations.py",
                    "late_rename/corruption.py", "late_rename/evaluate.py", "late_rename/prepare_data.py",
                    "variable_identifier/runtime.py", "fixed_identifier/runtime.py", "fixed_identifier/evaluate.py",
                    "native_finetune/evaluate.py")},
                "n": len(rows), "gold_input": args.oracle_length,
                "status": "running", "selection_may_use_test": False,
                "context_policy": "oracle_reference16" if args.oracle_length else "reference4/reserve64/maxsites4" if args.window_policy=="controlled" else "historical_current_k/reserve64/maxsites8",
                "canvas_semantics": "global generated-token capacity per window, not per-site final length"}
    manifest_path.write_text(json.dumps(manifest, indent=2)+"\n")
    all_results = defaultdict(list)
    with path.open("x") as stream:
        for k, cap in grid:
            spec = dict(vars(args), initial_masks=k, max_canvas=cap)
            key = f"k{k}_cap{cap}" if args.model=="dreamon" else "oracle_length" if args.oracle_length else f"fixed{k}"
            for row in rows:
                result = dict(evaluate_record(model,row,tokenizer,spec), decode_condition=key)
                stream.write(json.dumps(result, ensure_ascii=False)+"\n")
                stream.flush()
                all_results[key].append(result)
    summaries = {key: {"overall": summarize(values), "by_task": {condition:summarize([r for r in values if r["condition"]==condition])
                    for condition in sorted({r["condition"] for r in values})}} for key,values in all_results.items()}
    summary_path.write_text(json.dumps(summaries,indent=2)+"\n")
    manifest["status"]="complete"
    manifest["result_sha256"]=file_hash(path)
    manifest_path.write_text(json.dumps(manifest,indent=2)+"\n")
    print(json.dumps(summaries,indent=2))


if __name__=="__main__":
    main()
