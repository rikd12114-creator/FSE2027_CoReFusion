"""DreamOn k2/k4 comparison on EXACT historical k2 context windows.

This independent entry point does not alter the frozen controlled evaluator or
pipeline. A reference2/reserve64/maxsites8 plan preserves old k2 inputs; only
the per-site mask spans are replaced for k4. Canvas64, expansion128, actions512.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from experiments.late_rename.corruption import Window,tokenize_windows
from experiments.late_rename.evaluate import extract_sites
from experiments.native_finetune.evaluate import PROFILES,load_tokenizer,runtime_versions
from experiments.protocol_verification_20260920.ablations import digest,file_hash
from experiments.protocol_verification_20260920.evaluate import (
    load_model,native_generate,read_records,score,summarize,
)


POLICY="dreamon_historical_k2_context_reference2_reserve64_maxsites8"


def bridge_windows(code_masked,tokenizer,*,initial_masks,max_length=1024):
    """Gold-free planner with unchanged old-k2 context and ownership."""
    if initial_masks not in (2,4):
        raise ValueError("Historical-context bridge is prespecified for k2/k4")
    old=tokenize_windows({"code_masked":code_masked,
                          "target_ids_override":[tokenizer.mask_token_id]*2},
                         tokenizer,max_length,64,8)
    result=[]
    for window in old:
        ids,spans,anchors,cursor=[],[],[],0
        for start,end in window.sites:
            anchor=window.ids[cursor:start]
            anchors.append(anchor)
            ids.extend(anchor)
            spans.append((len(ids),len(ids)+initial_masks))
            ids.extend([tokenizer.mask_token_id]*initial_masks)
            cursor=end
        anchors.append(window.ids[cursor:])
        ids.extend(window.ids[cursor:])
        if len(ids)>max_length or ids.count(tokenizer.mask_token_id)!=initial_masks*len(spans):
            raise ValueError("Invalid bridge canvas or an observed native MASK token")
        if ids[0]!=tokenizer.bos_token_id or ids[-1]!=tokenizer.eos_token_id:
            raise ValueError("Bridge lost native boundaries")
        if initial_masks==2 and (ids!=window.ids or spans!=window.sites):
            raise AssertionError("Reference2 bridge changed a historical k2 input")
        result.append((Window(ids,spans,list(window.site_indices)),digest(anchors)))
    return result


def audit_inputs(records,tokenizer,max_length=1024):
    """Serialize token arrays identically before byte comparison; no GPU model."""
    old_digest,new_digest=hashlib.sha256(),hashlib.sha256()
    windows=sites=0
    rows=[]
    encode=lambda value:json.dumps(value,separators=(",",":"),ensure_ascii=False).encode()
    for row in records:
        legacy=tokenize_windows({"code_masked":row["code_masked"],
                                 "target_ids_override":[tokenizer.mask_token_id]*2},tokenizer,max_length,64,8)
        two=bridge_windows(row["code_masked"],tokenizer,initial_masks=2,max_length=max_length)
        four=bridge_windows(row["code_masked"],tokenizer,initial_masks=4,max_length=max_length)
        if len(legacy)!=len(two) or len(two)!=len(four):
            raise AssertionError("Bridge changed window count")
        for original,(left,lcontext),(right,rcontext) in zip(legacy,two,four):
            before=encode([original.ids,original.sites,original.site_indices])
            after=encode([left.ids,left.sites,left.site_indices])
            if before!=after:
                raise AssertionError("Historical k2 tokens/spans/ownership differ byte-for-byte")
            if lcontext!=rcontext or left.site_indices!=right.site_indices:
                raise AssertionError("k4 changed context or site ownership")
            if len(right.ids)-len(left.ids)!=2*len(left.sites):
                raise AssertionError("k4 changed more than initial mask counts")
            old_digest.update(before+b"\n");new_digest.update(after+b"\n")
            windows+=1;sites+=len(left.sites)
        rows.append({"id":row["id"],"windows":len(two),"sites":sum(len(w.sites) for w,_ in two),
                     "k2_byte_identical_to_historical":True,"k2_k4_context_and_ownership_identical":True})
    return {"status":"cpu_input_audit_complete_no_model_inference","policy":POLICY,
            "tasks":len(records),"windows":windows,"sites":sites,
            "historical_k2_serialized_plan_sha256":old_digest.hexdigest(),
            "bridge_k2_serialized_plan_sha256":new_digest.hexdigest(),
            "byte_identical_tasks":len(records),"same_context_k2_k4_tasks":len(records),"rows":rows}


def evaluate_bridge_record(model,row,tokenizer,spec):
    predictions=[""]*len(row["target_by_site"])
    logs,errors,preserved=[],[],True
    try:
        windows=bridge_windows(row["code_masked"],tokenizer,initial_masks=spec["initial_masks"],max_length=spec["max_length"])
        for index,(window,context_sha) in enumerate(windows):
            seed=int.from_bytes(hashlib.sha256(f"{spec['seed']}:{row['id']}:{index}".encode()).digest()[:4],"big")%2**31
            sequence,log=native_generate(model,tokenizer,window.ids,spec,seed)
            found,ok=extract_sites(sequence,window,tokenizer)
            preserved &= ok
            if log.get("error"):errors.append(log["error"])
            for site,prediction in zip(window.site_indices,found):predictions[site]=prediction
            initial=sum(b-a for a,b in window.sites)
            log.update(context_sha256=context_sha,input_plan_sha256=digest(window.ids),site_indices=window.site_indices,
                       initial_mask_tokens=initial,identifier_groups=[row["identifier_by_site"][i] for i in window.site_indices],
                       visible_identifier_count=len({row["identifier_by_site"][i] for i in window.site_indices}),
                       final_generated_tokens=len(sequence)-(len(window.ids)-initial) if ok else None,context_preserved=ok)
            logs.append(log)
    except Exception as exc:
        preserved=False
        errors.append(f"{type(exc).__name__}: {exc}")
    return {"id":row["id"],"repository":row.get("repository"),"source_cluster_id":row["source_cluster_id"],
            "condition":row.get("condition","legacy_same_identifier"),"site_predictions":predictions,
            "target_by_site":row["target_by_site"],"identifier_by_site":row["identifier_by_site"],
            "gold_token_lengths":[len(tokenizer.encode(t,add_special_tokens=False)) for t in row["target_by_site"]],
            "all_target_sites_one_window":len(logs)==1 and len(logs[0]["site_indices"])==len(predictions),
            "joint_multi_identifier_windows":sum(log["visible_identifier_count"]>1 for log in logs),
            "forward_passes":sum(log["nfe"] for log in logs),"seconds":sum(log["seconds"] for log in logs),
            "windows":logs,**score(row,predictions,preserved,errors)}


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model",choices=("dreamon",),default="dreamon")
    parser.add_argument("--checkpoint")
    parser.add_argument("--data",required=True)
    parser.add_argument("--phase",choices=("validation","test"),default="test")
    parser.add_argument("--output",required=True)
    parser.add_argument("--audit-inputs",action="store_true",help="CPU tokenizer/input proof only; output JSON")
    parser.add_argument("--grid",default="2:64,4:64",choices=("2:64,4:64",))
    parser.add_argument("--max-samples",type=int,default=0)
    parser.add_argument("--seed",type=int,default=42)
    args=parser.parse_args(argv)
    if args.max_samples<0 or (args.max_samples and args.phase=="test" and not args.audit_inputs):
        parser.error("Inference engineering smoke must use development, not a test prefix")
    output=Path(args.output)
    manifest_path,summary_path=output.with_suffix(".manifest.json"),output.with_suffix(".summary.json")
    if any(path.exists() for path in (output,manifest_path,summary_path)):
        raise FileExistsError(output)
    rows=read_records(args.data,args.phase)
    if args.max_samples:rows=rows[:args.max_samples]
    tokenizer=load_tokenizer("dreamon")
    proof=audit_inputs(rows,tokenizer)
    output.parent.mkdir(parents=True,exist_ok=True)
    if args.audit_inputs:
        proof.update(data_sha256=file_hash(args.data),wrapper_sha256=file_hash(__file__),
                     frozen_evaluator_sha256=file_hash(Path(__file__).with_name("evaluate.py")))
        with output.open("x") as stream:json.dump(proof,stream,indent=2);stream.write("\n")
        print(json.dumps({k:v for k,v in proof.items() if k!="rows"},indent=2))
        return
    checkpoint_hashes=({path.name:file_hash(path) for path in Path(args.checkpoint).iterdir()
                        if path.is_file() and (path.suffix in (".json",".safetensors") or path.name.startswith("pytorch_model"))}
                       if args.checkpoint else None)
    model=load_model("dreamon",args.checkpoint)
    import torch
    gpu=torch.cuda.get_device_name()
    if "RTX PRO 6000" not in gpu.upper():
        raise RuntimeError(f"Requested PRO6000 contract not met: {gpu}")
    sources=["protocol_verification_20260920/bridge_evaluate.py","protocol_verification_20260920/evaluate.py",
             "protocol_verification_20260920/ablations.py","late_rename/corruption.py","late_rename/evaluate.py",
             "late_rename/prepare_data.py","variable_identifier/runtime.py","native_finetune/evaluate.py"]
    arguments={**vars(args),"window_policy":POLICY,"max_length":1024,"max_canvas":64,"max_actions":512,
               "expansion_budget":128,"temperature":.2,"steps":1,"oracle_length":False}
    manifest={"arguments":arguments,"grid":[[2,64],[4,64]],"profile":PROFILES["dreamon"],
              "n":len(rows),"status":"running","data_sha256":file_hash(args.data),"checkpoint_hashes":checkpoint_hashes,
              "source_sha256":{name:file_hash(Path(__file__).parents[1]/name) for name in sources},
              "context_policy":POLICY,"reference_initial_masks":2,"max_sites":8,"reserve_tokens":64,
              "gold_input":False,"selection_may_use_test":False,"runtime":runtime_versions(),"gpu":gpu,
              "input_proof":{key:value for key,value in proof.items() if key!="rows"},
              "frozen_evaluator_modified":False,"canvas_semantics":"global64 per window; expansion budget128; max actions512"}
    manifest_path.write_text(json.dumps(manifest,indent=2)+"\n")
    results={}
    with output.open("x") as stream:
        for width in (2,4):
            condition=f"k{width}_cap64"
            results[condition]=[]
            spec={**arguments,"initial_masks":width}
            for row in rows:
                result={**evaluate_bridge_record(model,row,tokenizer,spec),"decode_condition":condition,"context_policy":POLICY}
                stream.write(json.dumps(result,ensure_ascii=False)+"\n");stream.flush()
                results[condition].append(result)
    summaries={condition:{"overall":summarize(values),"by_task":{label:summarize([row for row in values if row["condition"]==label])
                      for label in sorted({row["condition"] for row in values})}} for condition,values in results.items()}
    summary_path.write_text(json.dumps(summaries,indent=2)+"\n")
    manifest.update(status="complete",result_sha256=file_hash(output))
    manifest_path.write_text(json.dumps(manifest,indent=2)+"\n")
    print(json.dumps(summaries,indent=2))


if __name__=="__main__":main()
