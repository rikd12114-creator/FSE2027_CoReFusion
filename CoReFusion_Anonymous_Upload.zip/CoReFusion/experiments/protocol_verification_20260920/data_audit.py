"""Recompute lexical clone diagnostics for the frozen historical datasets."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path

from experiments.late_rename.prepare_data import JAVA_RESERVED, lexical_tokens, normalized_fingerprint
from experiments.refineid_comparison.data import read_records


def alpha_fingerprint(code):
    """Normalize every non-keyword identifier by first-occurrence index.

    This conservative lexical diagnostic is not a Java binding resolver.
    Literal values and punctuation are retained, comments/whitespace ignored.
    """
    mapping, output = {}, []
    for kind, token, *_ in lexical_tokens(code):
        if kind == 'identifier' and token not in JAVA_RESERVED:
            if token not in mapping:
                mapping[token] = f'ID{len(mapping)}'
            token = mapping[token]
        output.append((kind, token))
    return hashlib.sha256(json.dumps(output, separators=(',', ':')).encode()).hexdigest()


def audit(data_root, test_path):
    cohorts = {split: [json.loads(line) for line in (Path(data_root)/f'{split}.jsonl').open()]
               for split in ('train', 'validation')}
    cohorts['test'] = read_records(test_path)
    index, stats = {}, {}
    for split, rows in cohorts.items():
        index[split] = {kind: defaultdict(list) for kind in ('exact', 'alpha', 'template')}
        for row in rows:
            code = row['code_masked'].replace('[MASK]', row['target'])
            for kind, fingerprint in [('exact', normalized_fingerprint(code)),
                                      ('alpha', alpha_fingerprint(code)),
                                      ('template', normalized_fingerprint(row['code_masked']))]:
                index[split][kind][fingerprint].append(row['id'])
        stats[split] = {'rows': len(rows), 'repositories': len({r.get('repository') for r in rows if r.get('repository')})}
    report = {'cohorts': stats, 'overlaps': {}, 'limitation':
              'Alpha normalization is lexical all-identifier normalization, a conservative clone diagnostic, not a compiler binding proof; inherited test has no repository metadata.'}
    for left, right in [('train', 'validation'), ('train', 'test'), ('validation', 'test')]:
        comparison = {}
        for kind in ('exact', 'template', 'alpha'):
            shared = set(index[left][kind]) & set(index[right][kind])
            comparison[kind] = {
                'groups': len(shared),
                'left_rows': sum(len(index[left][kind][key]) for key in shared),
                'right_rows': sum(len(index[right][kind][key]) for key in shared),
                'pairs': [{'fingerprint': key, left: index[left][kind][key], right: index[right][kind][key]}
                          for key in sorted(shared)]}
        report['overlaps'][left+'__'+right] = comparison
    report['train_validation_repository_overlap'] = sorted(
        {r['repository'] for r in cohorts['train']} & {r['repository'] for r in cohorts['validation']})
    report['input_sha256'] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                             for path in [Path(data_root)/'train.jsonl', Path(data_root)/'validation.jsonl', Path(test_path)]}
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root', default='data/stack_v2_java_pilot/training')
    parser.add_argument('--test', default='data/test.csv')
    parser.add_argument('--output', default='results/protocol_audit_20260920/data-overlap-audit.json')
    args = parser.parse_args()
    report = audit(args.data_root, args.test)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({'output': str(out), 'cohorts': report['cohorts']}))


if __name__ == '__main__':
    main()
