"""Controlled identifier-objective LoRA/full training; no evaluation-set selection.

Run using torchrun with two RTX PRO 6000 GPUs. The native-objective cells use
native_bootstrap.py and the original authors' trainer, not this loop.
"""
from __future__ import annotations

import argparse
from contextlib import nullcontext
import hashlib
import json
import math
import os
from pathlib import Path
import random
import shutil
import time

from experiments.variable_identifier.corruption import corrupt
from experiments.variable_identifier.train import prepare_record
from experiments.variable_identifier.runtime import LORA_MODULES, balanced_loss
from experiments.late_rename.runtime import file_hash

MODELS = {
    "dreamon": {"model_id": "Dream-org/DreamOn-v0-7B", "revision": "57e0e4115c97899e3e859b00eae26f54f9cf3872"},
    "dreamcoder": {"model_id": "Dream-org/Dream-Coder-v0-Base-7B", "revision": "2346ccd3be517d0d314152b988a3b9bafa7d6d63"},
}


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def validate_config(config):
    if config["model"] not in MODELS or config["adaptation"] not in ("lora", "full"):
        raise ValueError("Explicit model and lora/full adaptation are required")
    if config["objective"] != "identifier":
        raise ValueError("The native objective must use the original native trainer")
    for name in ("steps", "global_batch_size", "max_length", "rank"):
        if type(config[name]) is not int or config[name] <= 0:
            raise ValueError(f"{name} must be a positive integer")
    for name in ("learning_rate", "gradient_clip"):
        if not math.isfinite(config[name]) or config[name] <= 0:
            raise ValueError(f"{name} must be finite and positive")
    if not 0 <= config["warmup_fraction"] < 1 or not 0 <= config["weight_decay"] < 1:
        raise ValueError("Invalid optimizer configuration")
    if len(config["betas"]) != 2 or not all(0 <= x < 1 for x in config["betas"]):
        raise ValueError("Invalid AdamW betas")
    if config["lora_dropout"] != 0 or config["lora_alpha"] != 2 * config["rank"]:
        raise ValueError("Matched adaptation requires dropout zero and alpha twice rank")
    if config["model"] == "dreamon":
        if config["time_reweighting"] != "linear" or config["delete_loss_balancing"] is not True:
            raise ValueError("DreamOn requires the historical linear and deletion-balanced identifier objective")
        for name in ("max_delete", "max_total_delete"):
            if type(config[name]) is not int or config[name] < 2:
                raise ValueError("DreamOn deletion budgets must permit deletion supervision")
        if not all(0 < config[name] < 1 for name in ("merge_prob", "static_probability")):
            raise ValueError("DreamOn merge probabilities must be in (0,1)")
    elif config["time_reweighting"] != "none" or config["delete_loss_balancing"] is not False:
        raise ValueError("Dream-Coder identifier objective has no time or deletion weighting")
    if config.get("selection_metric") != "heldout_identifier_exact_match":
        raise ValueError("Model selection must use independently evaluated development identifier EM")
    if any(type(x) is not int or x < 1 for x in config["save_steps"]):
        raise ValueError("Invalid checkpoint steps")


def load_records(path):
    records = [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]
    if not records:
        raise ValueError(f"Empty data: {path}")
    normalized = []
    for index, row in enumerate(records):
        template = row.get("code_masked_template", row.get("code_masked"))
        target = row.get("target")
        if not isinstance(template, str) or "[MASK]" not in template or not isinstance(target, str) or not target:
            raise ValueError(f"Row {index} must contain a public [MASK] template and target")
        if any(token in template or token in target for token in ("<|mask|>", "<|expand|>")):
            raise ValueError("Use the single-slot public template; native-token counts are not occurrence counts")
        repo = row.get("repository", row.get("repo", row.get("repo_name")))
        if not isinstance(repo, str) or not repo:
            raise ValueError("Repository identity is required for split isolation")
        normalized.append(dict(row, code_masked=template, repository=repo))
    return normalized


def audit_splits(train, validation):
    train_repos = {row["repository"] for row in train}
    val_repos = {row["repository"] for row in validation}
    if train_repos & val_repos:
        raise ValueError("Training and selection-validation repositories overlap")
    def gold(row):
        return hashlib.sha256(row["code_masked"].replace("[MASK]", row["target"]).encode()).hexdigest()
    if {gold(row) for row in train} & {gold(row) for row in validation}:
        raise ValueError("Exact reconstructed-code duplicate crosses the split")
    return {"train_rows": len(train), "validation_rows": len(validation),
            "train_repositories": len(train_repos), "validation_repositories": len(val_repos),
            "repository_overlap": 0, "exact_code_overlap": 0}


def sampled_indices(count, step, batch_size, seed):
    """Exact global order of upstream two-rank DistributedSampler/drop_last.

    Both native loaders use sampler.seed=seed and sampler.set_epoch(epoch).
    Native source Parquet rows must preserve source JSONL order.
    """
    import torch
    steps_per_epoch = count // batch_size
    if steps_per_epoch < 1 or step < 1:
        raise ValueError("Need one complete global batch and a positive step")
    epoch, within = divmod(step - 1, steps_per_epoch)
    permutation = torch.randperm(count, generator=torch.Generator().manual_seed(seed + epoch)).tolist()
    return permutation[within * batch_size:(within + 1) * batch_size]


def schedule_factor(step, total, warmup):
    """The upstream verl cosine schedule, including its zero first warmup LR."""
    if step < warmup:
        return step / max(1, warmup)
    progress = (step - warmup) / max(1, total - warmup)
    return max(0., .5 * (1 + math.cos(math.pi * progress)))


def make_state(record, model_name, seed, step, ordinal, config):
    rng = random.Random((seed + 1) * 1000000007 + step * 100003 + ordinal)
    if model_name == "dreamon":
        state = corrupt(record, rng, **{key: config[key] for key in
                         ("max_length", "max_delete", "max_total_delete", "merge_prob", "static_probability")})
        state["masked_count"] = sum(state["action_counts"].values())
        return state
    ids = list(record["gold_input_ids"])
    labels = [-100] * len(ids)
    for start, end in record["target_token_spans"]:
        for position in range(start, end):
            labels[position], ids[position] = ids[position], 151666
    return {"input_ids": ids, "labels": labels, "time_weight": 1.0,
            "masked_count": sum(x != -100 for x in labels)}


def require_finite(tensor, label):
    import torch
    if not bool(torch.isfinite(tensor).all().item()):
        raise FloatingPointError(f"Non-finite {label}; this run is invalid")


def check_parameters(model, label):
    import torch
    # Only locally owned FSDP shards are checked; every rank executes this gate.
    for name, parameter in model.named_parameters():
        require_finite(parameter.detach(), f"{label} parameter {name}")


def acquire_export_lock(output, rank, full):
    """Serialize new exports on the shared storage and retain 80 GiB headroom."""
    if rank:
        return None
    import fcntl
    storage = Path(os.getenv("CF_NATIVE_STORAGE", str(Path(output).resolve().parent)))
    handle = (storage / ".protocol-verification-export.lock").open("a")
    fcntl.flock(handle, fcntl.LOCK_EX)
    required = (80 if full else 2) * 2**30
    if shutil.disk_usage(output).free < required:
        handle.close()
        raise RuntimeError(f"Insufficient free storage before export; require {required / 2**30:g} GiB")
    return handle


def build_loss_module(base, model_name="dreamcoder"):
    import torch
    import torch.nn.functional as F

    class SparseIdentifierLoss(torch.nn.Module):
        def __init__(self, model):
            super().__init__()
            self.base = model

        def forward(self, input_ids, labels, time_weight=1.0):
            native = self.base.get_base_model() if hasattr(self.base, "get_base_model") else self.base
            positions = torch.nonzero(labels != -100, as_tuple=False).flatten()
            if positions.numel() == 0 or int(positions.min()) <= 0:
                raise ValueError("Identifier supervision requires nonempty targets after BOS")
            if not bool((input_ids[0, positions] == 151666).all().item()):
                raise ValueError("Only native mask positions may receive action labels")
            length = input_ids.shape[-1]
            attention = torch.ones((1, 1, length, length), dtype=torch.bool, device=input_ids.device)
            hidden = native.model(input_ids=input_ids, attention_mask=attention,
                                  position_ids=torch.arange(length, device=input_ids.device)[None],
                                  use_cache=False, return_dict=True)[0]
            # Native Dream samplers use the physical one-position shift.
            logits = native.lm_head(hidden[0, positions - 1])
            if model_name == "dreamon":
                loss, _, _ = balanced_loss(logits, labels[positions], time_weight)
            else:
                loss = F.cross_entropy(logits.float(), labels[positions], reduction="mean")
            return loss

    return SparseIdentifierLoss(base)


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", required=True)
    p.add_argument("--train-file", required=True)
    p.add_argument("--validation-file", required=True, help="Selection validation only, never ablation test")
    p.add_argument("--output", required=True)
    p.add_argument("--model-path", help="Local pinned HF snapshot")
    p.add_argument("--steps", type=int)
    p.add_argument("--learning-rate", type=float)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--prepare-only", action="store_true")
    return p


def run(argv=None):
    args = parser().parse_args(argv)
    config = json.loads(Path(args.config).read_text())
    if args.steps is not None:
        config["steps"] = args.steps
    if args.learning_rate is not None:
        config["learning_rate"] = args.learning_rate
    validate_config(config)
    if "test" in Path(args.validation_file).stem.lower():
        raise ValueError("A test file cannot be supplied for validation")
    train = load_records(args.train_file)
    validation = load_records(args.validation_file)
    split_audit = audit_splits(train, validation)
    profile = MODELS[config["model"]]
    source = {"train": str(Path(args.train_file).resolve()), "selection_validation": str(Path(args.validation_file).resolve())}
    contract = {"config": config, "profile": profile, "seed": args.seed,
                "source_data": source, "data_sha256": {key: file_hash(path) for key, path in source.items()},
                "source_sha256": {str(Path(__file__).name): file_hash(__file__),
                                  **{f"variable_identifier/{name}.py": file_hash(Path(__file__).parents[1] / "variable_identifier" / f"{name}.py")
                                     for name in ("corruption", "runtime", "train")}},
                "split_audit": split_audit, "selection": "External shared evaluator on selection_validation only",
                "precision": "fp32 master parameters and AdamW states; bf16 forward; fp32 gradients/reductions",
                "sample_policy": "upstream two-rank shuffled epoch order, drop incomplete global batch; all context and occurrences retained",
                "initial_masks_at_inference": 4 if config["model"] == "dreamon" else 2,
                "training_masks": "variable action corruption; not a fixed inference initial canvas"}
    from transformers import AutoTokenizer
    local = args.model_path or profile["model_id"]
    if args.model_path and Path(args.model_path).name != profile["revision"]:
        raise ValueError("Local model path must identify the pinned revision snapshot")
    common = {"trust_remote_code": True, "local_files_only": True}
    if not args.model_path:
        common.update(revision=profile["revision"], code_revision=profile["revision"])
    tokenizer = AutoTokenizer.from_pretrained(local, **common)
    if (tokenizer.bos_token_id, tokenizer.mask_token_id, tokenizer.eos_token_id) != (151665, 151666, 151643):
        raise ValueError("Pinned tokenizer token contract failed")
    prepared = {"train": [], "validation": []}
    for split, rows in (("train", train), ("validation", validation)):
        for row in rows:
            prepared[split].append(prepare_record(row, tokenizer, config["max_length"]))
    contract["max_intact_sequence_lengths"] = {key: max(len(row["gold_input_ids"]) for row in value) for key, value in prepared.items()}
    contract["identifier_objective"] = ("dreamon_official_augmented_all_identifier_masked" if config["model"] == "dreamon"
                                         else "fixed_length_all_occurrences")
    if args.prepare_only:
        print(json.dumps({"status": "prepared_no_weights_loaded", "contract": contract}), flush=True)
        return 0
    import torch
    import torch.distributed as dist
    from functools import partial
    from torch.distributed.fsdp import FullyShardedDataParallel as FSDP, MixedPrecision, ShardingStrategy
    from torch.distributed.fsdp.wrap import transformer_auto_wrap_policy
    from transformers import AutoModel
    from peft import LoraConfig, get_peft_model
    rank, world, local_rank = (int(os.getenv(key, default)) for key, default in (("RANK", "0"), ("WORLD_SIZE", "1"), ("LOCAL_RANK", "0")))
    if not torch.cuda.is_available() or not torch.cuda.is_bf16_supported():
        raise RuntimeError("Requires CUDA bf16-capable RTX PRO 6000")
    torch.cuda.set_device(local_rank)
    gpu_name = torch.cuda.get_device_name(local_rank)
    if "RTX PRO 6000" not in gpu_name.upper():
        raise RuntimeError(f"Explicit hardware contract failed: {gpu_name}")
    if world != 2 or config["global_batch_size"] % world:
        raise ValueError("Matched protocol requires two GPUs and a divisible global batch")
    dist.init_process_group("nccl")
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    random.seed(args.seed)
    output = Path(args.output)
    if rank == 0:
        if output.exists() and any(output.iterdir()):
            raise FileExistsError(f"Refusing to overwrite an existing run: {output}")
        output.mkdir(parents=True, exist_ok=True)
    dist.barrier()
    base = AutoModel.from_pretrained(local, **common, torch_dtype=torch.float32,
                                     attn_implementation="sdpa", low_cpu_mem_usage=True)
    if base.config.mask_token_id != 151666 or base.config.eos_token_id != 151643:
        raise ValueError("Pinned native model token contract failed")
    if (getattr(base.config, "expand_token_id", None) == 151667) != (config["model"] == "dreamon"):
        raise ValueError("Wrong fixed/variable-canvas native model")
    base.config.use_cache = False
    base.config._name_or_path = profile["model_id"]
    layer_class = type(base.model.layers[0])
    if config["adaptation"] == "lora":
        base = get_peft_model(base, LoraConfig(r=config["rank"], lora_alpha=config["lora_alpha"],
            lora_dropout=config["lora_dropout"], target_modules=LORA_MODULES, bias="none", revision=profile["revision"]))
        base.peft_config["default"].base_model_name_or_path = profile["model_id"]
    base.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    base.enable_input_require_grads()
    trainable_count = sum(p.numel() for p in base.parameters() if p.requires_grad)
    total_count = sum(p.numel() for p in base.parameters())
    model = FSDP(build_loss_module(base, config["model"]),
        auto_wrap_policy=partial(transformer_auto_wrap_policy, transformer_layer_cls={layer_class}),
        sharding_strategy=ShardingStrategy.FULL_SHARD,
        mixed_precision=MixedPrecision(param_dtype=torch.bfloat16, reduce_dtype=torch.float32, buffer_dtype=torch.float32),
        device_id=local_rank, sync_module_states=True, use_orig_params=True, limit_all_gathers=True)
    optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],
        lr=config["learning_rate"], betas=tuple(config["betas"]), weight_decay=config["weight_decay"], foreach=False)
    warmup = int(config["steps"] * config["warmup_fraction"])
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer,
        lambda step: schedule_factor(step, config["steps"], warmup))
    run_meta = {"contract": contract, "training_type": config["adaptation"],
        "trainable_parameters": trainable_count, "total_parameters": total_count,
        "world_size": world, "gpu": gpu_name, "torch_version": torch.__version__,
        "slurm_job_id": os.getenv("SLURM_JOB_ID"), "status": "running"}
    if rank == 0:
        write_json(output / "run.json", run_meta)
    check_parameters(model, "initial")
    local_batch = config["global_batch_size"] // world
    metrics_stream = (output / "metrics.jsonl").open("w") if rank == 0 else nullcontext()
    save_steps = set(config["save_steps"]) | {config["steps"]}

    def save_checkpoint(step):
        from torch.distributed.fsdp import FullStateDictConfig, StateDictType
        check_parameters(model, f"pre-export step {step}")
        export_lock = acquire_export_lock(output, rank, config["adaptation"] == "full")
        with FSDP.state_dict_type(model, StateDictType.FULL_STATE_DICT,
                                 FullStateDictConfig(offload_to_cpu=True, rank0_only=True)):
            state = model.state_dict()
        if rank == 0:
            state = {key.removeprefix("base."): tensor for key, tensor in state.items()}
            for key, tensor in state.items():
                require_finite(tensor, f"export {key}")
            # Inference-only export limits each full checkpoint to about 15 GB;
            # the optimizer always updates full-precision master parameters.
            if config["adaptation"] == "full":
                state = {key: value.to(torch.bfloat16) if value.is_floating_point() else value
                         for key, value in state.items()}
            destination = output / f"checkpoint-{step:06d}"
            staging = output / (destination.name + ".incomplete")
            staging.mkdir()
            base.save_pretrained(staging, state_dict=state, safe_serialization=True, max_shard_size="5GB")
            tokenizer.save_pretrained(staging)
            weight_files = list(staging.glob("*.safetensors"))
            if not weight_files:
                raise RuntimeError("Checkpoint export has no safetensors")
            write_json(staging / "checkpoint.json", {
                "step": step, "optimizer_step": step, "examples_seen": step * config["global_batch_size"],
                "model": config["model"], "profile": profile, "training_type": config["adaptation"],
                "objective": "identifier", "config": config, "source_data": source,
                "data_sha256": contract["data_sha256"], "seed": args.seed,
                "weight_sha256": {path.name: file_hash(path) for path in weight_files},
                "export_precision": "bf16" if config["adaptation"] == "full" else "fp32 adapters",
                "finite_weights": True, "inference_initial_masks": 4 if config["model"] == "dreamon" else 2,
                "resume_supported": False, "selection_status": "unselected"})
            staging.rename(destination)
        del state
        dist.barrier()
        if export_lock is not None:
            export_lock.close()

    with metrics_stream as stream:
        for step in range(1, config["steps"] + 1):
            tick = time.monotonic()
            model.train()
            optimizer.zero_grad(set_to_none=True)
            indices = sampled_indices(len(train), step, config["global_batch_size"], args.seed)
            local_loss = 0.0
            supervised = 0
            for ordinal in range(rank, len(indices), world):
                state = make_state(prepared["train"][indices[ordinal]], config["model"], args.seed, step, ordinal, config)
                ids = torch.tensor([state["input_ids"]], dtype=torch.long, device=local_rank)
                labels = torch.tensor(state["labels"], dtype=torch.long, device=local_rank)
                with torch.autocast("cuda", dtype=torch.bfloat16):
                    loss = model(ids, labels, state["time_weight"])
                require_finite(loss.detach(), f"training loss at step {step}")
                (loss / local_batch).backward()
                local_loss += float(loss.detach()) / local_batch
                supervised += state["masked_count"]
            grad_norm = model.clip_grad_norm_(config["gradient_clip"])
            require_finite(grad_norm, f"gradient norm at step {step}")
            for name, p in model.named_parameters():
                if p.grad is not None:
                    require_finite(p.grad, f"gradient {name} at step {step}")
            learning_rate_used = optimizer.param_groups[0]["lr"]
            optimizer.step()
            scheduler.step()
            check_parameters(model, f"post-update step {step}")
            aggregate = torch.tensor([local_loss, supervised], dtype=torch.float64, device=local_rank)
            dist.all_reduce(aggregate)
            if rank == 0:
                row = {"step": step, "train_loss": float(aggregate[0]) / world,
                    "grad_norm": float(grad_norm), "learning_rate": learning_rate_used,
                    "examples_seen": step * config["global_batch_size"], "supervised_tokens": int(aggregate[1]),
                    "step_seconds": time.monotonic() - tick,
                    "max_memory_allocated_gib": torch.cuda.max_memory_allocated() / 2**30,
                    "numerical_gates": "finite loss, gradients, norm, post-update weights"}
                stream.write(json.dumps(row, allow_nan=False) + "\n")
                stream.flush()
                print(json.dumps(row), flush=True)
            if step in save_steps:
                save_checkpoint(step)
        if rank == 0:
            run_meta.update(status="training_complete_unselected", completed_steps=config["steps"],
                            examples_seen=config["steps"] * config["global_batch_size"])
            write_json(output / "completion.json", run_meta)
    dist.destroy_process_group()
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
