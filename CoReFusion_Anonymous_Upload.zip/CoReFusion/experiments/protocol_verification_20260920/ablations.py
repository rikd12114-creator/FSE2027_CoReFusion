"""Freeze repository-disjoint selection and source-linked Java ablation cohorts.

Offsets are Unicode characters. Gold names are scoring metadata: evaluation
constructs every non-oracle input solely from code_masked and fixed budgets.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import sys

from experiments.late_rename.prepare_data import (
    lexical_tokens, normalized_fingerprint, normalize_repository, valid_identifier,
)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":")).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_jsonl(path):
    with Path(path).open() as stream:
        return [json.loads(line) for line in stream if line.strip()]


def write_jsonl(path, rows):
    with Path(path).open("x") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def partition_repository(repository, seed=20260920, test_fraction=.25):
    if not 0 < test_fraction < 1:
        raise ValueError("test fraction must be strictly between zero and one")
    value = int(digest([seed, normalize_repository(repository)])[:16], 16) / 2**64
    return "ablation_test" if value < test_fraction else "selection_validation"


def original_code(row):
    template = row.get("code_masked_template", row.get("code_masked"))
    reconstructed = template.replace("[MASK]", row["target"])
    if row.get("code", reconstructed) != reconstructed:
        raise ValueError("Saved source does not match the original mask template")
    return reconstructed


def canonical_selection_row(row):
    return {"id": str(row["id"]), "repository": normalize_repository(row["repository"]),
            "code_masked": row.get("code_masked_template", row["code_masked"]),
            "target": row["target"], "source_path": row.get("source_path", ""),
            "split": "validation", "source_row_sha256": digest(row)}


def blank_comments(code):
    # The existing scanner preserves literals including Java text blocks.
    out = [char if char.isspace() else " " for char in code]
    for _, _, start, end in lexical_tokens(code):
        out[start:end] = code[start:end]
    return "".join(out)


def make_task(code, candidates, source, condition):
    """Mask every occurrence, preserving identifier identity separately from text."""
    targets, edits = {}, []
    for index, candidate in enumerate(candidates):
        group = f"identifier_{index}"
        target = candidate["target"]
        if not valid_identifier(target):
            raise ValueError("Invalid identifier")
        targets[group] = target
        expected = [(a, b) for kind, text, a, b in lexical_tokens(code)
                    if kind == "identifier" and text == target]
        spans = [tuple(s) for s in candidate["target_spans"]]
        if spans != expected or len(spans) < 2:
            raise ValueError("AST target does not cover every lexical occurrence")
        if any(target in text for kind, text, _, _ in lexical_tokens(code) if kind == "literal"):
            raise ValueError("Target spelling appears in a literal")
        edits.extend((a, b, group) for a, b in spans)
    edits.sort()
    if any(left[1] > right[0] for left, right in zip(edits, edits[1:])):
        raise ValueError("Overlapping target spans")
    masked, cursor = [], 0
    for start, end, _ in edits:
        masked.extend((code[cursor:start], "[MASK]"))
        cursor = end
    masked.append(code[cursor:])
    masked = "".join(masked)
    if any(kind == "identifier" and name in targets.values()
           for kind, name, _, _ in lexical_tokens(masked)):
        raise ValueError("Visible target identifier remains")
    cluster = normalized_fingerprint(code)
    groups = [group for _, _, group in edits]
    task = {"id": digest([source["repository"], cluster, condition, targets]),
            "repository": source["repository"], "source_cluster_id": cluster,
            "source_row_id": str(source["id"]), "source_file_id": source.get("source_file_id"),
            "source_path": source.get("source_path"), "source_code_sha256": digest(code),
            "source_row_sha256": digest(source), "condition": condition,
            "code_masked": masked, "targets": targets, "identifier_by_site": groups,
            "target_by_site": [targets[group] for group in groups],
            "original_character_spans": [[a, b] for a, b, _ in edits],
            "focal_identifier": "identifier_0", "split": "test",
            "num_identifiers": len(targets), "num_sites": len(edits),
            "comments": "blanked with offsets preserved", "literal_answer_leakage": False,
            "binding_policy": "conservative declaration-backed spelling; not compiler-resolved"}
    return task


def tasks_for_source(row, *, seed=20260920, max_identifiers=3):
    """Re-extract from the exact saved method, excluding ambiguous syntax roles."""
    from experiments.stack_v2_java.identifiers import extract_samples
    code = blank_comments(original_code(row))
    if "[MASK]" in code:
        raise ValueError("Raw source contains mask literal")
    # Complete methods are legal within a synthetic class. The wrapper is used
    # only for parsing and is absent from every model input and source hash.
    wrapper = "class ProtocolAblation {\n" + code + "\n}"
    candidates = extract_samples(wrapper, min_occurrences=2)
    groups = {}
    for candidate in candidates:
        groups.setdefault(candidate["code"], []).append(candidate)
    tasks = []
    for snippet, candidates in sorted(groups.items()):
        candidates = sorted(candidates, key=lambda item: digest([seed, item["target"]]))
        eligible = []
        for candidate in candidates:
            try:
                make_task(snippet, [candidate], row, "eligibility")
                eligible.append(candidate)
            except ValueError:
                continue
        if not eligible:
            continue
        # The same focal name/source occurs in every paired difficulty arm.
        for number in range(1, min(max_identifiers, len(eligible)) + 1):
            condition = "same_identifier" if number == 1 else f"multiple_identifiers_{number}"
            tasks.append(make_task(snippet, eligible[:number], row, condition))
    return tasks


def build(source_validation, source_train, output, *, seed=20260920,
          test_fraction=.25, legacy_test=None):
    from experiments.protocol_verification_20260920.data_audit import alpha_fingerprint
    validation, training = read_jsonl(source_validation), read_jsonl(source_train)
    train_repos = {normalize_repository(r["repository"]) for r in training}
    train_sources = {normalized_fingerprint(original_code(r)) for r in training}
    train_alpha = {alpha_fingerprint(original_code(r)) for r in training}
    validation_repos = {normalize_repository(r["repository"]) for r in validation}
    if train_repos & validation_repos:
        raise ValueError("Original train/validation repositories overlap")
    legacy_sources = set()
    legacy_alpha = set()
    if legacy_test:
        csv.field_size_limit(sys.maxsize)
        with Path(legacy_test).open(newline="") as stream:
            for _, masked, target in csv.reader(stream):
                legacy_sources.add(normalized_fingerprint(masked.replace("[MASK]", target)))
                legacy_alpha.add(alpha_fingerprint(masked.replace("[MASK]", target)))
    # Treat repositories linked by alpha-normalized validation source clones
    # as indivisible components; a clone can never bridge selection and test.
    parents = {repository: repository for repository in validation_repos}
    def root(repo):
        while parents[repo] != repo:
            parents[repo] = parents[parents[repo]]
            repo = parents[repo]
        return repo
    alpha_owner = {}
    for row in validation:
        repo = normalize_repository(row["repository"])
        fingerprint = alpha_fingerprint(original_code(row))
        if fingerprint in train_alpha or fingerprint in legacy_alpha:
            continue
        if fingerprint in alpha_owner:
            a, b = sorted((root(repo), root(alpha_owner[fingerprint])))
            parents[b] = a
        else:
            alpha_owner[fingerprint] = repo
    components = {}
    for repo in sorted(validation_repos):
        components.setdefault(root(repo), []).append(repo)
    partitions = {repo: ("ablation_test" if int(digest([seed, members])[:16], 16)/2**64 < test_fraction
                         else "selection_validation")
                  for members in components.values() for repo in members}
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    rows, tasks, excluded, seen = [], [], [], set()
    for row in sorted(validation, key=lambda r: (r["repository"], str(r["id"]))):
        repo = normalize_repository(row["repository"])
        partition = partitions[repo]
        source_hash = normalized_fingerprint(original_code(row))
        source_alpha = alpha_fingerprint(original_code(row))
        if source_alpha in train_alpha or source_alpha in legacy_alpha:
            excluded.append({"id": str(row["id"]), "repository": repo,
                             "reason": "alpha_clone_overlap_train_or_legacy"})
            continue
        if source_hash in train_sources or source_hash in legacy_sources:
            excluded.append({"id": str(row["id"]), "repository": repo,
                             "reason": "source_overlap_train_or_legacy"})
            continue
        if partition == "selection_validation":
            rows.append(canonical_selection_row(row))
            continue
        key = (repo, source_hash)
        if key in seen:
            continue
        seen.add(key)
        try:
            new = tasks_for_source(dict(row, repository=repo), seed=seed)
            tasks.extend(new)
            if not new:
                excluded.append({"id": str(row["id"]), "repository": repo, "reason": "no_eligible_target"})
        except ValueError as exc:
            excluded.append({"id": str(row["id"]), "repository": repo, "reason": str(exc)})
    if not rows or not tasks:
        raise ValueError("Empty selection or ablation cohort")
    # Source clones across validation repos are retained only on one side. A
    # reserved-test clone must never be used for new checkpoint selection.
    test_clusters = {task["source_cluster_id"] for task in tasks}
    screened = []
    for row in rows:
        if normalized_fingerprint(original_code(row)) in test_clusters:
            excluded.append({"id": row["id"], "repository": row["repository"],
                             "reason": "selection_source_clone_of_reserved_test"})
        else:
            screened.append(row)
    rows = screened
    if not rows:
        raise ValueError("Selection empty after clone screen")
    if len({task["id"] for task in tasks}) != len(tasks):
        raise ValueError("Duplicate ablation task IDs")
    write_jsonl(output / "selection_validation.jsonl", rows)
    write_jsonl(output / "ablation_test.jsonl", tasks)
    write_jsonl(output / "excluded.jsonl", excluded)
    manifest = {"schema_version": 1, "seed": seed, "test_fraction": test_fraction,
                "source_validation": {"path": str(source_validation), "sha256": file_hash(source_validation)},
                "source_train": {"path": str(source_train), "sha256": file_hash(source_train)},
                "legacy_test_sha256": file_hash(legacy_test) if legacy_test else None,
                "files": {name: {"sha256": file_hash(output / name), "rows": count}
                          for name, count in [("selection_validation.jsonl", len(rows)),
                                              ("ablation_test.jsonl", len(tasks)),
                                              ("excluded.jsonl", len(excluded))]},
                "selection_repositories": sorted({r["repository"] for r in rows}),
                "reserved_test_repositories": sorted(r for r in validation_repos if partitions[r] == "ablation_test"),
                "repository_clone_components": sorted(components.values()),
                "partition_unit": "repository components connected by lexical alpha-normalized source clones",
                "task_counts": dict(Counter(t["condition"] for t in tasks)),
                "binding_limit": "syntax-based conservative screening, not compiler binding resolution",
                "selection_rule": "new run selection may consume selection_validation only",
                "historical_contamination_boundary": "prior runs may already have used all original validation repositories"}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-validation", required=True)
    parser.add_argument("--source-train", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--legacy-test")
    parser.add_argument("--seed", type=int, default=20260920)
    parser.add_argument("--test-fraction", type=float, default=.25)
    args = parser.parse_args(argv)
    print(json.dumps(build(args.source_validation, args.source_train, args.output,
                           seed=args.seed, test_fraction=args.test_fraction,
                           legacy_test=args.legacy_test), indent=2))


if __name__ == "__main__":
    main()
