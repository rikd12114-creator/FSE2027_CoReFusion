"""Paired inference comparison with immutable denominators and cluster intervals."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import random

from experiments.protocol_verification_20260920.ablations import file_hash, read_jsonl


def complete_rows(path, decode_condition):
    path = Path(path)
    manifest = json.loads(path.with_suffix(".manifest.json").read_text())
    if manifest.get("status") != "complete" or manifest.get("result_sha256") != file_hash(path):
        raise ValueError("Evaluation is incomplete or its bytes differ from its manifest")
    rows = [row for row in read_jsonl(path) if row["decode_condition"] == decode_condition]
    if len(rows) != manifest["n"] or len({row["id"] for row in rows}) != len(rows):
        raise ValueError("A decode condition must contain every planned row exactly once")
    return rows,manifest


def interval(left,right,*,metric="strict_em",seed=42,replicates=10000,repository_components=None):
    if type(replicates) is not int or replicates < 100:
        raise ValueError("Require at least 100 bootstrap replicates")
    if not left or [r["id"] for r in left] != [r["id"] for r in right]:
        raise ValueError("Paired comparison requires the same nonempty IDs and order")
    groups=defaultdict(list)
    for before,after in zip(left,right):
        if (before.get("repository"),before["source_cluster_id"]) != (after.get("repository"),after["source_cluster_id"]):
            raise ValueError("Paired source identities differ")
        repository=before.get("repository")
        cluster=((repository_components or {}).get(repository,repository)
                 if repository else before["source_cluster_id"])
        groups[cluster].append(int(after[metric])-int(before[metric]))
    sufficient=[(sum(values),len(values)) for values in groups.values()]
    rng=random.Random(seed)
    draws=[]
    for _ in range(replicates):
        picked=[rng.choice(sufficient) for _ in sufficient]
        draws.append(sum(s for s,n in picked)/sum(n for s,n in picked))
    draws.sort()
    return {"n":len(left),"clusters":len(groups),"metric":metric,
            "left":sum(r[metric] for r in left)/len(left),
            "right":sum(r[metric] for r in right)/len(right),
            "right_minus_left":sum(s for s,n in sufficient)/len(left),
            "cluster_bootstrap_95_percentile_interval":[draws[int(.025*(replicates-1))],draws[int(.975*(replicates-1))]],
            "discordant_left_only":sum(bool(a[metric]) and not b[metric] for a,b in zip(left,right)),
            "discordant_right_only":sum(bool(b[metric]) and not a[metric] for a,b in zip(left,right)),
            "replicates":replicates,"seed":seed}


def stratum(row):
    sites=row["sites"]
    gold=max(row["gold_token_lengths"])
    return {"masked_sites":"1" if sites==1 else "2" if sites==2 else "3-4" if sites<=4 else "5-8" if sites<=8 else "9+",
            "max_target_tokens":str(gold) if gold<=3 else "4+",
            "identifiers":str(len(set(row["identifier_by_site"]))),
            "task":row["condition"]}


def compare(left,right,*,seed=42,replicates=10000,repository_components=None):
    left=sorted(left,key=lambda r:r["id"])
    right=sorted(right,key=lambda r:r["id"])
    primary=interval(left,right,seed=seed,replicates=replicates,repository_components=repository_components)
    strata={}
    for field in ("masked_sites","max_target_tokens","identifiers","task"):
        strata[field]={}
        for label in sorted({stratum(row)[field] for row in left}):
            pairs=[(a,b) for a,b in zip(left,right) if stratum(a)[field]==label]
            a,b=map(list,zip(*pairs))
            strata[field][label]=interval(a,b,seed=seed,replicates=replicates,repository_components=repository_components)
    return {"primary":primary,
            "focal_identifier":interval(left,right,metric="focal_em",seed=seed,replicates=replicates,repository_components=repository_components),
            "context_plan_matches":sum([w["context_sha256"] for w in a["windows"]]==[w["context_sha256"] for w in b["windows"]]
                                       for a,b in zip(left,right)),
            "input_plan_matches":sum([w["input_plan_sha256"] for w in a["windows"]]==[w["input_plan_sha256"] for w in b["windows"]]
                                     for a,b in zip(left,right)),
            "error_samples":{"left":sum(bool(r["errors"]) for r in left),"right":sum(bool(r["errors"]) for r in right)},
            "strata":strata,"multiple_comparison_note":"All strata and grid comparisons are prespecified descriptive analyses; no test-based model or budget selection."}


def compare_tasks(left,right,left_task,right_task,*,seed=42,replicates=10000,repository_components=None):
    """Compare the SAME focal name on matched source while hiding more names.

    Masked-site count necessarily changes; this estimates added-hidden-context
    difficulty, not a causal identifier-count effect holding site count fixed.
    """
    def index(rows,condition):
        result={}
        for row in rows:
            if row["condition"]!=condition:
                continue
            focal=next(target for target,group in zip(row["target_by_site"],row["identifier_by_site"])
                       if group=="identifier_0")
            key=json.dumps([row.get("repository"),row["source_cluster_id"],focal],separators=(",",":"))
            if key in result:
                raise ValueError("Duplicate source/focal task pairing")
            result[key]=dict(row,id=key)
        return result
    a,b=index(left,left_task),index(right,right_task)
    keys=sorted(set(a)&set(b))
    if not keys:
        raise ValueError("No common source/focal identifiers across task arms")
    before,after=[a[k] for k in keys],[b[k] for k in keys]
    joint=[i for i in range(len(keys)) if before[i]["all_target_sites_one_window"] and after[i]["all_target_sites_one_window"]]
    return {"paired_focal":interval(before,after,metric="focal_em",seed=seed,replicates=replicates,repository_components=repository_components),
            "fully_joint_single_window_focal":interval([before[i] for i in joint],[after[i] for i in joint],metric="focal_em",
                    seed=seed,replicates=replicates,repository_components=repository_components) if joint else None,
            "unpaired_sources":{"left":len(a)-len(keys),"right":len(b)-len(keys)},
            "mean_masked_sites":{"left":sum(r["sites"] for r in before)/len(keys),"right":sum(r["sites"] for r in after)/len(keys)},
            "interpretation":"Source/focal paired difficulty under additional hidden names. Identifier count and total masked sites jointly change; no isolated identity-count causal claim."}


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--left",required=True)
    parser.add_argument("--right",required=True)
    parser.add_argument("--left-condition",required=True)
    parser.add_argument("--right-condition",required=True)
    parser.add_argument("--left-task")
    parser.add_argument("--right-task")
    parser.add_argument("--split-manifest",help="groups clone-linked repositories for bootstrap")
    parser.add_argument("--output",required=True)
    parser.add_argument("--replicates",type=int,default=10000)
    parser.add_argument("--seed",type=int,default=42)
    args=parser.parse_args(argv)
    left,lm=complete_rows(args.left,args.left_condition)
    right,rm=complete_rows(args.right,args.right_condition)
    if lm["data_sha256"] != rm["data_sha256"]:
        raise ValueError("Paired model/budget comparison requires identical dataset bytes")
    components={}
    if args.split_manifest:
        manifest=json.loads(Path(args.split_manifest).read_text())
        components={repo:json.dumps(members) for members in manifest["repository_clone_components"] for repo in members}
    if bool(args.left_task)!=bool(args.right_task):
        parser.error("Supply both task names for source/focal paired task comparison")
    result=(compare_tasks(left,right,args.left_task,args.right_task,seed=args.seed,replicates=args.replicates,repository_components=components)
            if args.left_task else compare(left,right,seed=args.seed,replicates=args.replicates,repository_components=components))
    result["inputs"]={"left_sha256":file_hash(args.left),"right_sha256":file_hash(args.right),
                      "left_condition":args.left_condition,"right_condition":args.right_condition}
    with Path(args.output).open("x") as stream:
        json.dump(result,stream,indent=2)
        stream.write("\n")
    print(json.dumps(result.get("primary",result.get("paired_focal")),indent=2))


if __name__=="__main__":
    main()
