"""CPU-only bridge from historical Dream-Coder windows to controlled windows."""
import argparse
from collections import Counter
import json
from pathlib import Path

from experiments.fixed_identifier.runtime import load_tokenizer
from experiments.refineid_comparison.data import build_masked_windows
from experiments.protocol_verification_20260920.ablations import digest,file_hash,read_jsonl
from experiments.protocol_verification_20260920.evaluate import input_windows,read_records
from experiments.late_rename.evaluate import extract_sites


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--test",default="data/test.csv")
    parser.add_argument("--old-results",default="results/refineid_comparison_20260910/final")
    parser.add_argument("--new-results",default="results/protocol_audit_20260920/remote")
    parser.add_argument("--output",default="results/protocol_audit_20260920/dreamcoder-input-plan-bridge.json")
    args=parser.parse_args(argv)
    tokenizer=load_tokenizer("dreamcoder",local_files_only=True)
    source=read_records(args.test,"test")
    oldroot,newroot=Path(args.old_results),Path(args.new_results)
    oldmanifest=json.loads((oldroot/"manifest.json").read_text())
    oldreport=json.loads((oldroot/"report.json").read_text())
    assert oldmanifest["dataset_sha256"]==file_hash(args.test)
    newmanifest=json.loads((newroot/"dreamcoder-historical-lora-test-2vs4.manifest.json").read_text())
    assert oldmanifest["checkpoint"]["metadata"]["adapter_sha256"]==newmanifest["checkpoint_hashes"]["adapter_model.safetensors"]
    old,new={},{}
    for oldvariant,newvariant in (("base","base"),("adapter","historical-lora")):
        path=oldroot/f"{oldvariant}-fixed_2.jsonl"
        assert file_hash(path)==oldreport["variants"][oldvariant]["fixed_2"]["sha256"]
        old[newvariant]={row["id"]:row for row in read_jsonl(path)}
        new[newvariant]={row["id"]:row for row in read_jsonl(newroot/f"dreamcoder-{newvariant}-test-2vs4.jsonl") if row["decode_condition"]=="fixed2"}
    details=[]
    predicted={variant:Counter() for variant in old}
    differences={variant:[] for variant in old}
    normalization={variant:Counter() for variant in old}
    for original in source:
        sample_id=original["id"]
        oldplan=build_masked_windows(original["code_masked"],tokenizer,mask_length=2,max_length=1024)
        newplan=input_windows(original["code_masked"],tokenizer,initial_masks=2,max_length=1024,window_policy="controlled")
        assert oldplan["input_plan_sha256"]==old["base"][sample_id]["input_plan_sha256"]
        assert [digest(window.ids) for window,_ in newplan]==[w["input_plan_sha256"] for w in new["base"][sample_id]["windows"]]
        old_windows=[digest([window["input_ids"],window["owned_site_indices"],window["owned_token_spans"]]) for window in oldplan["windows"]]
        new_windows=[digest([window.ids,window.site_indices,window.sites]) for window,_ in newplan]
        old_inputs=Counter(digest(window["input_ids"]) for window in oldplan["windows"])
        new_inputs=Counter(digest(window.ids) for window,_ in newplan)
        same_windows=sum((old_inputs&new_inputs).values())
        oldsites={site:digest([window["input_ids"],span]) for window in oldplan["windows"]
                  for site,span in zip(window["owned_site_indices"],window["owned_token_spans"])}
        newsites={site:digest([window.ids,span]) for window,_ in newplan for site,span in zip(window.site_indices,window.sites)}
        assert set(oldsites)==set(newsites)==set(range(len(original["target_by_site"])))
        identical_sites=[site for site in oldsites if oldsites[site]==newsites[site]]
        same_task=old_windows==new_windows
        detail={"id":sample_id,"sites":len(oldsites),"old_windows":len(old_windows),"new_windows":len(new_windows),
                "identical_input_windows":same_windows,"identical_complete_task_plan":same_task,
                "identical_input_sites":len(identical_sites),"changed_input_sites":len(oldsites)-len(identical_sites),
                "old_total_context_tokens":sum(len(w["input_ids"])-sum(b-a for a,b in w["visible_token_spans"]) for w in oldplan["windows"]),
                "new_total_context_tokens":sum(len(w.ids)-sum(b-a for a,b in w.sites) for w,_ in newplan)}
        details.append(detail)
        for variant in old:
            previous,current=old[variant][sample_id],new[variant][sample_id]
            old_texts=[item["identifier_name"] for item in previous["predictions"]]
            normalized=[tokenizer.decode(item["token_ids"],skip_special_tokens=False).strip() for item in previous["predictions"]]
            old_score=previous["java_whitespace_trimmed_identifier_name_em"]
            new_style_score=bool(not previous["errors"] and all(text==original["target"] for text in normalized))
            normalization[variant]["tasks"]+=1
            normalization[variant]["old_score_differs_from_python_strip_recompute"]+=old_score!=new_style_score
            normalization[variant]["old_formatting_only_successes"]+=previous["formatting_only_success"]
            normalization[variant]["usable_sites_with_java_vs_python_trim_difference"]+=sum(
                bool(item["usable_tokens"] and item["text"].strip(" \t\r\n\f")!=item["text"].strip()) for item in previous["predictions"])
            predicted[variant]["all_identical_input_sites"]+=len(identical_sites)
            predicted[variant]["identical_input_sites_identical_text"]+=sum(normalized[site]==current["site_predictions"][site] for site in identical_sites)
            predicted[variant]["identical_input_sites_identical_exactness"]+=sum((normalized[site]==original["target"])==(current["site_predictions"][site]==original["target"]) for site in identical_sites)
            if same_task:
                replayed=[""]*len(old_texts)
                replay_context=True
                for window,_ in newplan:
                    sequence=list(window.ids)
                    for site,(start,end) in zip(window.site_indices,window.sites):
                        token_ids=previous["predictions"][site]["token_ids"]
                        assert len(token_ids)==end-start
                        sequence[start:end]=token_ids
                    extracted,ok=extract_sites(sequence,window,tokenizer)
                    replay_context &= ok
                    for site,text in zip(window.site_indices,extracted):replayed[site]=text
                normalization[variant]["old_token_replay_new_extraction_tasks"]+=1
                normalization[variant]["old_token_replay_context_preserved"]+=replay_context
                normalization[variant]["old_token_replay_new_extraction_matches_direct_decode"]+=replayed==normalized
                normalization[variant]["old_token_replay_old_strict_score_matches"]+=(bool(replay_context and all(t==original["target"] for t in replayed))==old_score)
                predicted[variant]["identical_complete_task_plan_tasks"]+=1
                predicted[variant]["identical_complete_task_plan_all_prediction_texts_match"]+=normalized==current["site_predictions"]
                predicted[variant]["identical_complete_task_plan_strict_scores_match"]+=old_score==current["strict_em"]
                predicted[variant]["old_correct_on_identical_complete_task_plans"]+=old_score
                predicted[variant]["new_correct_on_identical_complete_task_plans"]+=current["strict_em"]
                if normalized!=current["site_predictions"]:
                    differences[variant].append({"id":sample_id,"old_python_normalized":normalized,
                        "new_predictions":current["site_predictions"],"old_strict":old_score,"new_strict":current["strict_em"]})
            else:
                predicted[variant]["changed_plan_tasks"]+=1
                predicted[variant]["old_correct_on_changed_plans"]+=old_score
                predicted[variant]["new_correct_on_changed_plans"]+=current["strict_em"]
    def bin_sites(count):
        return "1" if count==1 else "2" if count==2 else "3-4" if count<=4 else "5-8" if count<=8 else "9+"
    strata={}
    for label in sorted({bin_sites(row["sites"]) for row in details}):
        group=[row for row in details if bin_sites(row["sites"])==label]
        strata[label]={"tasks":len(group),"identical_complete_task_plans":sum(row["identical_complete_task_plan"] for row in group),
                       "sites":sum(row["sites"] for row in group),"identical_input_sites":sum(row["identical_input_sites"] for row in group),
                       "changed_input_sites":sum(row["changed_input_sites"] for row in group),
                       "old_windows":sum(row["old_windows"] for row in group),"new_windows":sum(row["new_windows"] for row in group)}
    summary={"tasks":len(details),"sites":sum(row["sites"] for row in details),
             "old_windows":sum(row["old_windows"] for row in details),"new_windows":sum(row["new_windows"] for row in details),
             "identical_complete_task_plans":sum(row["identical_complete_task_plan"] for row in details),
             "tasks_with_any_identical_input_window":sum(row["identical_input_windows"]>0 for row in details),
             "identical_input_windows":sum(row["identical_input_windows"] for row in details),
             "identical_input_sites":sum(row["identical_input_sites"] for row in details),
             "changed_input_sites":sum(row["changed_input_sites"] for row in details)}
    report={"type":"CPU-only input-plan bridge; no model inference","summary":summary,"site_count_strata":strata,
            "old_protocol":"refineid_comparison.build_masked_windows:1024 context,2 boundary tokens,no reserve,no site cap; overlap retains masked visible slots",
            "new_protocol":"controlled reference4/reserve64/maxsites4 then fixed2; windows/anchors frozen across k2/k4",
            "old_legacy_flag_warning":"evaluate.py --window-policy legacy means historical DreamOn tokenize_windows, NOT historical Dream-Coder tile_canvas",
            "tokenizer_revision":newmanifest["profile"]["revision"],"data_sha256":file_hash(args.test),
            "old_prediction_hashes":{variant:file_hash(oldroot/f'{variant}-fixed_2.jsonl') for variant in ('base','adapter')},
            "adapter_weight_sha256":oldmanifest["checkpoint"]["metadata"]["adapter_sha256"],
            "prediction_invariance":{variant:dict(counts) for variant,counts in predicted.items()},
            "normalization_audit":{variant:dict(counts) for variant,counts in normalization.items()},
            "prediction_differences_on_identical_complete_plans":differences,"row_details":details}
    with Path(args.output).open("x") as stream:json.dump(report,stream,indent=2);stream.write("\n")
    print(json.dumps({key:report[key] for key in ('summary','site_count_strata','prediction_invariance','normalization_audit')},indent=2))


if __name__=="__main__":main()
