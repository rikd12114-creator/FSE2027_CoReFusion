"""Headerless ReFineID CSV, no dropped rows, complete-slot bounded windows."""
import csv
import hashlib
import json
from pathlib import Path
import sys

MASK = "[MASK]"
CONDITIONS = ("oracle_length", "fixed_2")


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_records(path, expected_rows=1000):
    csv.field_size_limit(sys.maxsize)
    with Path(path).open(newline="", encoding="utf-8") as stream:
        values = list(csv.reader(stream))
    if len(values) != expected_rows or any(len(row) != 3 for row in values):
        raise ValueError(f"Expected exactly {expected_rows} headerless id,masked_code,target rows")
    if len({row[0] for row in values}) != len(values):
        raise ValueError("CSV IDs must be unique")
    return [dict(zip(("id", "code_masked", "target"), row)) for row in values]


def tile_canvas(ids, spans, *, max_length, bos_token_id, eos_token_id):
    """Each site is owned exactly once; overlapping context remains masked.

    Center the first unassigned site within the content budget, use available
    edge context, then move boundaries inward if they would cut any mask span.
    Assign every previously unassigned complete site in this window. Already
    owned overlapping sites stay masks and receive no prediction transfer.
    """
    budget = max_length - 2
    if budget < 1 or not spans:
        raise ValueError("Positive context budget and at least one mask slot required")
    previous = 0
    for a, b in spans:
        if not 0 <= a < b <= len(ids) or a < previous or b - a > budget:
            raise ValueError("Invalid, overlapping, or oversized mask slot")
        previous = b
    windows, assigned = [], set()
    for site, (a, b) in enumerate(spans):
        if site in assigned:
            continue
        left = max(0, a - (budget - (b - a)) // 2)
        right = min(len(ids), left + budget)
        left = max(0, right - budget)
        for x, y in spans:
            if x < left < y:
                left = y
            if x < right < y:
                right = x
        included = [i for i, (x, y) in enumerate(spans) if left <= x and y <= right]
        owned = [i for i in included if i not in assigned]
        if site not in owned or not left <= a < b <= right:
            raise AssertionError("Window selection lost the current complete mask slot")
        assigned.update(owned)
        windows.append({
            "index": len(windows), "content_token_start": left, "content_token_end": right,
            "input_ids": [bos_token_id] + ids[left:right] + [eos_token_id],
            "owned_site_indices": owned, "visible_site_indices": included,
            "owned_token_spans": [[spans[i][0] - left + 1, spans[i][1] - left + 1] for i in owned],
            "has_all_file_context": left == 0 and right == len(ids),
        })
    if assigned != set(range(len(spans))):
        raise AssertionError("Some original CSV mask slots were not assigned")
    return windows


def build_masked_windows(code_masked, tokenizer, *, mask_length=2, max_length=1024):
    """Gold-free public canvas/window builder for fixed and native samplers.

    Return full content token spans plus windows with original site indices and
    local owned/visible spans. Native multi-step baselines can fill all visible
    slots, then extract only owned spans after verifying frozen context.
    """
    if type(mask_length) is not int or mask_length < 1:
        raise ValueError("mask_length must be a positive integer")
    parts = code_masked.split(MASK)
    if len(parts) < 2:
        raise ValueError("CSV row contains no [MASK] slot")
    ids, spans = [], []
    special = set(tokenizer.all_special_ids)
    for index, part in enumerate(parts):
        context = tokenizer.encode(part, add_special_tokens=False)
        if any(t in special for t in context):
            raise ValueError("Observed context contains a native special token; cannot treat it as an extra target")
        ids.extend(context)
        if index < len(parts) - 1:
            spans.append([len(ids), len(ids) + mask_length])
            ids.extend([tokenizer.mask_token_id] * mask_length)
    windows = tile_canvas(ids, spans, max_length=max_length,
                          bos_token_id=tokenizer.bos_token_id, eos_token_id=tokenizer.eos_token_id)
    for window in windows:
        left = window["content_token_start"]
        window["visible_token_spans"] = [[spans[i][0]-left+1, spans[i][1]-left+1]
                                          for i in window["visible_site_indices"]]
    return {"provided_mask_length": mask_length, "occurrences": len(spans),
            "full_file_canvas_tokens": len(ids) + 2, "target_content_token_spans": spans,
            "windows": windows, "input_plan_sha256": hashlib.sha256(json.dumps(windows,
                sort_keys=True, separators=(",", ":")).encode()).hexdigest()}


def prepare_record(row, tokenizer, *, condition, max_length=1024):
    if condition not in CONDITIONS:
        raise ValueError(f"Unsupported length condition: {condition}")
    # In fixed_2 mode gold tokenization is exclusively reporting/scoring data;
    # neither the length nor target text is used to construct the model input.
    gold_ids = tokenizer.encode(row["target"], add_special_tokens=False)
    if not gold_ids:
        raise ValueError("Empty target tokenization")
    provided = len(gold_ids) if condition == "oracle_length" else 2
    prepared = build_masked_windows(row["code_masked"], tokenizer,
                                     mask_length=provided, max_length=max_length)
    return {
        **prepared, "id": row["id"], "condition": condition,
        "gold_token_ids": gold_ids, "gold_token_length": len(gold_ids),
        "row_sha256": hashlib.sha256(json.dumps(row, sort_keys=True,
            separators=(",", ":"), ensure_ascii=False).encode()).hexdigest(),
    }
