"""Strict fixed-canvas ReFineID evaluation; one forward per complete-slot window."""
import argparse
from collections import Counter
import gc
import hashlib
import json
from pathlib import Path
import time

from .data import CONDITIONS, file_hash, prepare_record, read_records
from experiments.fixed_identifier.common import source_hashes as native_source_hashes, validate_checkpoint
from experiments.fixed_identifier.evaluate import valid_java_identifier
from experiments.fixed_identifier.profiles import PROFILES, get_profile
from experiments.fixed_identifier.runtime import load_model, load_tokenizer, selected_logits

JAVA_EDGE_WHITESPACE = " \t\r\n\f"


def source_hashes():
    return {str(p): file_hash(p) for folder in (Path(__file__).parent, Path("experiments/fixed_identifier"))
            for p in sorted(folder.glob("*.py"))}


def dump_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def score_site(token_ids, target, tokenizer):
    special = set(tokenizer.all_special_ids)
    usable = bool(token_ids) and all(type(t) is int and 0 <= t < len(tokenizer) and t not in special for t in token_ids)
    text = tokenizer.decode(token_ids, clean_up_tokenization_spaces=False) if usable else None
    name = text.strip(JAVA_EDGE_WHITESPACE) if text is not None else None
    valid = usable and valid_java_identifier(name)
    return {"token_ids": token_ids, "text": text, "identifier_name": name,
            "usable_tokens": usable, "valid_identifier": bool(valid),
            "raw_span_exact": usable and text == target,
            "identifier_name_exact": bool(valid and name == target)}


def evaluate_record(model, row, tokenizer, *, condition, max_length=1024, logits_fn=selected_logits):
    import torch
    tick = time.monotonic()
    count = row["code_masked"].count("[MASK]")
    result = {"id": row["id"], "target": row["target"], "condition": condition,
              "occurrences": count, "predictions": [], "window_trace": [], "errors": [],
              "forward_passes": 0, "completed_windows": 0}
    try:
        prepared = prepare_record(row, tokenizer, condition=condition, max_length=max_length)
    except Exception as exc:
        result["errors"].append({"stage": "prepare", "type": type(exc).__name__, "message": str(exc)})
        prepared = None
    sites = [None] * count
    if prepared is not None:
        result.update({k: v for k, v in prepared.items() if k != "windows"})
        result["planned_windows"] = len(prepared["windows"])
        for window in prepared["windows"]:
            trace = {k: v for k, v in window.items() if k not in ("input_ids", "owned_token_spans")}
            trace.update({"input_tokens": len(window["input_ids"]), "forward_attempts": 1})
            result["forward_passes"] += 1
            window_tick = time.monotonic()
            try:
                positions = [p for a, b in window["owned_token_spans"] for p in range(a, b)]
                with torch.inference_mode():
                    logits = logits_fn(model, list(window["input_ids"]), positions)
                    if logits.ndim != 2 or logits.shape[0] != len(positions):
                        raise ValueError("Forward returned an invalid selected-logit shape")
                    if not torch.isfinite(logits).all():
                        raise ValueError("Forward returned non-finite logits")
                    predicted = logits.argmax(-1).tolist()
                    del logits
                cursor = 0
                for site, (a, b) in zip(window["owned_site_indices"], window["owned_token_spans"]):
                    if sites[site] is not None:
                        raise AssertionError("An occurrence was assigned more than once")
                    sites[site] = predicted[cursor:cursor + b - a]
                    cursor += b - a
                result["completed_windows"] += 1
                trace["error"] = None
            except Exception as exc:
                error = {"stage": "forward", "window": window["index"],
                         "type": type(exc).__name__, "message": str(exc)}
                result["errors"].append(error)
                trace["error"] = error
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            trace["seconds"] = time.monotonic() - window_tick
            result["window_trace"].append(trace)
    else:
        result["planned_windows"] = None
    result["predictions"] = [dict(site_index=i, **score_site(ids or [], row["target"], tokenizer))
                             for i, ids in enumerate(sites)]
    result["raw_span_em"] = bool(count and not result["errors"] and all(p["raw_span_exact"] for p in result["predictions"]))
    result["java_whitespace_trimmed_identifier_name_em"] = bool(count and not result["errors"] and all(p["identifier_name_exact"] for p in result["predictions"]))
    result["formatting_only_success"] = result["java_whitespace_trimmed_identifier_name_em"] and not result["raw_span_em"]
    result["seconds"] = time.monotonic() - tick
    return result


def summarize(rows):
    n = len(rows)
    if not n:
        raise ValueError("Empty evaluation selection")
    occurrences = sum(r["occurrences"] for r in rows)
    return {
        "examples": n, "occurrences": occurrences,
        "errors_counted_as_failures": sum(bool(r["errors"]) for r in rows),
        "raw_span_correct": sum(r["raw_span_em"] for r in rows),
        "raw_span_em": sum(r["raw_span_em"] for r in rows) / n,
        "identifier_name_correct": sum(r["java_whitespace_trimmed_identifier_name_em"] for r in rows),
        "java_whitespace_trimmed_identifier_name_em": sum(r["java_whitespace_trimmed_identifier_name_em"] for r in rows) / n,
        "formatting_only_successes": sum(r["formatting_only_success"] for r in rows),
        "correct_name_occurrences": sum(p["identifier_name_exact"] for r in rows for p in r["predictions"]),
        "forward_passes": sum(r["forward_passes"] for r in rows),
        "completed_windows": sum(r["completed_windows"] for r in rows),
        "one_window_files": sum(r["planned_windows"] == 1 for r in rows),
        "full_context_files": sum(any(w["has_all_file_context"] for w in r["window_trace"]) for r in rows),
        "seconds": sum(r["seconds"] for r in rows),
    }


def checkpoint_contract(run_dir, checkpoint, profile_key, tiny):
    run_dir = Path(run_dir).resolve()
    run = json.loads((run_dir / "run.json").read_text())
    contract = run["contract"]
    if contract["profile"] != get_profile(profile_key) or bool(contract["tiny"]) != tiny:
        raise ValueError("Run profile or tiny status differs from requested evaluation")
    if contract["source_sha256"] != native_source_hashes():
        raise ValueError("Native runtime source differs from the training snapshot")
    path = Path(checkpoint).resolve() if checkpoint else run_dir / json.loads((run_dir / "completed.json").read_text())["checkpoint"]
    if path.parent != run_dir:
        raise ValueError("Checkpoint must belong to the supplied run directory")
    meta = validate_checkpoint(path, contract)
    return path, {"run_json_sha256": file_hash(run_dir / "run.json"), "checkpoint": str(path),
                  "metadata": meta, "training_contract": contract}


def preparation_audit(records, tokenizer, conditions, max_length):
    result = {}
    for condition in conditions:
        lengths, windows, errors, mask_lengths = [], [], [], Counter()
        digest = hashlib.sha256()
        for row in records:
            try:
                p = prepare_record(row, tokenizer, condition=condition, max_length=max_length)
                lengths.append(p["full_file_canvas_tokens"]); windows.append(len(p["windows"]))
                mask_lengths[p["provided_mask_length"]] += 1
                digest.update((row["id"] + ":" + p["input_plan_sha256"] + "\n").encode())
            except Exception as exc:
                errors.append({"id": row["id"], "type": type(exc).__name__, "message": str(exc)})
        ordered = sorted(lengths)
        result[condition] = {"examples": len(records), "valid_preparations": len(lengths), "errors": errors,
            "input_plan_sha256": digest.hexdigest(), "planned_windows": sum(windows),
            "window_count_distribution": dict(sorted(Counter(windows).items())),
            "provided_mask_length_distribution": dict(sorted(mask_lengths.items())),
            "full_file_canvas_token_quantiles": {label: ordered[min(len(ordered)-1, int(q*len(ordered)))]
                for label, q in (("min", 0), ("p50", .5), ("p90", .9), ("p95", .95), ("p99", .99), ("max", 1))} if ordered else None}
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", default="data/test.csv")
    parser.add_argument("--profile", choices=tuple(PROFILES), required=True)
    parser.add_argument("--output", required=True, help="Fresh output directory")
    parser.add_argument("--run-dir", help="Validated FT run; include paired base + adapter")
    parser.add_argument("--checkpoint", help="Optional explicit checkpoint inside --run-dir")
    parser.add_argument("--condition", nargs="+", choices=CONDITIONS, default=list(CONDITIONS))
    parser.add_argument("--max-length", type=int, default=1024)
    parser.add_argument("--limit", type=int, help="Explicit smoke subset; omitted evaluates all 1000")
    parser.add_argument("--tiny", action="store_true", help="Random native tiny CPU architecture; never a model result")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args(argv)
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(output)
    if args.checkpoint and not args.run_dir:
        raise ValueError("--checkpoint requires --run-dir")
    profile = get_profile(args.profile)
    if not 12 <= args.max_length <= profile["max_position_embeddings"]:
        raise ValueError("max-length must be between12 and native model context limit")
    if args.tiny and args.max_length > 4096:
        raise ValueError("Tiny config supports at most4096 positions")
    if args.limit is not None and not 1 <= args.limit <= 1000:
        raise ValueError("limit must be between1 and1000")
    records = read_records(args.data)[:args.limit]
    conditions = sorted(set(args.condition))
    checkpoint, checkpoint_info = (None, None)
    if args.run_dir:
        checkpoint, checkpoint_info = checkpoint_contract(args.run_dir, args.checkpoint, args.profile, args.tiny)
        if checkpoint_info["training_contract"]["seed"] != args.seed:
            raise ValueError("Use the checkpoint training seed, especially for random tiny base reconstruction")
    manifest = {"schema_version": 1, "dataset_sha256": file_hash(args.data), "source_sha256": source_hashes(),
        "profile": profile, "checkpoint": checkpoint_info, "selection_ids": [r["id"] for r in records],
        "full_1000_test": len(records) == 1000, "conditions": conditions, "max_length": args.max_length,
        "seed": args.seed, "tiny_random_model_smoke_only": args.tiny,
        "input_policy": "All original CSV mask slots retained; complete-slot windows; all visible slots stay masked; no cross-window prediction transfer",
        "length_policy": {"oracle_length": "Gold tokenizer subtoken length supplied at every site", "fixed_2": "Exactly2 mask tokens per site; target and target length excluded from input construction"},
        "decode_policy": "One simultaneous unfiltered argmax forward per window; no voting, truncation, insertions, deletions or extra attempts",
        "scoring_policy": "All original CSV slots must match; only Java edge whitespace stripped for name metric; errors remain in selection denominator"}
    tokenizer = load_tokenizer(args.profile)
    output.mkdir(parents=True)
    dump_json(output / "manifest.json", manifest)
    audit = preparation_audit(records, tokenizer, conditions, args.max_length)
    dump_json(output / "preparation.json", audit)
    if args.prepare_only:
        print(json.dumps({"output": str(output), "preparation": audit}, ensure_ascii=False), flush=True)
        return
    import torch
    if args.tiny:
        torch.set_num_threads(2)
    variants = [("base", None)] + ([("adapter", str(checkpoint))] if checkpoint else [])
    report = {"manifest_sha256": file_hash(output / "manifest.json"), "variants": {}}
    for variant, adapter in variants:
        torch.manual_seed(args.seed)
        model = load_model(args.profile, adapter=adapter, tiny=args.tiny, device="cpu" if args.tiny else "cuda")
        report["variants"][variant] = {}
        for condition in conditions:
            rows = []
            filename = f"{variant}-{condition}.jsonl"
            with (output / filename).open("x", encoding="utf-8") as stream:
                for index, row in enumerate(records):
                    result = evaluate_record(model, row, tokenizer, condition=condition, max_length=args.max_length)
                    stream.write(json.dumps(result, ensure_ascii=False, allow_nan=False) + "\n"); stream.flush()
                    rows.append(result)
                    if (index + 1) % 25 == 0 or index + 1 == len(records):
                        print(json.dumps({"variant": variant, "condition": condition, "done": index+1, "total": len(records), "name_correct": sum(r["java_whitespace_trimmed_identifier_name_em"] for r in rows)}), flush=True)
            report["variants"][variant][condition] = {**summarize(rows), "file": filename, "sha256": file_hash(output / filename)}
        del model
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    if file_hash(args.data) != manifest["dataset_sha256"] or source_hashes() != manifest["source_sha256"]:
        raise ValueError("Source or input dataset changed while evaluating")
    dump_json(output / "report.json", report)
    print(json.dumps({"report": str(output / "report.json"), "full_1000_test": len(records)==1000}), flush=True)


if __name__ == "__main__":
    main()
