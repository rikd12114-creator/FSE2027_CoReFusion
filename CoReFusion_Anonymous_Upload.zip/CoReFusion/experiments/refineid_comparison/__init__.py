"""Complete ReFineID fixed-canvas comparisons; separate from frozen FT code."""
