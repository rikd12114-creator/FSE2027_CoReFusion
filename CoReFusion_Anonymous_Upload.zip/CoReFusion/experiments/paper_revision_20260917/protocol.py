"""Gold-free task contract shared by AR and native FIM baselines."""
import hashlib
import unicodedata

MARKER = '[MASK]'
HOLE = '[HOLE]'
TASK = (
    'Task: Recover one Java identifier from its code context. '
    'Every [MASK] marker and the selected hole refer to the same identifier. '
    'The markers are not names and must not be copied as the answer. '
    'Choose a meaningful identifier for its role, use exactly the same spelling at '
    'every occurrence, and preserve all other code. Return only the replacement '
    'Java identifier, without explanation, quotes, Markdown, or surrounding code.'
)
FIM = {
    'starcoder': ('<fim_prefix>', '<fim_suffix>', '<fim_middle>'),
    'deepseek': ('<｜fim▁begin｜>', '<｜fim▁hole｜>', '<｜fim▁end｜>'),
    'codellama': ('▁<PRE>', '▁<SUF>', '▁<MID>'),
    'codegemma': ('<|fim_prefix|>', '<|fim_suffix|>', '<|fim_middle|>'),
    'qwen25coder': ('<|fim_prefix|>', '<|fim_suffix|>', '<|fim_middle|>'),
}
JAVA_RESERVED = set(('abstract assert boolean break byte case catch char class const continue '
    'default do double else enum extends final finally float for goto if implements import '
    'instanceof int interface long native new package private protected public return short '
    'static strictfp super switch synchronized this throw throws transient try void volatile '
    'while true false null _').split())

def id_start(c):
    return c in '_$' or unicodedata.category(c) in ('Lu','Ll','Lt','Lm','Lo','Nl','Sc','Pc')

def id_part(c):
    return id_start(c) or unicodedata.category(c) in ('Mn','Mc','Nd','Cf')

def identifier_boundary(raw):
    text = raw.lstrip(' \t\r\n\f')
    # Byte-level tokenizers can decode incomplete UTF-8 as U+FFFD. Wait for
    # continuation tokens rather than committing to a truncated identifier.
    if text.endswith('\ufffd'): return False
    return bool(text and (not id_start(text[0]) or any(not id_part(c) for c in text)))

def extract_identifier(raw):
    """Only an anchored identifier span; never search through prose or code fences.

    Native completion can emit a boundary (e.g. ';'). It terminates the span;
    that boundary is never inserted into the source. All untrimmed text is logged.
    """
    text = raw.lstrip(' \t\r\n\f')
    if not text or '\ufffd' in text or not id_start(text[0]): return None
    i = 1
    while i < len(text) and id_part(text[i]): i += 1
    name = text[:i]
    return None if name in JAVA_RESERVED or name in ('MASK','HOLE','__CF_INVALID__') else name

def crop_context(prefix, suffix, tokenizer, budget):
    """Same gold-free first-hole neighborhood for the two tied protocols.

    Allocate half the code budget on each side, then transfer unused capacity.
    Wrapper/instruction tokens have a separate reserve and are never truncated.
    """
    p = tokenizer.encode(prefix, add_special_tokens=False)
    s = tokenizer.encode(suffix, add_special_tokens=False)
    pb = min(len(p), budget // 2)
    sb = min(len(s), budget - pb)
    pb = min(len(p), budget - sb)
    pt = tokenizer.decode(p[-pb:], clean_up_tokenization_spaces=False) if pb else ''
    st = tokenizer.decode(s[:sb], clean_up_tokenization_spaces=False) if sb else ''
    return pt, st, {'prefix_tokens_original':len(p),'suffix_tokens_original':len(s),
        'prefix_tokens_retained':pb,'suffix_tokens_retained':sb,
        'truncated': pb < len(p) or sb < len(s)}

def build_input(code, tokenizer, model_type, mode, code_budget=4096, chat=False):
    prefix, suffix = code.split('[MASK]', 1)
    prefix, suffix = prefix.replace('[MASK]',MARKER), suffix.replace('[MASK]',MARKER)
    prefix, suffix, trace = crop_context(prefix,suffix,tokenizer,code_budget)
    if mode.startswith('fim-'):
        tokens = FIM[model_type]
        sentinel_ids = [tokenizer.convert_tokens_to_ids(t) for t in tokens]
        if any(i is None or i == tokenizer.unk_token_id for i in sentinel_ids):
            raise ValueError('Native FIM sentinel absent from pinned tokenizer: '+str(tokens))
        # Construct from IDs so SentencePiece cannot split/duplicate sentinels.
        code_prefix = '// '+TASK+'\n'+prefix
        ids = ([tokenizer.bos_token_id] if model_type in ('codellama','deepseek') else [])
        ids += [sentinel_ids[0]] + tokenizer.encode(code_prefix,add_special_tokens=False)
        ids += [sentinel_ids[1]] + tokenizer.encode(suffix,add_special_tokens=False) + [sentinel_ids[2]]
        prompt = tokenizer.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False)
    else:
        body = TASK+'\nThe selected hole is [HOLE].\nJava context:\n'+prefix+HOLE+suffix+'\nReplacement identifier:\n'
        if chat:
            ids = tokenizer.apply_chat_template([{'role':'user','content':body}],tokenize=True,add_generation_prompt=True)
            prompt = tokenizer.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False)
        else:
            ids = tokenizer.encode(body,add_special_tokens=True)
            prompt = body
    trace.update({'input_token_count':len(ids),'input_sha256':hashlib.sha256(str(ids).encode()).hexdigest(),
        'code_context_sha256':hashlib.sha256((prefix+HOLE+suffix).encode()).hexdigest()})
    return ids, prompt, trace

def score(target, predictions, sites, error=None):
    covered = len(predictions) == sites
    valid = [p is not None and extract_identifier(p)==p for p in predictions]
    return {'expected_sites':sites,'predicted_sites':len(predictions),'coverage_ok':covered,
        'correct_sites':sum(p==target for p in predictions) if not error else 0,
        'all_sites_name_exact':bool(not error and covered and all(p==target for p in predictions)),
        'consistent_nonempty':bool(not error and covered and all(valid) and len(set(predictions))==1)}
