"""Auditable reference agreement and structural diagnostics for identifier recovery.

Public interface: score_sample({id, target, predictions: list[str], expected_sites}).
Optionally supply code_masked and a JavaStructureChecker. The CLI joins every
prediction to the complete source manifest; missing/error rows score zero.
Subtoken set P/R/F1 follows Nie et al. ACL 2022's official EvalMetrics.set_match.
These are lexical agreement metrics, not semantic equivalence or human quality.
"""
from __future__ import annotations

import argparse
import csv
from functools import lru_cache
import hashlib
import importlib.metadata
import json
from pathlib import Path
import random
import re
import sys
import unicodedata

VERSION = "identifier-metrics-v1-20260917"
MASK = "[MASK]"
JAVA_EDGE = " \t\r\n\f"
JAVA_RESERVED = set("abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while _ true false null".split())
MEAN_METRICS = (
    "all_sites_em", "provided_span_all_sites_em", "complete_site_coverage", "site_coverage",
    "site_consistency", "all_sites_valid_identifier", "site_valid_identifier",
    "site_em", "site_subtoken_precision", "site_subtoken_recall", "site_subtoken_f1",
    "consistent_subtoken_f1", "site_ordered_subtoken_accuracy",
)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def is_java_identifier(name):
    """JLS lexical screen using Python's recorded Unicode character database.

    Restricted/contextual keywords remain allowed by the lexical grammar;
    binding legality and context-dependent restrictions require a compiler.
    Literal Java Unicode escape sequences are not decoded by this screen.
    """
    if not isinstance(name, str) or not name or name in JAVA_RESERVED:
        return False
    def start(c):
        cat = unicodedata.category(c)
        return cat.startswith("L") or cat in ("Nl", "Sc", "Pc")
    def part(c):
        code = ord(c)
        ignorable = code <= 8 or 14 <= code <= 27 or 127 <= code <= 159
        return start(c) or unicodedata.category(c) in ("Mn", "Mc", "Nd", "Cf") or ignorable
    return start(name[0]) and all(part(c) for c in name[1:])


@lru_cache(maxsize=100_000)
def split_subtokens(name):
    """Explicit camel/snake/acronym/digit splitting, independent of model BPE."""
    chunks, current = [], []
    for i, char in enumerate(name):
        if not char.isalnum():
            if current:
                chunks.append("".join(current).lower()); current = []
            continue
        previous = name[i - 1] if i else ""
        following = name[i + 1] if i + 1 < len(name) else ""
        boundary = current and (
            (char.isupper() and (previous.islower() or (previous.isupper() and following.islower())))
            or char.isdigit() != previous.isdigit()
        )
        if boundary:
            chunks.append("".join(current).lower()); current = []
        current.append(char)
    if current:
        chunks.append("".join(current).lower())
    return tuple(chunks)


@lru_cache(maxsize=100_000)
def subtoken_scores(target, prediction):
    gold, pred = split_subtokens(target), split_subtokens(prediction)
    gs, ps = set(gold), set(pred)
    matches = len(gs & ps)
    precision = matches / len(ps) if ps else 0.0
    recall = matches / len(gs) if gs else 0.0
    f1 = 2 * matches / (len(gs) + len(ps)) if gs or ps else 0.0
    ordered = sum(a == b for a, b in zip(gold, pred)) / max(len(gold), len(pred), 1)
    return {"precision": precision, "recall": recall, "f1": f1, "ordered_accuracy": ordered}


def _texts(record):
    values = record.get("predictions", record.get("site_predictions", []))
    if not isinstance(values, list):
        raise ValueError("predictions must be a list, never a delimiter-encoded string")
    result = []
    for item in values:
        if isinstance(item, dict):
            # The raw decoded span is authoritative; never prefer regex recovery.
            if "text" not in item:
                raise ValueError("structured site prediction requires raw text")
            item = item["text"]
        if item is not None and not isinstance(item, str):
            raise ValueError("site prediction must be a string or null")
        result.append(item)
    return result


def _has_error(record):
    return bool(record.get("error") or record.get("errors") or record.get("error_count", 0))


def reconstruct(code_masked, names):
    parts = code_masked.split(MASK)
    if len(parts) != len(names) + 1:
        raise ValueError("Cannot reconstruct a patch without exactly one prediction per original site")
    spans, chunks, offset = [], [], 0
    for i, part in enumerate(parts):
        chunks.append(part); offset += len(part.encode("utf-8"))
        if i < len(names):
            name = names[i]
            if not isinstance(name, str):
                raise ValueError("A missing site has no reconstructable patch")
            length = len(name.encode("utf-8"))
            spans.append((offset, offset + length)); offset += length; chunks.append(name)
    return "".join(chunks), tuple(spans)


class JavaStructureChecker:
    """Syntax diagnostics on deterministic site replacement, not compilation.

    The reference must parse and every target span must be an identifier AST
    node. The fingerprint masks only those target leaves and retains all other
    leaf spellings and the full tree shape. Scope/binding is deliberately absent.
    """
    def __init__(self):
        from tree_sitter import Language, Parser
        import tree_sitter_java
        self.parser = Parser(Language(tree_sitter_java.language()))
        self.versions = {name: importlib.metadata.version(name) for name in ("tree-sitter", "tree-sitter-java")}

    def inspect(self, code, spans):
        source = code.encode("utf-8")
        tree = self.parser.parse(source)
        if tree.root_node.has_error:
            return {"parseable": False, "all_target_nodes": False, "fingerprint": None}
        targets, found, digest = set(spans), set(), hashlib.sha256()
        stack = [tree.root_node]
        while stack:
            node = stack.pop()
            digest.update(node.type.encode("utf-8") + b":" + str(node.child_count).encode() + b";")
            if node.child_count:
                stack.extend(reversed(node.children))
            else:
                span = (node.start_byte, node.end_byte)
                if span in targets and node.type in ("identifier", "type_identifier"):
                    found.add(span); value = b"<TARGET>"
                else:
                    value = source[node.start_byte:node.end_byte]
                digest.update(str(len(value)).encode() + b":" + value)
        return {"parseable": True, "all_target_nodes": found == targets, "fingerprint": digest.hexdigest()}

    @lru_cache(maxsize=1100)
    def reference(self, code_masked, target):
        code, spans = reconstruct(code_masked, [target] * code_masked.count(MASK))
        return self.inspect(code, spans)

    def score(self, code_masked, target, names, ok):
        ref = self.reference(code_masked, target)
        eligible = ref["parseable"] and ref["all_target_nodes"]
        out = {"reference_parseable": ref["parseable"], "parse_eligible": eligible,
               "patch_parse_success": None, "patch_structure_preserved": None}
        if not eligible:
            return out
        out.update(patch_parse_success=False, patch_structure_preserved=False)
        if not ok:
            return out
        code, spans = reconstruct(code_masked, names)
        pred = self.inspect(code, spans)
        out["patch_parse_success"] = pred["parseable"]
        out["patch_structure_preserved"] = bool(pred["all_target_nodes"] and pred["fingerprint"] == ref["fingerprint"])
        return out


def score_sample(record, structure_checker=None):
    target = record.get("target", record.get("ground_truth"))
    if not isinstance(target, str) or not target:
        raise ValueError("A non-empty reference target is required")
    expected = record.get("expected_sites", record.get("occurrences", record.get("n_total_masks")))
    if expected is None and isinstance(record.get("code_masked"), str):
        expected = record["code_masked"].count(MASK)
    if type(expected) is not int or expected <= 0:
        raise ValueError("An independently supplied positive expected_sites count is required")
    raw = _texts(record)
    names = [text.strip(JAVA_EDGE) if isinstance(text, str) else "" for text in raw]
    exact_count = len(names) == expected
    error = _has_error(record)
    covered = sum(bool(name) for name in names[:expected])
    complete = exact_count and covered == expected
    consistent = bool(complete and len(set(names)) == 1)
    valid = [is_java_identifier(name) for name in names]
    all_valid = complete and all(valid)
    # Global malformed site cardinality or runtime error invalidates quality.
    scoring_ok = len(names) <= expected and not error
    site = []
    for i in range(expected):
        guess = names[i] if i < len(names) else ""
        usable = scoring_ok and is_java_identifier(guess)
        scores = subtoken_scores(target, guess) if usable else dict(precision=0.0, recall=0.0, f1=0.0, ordered_accuracy=0.0)
        site.append({"prediction": guess, "valid_identifier": is_java_identifier(guess),
                     "exact": bool(usable and guess == target), **scores})
    out = {
        "id": str(record.get("id", "")), "target": target,
        "source_cluster_id": record.get("source_cluster_id") or str(record.get("id", "")),
        "expected_sites": expected, "predicted_sites": len(raw), "has_error": error,
        "missing_result": bool(record.get("missing_result")),
        "all_sites_em": bool(complete and not error and all(name == target for name in names)),
        # This is the supplied site span, not necessarily the raw decoder output:
        # some inference protocols extract a candidate before handing it to us.
        "provided_span_all_sites_em": bool(complete and not error and all(name == target for name in raw)),
        "complete_site_coverage": complete, "site_coverage": covered / expected,
        "site_consistency": consistent,
        "all_sites_valid_identifier": bool(all_valid and not error),
        "site_valid_identifier": sum(p["valid_identifier"] for p in site) / expected if not error else 0.0,
        "site_em": sum(p["exact"] for p in site) / expected,
        "site_subtoken_precision": sum(p["precision"] for p in site) / expected,
        "site_subtoken_recall": sum(p["recall"] for p in site) / expected,
        "site_subtoken_f1": sum(p["f1"] for p in site) / expected,
        "site_ordered_subtoken_accuracy": sum(p["ordered_accuracy"] for p in site) / expected,
        "consistent_subtoken_f1": subtoken_scores(target, names[0])["f1"] if consistent and all_valid and not error else 0.0,
        "per_site": site,
    }
    if structure_checker is not None:
        out.update(structure_checker.score(record["code_masked"], target, names,
                                            complete and not error))
    return out


def aggregate(scores):
    if not scores:
        raise ValueError("No samples to aggregate")
    n = len(scores)
    out = {"n_tasks": n, "n_expected_sites": sum(s["expected_sites"] for s in scores),
           "n_errors": sum(s["has_error"] for s in scores),
           "n_missing_results": sum(s["missing_result"] for s in scores),
           "n_consistent": sum(s["site_consistency"] for s in scores),
           "n_source_clusters": len({s["source_cluster_id"] for s in scores})}
    out.update({key: sum(s[key] for s in scores) / n for key in MEAN_METRICS})
    n_consistent = out["n_consistent"]
    out["em_given_consistent"] = sum(s["all_sites_em"] for s in scores) / n_consistent if n_consistent else None
    parse_rows = [s for s in scores if s.get("parse_eligible")]
    out["n_parse_eligible"] = len(parse_rows)
    for key in ("patch_parse_success", "patch_structure_preserved"):
        out[key] = sum(s[key] for s in parse_rows) / len(parse_rows) if parse_rows else None
    out["n_reference_unparseable"] = sum(s.get("reference_parseable") is False for s in scores)
    return out


def cluster_bootstrap(scores, repetitions=2000, seed=42):
    """Percentile source-cluster CIs for task-macro scores; no seed CI claim."""
    if repetitions <= 0:
        return {}
    groups = {}
    for s in scores:
        groups.setdefault(s["source_cluster_id"], []).append(s)
    if len(groups) < 2:
        return {}  # One source cannot estimate between-source uncertainty.
    values = [groups[key] for key in sorted(groups)]
    keys = ("all_sites_em", "site_subtoken_f1", "consistent_subtoken_f1", "site_consistency")
    totals = [([sum(s[k] for s in group) for k in keys], len(group)) for group in values]
    rng, distributions = random.Random(seed), [[] for _ in keys]
    for _ in range(repetitions):
        selected = rng.choices(totals, k=len(totals))
        count = sum(v[1] for v in selected)
        for i in range(len(keys)):
            distributions[i].append(sum(v[0][i] for v in selected) / count)
    def quantile(values, q):
        values = sorted(values); x = (len(values) - 1) * q; lower = int(x)
        return values[lower] + (values[min(lower + 1, len(values) - 1)] - values[lower]) * (x - lower)
    return {k: {"low": quantile(d, .025), "high": quantile(d, .975)} for k, d in zip(keys, distributions)}


def load_sources(path):
    from experiments.late_rename.prepare_data import normalized_fingerprint
    csv.field_size_limit(sys.maxsize)
    with Path(path).open(encoding="utf-8", newline="") as stream:
        rows = list(csv.reader(stream))
    if not rows or any(len(r) != 3 for r in rows):
        raise ValueError("Expected headerless id,code_masked,target CSV")
    sources = {}
    for identifier, code, target in rows:
        if identifier in sources or not code.count(MASK):
            raise ValueError("Duplicate source ID or no original mask sites")
        sources[identifier] = {"id": identifier, "code_masked": code, "target": target,
                               "expected_sites": code.count(MASK),
                               "source_cluster_id": normalized_fingerprint(code.replace(MASK, target))}
    return sources


def load_predictions(path):
    path = Path(path)
    if path.suffix != ".jsonl":
        raise ValueError("Use lossless JSONL. Legacy pipe-separated CSV can merge generated pipe characters.")
    rows = {}
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            identifier = str(row["id"])
            if identifier in rows:
                raise ValueError(f"Duplicate prediction ID {identifier} in {path}")
            rows[identifier] = row
    return rows


def score_file(path, sources, checker=None, require_complete=False):
    predictions = load_predictions(path)
    if set(predictions) - set(sources):
        raise ValueError(f"Unexpected prediction IDs in {path}")
    if require_complete and set(predictions) != set(sources):
        raise ValueError(f"Incomplete prediction file: {len(predictions)}/{len(sources)} rows")
    scores = []
    for identifier, source in sources.items():
        row = predictions.get(identifier)
        if row is None:
            row = {"predictions": [], "error": "missing_result", "missing_result": True}
        target = row.get("target", row.get("ground_truth"))
        if target is not None and target != source["target"]:
            raise ValueError(f"Reference target mismatch for ID {identifier}")
        for key in ("expected_sites", "occurrences", "n_total_masks"):
            if key in row and row[key] != source["expected_sites"]:
                raise ValueError(f"Original site count mismatch for ID {identifier}")
        scores.append(score_sample({**row, **source}, checker))
    return scores


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", action="append", required=True, type=Path)
    parser.add_argument("--label", action="append", help="One unique display label per input, in input order")
    parser.add_argument("--data", type=Path, default=Path("data/test.csv"))
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--protocol-label", required=True)
    parser.add_argument("--parse", action="store_true", help="Require tree-sitter-java and score reconstructed patches")
    parser.add_argument("--require-complete", action="store_true")
    parser.add_argument("--bootstrap", type=int, default=2000)
    args = parser.parse_args(argv)
    labels = args.label or [p.stem for p in args.input]
    if len(labels) != len(args.input) or len(set(labels)) != len(labels):
        parser.error("Labels must match inputs one-to-one and be unique")
    checker = JavaStructureChecker() if args.parse else None
    sources = load_sources(args.data)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    manifest = {"metric_version": VERSION, "protocol_label": args.protocol_label,
                "source_path": str(args.data.resolve()), "source_sha256": sha256(args.data),
                "scorer_sha256": sha256(__file__), "python_version": sys.version,
                "unicode_version": unicodedata.unidata_version,
                "parser_versions": checker.versions if checker else None,
                "n_tasks": len(sources), "inputs": [],
                "bootstrap_repetitions": args.bootstrap, "bootstrap_seed": 42,
                "source_cluster_policy": "late_rename.prepare_data.normalized_fingerprint of reconstructed reference; omit whitespace/comments, retain literal/token text",
                "ordered_id_cluster_sha256": hashlib.sha256(json.dumps([[r["id"], r["source_cluster_id"]] for r in sources.values()], ensure_ascii=False, separators=(",", ":")).encode()).hexdigest(),
                "scores_are_semantic_correctness": False,
                "syntax_policy": "parse deterministic site-replacement patch; no compilation or binding check"}
    summaries, confidence = [], {}
    for label, path in zip(labels, args.input):
        scores = score_file(path, sources, checker, args.require_complete)
        summary = {"model": label, "protocol_label": args.protocol_label, **aggregate(scores)}
        filename = re.sub(r"[^A-Za-z0-9_.-]", "_", label) + ".scores.jsonl"
        with (args.output_dir / filename).open("w", encoding="utf-8") as stream:
            for score in scores:
                stream.write(json.dumps(score, ensure_ascii=False, allow_nan=False) + "\n")
        confidence[label] = cluster_bootstrap(scores, args.bootstrap)
        summaries.append(summary)
        manifest["inputs"].append({"label": label, "path": str(path.resolve()),
                                   "sha256": sha256(path), "scores_file": filename})
        print(json.dumps({k: summary[k] for k in ("model", "n_tasks", "n_errors", "all_sites_em", "site_subtoken_f1", "n_parse_eligible")}), flush=True)
    with (args.output_dir / "summary.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summaries[0])); writer.writeheader(); writer.writerows(summaries)
    write_json(args.output_dir / "summary.json", summaries)
    write_json(args.output_dir / "confidence_intervals.json", confidence)
    write_json(args.output_dir / "manifest.json", manifest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
