"""Auditable September 2026 manuscript revision experiments."""
