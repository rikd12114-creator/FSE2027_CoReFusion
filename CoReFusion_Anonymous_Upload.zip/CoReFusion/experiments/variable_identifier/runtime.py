"""Pinned DreamOn native model, compact shifted logits and balanced action loss."""
from .corruption import MASK, EXPAND, DELETE, IGNORE

MODEL_ID = "Dream-org/DreamOn-v0-7B"
REVISION = "57e0e4115c97899e3e859b00eae26f54f9cf3872"
LORA_MODULES = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]


def load_tokenizer():
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, revision=REVISION,
        code_revision=REVISION, trust_remote_code=True)
    observed = {"mask": tokenizer.mask_token_id, "expand": tokenizer.convert_tokens_to_ids("<|expand|>"),
                "delete": tokenizer.eos_token_id, "bos": tokenizer.bos_token_id}
    if observed != {"mask": MASK, "expand": EXPAND, "delete": DELETE, "bos": 151665}:
        raise ValueError("Tokenizer differs from pinned DreamOn contract")
    return tokenizer


def load_model(*, adapter=None, train=False, rank=16, tiny=False):
    import torch
    from transformers import AutoConfig, AutoModel
    from peft import LoraConfig, PeftConfig, PeftModel, get_peft_model
    if type(rank) is not int or rank < 1:
        raise ValueError("Rank must be a positive integer")
    if not tiny and (not torch.cuda.is_available() or not torch.cuda.is_bf16_supported()):
        raise RuntimeError("Native 7B training requires bf16 CUDA; use --tiny for CPU contract tests")
    common = dict(revision=REVISION, code_revision=REVISION, trust_remote_code=True)
    config = AutoConfig.from_pretrained(MODEL_ID, **common)
    if (config.mask_token_id, config.expand_token_id, config.eos_token_id, config.vocab_size) != (MASK, EXPAND, DELETE, 152064):
        raise ValueError("Wrong DreamOn model/action configuration")
    if getattr(config, "_commit_hash", REVISION) != REVISION:
        raise ValueError("Wrong DreamOn revision")
    if tiny:
        for key, value in {"hidden_size":32,"intermediate_size":64,"num_hidden_layers":2,
                           "num_attention_heads":4,"num_key_value_heads":2,
                           "max_position_embeddings":4096,"max_window_layers":2,
                           "attention_dropout":0.,"use_cache":False}.items():
            setattr(config, key, value)
        config._attn_implementation = "sdpa"
        model = AutoModel.from_config(config, trust_remote_code=True, code_revision=REVISION)
    else:
        model = AutoModel.from_pretrained(MODEL_ID, config=config, **common,
            torch_dtype=torch.bfloat16, attn_implementation="sdpa", low_cpu_mem_usage=True)
    model.config.use_cache = False
    model.to("cpu" if tiny else "cuda")
    if adapter:
        cfg = PeftConfig.from_pretrained(adapter)
        if cfg.base_model_name_or_path != MODEL_ID or cfg.revision != REVISION:
            raise ValueError("Adapter is not bound to the original pinned DreamOn base")
        model = PeftModel.from_pretrained(model, adapter, is_trainable=train)
    elif train:
        model = get_peft_model(model, LoraConfig(r=rank, lora_alpha=rank*2,
            lora_dropout=0. if tiny else .05, target_modules=LORA_MODULES,
            bias="none", revision=REVISION))
    if train:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant":False})
        model.enable_input_require_grads()
        model.train()
    else:
        model.eval()
    return model


def selected_logits(model, ids, positions):
    import torch
    if not positions or any(type(p) is not int or not 0 < p < len(ids) for p in positions):
        raise ValueError("Supervised positions must follow the unmasked BOS")
    if len(set(positions)) != len(positions):
        raise ValueError("Duplicate target position")
    base = model.get_base_model() if hasattr(model, "get_base_model") else model
    device = next(base.parameters()).device
    inputs = torch.tensor([ids], dtype=torch.long, device=device)
    length = len(ids)
    attention = torch.ones((1,1,length,length),dtype=torch.bool,device=device)
    # PEFT injects LoRA into decoder projections; these modules remain active
    # through get_base_model().model. The native integration test checks this.
    hidden = base.model(input_ids=inputs, attention_mask=attention,
        position_ids=torch.arange(length,device=device).unsqueeze(0),
        use_cache=False, return_dict=True)[0]
    return base.lm_head(hidden[0, [p-1 for p in positions], :])


def balanced_loss(logits, targets, time_weight):
    """Official deletion-balanced CE, with a defined zero-delete branch.

    When deletes exist: (sum(nondelete CE)+mean(delete CE))/(nondelete_count+1).
    Without deletes: ordinary mean CE. Upstream divides by zero in this case;
    its undefined branch is deliberately not reproduced.
    """
    import torch
    import torch.nn.functional as F
    if not 0 < time_weight <= 1:
        raise ValueError("Time weight must be finite and in (0,1]")
    if logits.ndim != 2 or len(targets) != logits.shape[0] or not len(targets):
        raise ValueError("Nonempty logits and targets must align")
    labels = torch.as_tensor(targets,dtype=torch.long,device=logits.device)
    ce = F.cross_entropy(logits.float(),labels,reduction="none")
    delete = labels == DELETE
    n_delete = int(delete.sum())
    if n_delete:
        loss = (ce[~delete].sum() + ce[delete].mean()) / (int((~delete).sum()) + 1)
    else:
        loss = ce.mean()
    return loss * time_weight, ce, labels


def state_loss(model, state):
    ids, labels = state["input_ids"], state["labels"]
    positions = [p for p, token in enumerate(labels) if token != IGNORE]
    if len(ids) != len(labels) or {p for p,t in enumerate(ids) if t==MASK} != set(positions):
        raise ValueError("Loss only accepts all-target-masked states")
    logits = selected_logits(model, ids, positions)
    targets = [labels[p] for p in positions]
    loss, ce, gold = balanced_loss(logits, targets, state["time_weight"])
    predicted = logits.argmax(-1)
    stats = {}
    for kind in ("lexical", "expand", "delete"):
        selected = gold == EXPAND if kind == "expand" else gold == DELETE if kind == "delete" else (gold != EXPAND) & (gold != DELETE)
        count = int(selected.sum())
        stats[kind] = {"tokens":count,"correct":int((predicted[selected]==gold[selected]).sum()),
                       "ce_sum":float(ce[selected].detach().sum())}
    return loss, stats
