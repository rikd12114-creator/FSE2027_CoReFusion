"""Identifier-conditional DreamOn augmentation with explicit length actions."""
