"""Resumable single-GPU LoRA with official-derived DreamOn length actions.

This is conditional adaptation to one fully hidden identifier, not replication
of upstream full-code SFT. Native variable-length evaluation is a separate run.
"""
import argparse
from collections import Counter
import importlib.metadata
import json
import math
import os
from pathlib import Path
import random
import shutil
import signal
import time

from .common import contract_hash, file_hash, read_jsonl, source_hashes, validate_checkpoint, write_json
from .corruption import MASK, EXPAND, DELETE, UPSTREAM_COMMIT, corrupt
from .runtime import MODEL_ID, REVISION, load_model, load_tokenizer, state_loss

OBJECTIVE = "dreamon_official_augmented_all_identifier_masked"
KINDS = ("lexical", "expand", "delete")


def validate_config(config):
    if config["objective"] != OBJECTIVE or config["time_reweighting"] != "linear" or config["delete_loss_balancing"] is not True:
        raise ValueError("Expected official-derived augmentation and balanced linear-weighted loss")
    for key in ("steps","rank","gradient_accumulation","max_length","eval_every","save_every"):
        if type(config[key]) is not int or config[key] < 1:
            raise ValueError(key+" must be a positive integer")
    for key in ("max_delete","max_total_delete"):
        if type(config[key]) is not int or config[key] < 2:
            raise ValueError(key+" must permit deletion supervision")
    for key in ("merge_prob","static_probability"):
        if not 0 < config[key] < 1:
            raise ValueError(key+" must be in (0,1)")
    for key in ("learning_rate","gradient_clip"):
        if not math.isfinite(config[key]) or config[key] <= 0:
            raise ValueError(key+" must be finite and positive")
    if not 0 <= config["warmup_fraction"] < 1 or not 0 <= config["weight_decay"] < 1:
        raise ValueError("Invalid optimizer configuration")
    if len(config["betas"]) != 2 or not all(0 <= x < 1 for x in config["betas"]):
        raise ValueError("Invalid optimizer betas")
    if "mixture" in config or config["selected_checkpoint"] != "final_preregistered":
        raise ValueError("Old corruption mixture or validation checkpoint selection is not this experiment")


def prepare_record(record, tokenizer, max_length):
    parts = record["code_masked"].split("[MASK]")
    target = tokenizer.encode(record["target"],add_special_tokens=False)
    if len(parts) < 2 or not target or any(t in (MASK,EXPAND,DELETE) for t in target):
        raise ValueError("Invalid identifier/template: "+str(record["id"]))
    ids, spans = [tokenizer.bos_token_id], []
    for i, part in enumerate(parts):
        ids.extend(tokenizer.encode(part,add_special_tokens=False))
        if i+1 < len(parts):
            start = len(ids)
            ids.extend(target)
            spans.append((start,len(ids)))
    ids.append(tokenizer.eos_token_id)
    if len(ids) > max_length:
        raise ValueError(f"Refuse cropping context/sites: {record['id']} has {len(ids)} tokens")
    if MASK in ids:
        raise ValueError("Original context contains a native mask: "+str(record["id"]))
    return {"id":str(record["id"]),"repository":record["repository"],
            "gold_input_ids":ids,"target_token_spans":spans,"target":record["target"]}


def prepare_dataset(data_dir, tokenizer, config):
    root = Path(data_dir)
    manifest = json.loads((root/"manifest.json").read_text())
    prepared = {}
    hashes = {name:file_hash(root/name) for name in ("train.jsonl","validation.jsonl","manifest.json")}
    for split in ("train","validation"):
        records = read_jsonl(root/f"{split}.jsonl")
        declared = manifest["splits"][split]
        if len(records) != declared["records"] or hashes[f"{split}.jsonl"] != declared["sha256"]:
            raise ValueError("Dataset differs from declared manifest: "+split)
        prepared[split] = [prepare_record(r,tokenizer,config["max_length"]) for r in records]
        if not records or len({r["id"] for r in prepared[split]}) != len(records):
            raise ValueError("Split must be nonempty with unique source IDs")
    if {r["id"] for r in prepared["train"]} & {r["id"] for r in prepared["validation"]}:
        raise ValueError("Training/validation IDs overlap")
    if {r["repository"] for r in prepared["train"]} & {r["repository"] for r in prepared["validation"]}:
        raise ValueError("Training/validation repositories overlap")
    return prepared, hashes


def corruption_options(config):
    return {k:config[k] for k in ("max_length","max_delete","max_total_delete","merge_prob","static_probability")}


def augmentation_audit(records, config, seed=73419):
    rng = random.Random(seed)
    counts, states = Counter(), Counter()
    minimum, maximum, deleted, merged = config["max_length"], 0, 0, 0
    for row in records:
        state = corrupt(row,rng,**corruption_options(config))
        counts.update(state["action_counts"])
        states.update({k:int(v>0) for k,v in state["action_counts"].items()})
        minimum=min(minimum,state["sequence_length"])
        maximum=max(maximum,state["sequence_length"])
        deleted+=state["delete_slots_appended"]
        merged+=state["merged_out_slots"]
    return {"records":len(records),"seed":seed,"action_counts":{k:counts[k] for k in KINDS},
            "states_with_action":{k:states[k] for k in KINDS},"all_context_and_occurrences_preserved":True,
            "min_sequence_length":minimum,"max_sequence_length":maximum,
            "delete_slots_appended":deleted,"merged_out_slots":merged}


def diagnose(model, records, config):
    import torch
    was_training = model.training
    model.eval()
    stats = {k:{"tokens":0,"correct":0,"ce_sum":0.} for k in KINDS}
    losses=[]
    rng=random.Random(9173)
    try:
        with torch.no_grad():
            for row in records:
                state=corrupt(row,rng,**corruption_options(config))
                loss,item=state_loss(model,state)
                losses.append(float(loss))
                for kind in KINDS:
                    for key,value in item[kind].items():stats[kind][key]+=value
    finally:
        model.train(was_training)
    return {"condition":"deterministic augmented all-identifier-mask one-forward ACTION diagnostic; not generation EM",
            "states":len(records),"mean_weighted_loss":sum(losses)/len(losses),"actions":stats}


def schedule_factor(step,total,warmup):
    if warmup and step < warmup:return (step+1)/warmup
    progress=min(1.,max(0.,(step-warmup)/max(1,total-warmup)))
    return .5*(1+math.cos(math.pi*progress))


def validate_history(path, step):
    records=read_jsonl(path) if Path(path).exists() else []
    if [r["step"] for r in records] != list(range(1,step+1)):
        raise ValueError("Metrics must be a complete contiguous checkpoint prefix; preserve any stale tail")


def save_checkpoint(out,step,model,tokenizer,optimizer,scheduler,rng,examples,counts,states,contract):
    import torch
    destination=out/f"checkpoint-{step:06d}"
    temporary=out/(destination.name+".incomplete")
    if destination.exists() or temporary.exists():raise FileExistsError(destination)
    temporary.mkdir()
    model.save_pretrained(temporary,safe_serialization=True)
    tokenizer.save_pretrained(temporary)
    torch.save({"step":step,"examples_seen":examples,"action_counts":dict(counts),
                "states_with_action":dict(states),"contract":contract,"optimizer":optimizer.state_dict(),
                "scheduler":scheduler.state_dict(),"python_rng":rng.getstate(),"torch_rng":torch.get_rng_state(),
                "cuda_rng":torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None},temporary/"training_state.pt")
    metadata={"step":step,"examples_seen":examples,"action_counts":dict(counts),"states_with_action":dict(states),
              "contract_sha256":contract_hash(contract),
              "adapter_sha256":file_hash(temporary/"adapter_model.safetensors"),
              "adapter_config_sha256":file_hash(temporary/"adapter_config.json"),
              "state_sha256":file_hash(temporary/"training_state.pt")}
    write_json(temporary/"checkpoint.json",metadata)
    temporary.rename(destination)
    return destination


def parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config",default="experiments/variable_identifier/configs/dreamon.json")
    p.add_argument("--data-dir",required=True)
    p.add_argument("--run-dir",required=True)
    p.add_argument("--steps",type=int)
    p.add_argument("--seed",type=int,default=42)
    p.add_argument("--validation-examples",type=int,default=32)
    p.add_argument("--resume")
    p.add_argument("--tiny",action="store_true")
    p.add_argument("--prepare-only",action="store_true")
    p.add_argument("--stop-after-step",type=int)
    return p


def main(argv=None):
    stopped=False
    def stop(signum,frame):
        nonlocal stopped
        stopped=True
    old=signal.signal(signal.SIGUSR1,stop)
    try:return run(argv,lambda:stopped)
    finally:signal.signal(signal.SIGUSR1,old)


def run(argv,stop_requested=lambda:False):
    args=parser().parse_args(argv)
    config=json.loads(Path(args.config).read_text())
    if args.steps is not None:config["steps"]=args.steps
    validate_config(config)
    if args.validation_examples < 1 or (args.stop_after_step is not None and args.stop_after_step<1):
        raise ValueError("Diagnostic and stop budgets must be positive")
    tokenizer=load_tokenizer()
    records,hashes=prepare_dataset(args.data_dir,tokenizer,config)
    selected=sorted(records["validation"],key=lambda r:r["id"])[:args.validation_examples]
    audit=augmentation_audit(records["train"],config)
    if not args.tiny and any(audit["action_counts"][k]==0 for k in KINDS):
        raise ValueError("Preparation found no examples for one action class: "+str(audit))
    upstream=Path(__file__).parent/"upstream_sources"
    contract={"config":config,"model":MODEL_ID,"revision":REVISION,"seed":args.seed,"tiny":args.tiny,
              "upstream_commit":UPSTREAM_COMMIT,"source_sha256":source_hashes(),
              "upstream_source_sha256":{p.name:file_hash(p) for p in sorted(upstream.glob("*.txt"))},
              "data_hashes":hashes,"validation_ids":[r["id"] for r in selected]}
    if args.prepare_only:
        print(json.dumps({"status":"prepared","weights_loaded":False,"contract":contract,
                          "rows":{k:len(v) for k,v in records.items()},"augmentation_audit":audit}))
        return 0
    out=Path(args.run_dir)
    checkpoint=Path(args.resume).resolve() if args.resume else None
    metadata=None
    if checkpoint:
        if checkpoint.parent != out.resolve():raise ValueError("Resume checkpoint must belong to same run")
        if json.loads((out/"run.json").read_text())["contract"] != contract:
            raise ValueError("Resume data/source/config/model changed")
        metadata=validate_checkpoint(checkpoint,contract)
        validate_history(out/"metrics.jsonl",metadata["step"])
    elif out.exists() and any(out.iterdir()):raise FileExistsError(out)
    import torch
    if args.tiny:torch.set_num_threads(2)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(args.seed)
    rng=random.Random(args.seed)
    model=load_model(adapter=str(checkpoint) if checkpoint else None,train=True,rank=config["rank"],tiny=args.tiny)
    optimizer=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],
        lr=config["learning_rate"],weight_decay=config["weight_decay"],betas=tuple(config["betas"]))
    warmup=int(config["steps"]*config["warmup_fraction"])
    scheduler=torch.optim.lr_scheduler.LambdaLR(optimizer,lambda s:schedule_factor(s,config["steps"],warmup))
    start,examples=0,0
    counts,states=Counter({k:0 for k in KINDS}),Counter({k:0 for k in KINDS})
    out.mkdir(parents=True,exist_ok=True)
    if checkpoint:
        state=torch.load(checkpoint/"training_state.pt",map_location="cpu",weights_only=True)
        if state["contract"] != contract or state["step"] != metadata["step"] or state["examples_seen"] != metadata["examples_seen"]:
            raise ValueError("Serialized state does not match checkpoint")
        if state["action_counts"] != metadata["action_counts"] or state["states_with_action"] != metadata["states_with_action"]:
            raise ValueError("Serialized action counts differ from checkpoint")
        start,examples=state["step"],state["examples_seen"]
        counts.update(state["action_counts"]);states.update(state["states_with_action"])
        optimizer.load_state_dict(state["optimizer"]);scheduler.load_state_dict(state["scheduler"])
        rng.setstate(state["python_rng"]);torch.set_rng_state(state["torch_rng"])
        if state["cuda_rng"] is not None:torch.cuda.set_rng_state_all(state["cuda_rng"])
    else:
        versions={p:importlib.metadata.version(p) for p in ("torch","transformers","peft","accelerate","huggingface-hub")}
        write_json(out/"run.json",{"contract":contract,"device":str(next(model.parameters()).device),
            "versions":versions,"augmentation_audit":audit,"rows":{k:len(v) for k,v in records.items()},
            "trainable_parameters":sum(p.numel() for p in model.parameters() if p.requires_grad)})
        snapshot=out/"source_snapshot";snapshot.mkdir()
        for name in contract["source_sha256"]:shutil.copy2(Path(__file__).parent/name,snapshot/name)
        write_json(snapshot/"config.json",config)
        write_json(out/"baseline-action-diagnostics.json",diagnose(model,selected,config))
    def finish(path,step):
        if not args.tiny and step>=100 and any(counts[k]==0 for k in KINDS):
            raise ValueError("Completed optimizer run lacks required lexical/expand/delete training supervision")
        write_json(out/"completed.json",{"step":step,"checkpoint":path.name,"examples_seen":examples,
            "action_counts":dict(counts),"states_with_action":dict(states),"tiny_random_model_smoke_only":args.tiny,
            "selected_checkpoint":"final_preregistered","contract_sha256":contract_hash(contract)})
    if start>=config["steps"]:
        finish(checkpoint,start);return 0
    tick=time.monotonic()
    for step in range(start+1,config["steps"]+1):
        model.train();optimizer.zero_grad(set_to_none=True)
        loss_sum=0.;action_stats={k:{"tokens":0,"correct":0,"ce_sum":0.} for k in KINDS}
        for _ in range(config["gradient_accumulation"]):
            state=corrupt(rng.choice(records["train"]),rng,**corruption_options(config))
            loss,item=state_loss(model,state)
            if not torch.isfinite(loss):raise FloatingPointError("Non-finite loss")
            (loss/config["gradient_accumulation"]).backward()
            loss_sum+=float(loss.detach());examples+=1
            counts.update(state["action_counts"])
            states.update({k:int(v>0) for k,v in state["action_counts"].items()})
            for k in KINDS:
                for name,value in item[k].items():action_stats[k][name]+=value
        gradient=torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],config["gradient_clip"])
        if not torch.isfinite(gradient):raise FloatingPointError("Non-finite gradient")
        used_lr=optimizer.param_groups[0]["lr"]
        optimizer.step();scheduler.step()
        metric={"step":step,"mean_example_weighted_loss":loss_sum/config["gradient_accumulation"],
                "learning_rate":used_lr,"gradient_norm":float(gradient),"examples_seen":examples,
                "action_counts":dict(counts),"states_with_action":dict(states),"batch_actions":action_stats,
                "elapsed_seconds_this_session":time.monotonic()-tick}
        final=step==config["steps"]
        interrupted=stop_requested() or args.stop_after_step is not None and step>=args.stop_after_step
        if step%config["eval_every"]==0 or final:
            diagnostic=diagnose(model,selected,config)
            write_json(out/f"action-diagnostics-{step:06d}.json",diagnostic)
            metric["validation_action_diagnostics"]=diagnostic
        with (out/"metrics.jsonl").open("a") as stream:
            stream.write(json.dumps(metric,allow_nan=False)+"\n");stream.flush();os.fsync(stream.fileno())
        print(json.dumps(metric,allow_nan=False),flush=True)
        if final or interrupted or step%config["save_every"]==0:
            checkpoint=save_checkpoint(out,step,model,tokenizer,optimizer,scheduler,rng,examples,counts,states,contract)
        if final:finish(checkpoint,step);return 0
        if interrupted:
            print(json.dumps({"status":"checkpointed_for_resume","step":step,"checkpoint":str(checkpoint)}))
            return 75


if __name__=="__main__":
    raise SystemExit(main())
