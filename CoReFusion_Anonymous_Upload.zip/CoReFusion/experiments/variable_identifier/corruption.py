"""Condition the official DreamOn augmentation on all identifier slots masked.

Reference: DreamLM/DreamOn@8a0a54918412eda9402a327646f7f067f7160ec8,
src/trainer/sft_expand_dataset.py:269-309. Pseudo masks gate merging; the final
all-mask condition is task-specific. Context tokens never enter augmentation.
"""
from collections import Counter
import math

MASK, EXPAND, DELETE, IGNORE = 151666, 151667, 151643, -100
UPSTREAM_COMMIT = "8a0a54918412eda9402a327646f7f067f7160ec8"


def augment_site(gold, rng, *, t, schedule, merge_prob, delete_count):
    """Return compact action targets, including overlapping merged-edge chains.

    Official code can merge the last lexical token with the first appended EOS,
    but stops scanning once the LEFT original token is EOS. Preserve that rule.
    Draw pseudo masks before forcing EOS to mask, as the upstream inverse rate
    uses the realized *pre-forcing* Bernoulli mask count.
    """
    if not gold or any(type(x) is not int or x in (MASK, EXPAND, DELETE) for x in gold):
        raise ValueError("Identifier must contain ordinary token IDs")
    if not 0 <= t < 1 or not 0 <= merge_prob <= 1 or schedule not in ("static", "dynamic_inverse"):
        raise ValueError("Invalid augmentation schedule")
    if type(delete_count) is not int or delete_count < 0:
        raise ValueError("Delete count must be a nonnegative integer")
    augmented = list(gold) + [DELETE] * delete_count
    pseudo = [rng.random() < t for _ in augmented]
    masked = [flag or token == DELETE for flag, token in zip(pseudo, augmented)]
    rate = merge_prob if schedule == "static" else merge_prob * (1 - sum(pseudo) / len(pseudo))
    edge_draws = [rng.random() for _ in augmented[:-1]]
    labels, active = list(augmented), [True] * len(augmented)
    merged_edges = []
    for i, draw in enumerate(edge_draws):
        if augmented[i] == DELETE:
            break
        if masked[i] and masked[i + 1] and draw < rate:
            labels[i], active[i + 1] = EXPAND, False
            merged_edges.append(i)
    active_indices = [i for i, enabled in enumerate(active) if enabled]
    compact_labels = [labels[i] for i in active_indices]
    # Do not reveal any gold lexical token, even if the pseudo-mask gate was 0.
    return {
        "input_ids": [MASK] * len(compact_labels), "labels": compact_labels,
        "active_original_indices": active_indices, "augmented_gold_ids": augmented,
        "pseudo_mask": pseudo, "merged_edges": merged_edges,
        "merge_rate": rate, "t": t, "schedule": schedule,
        "delete_slots_appended": delete_count,
    }


def corrupt(record, rng, *, max_length=1024, max_delete=64,
            max_total_delete=64, merge_prob=.5, static_probability=.5):
    """Augment all sites independently, using one sampled t/scheduler per row.

    max_delete follows upstream's exclusive randint high (64 -> 0..63).
    A randomized site order allocates a shared deletion budget; draws are capped
    by remaining pre-merge context room, so no original context is truncated.
    """
    ids, spans = record["gold_input_ids"], record["target_token_spans"]
    if not ids or len(ids) > max_length or not spans:
        raise ValueError("Gold code must fit intact and have at least one site")
    if any(type(v) is not int or v < 0 for v in (max_delete, max_total_delete)):
        raise ValueError("Deletion budgets must be nonnegative integers")
    if not 0 <= merge_prob <= 1 or not 0 <= static_probability <= 1:
        raise ValueError("Invalid merge probabilities")
    previous = 1
    target_positions = set()
    for start, end in spans:
        if type(start) is not int or type(end) is not int or not previous <= start < end < len(ids):
            raise ValueError("Target spans must be sorted, disjoint and inside boundaries")
        target_positions.update(range(start, end))
        previous = end
    if any(token == MASK for token in ids):
        raise ValueError("Original code cannot contain native MASK tokens")
    t = rng.random()
    schedule = "static" if rng.random() < static_probability else "dynamic_inverse"
    budget = min(max_total_delete, max_length - len(ids))
    allocated = [0] * len(spans)
    order = list(range(len(spans)))
    rng.shuffle(order)
    for index in order:
        high = min(max_delete, budget + 1)
        count = rng.randrange(high) if high > 0 else 0
        allocated[index] = count
        budget -= count
    output, labels, output_spans, sites = [], [], [], []
    source_cursor = 0
    for (start, end), count in zip(spans, allocated):
        output.extend(ids[source_cursor:start])
        labels.extend([IGNORE] * (start - source_cursor))
        site = augment_site(ids[start:end], rng, t=t, schedule=schedule,
                            merge_prob=merge_prob, delete_count=count)
        begin = len(output)
        output.extend(site["input_ids"])
        labels.extend(site["labels"])
        output_spans.append((begin, len(output)))
        sites.append(site)
        source_cursor = end
    output.extend(ids[source_cursor:])
    labels.extend([IGNORE] * (len(ids) - source_cursor))
    counts = Counter("expand" if x == EXPAND else "delete" if x == DELETE else "lexical"
                     for x in labels if x != IGNORE)
    counts = {k: counts[k] for k in ("lexical", "expand", "delete")}
    state = {
        "input_ids": output, "labels": labels, "target_token_spans": output_spans,
        "t": t, "time_weight": 1 - t, "schedule": schedule,
        "action_counts": counts, "sites": sites,
        "original_sequence_length": len(ids), "sequence_length": len(output),
        "delete_slots_appended": sum(allocated),
        "merged_out_slots": sum(len(s["merged_edges"]) for s in sites),
        "all_identifier_occurrences_masked": True,
    }
    if len(output) != len(labels) or len(output) > max_length or not math.isfinite(state["time_weight"]):
        raise ValueError("Invalid augmented canvas")
    if {i for i, x in enumerate(output) if x == MASK} != {i for i, x in enumerate(labels) if x != IGNORE}:
        raise ValueError("Only and all target slots must be masked and supervised")
    observed_before = [x for i, x in enumerate(ids) if i not in target_positions]
    observed_after = [x for x, label in zip(output, labels) if label == IGNORE]
    if observed_before != observed_after:
        raise ValueError("Augmentation changed observed context")
    return state
