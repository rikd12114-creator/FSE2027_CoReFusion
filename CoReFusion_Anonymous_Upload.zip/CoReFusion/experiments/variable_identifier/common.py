"""Atomic persistence and exact-run binding for variable identifier training."""
import hashlib
import json
import os
from pathlib import Path


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda:stream.read(1024*1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name+".tmp")
    with temporary.open("w") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def contract_hash(contract):
    return hashlib.sha256(json.dumps(contract,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()


def source_hashes():
    root = Path(__file__).parent
    return {str(p.relative_to(root)):file_hash(p) for p in sorted(root.glob("*.py"))}


def validate_checkpoint(path, contract):
    path = Path(path)
    meta = json.loads((path/"checkpoint.json").read_text())
    if meta["contract_sha256"] != contract_hash(contract):
        raise ValueError("Checkpoint contract changed")
    step = meta["step"]
    if type(step) is not int or not 1 <= step <= contract["config"]["steps"] or path.name != f"checkpoint-{step:06d}":
        raise ValueError("Invalid checkpoint step/directory")
    if meta["examples_seen"] != step*contract["config"]["gradient_accumulation"]:
        raise ValueError("Checkpoint example count differs from optimizer steps")
    for field in ("action_counts", "states_with_action"):
        if set(meta[field]) != {"lexical","expand","delete"} or any(type(v) is not int or v < 0 for v in meta[field].values()):
            raise ValueError("Invalid checkpoint action counters")
    for filename,key in (("adapter_model.safetensors","adapter_sha256"),
                         ("adapter_config.json","adapter_config_sha256"),
                         ("training_state.pt","state_sha256")):
        if file_hash(path/filename) != meta[key]:
            raise ValueError("Checkpoint hash mismatch: "+filename)
    return meta
