"""Full-parameter training through the pinned official Dream trainers."""
