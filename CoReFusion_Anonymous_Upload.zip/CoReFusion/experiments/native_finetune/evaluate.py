"""Resumable full-checkpoint evaluation with validation-only model selection.

This deliberately imports the existing benchmark decoders. Full fine-tuned
weights and their pinned base therefore receive the same inputs and scoring.
No PEFT adapter, weight merge, or test-based checkpoint selection is used.
"""
import argparse
from collections import Counter
from contextlib import contextmanager
import fcntl
import gc
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import random
import sys
import time


ROOT = Path(__file__).resolve().parents[2]
PROFILES = {
    "dreamon": {
        "model_id": "Dream-org/DreamOn-v0-7B",
        "revision": "57e0e4115c97899e3e859b00eae26f54f9cf3872",
    },
    "dreamcoder": {
        "model_id": "Dream-org/Dream-Coder-v0-Base-7B",
        "revision": "2346ccd3be517d0d314152b988a3b9bafa7d6d63",
    },
}
ARCHITECTURE_FIELDS = (
    "model_type", "hidden_size", "intermediate_size", "num_hidden_layers",
    "num_attention_heads", "num_key_value_heads", "vocab_size",
    "mask_token_id", "eos_token_id", "expand_token_id", "rope_theta",
)


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def object_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def source_hashes():
    # Hash only runtime dependencies, not unrelated training files that may
    # change while a completed evaluation is being inspected.
    names = ["native_finetune/evaluate.py", "fixed_identifier/evaluate.py",
             "fixed_identifier/runtime.py", "fixed_identifier/profiles.py",
             "refineid_comparison/data.py", "refineid_comparison/evaluate.py",
             "late_rename/evaluate.py", "late_rename/corruption.py",
             "late_rename/runtime.py", "late_rename/prepare_data.py"]
    return {name: file_hash(ROOT / "experiments" / name) for name in names}


def runtime_versions():
    result = {"python": sys.version.split()[0]}
    for name in ("torch", "transformers", "tokenizers", "safetensors", "tree-sitter", "tree-sitter-java"):
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            result[name] = None
    return result


def protocol(model, *, condition="fixed_2", seed=42, max_length=1024):
    if model not in PROFILES:
        raise ValueError("Unknown model")
    if type(seed) is not int or type(max_length) is not int or not 128 <= max_length <= 32768:
        raise ValueError("Require integer seed and max_length in [128, 32768]")
    common = {"model": model, "profile": PROFILES[model], "seed": seed,
              "max_length": max_length, "metric": "strict_em",
              "errors_count_as_failures": True, "all_occurrences_required": True}
    if model == "dreamon":
        if condition != "fixed_2":
            raise ValueError("DreamOn uses its native variable-length two-mask initialization")
        return {**common, "decoder": "native-dreamon-v1-exact-anchors",
                "initial_masks": 2, "max_sites": 8, "max_canvas": 64,
                "max_actions": 512, "temperature": 0.2,
                "normalization": "tokenizer.decode(skip_special_tokens=False).strip()",
                "gold_length_input": False}
    if condition not in ("fixed_2", "oracle_length"):
        raise ValueError("Unsupported Dream-Coder condition")
    return {**common, "decoder": "refineid-complete-slot-single-forward",
            "condition": condition, "gold_length_input": condition == "oracle_length",
            "normalization": "Java edge whitespace trimmed; valid identifier required"}


def checkpoint_info(path, model):
    """Inspect and hash a completed HF full-weight export, never optimizer files."""
    path = Path(path).resolve()
    if (path / "adapter_config.json").exists() or list(path.glob("adapter_model.*")):
        raise ValueError("Adapter checkpoints are not full-model checkpoints")
    metadata_path = path / "native_checkpoint.json"
    metadata = json.loads(metadata_path.read_text())
    profile = PROFILES[model]
    if (metadata.get("model_id"), metadata.get("model_revision"), metadata.get("training_type")) != (
            profile["model_id"], profile["revision"], "full_parameters"):
        raise ValueError("Checkpoint is not a full-parameter export from the pinned base")
    if type(metadata.get("optimizer_step")) is not int or metadata["optimizer_step"] < 1:
        raise ValueError("A checkpoint must contain a positive completed optimizer step")
    weights = sorted(path.glob("model*.safetensors"))
    if list(path.glob("pytorch_model*.bin")):
        raise ValueError("Complete loading verification supports safetensors exports only")
    if not weights:
        raise ValueError("No full Hugging Face model weights found")
    indexes = sorted(path.glob("*.index.json"))
    for index in indexes:
        mapping = json.loads(index.read_text()).get("weight_map", {})
        if not mapping:
            raise ValueError("Empty model shard index")
        if any(Path(name).name != name or not (path / name).is_file() for name in mapping.values()):
            raise ValueError("Model shard index references an absent or external file")
    config_path = path / "config.json"
    config = json.loads(config_path.read_text())
    if config.get("hidden_size", 0) < 1000 or config.get("num_hidden_layers", 0) < 10:
        raise ValueError("Tiny/random test architecture cannot be a benchmark checkpoint")
    files = sorted(set([metadata_path, config_path, *weights, *indexes]))
    inventory = {p.name: {"sha256": file_hash(p), "size": p.stat().st_size} for p in files}
    registered = metadata.get("model_weight_sha256")
    if metadata.get("audit_type") == "external_post_training_verification_of_unchanged_official_trainer" and not registered:
        raise ValueError("Registered official checkpoint lacks its audited weight hashes")
    if registered is not None and registered != {name: entry["sha256"] for name, entry in inventory.items()
                                                if name != metadata_path.name}:
        raise ValueError("Registered checkpoint files differ from the completed official audit")
    return {"path": str(path), "metadata": metadata, "files": inventory}


def verify_loaded_safetensors(loaded, directory, expected_dtype):
    """Compare every returned model tensor to its saved weight after dtype cast.

    The pinned models' original from_pretrained override does not support
    output_loading_info=True. Inspect its ordinary returned model independently
    without changing or bypassing that upstream implementation.
    """
    import torch
    from safetensors import safe_open
    directory = Path(directory)
    files = sorted(directory.glob("model*.safetensors"))
    if not files:
        raise ValueError("Full loading verification requires original safetensors weights")
    state = loaded.state_dict()
    seen, dtypes, elements = set(), Counter(), 0
    for path in files:
        with safe_open(str(path), framework="pt", device="cpu") as stream:
            for name in stream.keys():
                if name in seen or name not in state:
                    raise ValueError(f"Duplicate or unexpected saved tensor: {name}")
                seen.add(name)
                actual = state[name]
                if actual.device.type != "cpu":
                    raise ValueError("Full loading verification must precede GPU transfer")
                saved = stream.get_tensor(name)
                if actual.shape != saved.shape:
                    raise ValueError(f"Loaded tensor shape differs from saved weights: {name}")
                if actual.is_floating_point() and actual.dtype != expected_dtype:
                    raise ValueError(f"Loaded tensor has an unexpected inference dtype: {name}")
                if not torch.equal(actual, saved.to(dtype=actual.dtype)):
                    raise ValueError(f"Loaded tensor values differ from saved weights: {name}")
                dtypes[str(actual.dtype)] += 1
                elements += actual.numel()
                del saved
    if seen != set(state):
        raise ValueError(f"Model tensors are absent from saved weights: {sorted(set(state) - seen)}")
    return {"full_tensor_key_and_shape_match": True,
            "all_tensor_values_match_after_loading_cast": True,
            "tensor_count": len(seen), "parameter_and_buffer_elements": elements,
            "loaded_dtype_tensor_counts": dict(dtypes),
            "requested_float_dtype": str(expected_dtype),
            "verification_device": "cpu", "weight_files": [path.name for path in files]}


def load_full_model(model, checkpoint=None):
    """Use audited upstream model code with a complete base or trained state dict."""
    import torch
    from transformers import AutoConfig, AutoModel
    if not torch.cuda.is_available() or not torch.cuda.is_bf16_supported():
        raise RuntimeError("Full 7B evaluation requires a bf16 CUDA GPU")
    profile = PROFILES[model]
    common = {"revision": profile["revision"], "code_revision": profile["revision"],
              "trust_remote_code": True}
    config = AutoConfig.from_pretrained(profile["model_id"], **common)
    if checkpoint:
        local_config = json.loads((Path(checkpoint) / "config.json").read_text())
        expected = config.to_dict()
        for field in ARCHITECTURE_FIELDS:
            if local_config.get(field) != expected.get(field):
                raise ValueError(f"Full checkpoint architecture differs from pinned base: {field}")
        # The original remote class stays pinned even if an export contains
        # extra local Python files. Do not accidentally execute unpinned code.
        config.auto_map = {key: (value if "--" in value else profile["model_id"] + "--" + value)
                           for key, value in config.auto_map.items() if isinstance(value, str)}
        common.pop("revision")
    loaded = AutoModel.from_pretrained(
        str(checkpoint) if checkpoint else profile["model_id"], config=config,
        **common, torch_dtype=torch.bfloat16, attn_implementation="sdpa",
        low_cpu_mem_usage=True)
    if checkpoint:
        weight_directory = Path(checkpoint)
    else:
        from transformers.utils.hub import cached_file
        weight_directory = Path(cached_file(profile["model_id"], "config.json",
                                           revision=profile["revision"])).parent
    loaded._full_weight_loading_evidence = verify_loaded_safetensors(
        loaded, weight_directory, torch.bfloat16)
    loaded.config.use_cache = False
    return loaded.to("cuda").eval()


def load_tokenizer(model):
    if model == "dreamon":
        from experiments.late_rename.runtime import load_tokenizer as load
        return load()
    from experiments.fixed_identifier.runtime import load_tokenizer as load
    return load(model)


def read_records(path, phase):
    path = Path(path)
    if phase == "test":
        if path.suffix != ".csv":
            raise ValueError("Held-out evaluation requires the original 1000-row ReFineID CSV")
        from experiments.refineid_comparison.data import read_records as read
        records = read(path, expected_rows=1000)
    elif phase == "validation":
        if path.name != "validation.jsonl":
            raise ValueError("Selection requires the original validation.jsonl, never a test CSV")
        records = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        if any(row.get("split", "validation") != "validation" for row in records):
            raise ValueError("Non-validation record used for checkpoint selection")
    else:
        raise ValueError("Invalid evaluation phase")
    result = []
    for row in records:
        if not all(isinstance(row.get(k), str) and row[k] for k in ("code_masked", "target")):
            raise ValueError("Evaluation requires original masked code and target text")
        row = dict(row)
        if phase == "validation" and "code_masked_template" in row:
            # Stack stores native mask tokens (possibly multiple per site) in
            # code_masked, and exactly one public slot per occurrence here.
            # Reuse that saved template without consulting target token length.
            row["code_masked"] = row["code_masked_template"]
        if not isinstance(row["code_masked"], str) or not row["code_masked"].count("[MASK]"):
            raise ValueError("Evaluation requires a saved [MASK] template with at least one occurrence")
        occurrences = row["code_masked"].count("[MASK]")
        for field in ("occurrence_count", "num_occurrences"):
            if field in row and (type(row[field]) is not int or row[field] != occurrences):
                raise ValueError("Saved template occurrence count differs from the dataset")
        if phase == "validation" and "code" in row and row["code_masked"].replace("[MASK]", row["target"]) != row["code"]:
            raise ValueError("Saved template does not reconstruct the original validation code")
        # Stack source IDs are only unique within repositories. This is exactly
        # the original DreamOn evaluator's composite identity and seed policy.
        row["id"] = (json.dumps([row["repository"], str(row["id"])], separators=(",", ":"))
                     if row.get("repository") else str(row["id"]))
        result.append(row)
    if not result or len({r["id"] for r in result}) != len(result):
        raise ValueError("Evaluation records must be nonempty and have unique IDs")
    return result


def source_cluster(row):
    # Repository grouping on Stack validation; normalized source grouping on
    # external ReFineID, matching the earlier paired analysis.
    if row.get("repository"):
        return "repo:" + row["repository"]
    from experiments.late_rename.prepare_data import RecordError, normalized_fingerprint
    reconstructed = row["code_masked"].replace("[MASK]", row["target"])
    try:
        return normalized_fingerprint(reconstructed)
    except RecordError:
        return "raw:" + hashlib.sha256(reconstructed.encode()).hexdigest()


def evaluate_dreamon(model, row, tokenizer, spec):
    from experiments.late_rename.corruption import tokenize_windows
    from experiments.late_rename.evaluate import extract_sites, generate
    count = row["code_masked"].count("[MASK]")
    predictions, logs, preserved, errors = [""] * count, [], True, []
    try:
        masked = dict(row, target_ids_override=[tokenizer.mask_token_id] * spec["initial_masks"])
        windows = tokenize_windows(masked, tokenizer, spec["max_length"], 64, spec["max_sites"])
        for index, window in enumerate(windows):
            seed = int.from_bytes(hashlib.sha256(
                f"{spec['seed']}:{row['id']}:{index}".encode()).digest()[:4], "big") % 2**31
            sequence, log = generate(model, tokenizer, window.ids, spec["max_length"],
                spec["max_canvas"], spec["max_actions"], spec["temperature"], seed)
            found, context_ok = extract_sites(sequence, window, tokenizer)
            log["context_preserved"] = context_ok
            preserved &= context_ok
            if log["error"]:
                errors.append(log["error"])
            for site, prediction in zip(window.site_indices, found):
                predictions[site] = prediction
            logs.append(log)
    except Exception as exc:
        preserved = False
        errors.append(f"{type(exc).__name__}: {exc}")
    return {"id": row["id"], "target": row["target"], "site_predictions": predictions,
            "occurrences": count, "context_preserved": preserved, "errors": errors,
            "strict_em": bool(count and not errors and preserved and all(p == row["target"] for p in predictions)),
            "forward_passes": sum(log["nfe"] for log in logs),
            "seconds": sum(log["seconds"] for log in logs), "windows": logs}


def evaluate_record(model, row, tokenizer, spec):
    if spec["model"] == "dreamon":
        result = evaluate_dreamon(model, row, tokenizer, spec)
    else:
        from experiments.refineid_comparison.evaluate import evaluate_record as evaluate
        result = evaluate(model, row, tokenizer, condition=spec["condition"], max_length=spec["max_length"])
        result["strict_em"] = result["java_whitespace_trimmed_identifier_name_em"]
    result["source_cluster_id"] = source_cluster(row)
    return result


def validate_result(row, record):
    if row.get("id") != record["id"] or row.get("target") != record["target"]:
        raise ValueError("Prediction identity or target differs from the frozen selection")
    if row.get("occurrences") != record["code_masked"].count("[MASK]"):
        raise ValueError("Prediction occurrence denominator differs from the dataset")
    if type(row.get("strict_em")) is not bool or not isinstance(row.get("errors"), list):
        raise ValueError("Invalid prediction score/error schema")
    if row["errors"] and row["strict_em"]:
        raise ValueError("Errored predictions cannot be successes")
    if "site_predictions" in row:
        predictions = row["site_predictions"]
        expected = bool(predictions and len(predictions) == row["occurrences"] and
                        all(p == record["target"] for p in predictions) and
                        row.get("context_preserved") and not row["errors"])
    elif "predictions" in row:
        predictions = row["predictions"]
        expected = bool(predictions and len(predictions) == row["occurrences"] and
                        all(p["identifier_name"] == record["target"] and p["valid_identifier"]
                            for p in predictions) and not row["errors"])
    else:
        raise ValueError("Missing per-occurrence prediction evidence")
    if len(predictions) != row["occurrences"] or row["strict_em"] != expected:
        raise ValueError("Saved strict score disagrees with occurrence predictions")
    if not isinstance(row.get("source_cluster_id"), str):
        raise ValueError("Missing source cluster for paired analysis")


def read_predictions(path, records, *, recover_tail=False):
    """Resume only an exact ID prefix; preserve interrupted final bytes separately."""
    path = Path(path)
    if not path.exists():
        return []
    raw = path.read_bytes()
    if raw and not raw.endswith(b"\n"):
        if not recover_tail:
            raise ValueError("Incomplete final prediction row")
        split = raw.rfind(b"\n") + 1
        quarantine = path.with_name(path.name + ".interrupted-tail-" + str(time.time_ns()))
        quarantine.write_bytes(raw[split:])
        with path.open("r+b") as stream:
            stream.truncate(split)
        raw = raw[:split]
    rows = [json.loads(line) for line in raw.splitlines()]
    if len(rows) > len(records):
        raise ValueError("Prediction output has extra records")
    for row, record in zip(rows, records):
        validate_result(row, record)
    return rows


def summarize(rows, expected):
    if expected < 1 or len(rows) > expected:
        raise ValueError("Invalid expected coverage")
    correct = sum(bool(row["strict_em"]) and not row["errors"] for row in rows)
    return {"expected": expected, "completed": len(rows), "missing": expected - len(rows),
            "errors_counted_as_failures": sum(bool(row["errors"]) for row in rows),
            "correct": correct, "strict_em": correct / expected,
            "coverage": len(rows) / expected, "complete": len(rows) == expected,
            "forward_passes": sum(row.get("forward_passes", 0) for row in rows)}


def paired_comparison(base, finetuned, *, seed=42, replicates=2000):
    if not base or [r["id"] for r in base] != [r["id"] for r in finetuned]:
        raise ValueError("Pairing requires identical, complete IDs in original order")
    groups, outcomes = {}, Counter()
    for before, after in zip(base, finetuned):
        if before["source_cluster_id"] != after["source_cluster_id"]:
            raise ValueError("Paired source clusters differ")
        a, b = int(before["strict_em"] and not before["errors"]), int(after["strict_em"] and not after["errors"])
        groups.setdefault(before["source_cluster_id"], []).append(b - a)
        outcomes[f"base_{a}_finetuned_{b}"] += 1
    sufficient = [(sum(values), len(values)) for values in groups.values()]
    rng, draws = random.Random(seed), []
    for _ in range(replicates):
        sample = [rng.choice(sufficient) for _ in sufficient]
        draws.append(sum(a for a, _ in sample) / sum(b for _, b in sample))
    draws.sort()
    return {"examples": len(base), "source_clusters": len(groups), "outcomes": dict(outcomes),
            "finetuned_minus_base": sum(a for a, _ in sufficient) / len(base),
            "source_cluster_bootstrap_95_percentile_interval": [
                draws[int(.025 * (replicates - 1))], draws[int(.975 * (replicates - 1))]],
            "bootstrap_replicates": replicates, "seed": seed}


@contextmanager
def output_lock(output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    with (output / "evaluation.lock").open("a") as stream:
        try:
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError("Another evaluator already owns this output directory") from exc
        try:
            yield
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def choose_checkpoint(manifest, summaries):
    if manifest["phase"] != "validation":
        raise ValueError("Checkpoint selection is validation-only")
    candidates = manifest["checkpoints"]
    if not candidates:
        raise ValueError("At least one full checkpoint must be declared")
    for key in ["base", *candidates]:
        summary = summaries[key]
        if not summary["complete"] or summary["errors_counted_as_failures"] == summary["expected"]:
            raise ValueError("Selection requires full coverage and at least one non-error row for every variant")
    # Predeclared deterministic tie rule: earliest optimizer step, then path.
    return min(candidates, key=lambda key: (-summaries[key]["strict_em"],
               candidates[key]["metadata"]["optimizer_step"], candidates[key]["path"]))


def run_evaluation(*, output, phase, data, spec, checkpoints, selection=None, resume=False):
    output, data = Path(output).resolve(), Path(data).resolve()
    records = read_records(data, phase)
    if phase == "test" and not selection:
        raise ValueError("Test evaluation requires a validation selection certificate")
    manifest = {"schema_version": 1, "phase": phase, "data_path": str(data),
                "data_sha256": file_hash(data), "selection_ids": [r["id"] for r in records],
                "record_sha256": object_hash(records), "protocol": spec,
                "checkpoints": checkpoints, "selection": selection,
                "source_sha256": source_hashes(), "runtime_versions": runtime_versions(),
                "selection_rule": "Maximum validation strict EM; tie: earliest step then checkpoint path"}
    with output_lock(output):
        manifest_path = output / "manifest.json"
        if manifest_path.exists():
            if not resume:
                raise FileExistsError("Output exists; use --resume with the identical command")
            if json.loads(manifest_path.read_text()) != manifest:
                raise ValueError("Resume manifest differs: data, source, runtime, weights or protocol changed")
        else:
            if any(output.glob("*.jsonl")):
                raise ValueError("Existing predictions have no manifest")
            write_json(manifest_path, manifest)
        tokenizer, variants, summaries, evidence = None, {}, {}, {}
        for key in ["base", *checkpoints]:
            filename = output / f"{key}.jsonl"
            rows = read_predictions(filename, records, recover_tail=resume)
            if len(rows) < len(records):
                import torch
                if tokenizer is None:
                    tokenizer = load_tokenizer(spec["model"])
                torch.manual_seed(spec["seed"])
                model = load_full_model(spec["model"], None if key == "base" else checkpoints[key]["path"])
                try:
                    with filename.open("a", encoding="utf-8") as stream:
                        for record in records[len(rows):]:
                            row = evaluate_record(model, record, tokenizer, spec)
                            validate_result(row, record)
                            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
                            stream.flush()
                            os.fsync(stream.fileno())
                            rows.append(row)
                            if len(rows) % 25 == 0 or len(rows) == len(records):
                                print(json.dumps({"variant": key, **summarize(rows, len(records))}), flush=True)
                finally:
                    del model
                    gc.collect()
                    torch.cuda.empty_cache()
            variants[key], summaries[key] = rows, summarize(rows, len(records))
            evidence[key] = {"file": filename.name, "sha256": file_hash(filename)}
        if file_hash(data) != manifest["data_sha256"] or source_hashes() != manifest["source_sha256"]:
            raise ValueError("Data or evaluation source changed while running")
        for key, info in checkpoints.items():
            if checkpoint_info(info["path"], spec["model"]) != info:
                raise ValueError(f"Checkpoint changed while evaluating: {key}")
        report = {"manifest_sha256": file_hash(manifest_path), "phase": phase,
                  "summaries": summaries, "predictions": evidence,
                  "paired": {key: paired_comparison(variants["base"], variants[key], seed=spec["seed"])
                             for key in checkpoints}}
        if any(s["errors_counted_as_failures"] == s["expected"] for s in summaries.values()):
            write_json(output / "failed_report.json", report)
            raise RuntimeError("A variant failed every row; no successful report or selection produced")
        write_json(output / "report.json", report)
        if phase == "validation":
            selected = choose_checkpoint(manifest, summaries)
            certificate = {"schema_version": 1, "phase": "validation", "model": spec["model"],
                "protocol": spec, "checkpoint": checkpoints[selected], "variant": selected,
                "validation_data_sha256": manifest["data_sha256"],
                "validation_record_sha256": manifest["record_sha256"],
                "validation_output": str(output), "manifest_sha256": file_hash(manifest_path),
                "report_sha256": file_hash(output / "report.json"), "selection_rule": manifest["selection_rule"]}
            write_json(output / "selection.json", certificate)
        return report


def verify_selection(path):
    path = Path(path).resolve()
    selection = json.loads(path.read_text())
    if selection.get("phase") != "validation":
        raise ValueError("Only validation can authorize held-out testing")
    directory = Path(selection["validation_output"])
    if file_hash(directory / "manifest.json") != selection["manifest_sha256"] or file_hash(directory / "report.json") != selection["report_sha256"]:
        raise ValueError("Validation evidence changed after checkpoint selection")
    manifest = json.loads((directory / "manifest.json").read_text())
    report = json.loads((directory / "report.json").read_text())
    if manifest["phase"] != "validation" or report["phase"] != "validation":
        raise ValueError("Test output cannot be used for selection")
    if report["manifest_sha256"] != selection["manifest_sha256"]:
        raise ValueError("Validation report refers to another manifest")
    records = read_records(manifest["data_path"], "validation")
    if (file_hash(manifest["data_path"]) != manifest["data_sha256"] or
            selection["validation_data_sha256"] != manifest["data_sha256"] or
            object_hash(records) != selection["validation_record_sha256"]):
        raise ValueError("Validation dataset changed after selection")
    summaries = {}
    for key in ["base", *manifest["checkpoints"]]:
        evidence = report["predictions"][key]
        prediction_path = directory / evidence["file"]
        if file_hash(prediction_path) != evidence["sha256"]:
            raise ValueError("Validation prediction bytes changed after selection")
        summaries[key] = summarize(read_predictions(prediction_path, records), len(records))
    if summaries != report["summaries"]:
        raise ValueError("Validation report disagrees with its prediction rows")
    chosen = choose_checkpoint(manifest, summaries)
    if (chosen != selection["variant"] or manifest["checkpoints"][chosen] != selection["checkpoint"] or
            manifest["protocol"] != selection["protocol"] or selection["model"] != selection["protocol"]["model"]):
        raise ValueError("Selection does not follow the frozen validation rule/protocol")
    if source_hashes() != manifest["source_sha256"]:
        raise ValueError("Evaluation source changed after validation")
    if runtime_versions() != manifest["runtime_versions"]:
        raise ValueError("Evaluation runtime versions changed after validation")
    current = checkpoint_info(selection["checkpoint"]["path"], selection["model"])
    if current != selection["checkpoint"]:
        raise ValueError("Selected weights changed after validation")
    return selection


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="phase", required=True)
    validation = commands.add_parser("validation", help="Evaluate base/all declared checkpoints; select on validation")
    validation.add_argument("--model", choices=tuple(PROFILES), required=True)
    validation.add_argument("--data", required=True, help="Original Stack validation.jsonl with code_masked/target")
    validation.add_argument("--checkpoint", nargs="+", required=True, help="Completed full HF checkpoints")
    validation.add_argument("--condition", choices=("fixed_2", "oracle_length"), default="fixed_2")
    validation.add_argument("--seed", type=int, default=42)
    validation.add_argument("--max-length", type=int, default=1024)
    testing = commands.add_parser("test", help="Evaluate exactly 1000 held-out tasks with base and selected full weights")
    testing.add_argument("--selection", required=True)
    testing.add_argument("--data", default=str(ROOT / "data/test.csv"))
    for command in (validation, testing):
        command.add_argument("--output", required=True)
        command.add_argument("--resume", action="store_true")
    args = parser.parse_args(argv)
    selection = None
    if args.phase == "validation":
        spec = protocol(args.model, condition=args.condition, seed=args.seed, max_length=args.max_length)
        infos = [checkpoint_info(path, args.model) for path in args.checkpoint]
        if len({info["path"] for info in infos}) != len(infos):
            parser.error("Duplicate checkpoint paths")
        infos.sort(key=lambda info: (info["metadata"]["optimizer_step"], info["path"]))
        checkpoints = {f"checkpoint-{index:03d}-step-{info['metadata']['optimizer_step']}": info
                       for index, info in enumerate(infos)}
    else:
        selection = verify_selection(args.selection)
        spec = selection["protocol"]
        checkpoints = {selection["variant"]: selection["checkpoint"]}
        if file_hash(args.data) == selection["validation_data_sha256"]:
            parser.error("Test data cannot equal the checkpoint selection dataset")
    report = run_evaluation(output=args.output, phase=args.phase, data=args.data,
        spec=spec, checkpoints=checkpoints, selection=selection, resume=args.resume)
    print(json.dumps({"output": str(Path(args.output).resolve()), "summaries": report["summaries"]}), flush=True)


if __name__ == "__main__":
    main()
