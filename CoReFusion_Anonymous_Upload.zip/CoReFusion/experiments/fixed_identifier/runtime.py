"""Native bidirectional Dream-Coder/DiffuCoder forward and masked-only loss.

No length actions, vocabulary resizing, causal attention, or timestep conditioning
are introduced. ``selected_logits`` accepts target positions and applies the
official one-position logit shift before the sparse output projection.
"""

from .profiles import LORA_MODULES, get_profile


def validate_tokenizer_contract(tokenizer, profile_key):
    profile = get_profile(profile_key)
    literal_tokens = {
        "bos_token_id": "<|beginoftext|>", "eos_token_id": "<|endoftext|>",
        "pad_token_id": "<|endoftext|>", "mask_token_id": "<|mask|>",
    }
    observed = {}
    for key, literal in literal_tokens.items():
        actual = getattr(tokenizer, key, None)
        literal_id = tokenizer.convert_tokens_to_ids(literal)
        if actual != profile[key] or literal_id != profile[key]:
            raise ValueError(f"{profile_key} tokenizer {key} mismatch: {actual}, {literal_id}")
        observed[key] = actual
    if len(tokenizer) != profile["tokenizer_size"]:
        raise ValueError("Tokenizer vocabulary differs from the pinned native tokenizer")
    if "<|expand|>" in tokenizer.get_vocab():
        raise ValueError("DreamOn expand token is not part of this native model contract")
    if tokenizer.encode("<|mask|>", add_special_tokens=False) != [profile["mask_token_id"]]:
        raise ValueError("Native mask token must tokenize to exactly one mask ID")
    return observed


def load_tokenizer(profile_key, local_files_only=False):
    from transformers import AutoTokenizer
    profile = get_profile(profile_key)
    tokenizer = AutoTokenizer.from_pretrained(
        profile["model_id"], revision=profile["revision"],
        code_revision=profile["revision"], trust_remote_code=True,
        local_files_only=local_files_only,
    )
    validate_tokenizer_contract(tokenizer, profile_key)
    return tokenizer


def validate_model_contract(config, profile_key):
    profile = get_profile(profile_key)
    if config.model_type != "Dream":
        raise ValueError("Expected the pinned native Dream modeling architecture")
    model_classes = {
        "modeling_dream.DreamModel",
        profile["model_id"] + "--modeling_dream.DreamModel",
    }
    if getattr(config, "auto_map", {}).get("AutoModel") not in model_classes:
        raise ValueError("Unexpected native model class mapping")
    if getattr(config, "_commit_hash", profile["revision"]) != profile["revision"]:
        raise ValueError("Native model configuration revision differs from the pinned profile")
    for key in ("vocab_size", "mask_token_id", "pad_token_id", "eos_token_id"):
        if getattr(config, key, None) != profile[key]:
            raise ValueError(f"Native model {key} does not match {profile_key}")
    if getattr(config, "expand_token_id", None) is not None:
        raise ValueError("Length-action DreamOn checkpoints are not native fixed-canvas models")
    # The upstream model config reports BOS=151643. Data must use the real
    # tokenizer BOS=151665; do not silently replace it with config.bos_token_id.


def load_model(profile_key, adapter=None, train=False, rank=16, device="cuda", tiny=False):
    """Load pinned weights on CUDA, or random tiny official architecture on CPU.

    Tiny mode keeps the full native vocabulary and only reduces hidden/layer
    dimensions. It never downloads pretrained model weights and proves runtime
    compatibility only. LoRA adapters record and validate their base revision.
    """
    import torch
    from transformers import AutoConfig, AutoModel
    from peft import LoraConfig, PeftConfig, PeftModel, get_peft_model
    profile = get_profile(profile_key)
    if type(rank) is not int or rank < 1:
        raise ValueError("LoRA rank must be a positive integer")
    requested_device = torch.device(device)
    if tiny and requested_device.type != "cpu":
        raise ValueError("Tiny validation is CPU-only; pass device='cpu'")
    if not tiny:
        if requested_device.type != "cuda" or not torch.cuda.is_available():
            raise RuntimeError("7B training/evaluation requires CUDA; use tiny=True on CPU for smoke tests")
        if not torch.cuda.is_bf16_supported():
            raise RuntimeError("The 7B recipe requires a bf16-capable CUDA GPU")
    common = dict(revision=profile["revision"], code_revision=profile["revision"], trust_remote_code=True)
    if tiny:
        config = AutoConfig.from_pretrained(profile["model_id"], **common)
        validate_model_contract(config, profile_key)
        for key, value in {
            "hidden_size": 32, "intermediate_size": 64, "num_hidden_layers": 2,
            "num_attention_heads": 4, "num_key_value_heads": 2,
            "max_position_embeddings": 4096, "max_window_layers": 2,
            "attention_dropout": 0.0, "use_cache": False,
        }.items():
            setattr(config, key, value)
        config._attn_implementation = "sdpa"
        model = AutoModel.from_config(
            config, trust_remote_code=True, code_revision=profile["revision"],
        )
    else:
        model = AutoModel.from_pretrained(
            profile["model_id"], **common, torch_dtype=torch.bfloat16,
            attn_implementation="sdpa", low_cpu_mem_usage=True,
        )
        validate_model_contract(model.config, profile_key)
    model.config.use_cache = False
    model.to(requested_device)
    if adapter:
        adapter_config = PeftConfig.from_pretrained(adapter)
        if adapter_config.base_model_name_or_path != profile["model_id"]:
            raise ValueError("Adapter base model differs from the chosen native model profile")
        if adapter_config.revision != profile["revision"]:
            raise ValueError("Adapter base revision differs from the chosen native model profile")
        model = PeftModel.from_pretrained(model, adapter, is_trainable=train)
    elif train:
        model = get_peft_model(model, LoraConfig(
            r=rank, lora_alpha=2 * rank, lora_dropout=0.0 if tiny else 0.05,
            target_modules=LORA_MODULES, bias="none", revision=profile["revision"],
        ))
    if train:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        model.enable_input_require_grads()
        model.train()
    else:
        model.eval()
    return model


def selected_logits(model, input_ids, positions):
    """Return raw-vocabulary logits for TARGET positions after native shift.

    A target at p uses decoder hidden state p-1. The first token must therefore
    be an unmasked boundary, and p=0 is rejected. One sequence per microbatch
    avoids padding; all input tokens, including literal EOS, attend mutually.
    Output logits are unfiltered: EOS is a vocabulary prediction, and unused
    vocabulary rows remain measurable errors rather than silently remapped IDs.
    """
    import torch
    ids = list(input_ids)
    targets = list(positions)
    if not ids or not targets:
        raise ValueError("At least one input token and one target position are required")
    if any(type(p) is not int or not 0 < p < len(ids) for p in targets):
        raise ValueError("Target positions must be integers in [1, sequence length)")
    if len(targets) != len(set(targets)):
        raise ValueError("Target positions must not be duplicated")
    base = model.get_base_model() if hasattr(model, "get_base_model") else model
    device = next(base.parameters()).device
    inputs = torch.tensor([ids], dtype=torch.long, device=device)
    length = len(ids)
    if length > base.config.max_position_embeddings:
        raise ValueError("Input exceeds the native model position limit")
    attention = torch.ones((1, 1, length, length), dtype=torch.bool, device=device)
    position_ids = torch.arange(length, device=device).unsqueeze(0)
    hidden = base.model(
        input_ids=inputs, attention_mask=attention, position_ids=position_ids,
        use_cache=False, return_dict=True,
    )[0]
    source_positions = [p - 1 for p in targets]
    return base.lm_head(hidden[0, source_positions, :])


def state_loss(model, row):
    """Mean CE over this row's masked identifier tokens, with native alignment."""
    import torch
    import torch.nn.functional as F
    ids, labels = row["input_ids"], row["labels"]
    if len(ids) != len(labels):
        raise ValueError("Input IDs and dense labels must have the same length")
    targets = [p for p, label in enumerate(labels) if label != -100]
    if not targets:
        raise ValueError("A training row must supervise at least one masked token")
    base = model.get_base_model() if hasattr(model, "get_base_model") else model
    mask = base.config.mask_token_id
    if any(ids[p] != mask for p in targets):
        raise ValueError("Only masked identifier positions can contribute to the loss")
    if {p for p, token in enumerate(ids) if token == mask} != set(targets):
        raise ValueError("Every remaining mask must belong to the supervised identifier")
    logits = selected_logits(model, ids, targets)
    ground_truth = torch.tensor([labels[p] for p in targets], dtype=torch.long, device=logits.device)
    loss = F.cross_entropy(logits.float(), ground_truth, reduction="mean")
    correct = (logits.argmax(-1) == ground_truth).sum().item()
    return loss, correct, len(targets)
