"""Known-length, all-occurrence identifier recovery with native code diffusion."""
