"""Paired native base/adapter evaluation of an unchanged, known-length canvas.

The main endpoint is one forward pass. Optional confidence unmasking with more
passes is a separate ablation, never a replacement for the one-pass result.
"""
import argparse
import gc
import json
import math
from pathlib import Path
import random

from .common import file_hash, read_jsonl, source_hashes, validate_checkpoint, write_json
from .profiles import get_profile
from .runtime import load_model, load_tokenizer, selected_logits


JAVA_RESERVED = frozenset("""abstract assert boolean break byte case catch char class
const continue default do double else enum extends final finally float for goto
if implements import instanceof int interface long native new package private
protected public return short static strictfp super switch synchronized this
throw throws transient try void volatile while true false null _""".split())


def predict(model, input_ids, mask_token_id, *, steps=1, logits_fn=selected_logits):
    """Inference consumes the masked canvas only; neither labels nor gold text.

    No token filtering, voting across sites, EOS truncation or length actions.
    Unused vocabulary rows and special-token predictions count as invalid below.
    Track unresolved positions separately so a predicted MASK is a scored error,
    rather than causing an infinite loop or receiving extra decoding attempts.
    """
    import torch
    if type(steps) is not int or steps < 1:
        raise ValueError("steps must be a positive integer")
    canvas = list(input_ids)
    remaining = [p for p, token in enumerate(canvas) if token == mask_token_id]
    if not remaining or 0 in remaining:
        raise ValueError("Expected identifier masks after an unmasked BOS")
    forwards = 0
    with torch.no_grad():
        for index in range(steps):
            logits = logits_fn(model, canvas, remaining).float()
            # Confidence is max softmax over the full native vocabulary.
            log_probs = logits.log_softmax(-1)
            confidence, proposed = log_probs.max(-1)
            count = math.ceil(len(remaining) / (steps - index))
            chosen = sorted(range(len(remaining)), key=lambda i: (-confidence[i].item(), remaining[i]))[:count]
            for i in chosen:
                canvas[remaining[i]] = int(proposed[i].item())
            chosen = set(chosen)
            remaining = [p for i, p in enumerate(remaining) if i not in chosen]
            forwards += 1
            if not remaining:
                break
    return canvas, forwards


def valid_java_identifier(text):
    # Parsing a declaration handles Unicode identifiers and Java keywords with
    # the same pinned grammar used by the dataset, rather than an ASCII regex.
    from tree_sitter import Language, Parser
    import tree_sitter_java
    if not text or text in JAVA_RESERVED or any(char.isspace() for char in text):
        return False
    parser = Parser(Language(tree_sitter_java.language()))
    source = ("class Probe { int " + text + "; }").encode("utf-8")
    tree = parser.parse(source)
    if tree.root_node.has_error:
        return False
    def walk(node):
        yield node
        for child in node.children:
            yield from walk(child)
    matches = [node for node in walk(tree.root_node) if node.type == "variable_declarator"]
    if len(matches) != 1:
        return False
    name = matches[0].child_by_field_name("name")
    return name is not None and source[name.start_byte:name.end_byte].decode("utf-8") == text


def score_prediction(row, predicted, tokenizer):
    gold, inputs = row["gold_input_ids"], row["input_ids"]
    if len(predicted) != len(inputs):
        raise ValueError("Fixed-canvas decoder changed sequence length")
    positions = {p for a, b in row["target_token_spans"] for p in range(a, b)}
    if any(predicted[p] != token for p, token in enumerate(inputs) if p not in positions):
        raise ValueError("Decoder modified observed context")
    special = set(tokenizer.all_special_ids)
    occurrences = []
    for start, end in row["target_token_spans"]:
        ids = predicted[start:end]
        usable = all(0 <= token < len(tokenizer) and token not in special for token in ids)
        text = tokenizer.decode(ids, clean_up_tokenization_spaces=False) if usable else None
        occurrences.append({
            "token_ids": ids, "text": text,
            "exact": usable and text == row["target"],
            "valid_identifier": usable and valid_java_identifier(text),
            "usable_tokens": usable,
        })
    return {
        "id": row["id"], "repository": row["repository"],
        "provided_mask_length": row["provided_mask_length"],
        "correct_tokens": sum(predicted[p] == gold[p] for p in positions),
        "tokens": len(positions), "occurrences": len(occurrences),
        "exact_occurrences": sum(o["exact"] for o in occurrences),
        "all_occurrences_exact": all(o["exact"] for o in occurrences),
        "all_occurrences_valid": all(o["valid_identifier"] for o in occurrences),
        "consistent": all(o["usable_tokens"] for o in occurrences) and len({o["text"] for o in occurrences}) == 1,
        "predictions": occurrences,
    }


def summarize(rows):
    if not rows:
        raise ValueError("Cannot evaluate an empty selection")
    tokens, occurrences = sum(r["tokens"] for r in rows), sum(r["occurrences"] for r in rows)
    return {
        "examples": len(rows), "tokens": tokens, "occurrences": occurrences,
        "token_accuracy": sum(r["correct_tokens"] for r in rows) / tokens,
        "occurrence_exact_match": sum(r["exact_occurrences"] for r in rows) / occurrences,
        "all_occurrences_identifier_exact_match": sum(r["all_occurrences_exact"] for r in rows) / len(rows),
        "all_occurrences_valid_identifier_rate": sum(r["all_occurrences_valid"] for r in rows) / len(rows),
        "occurrence_consistency": sum(r["consistent"] for r in rows) / len(rows),
    }


def evaluate_model(model, records, tokenizer, *, steps=1):
    was_training = model.training
    model.eval()
    try:
        results = []
        for row in records:
            predicted, forwards = predict(model, row["input_ids"], tokenizer.mask_token_id, steps=steps)
            result = score_prediction(row, predicted, tokenizer)
            result["forward_passes"] = forwards
            results.append(result)
        return {"summary": summarize(results), "rows": results}
    finally:
        model.train(was_training)


def paired_comparison(base_rows, adapter_rows, *, seed=42, replicates=2000):
    """Row-weighted EM difference, bootstrap resampling whole repositories."""
    if [r["id"] for r in base_rows] != [r["id"] for r in adapter_rows]:
        raise ValueError("Paired evaluation requires identical example IDs and order")
    groups = {}
    for before, after in zip(base_rows, adapter_rows):
        if before["repository"] != after["repository"]:
            raise ValueError("Paired repositories differ")
        groups.setdefault(before["repository"], []).append(int(after["all_occurrences_exact"]) - int(before["all_occurrences_exact"]))
    sufficient = [(sum(values), len(values)) for values in groups.values()]
    rng = random.Random(seed)
    draws = []
    for _ in range(replicates):
        selected = [rng.choice(sufficient) for _ in sufficient]
        draws.append(sum(s for s, n in selected) / sum(n for s, n in selected))
    draws.sort()
    return {
        "metric": "all_occurrences_identifier_exact_match", "examples": len(base_rows),
        "repositories": len(groups), "adapter_minus_base": sum(s for s, n in sufficient) / len(base_rows),
        "repository_bootstrap_95_percentile_interval": [draws[int(.025 * (replicates - 1))], draws[int(.975 * (replicates - 1))]],
        "bootstrap_replicates": replicates, "seed": seed,
    }


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data-dir", required=True)
    p.add_argument("--run-dir", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--split", choices=["validation"], default="validation")
    p.add_argument("--limit", type=int)
    p.add_argument("--steps", type=int, nargs="+", default=[1])
    p.add_argument("--checkpoint", help="Defaults to checkpoint in completed.json")
    args = p.parse_args(argv)
    from .data import validate_fixed_dataset
    audit = validate_fixed_dataset(args.data_dir)
    run_dir, data = Path(args.run_dir), Path(args.data_dir)
    run = json.loads((run_dir / "run.json").read_text())
    contract = run["contract"]
    if audit["manifest"]["profile"]["key"] != contract["profile"]["key"]:
        raise ValueError("Dataset model profile differs from training")
    for name, sha in contract["data_hashes"].items():
        if file_hash(data / name) != sha:
            raise ValueError("Evaluation data differs from training contract")
    checkpoint = Path(args.checkpoint) if args.checkpoint else run_dir / json.loads((run_dir / "completed.json").read_text())["checkpoint"]
    if checkpoint.resolve().parent != run_dir.resolve():
        raise ValueError("Checkpoint must belong to the supplied run")
    checkpoint_meta = validate_checkpoint(checkpoint, contract)
    if contract["source_sha256"] != source_hashes():
        raise ValueError("Evaluation source differs from training snapshot; use the pinned source snapshot")
    if args.limit is not None and args.limit < 1:
        raise ValueError("--limit must be positive")
    if 1 not in args.steps or any(s < 1 for s in args.steps):
        raise ValueError("Always include the primary one-forward evaluation (--steps 1)")
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True)
    records = read_jsonl(data / (args.split + ".jsonl"))
    records = sorted(records, key=lambda r: r["id"])[:args.limit]
    key, tiny = contract["profile"]["key"], contract["tiny"]
    tokenizer = load_tokenizer(key)
    import torch
    if tiny:
        torch.set_num_threads(2)
    variants = {}
    for variant, adapter in (("base", None), ("adapter", str(checkpoint))):
        torch.manual_seed(contract["seed"])
        model = load_model(key, adapter=adapter, device="cpu" if tiny else "cuda", tiny=tiny)
        variants[variant] = {}
        for steps in sorted(set(args.steps)):
            result = evaluate_model(model, records, tokenizer, steps=steps)
            variants[variant][str(steps)] = result
            with (output / f"{variant}-{steps}-pass.jsonl").open("w") as stream:
                for row in result["rows"]:
                    stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        del model
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    report = {
        "profile": get_profile(key), "tiny_random_model_smoke_only": tiny,
        "condition": "gold subtoken length given; all occurrences masked; observed code frozen",
        "selection_ids": [r["id"] for r in records], "checkpoint": str(checkpoint),
        "checkpoint_adapter_sha256": file_hash(checkpoint / "adapter_model.safetensors"),
        "checkpoint_metadata": checkpoint_meta,
        "data_hashes": contract["data_hashes"],
        "variants": {v: {s: result["summary"] for s, result in results.items()} for v, results in variants.items()},
        "paired": {s: paired_comparison(variants["base"][s]["rows"], variants["adapter"][s]["rows"]) for s in variants["base"]},
    }
    write_json(output / "report.json", report)
    print(json.dumps({"report": str(output / "report.json"), "tiny": tiny, "examples": len(records)}))


if __name__ == "__main__":
    main()
