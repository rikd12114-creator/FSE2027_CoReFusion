"""Audited native fixed-canvas models; keys are explicit experiment choices."""
from copy import deepcopy


_TOKENS = {
    "mask_token": "<|mask|>",
    "bos_token_id": 151665,
    "eos_token_id": 151643,
    "pad_token_id": 151643,
    "mask_token_id": 151666,
    "vocab_size": 152064,
    "tokenizer_size": 151667,
    "shift": 1,
}

PROFILES = {
    "dreamcoder": {
        **_TOKENS,
        "key": "dreamcoder",
        "model_id": "Dream-org/Dream-Coder-v0-Base-7B",
        "revision": "2346ccd3be517d0d314152b988a3b9bafa7d6d63",
        "max_position_embeddings": 32768,
    },
    "diffucoder": {
        **_TOKENS,
        "key": "diffucoder",
        "model_id": "apple/DiffuCoder-7B-Base",
        "revision": "a2c33054cbe99b9ab7af074f09b1d13943157ff1",
        "max_position_embeddings": 131072,
    },
}

LORA_MODULES = [
    "q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj",
]


def get_profile(name):
    """Return an independent profile, rejecting ambiguous or arbitrary models."""
    if name not in PROFILES:
        raise ValueError(f"Unknown model profile {name!r}; choose {', '.join(PROFILES)}")
    return deepcopy(PROFILES[name])
