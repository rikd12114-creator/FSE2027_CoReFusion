"""Small persistence helpers shared by training and evaluation."""
import hashlib
import json
import os
from pathlib import Path


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_jsonl(path):
    with Path(path).open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def source_hashes():
    return {p.name: file_hash(p) for p in sorted(Path(__file__).parent.glob("*.py"))}


def contract_hash(contract):
    return hashlib.sha256(json.dumps(contract, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def validate_checkpoint(path, contract):
    """Bind a locally generated adapter and state to one exact training run."""
    path = Path(path)
    meta = json.loads((path / "checkpoint.json").read_text())
    if meta.get("contract_sha256") != contract_hash(contract):
        raise ValueError("Checkpoint contract differs from this run")
    step = meta.get("step")
    if type(step) is not int or not 1 <= step <= contract["config"]["steps"]:
        raise ValueError("Checkpoint step is outside the training budget")
    expected = step * contract["config"]["gradient_accumulation"]
    if type(meta.get("examples_seen")) is not int or meta["examples_seen"] != expected:
        raise ValueError("Checkpoint sample count differs from optimizer progress")
    if meta.get("objective_counts") != {"fixed_length_all_occurrences": expected}:
        raise ValueError("Checkpoint objective count mismatch")
    if path.name != f"checkpoint-{step:06d}":
        raise ValueError("Checkpoint directory does not match its step")
    for filename, key in (("adapter_model.safetensors", "adapter_sha256"),
                          ("adapter_config.json", "adapter_config_sha256"),
                          ("training_state.pt", "state_sha256")):
        if file_hash(path / filename) != meta.get(key):
            raise ValueError(f"Checkpoint hash mismatch: {filename}")
    return meta
