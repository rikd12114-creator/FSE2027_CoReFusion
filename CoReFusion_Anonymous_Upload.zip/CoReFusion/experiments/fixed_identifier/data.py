"""Retokenize audited Java identifier examples for a fixed-length final recovery.

The exact target subtoken count is supplied independently at every occurrence.
Every occurrence is entirely masked; context is unchanged and never truncated.
This is a controlled synthetic terminal state, not a sampled diffusion trace.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import tempfile

from experiments.stack_v2_java.publish import (
    ValidationError, sha256_file, validate_dataset as validate_source_dataset,
    validate_row,
)
from experiments.stack_v2_java.tokenization import encode_sample


OBJECTIVE = "fixed_length_all_occurrences"
SPLITS = ("train", "validation")
HASHED_FILES = frozenset({"README.md", "train.jsonl", "validation.jsonl", "excluded.jsonl"})
ALLOWED_FILES = HASHED_FILES | {"manifest.json"}
ENCODED_FIELDS = (
    "code_masked", "code_masked_template", "input_ids", "labels", "gold_input_ids",
    "target_token_ids", "target_token_spans", "num_occurrences", "num_mask_tokens", "corruption",
)
DEFAULT_SOURCE = Path(__file__).resolve().parents[2] / "data/stack_v2_java_pilot/dataset"


def _require(condition, message):
    if not condition:
        raise ValidationError(message)


def _sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _ids_digest(ids):
    return _sha256_text("".join(value + "\n" for value in sorted(ids)))


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def read_jsonl(path):
    """Yield JSON objects, rejecting empty lines and malformed records."""
    with Path(path).open(encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            try:
                row = json.loads(line)
                _require(isinstance(row, dict), "row must be a JSON object")
            except (ValueError, TypeError) as exc:
                raise ValidationError(f"{Path(path).name}:{number}: {exc}") from exc
            yield row


def _get_profile(key):
    from experiments.fixed_identifier.profiles import get_profile
    return get_profile(key)


def _tokenizer_metadata(profile_key, profile, tokenizer):
    metadata = {
        "profile": profile_key, "model_id": profile["model_id"], "revision": profile["revision"],
        "mask_token": tokenizer.mask_token, "mask_token_id": tokenizer.mask_token_id,
        "bos_token_id": tokenizer.bos_token_id, "eos_token_id": tokenizer.eos_token_id,
        "tokenizer_size": len(tokenizer), "vocab_size": profile["vocab_size"],
    }
    _require(metadata["tokenizer_size"] == profile["tokenizer_size"], "tokenizer size does not match pinned profile")
    for name in ("mask_token_id", "bos_token_id", "eos_token_id"):
        _require(type(metadata[name]) is int and 0 <= metadata[name] < metadata["tokenizer_size"],
                 f"invalid tokenizer {name}")
        _require(metadata[name] == profile[name], f"tokenizer {name} does not match pinned profile")
    _require(metadata["mask_token"] == profile["mask_token"],
             "tokenizer mask_token does not match pinned profile")
    _require(tokenizer.encode(tokenizer.mask_token, add_special_tokens=False) == [tokenizer.mask_token_id],
             "mask token does not encode to exactly one native mask id")
    return metadata


def _validate_fixed_row(row, split, profile_key, metadata, max_length, tokenizer=None):
    repository = validate_row(row, metadata["mask_token"], metadata["mask_token_id"],
                              bos_token_id=metadata["bos_token_id"], eos_token_id=metadata["eos_token_id"])
    _require(row.get("objective") == OBJECTIVE, "wrong fixed-length objective")
    _require(row.get("profile") == profile_key, "row profile mismatch")
    _require(row.get("source_sample_id") == row["id"], "source sample id changed")
    _require(row.get("source_split") == split, "source split changed")
    _require(type(row.get("provided_mask_length")) is int
             and row["provided_mask_length"] == len(row["target_token_ids"]), "provided mask length mismatch")
    _require(1 <= row["provided_mask_length"] <= 16, "target exceeds subtoken budget")
    size = len(row["input_ids"])
    _require(type(row.get("sequence_length")) is int and row["sequence_length"] == size,
             "sequence_length mismatch")
    _require(size <= max_length, "sequence exceeds declared token budget")
    _require(row.get("code_token_bounds") == [1, size - 1], "code_token_bounds must exclude only BOS and EOS")
    _require(row.get("source_code_sha256") == _sha256_text(row["code"]), "source code hash mismatch")
    _require(isinstance(row.get("source_row_sha256"), str)
             and re.fullmatch(r"[0-9a-f]{64}", row["source_row_sha256"]), "missing source row hash")
    for name in ("input_ids", "gold_input_ids", "target_token_ids"):
        _require(all(0 <= value < metadata["tokenizer_size"] for value in row[name]), f"{name} exceeds tokenizer vocabulary")
    special_ids = {metadata[name] for name in ("mask_token_id", "bos_token_id", "eos_token_id")}
    _require(not special_ids.intersection(row["target_token_ids"]), "target contains special action token")
    _require(not special_ids.intersection(row["gold_input_ids"][1:-1]), "code contains a special action token")
    for start, end in row["target_token_spans"]:
        _require(1 <= start < end <= size - 1, "target token span escapes code bounds")
    if "occurrence_count" in row:
        _require(type(row["occurrence_count"]) is int and row["occurrence_count"] == row["num_occurrences"],
                 "original occurrence_count mismatch")
    if "target_declaration_span" in row:
        _require(row["target_declaration_span"] in row["target_spans"], "target declaration is not masked")
    if "snippet_start" in row or "snippet_end" in row:
        a, b = row.get("snippet_start"), row.get("snippet_end")
        _require(type(a) is int and type(b) is int and a >= 0 and b - a == len(row["code"]),
                 "source snippet bounds do not cover exact original code")
        _require(row.get("span_unit") == "unicode_codepoints", "unknown character span unit")
        _require(row.get("file_target_spans") == [[a + x, a + y] for x, y in row["target_spans"]],
                 "file target spans differ from original snippet bounds")
    if tokenizer is not None:
        expected = encode_sample(row, tokenizer, max_length=max_length)
        _require(all(row.get(name) == expected[name] for name in ENCODED_FIELDS),
                 "recorded ids/spans differ from native tokenizer encoding")
    return repository


def validate_fixed_dataset(dataset_dir, *, tokenizer=None):
    """Audit profile, inventory, hashes, loss scope, code bounds, and split hygiene.

    Pass the pinned tokenizer to additionally re-encode every source snippet and
    compare every recorded token. Without it, validation is explicitly structural.
    """
    root = Path(dataset_dir)
    _require(root.is_dir() and not root.is_symlink(), "dataset directory missing or symlink")
    entries = list(root.iterdir())
    _require({p.name for p in entries} == ALLOWED_FILES, "unexpected fixed dataset file inventory")
    _require(all(p.is_file() and not p.is_symlink() for p in entries), "dataset files must be regular files")
    try:
        manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    except (ValueError, UnicodeError) as exc:
        raise ValidationError("invalid manifest JSON") from exc
    _require(isinstance(manifest, dict) and type(manifest.get("schema_version")) is int and manifest["schema_version"] == 1
             and manifest.get("dataset_type") == "fixed_identifier", "unsupported fixed dataset schema")
    _require(manifest.get("objective") == OBJECTIVE, "wrong dataset objective")
    profile_key = manifest.get("profile_key")
    profile = _get_profile(profile_key)
    _require(manifest.get("profile") == profile, "manifest does not match pinned model profile")
    metadata = manifest.get("tokenizer", {})
    for name in ("mask_token", "mask_token_id", "bos_token_id", "eos_token_id", "model_id", "revision", "tokenizer_size", "vocab_size"):
        _require(metadata.get(name) == profile[name], f"manifest tokenizer {name} differs from pinned profile")
    _require(metadata.get("profile") == profile_key and type(metadata.get("tokenizer_size")) is int
             and metadata["tokenizer_size"] > max(profile[name] for name in ("mask_token_id", "bos_token_id", "eos_token_id")),
             "invalid tokenizer vocabulary/profile metadata")
    if tokenizer is not None:
        _require(metadata == _tokenizer_metadata(profile_key, profile, tokenizer), "loaded tokenizer metadata mismatch")
    config = manifest.get("configuration", {})
    max_length = config.get("max_length")
    _require(type(max_length) is int and max_length >= 3, "invalid token budget")
    _require(config.get("length_oracle") is True and config.get("truncation") is False
             and config.get("max_target_tokens") == 16
             and config.get("code_boundaries") == "BOS + complete original snippet + EOS"
             and config.get("tokenization") == "encode unchanged segments and target separately; no added specials",
             "invalid fixed-length construction contract")
    files = manifest.get("files")
    _require(isinstance(files, dict) and set(files) == HASHED_FILES, "invalid file hash inventory")
    for name in HASHED_FILES:
        _require(isinstance(files[name], dict) and files[name].get("sha256") == sha256_file(root / name),
                 f"SHA-256 mismatch for {name}")
    _require(bool((root / "README.md").read_text(encoding="utf-8").strip()), "empty dataset card")
    source = manifest.get("source", {})
    input_hashes = source.get("input_files", {})
    _require(set(input_hashes) == {"manifest.json", "README.md", "train.jsonl", "validation.jsonl"}
             and all(isinstance(h, str) and re.fullmatch(r"[0-9a-f]{64}", h) for h in input_hashes.values()),
             "invalid source input hashes")
    seen_ids, repositories, fingerprints = set(), {}, {}
    split_ids, counts, accepted_repos = {}, {}, {}
    for split in SPLITS:
        split_ids[split], accepted_repos[split] = [], set()
        for number, row in enumerate(read_jsonl(root / f"{split}.jsonl"), 1):
            try:
                repository = _validate_fixed_row(row, split, profile_key, metadata, max_length, tokenizer)
                _require(row["id"] not in seen_ids, "duplicate sample id")
                seen_ids.add(row["id"])
                _require(repositories.get(repository, split) == split, "repository appears in both splits")
                repositories[repository] = split
                accepted_repos[split].add(repository)
                fingerprint = _sha256_text(row["code"])
                _require(fingerprints.get(fingerprint, split) == split, "identical code appears in both splits")
                fingerprints[fingerprint] = split
                split_ids[split].append(row["id"])
            except (ValueError, TypeError, KeyError) as exc:
                raise ValidationError(f"{split}.jsonl:{number}: {exc}") from exc
        counts[split] = len(split_ids[split])
        declared = files[f"{split}.jsonl"]
        _require(declared.get("rows") == counts[split], f"{split} row count mismatch")
        _require(declared.get("repositories") == sorted(accepted_repos[split]), f"{split} repository inventory mismatch")
        _require(declared.get("sample_ids_sha256") == _ids_digest(split_ids[split]), f"{split} sample id hash mismatch")
    exclusions, excluded_counts, reasons = [], Counter(), Counter()
    for row in read_jsonl(root / "excluded.jsonl"):
        _require(isinstance(row.get("id"), str) and row["id"] and row["id"] not in seen_ids, "duplicate/missing excluded sample id")
        seen_ids.add(row["id"])
        split = row.get("source_split")
        _require(split in SPLITS and isinstance(row.get("reason"), str) and row["reason"], "invalid exclusion split/reason")
        _require(isinstance(row.get("repository"), str) and row["repository"], "missing excluded repository")
        _require(isinstance(row.get("source_row_sha256"), str)
                 and re.fullmatch(r"[0-9a-f]{64}", row["source_row_sha256"]), "missing excluded source row hash")
        _require(repositories.get(row["repository"], split) == split, "excluded repository crosses split")
        repositories[row["repository"]] = split
        split_ids[split].append(row["id"])
        excluded_counts[split] += 1
        reasons[row["reason"]] += 1
        exclusions.append(row)
    _require(files["excluded.jsonl"].get("rows") == len(exclusions), "excluded row count mismatch")
    for split in SPLITS:
        declared = source.get("splits", {}).get(split, {})
        _require(declared.get("rows") == len(split_ids[split]), f"source {split} sample accounting mismatch")
        _require(declared.get("sample_ids_sha256") == _ids_digest(split_ids[split]), f"source {split} membership changed")
        _require(declared.get("repositories") == sorted(r for r, s in repositories.items() if s == split),
                 f"source {split} repository membership changed")
    _require(manifest.get("counts") == {
        "source_rows": sum(len(v) for v in split_ids.values()), "accepted_rows": sum(counts.values()),
        "excluded_rows": len(exclusions), "excluded_by_reason": dict(sorted(reasons.items())),
    }, "dataset counts mismatch")
    _require(counts["train"] > 0, "training split is empty")
    return {"validated": True, "rows": counts, "excluded_rows": len(exclusions),
            "tokenization_verified": tokenizer is not None, "manifest": manifest}


def _readme(profile_key, profile, counts):
    return f"""---
language: [java]
task_categories: [fill-mask]
tags: [code, diffusion, identifier-recovery, fixed-length]
configs:
- config_name: default
  data_files:
  - split: train
    path: train.jsonl
  - split: validation
    path: validation.jsonl
---
# Java identifier recovery: {profile_key}, provided length

Native checkpoint: `{profile['model_id']}` at `{profile['revision']}`.
There are {counts['train']} training and {counts['validation']} validation rows.
These are retokenized examples from the audited Stack v2 Java pilot. Repository
splits, source identifiers, original Java snippets, licenses and provenance are
preserved. Excluded records and reasons are inventoried in `excluded.jsonl`.

One selected identifier has **all lexical occurrences fully masked**. Each site
receives exactly the native tokenizer's ground-truth subtoken count. This is a
synthetic final recovery task with an oracle length, not variable-length editing
or an observed final state from a real diffusion rollout. No expand/delete labels
are created. The source extractor is spelling-based, not compiler-resolved.
Comments and string literals are unchanged, so they can contain the target name.
Existing benchmark screening is inherited; general near-duplicate detection is
not claimed. Source license metadata is retained without assigning a new license.

## Record schema

`id` and `source_sample_id` are the unchanged pilot sample id. `source_split` is
the original split; `repository` and the complete `source` dictionary preserve
attribution. `code` is the full, untruncated original method or constructor.
`source_code_sha256` binds its UTF-8 bytes; `source_row_sha256` identifies the
canonical original row. `target` is the original identifier. `target_spans` are
half-open Unicode code-point offsets for every lexical occurrence. Optional
`snippet_start`, `snippet_end`, and `file_target_spans` retain original file bounds.

`input_ids`, `gold_input_ids`, and `labels` are equal-length integer arrays from
the pinned native tokenizer. BOS and EOS enclose the complete code;
`code_token_bounds` is `[1, sequence_length - 1]`. Unchanged segments and target
identifiers are encoded separately without implicit special tokens. `target_token_ids`
is the gold identifier sequence; `target_token_spans` locates it at every site.
`provided_mask_length` is its length per site. `num_mask_tokens` is this length
times `num_occurrences`. Inputs contain masks only at those spans. Labels contain
gold tokens at those positions and `-100` everywhere else. `code_masked` uses the
native mask text and `code_masked_template` uses one `[MASK]` placeholder per site.
`objective` is `{OBJECTIVE}`; `profile` is `{profile_key}`.

Loss must apply the checkpoint's declared logit alignment from `manifest.json`.
Preserve sequence length during one-pass recovery; evaluate every occurrence and
cross-occurrence consistency. Native tokenizers can differ, so compare models on
the intersection of retained source sample ids. No training weights or raw
source-cache files are included in this dataset directory.
"""


def build_dataset(source_dir, output_dir, profile_key="dreamcoder", tokenizer=None, max_length=1024):
    """Build, validate in a sibling stage, then atomically publish a new directory."""
    source_dir, output_dir = Path(source_dir), Path(output_dir)
    _require(type(max_length) is int and max_length >= 3, "max_length must be at least 3")
    _require(not output_dir.exists() and not output_dir.is_symlink(), "output directory already exists; refusing overwrite")
    source_audit = validate_source_dataset(source_dir)
    profile = _get_profile(profile_key)
    if tokenizer is None:
        from experiments.fixed_identifier.runtime import load_tokenizer
        tokenizer = load_tokenizer(profile_key)
    metadata = _tokenizer_metadata(profile_key, profile, tokenizer)
    source_hashes = {p.name: sha256_file(p) for p in source_dir.iterdir()}
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=f".{output_dir.name}.stage-", dir=output_dir.parent) as temporary:
        stage = Path(temporary) / "dataset"
        stage.mkdir()
        source_splits, files, counts, reasons = {}, {}, {}, Counter()
        excluded_total = 0
        with (stage / "excluded.jsonl").open("w", encoding="utf-8") as excluded:
            for split in SPLITS:
                ids, accepted_ids, repositories, accepted_repositories = [], [], set(), set()
                with (stage / f"{split}.jsonl").open("w", encoding="utf-8") as destination:
                    for original in read_jsonl(source_dir / f"{split}.jsonl"):
                        ids.append(original["id"])
                        repositories.add(original["repository"])
                        row_hash = _sha256_text(_json(original))
                        try:
                            # Only textual code and character spans enter encoding.
                            # No DreamOn input ids, labels, or token spans are reused.
                            encoded = encode_sample(original, tokenizer, max_length=max_length)
                        except ValueError as exc:
                            reason = str(exc)
                            reasons[reason] += 1
                            excluded_total += 1
                            excluded.write(_json({"id": original["id"], "source_split": split,
                                                  "repository": original["repository"], "reason": reason,
                                                  "source_row_sha256": row_hash}) + "\n")
                            continue
                        row = {**original, **encoded, "objective": OBJECTIVE, "profile": profile_key,
                               "source_sample_id": original["id"], "source_split": split,
                               "source_row_sha256": row_hash, "source_code_sha256": _sha256_text(original["code"]),
                               "provided_mask_length": len(encoded["target_token_ids"]),
                               "sequence_length": len(encoded["input_ids"]),
                               "code_token_bounds": [1, len(encoded["input_ids"]) - 1]}
                        _validate_fixed_row(row, split, profile_key, metadata, max_length)
                        destination.write(_json(row) + "\n")
                        accepted_ids.append(row["id"])
                        accepted_repositories.add(row["repository"])
                counts[split] = len(accepted_ids)
                source_splits[split] = {"rows": len(ids), "sample_ids_sha256": _ids_digest(ids),
                                        "repositories": sorted(repositories)}
                files[f"{split}.jsonl"] = {"rows": len(accepted_ids), "sample_ids_sha256": _ids_digest(accepted_ids),
                                           "repositories": sorted(accepted_repositories)}
        _require(sum(counts.values()) > 0, "no examples survive native tokenization")
        (stage / "README.md").write_text(_readme(profile_key, profile, counts), encoding="utf-8")
        files.update({"README.md": {}, "excluded.jsonl": {"rows": excluded_total}})
        for name in HASHED_FILES:
            files[name]["sha256"] = sha256_file(stage / name)
        _require(source_hashes == {p.name: sha256_file(p) for p in source_dir.iterdir()},
                 "source files changed during construction")
        manifest = {
            "schema_version": 1, "dataset_type": "fixed_identifier", "objective": OBJECTIVE,
            "profile_key": profile_key, "profile": profile, "tokenizer": metadata,
            "configuration": {"max_length": max_length, "max_target_tokens": 16, "length_oracle": True,
                              "truncation": False, "code_boundaries": "BOS + complete original snippet + EOS",
                              "tokenization": "encode unchanged segments and target separately; no added specials"},
            "source": {"dataset_dir": str(source_dir.resolve()), "input_files": source_hashes,
                       "splits": source_splits,
                       "contains_synthetic_test_fixture": source_audit["contains_synthetic_test_fixture"],
                       "screening": source_audit["manifest"].get("screening", {})},
            "files": files,
            "counts": {"source_rows": sum(s["rows"] for s in source_splits.values()),
                       "accepted_rows": sum(counts.values()), "excluded_rows": excluded_total,
                       "excluded_by_reason": dict(sorted(reasons.items()))},
        }
        (stage / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        result = validate_fixed_dataset(stage, tokenizer=tokenizer)
        _require(not output_dir.exists() and not output_dir.is_symlink(), "output appeared during build; refusing overwrite")
        stage.rename(output_dir)
    return {**result, "output_dir": str(output_dir.resolve())}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--profile", choices=("dreamcoder", "diffucoder"), default="dreamcoder")
    parser.add_argument("--max-length", type=int, default=1024)
    args = parser.parse_args(argv)
    result = build_dataset(args.source_dir, args.output_dir, args.profile, max_length=args.max_length)
    print(json.dumps({k: v for k, v in result.items() if k != "manifest"}, indent=2))


if __name__ == "__main__":
    main()
