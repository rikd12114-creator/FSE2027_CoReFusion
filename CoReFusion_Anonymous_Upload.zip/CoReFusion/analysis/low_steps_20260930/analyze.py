#!/usr/bin/env python3
"""Independent score, DEV selection and held-out paired analysis.

References are read only here, after generation. A score requires the complete
frozen Cartesian attempt set; submitted jobs or partial journals never pass.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from experiments.paper_revision_20260917.metrics import subtoken_scores  # noqa: E402
from experiments.rq1_empirical.policy import valid_identifier  # noqa: E402
from experiments.rq1_empirical.schema import CONTEXT_CHARS, MARKER  # noqa: E402

PROTOCOL = "corefusion-low-steps-20260930-v1"
PROTOCOL_SHA = "7c717f63e0bfdb83e8f8e65319d5add396b7c75a25e2e504926ce5518895862c"
FROZEN_RUNNER_SHA = "106769d6dd3838fedf5b2c58276788106795a2c13ce13b1bfbd1c7423093cb3e"
FROZEN_SHARED_SHA = "bed0b153d701b138a923ac6b096322cbb0feeae5ce701c75d4601153b21a3286"
VERSION = "corefusion-low-steps-analysis-v1"
GRID = (1, 2, 4, 8, 16, 32, 64)
FIXED = ("dreamcoder-7b", "diffucoder-7b-base")
AR = ("Qwen2.5-Coder-7B-Instruct", "Qwen3-8B")
MODELS = FIXED + AR
LANGUAGES = ("Java", "Python", "C++")
METRICS = ("all_sites_exact_match", "mean_task_site_subtoken_f1", "complete_valid_consistent")
TERMINAL = {"complete", "failure", "censored", "input_failure", "interrupted"}
BOOTSTRAP_REPLICATES = 20000
BOOTSTRAP_SEED = 20260930


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def pinned_json(path: Path, expected_sha: str) -> dict:
    if sha(path) != expected_sha:
        raise ValueError(f"Pinned JSON hash differs: {path}")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def finite_nonnegative(value: Any) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def visible_code(code: str) -> str:
    if len(code) <= CONTEXT_CHARS:
        return code
    site = code.index(MARKER)
    before = (CONTEXT_CHARS - len(MARKER)) // 2
    start = max(0, min(site - before, len(code) - CONTEXT_CHARS))
    result = code[start:start + CONTEXT_CHARS]
    if MARKER not in result:
        raise ValueError("Frozen source crop lost the first supplied site")
    return result


def uid(language: str, task_key: str) -> str:
    return language + "\x1f" + task_key


def source_rows(files: list[dict], phase: str) -> dict[str, dict]:
    if len(files) != 3 or {f.get("language") for f in files} != set(LANGUAGES):
        raise ValueError("Exactly one source CSV per language required")
    found = {}
    for spec in files:
        path = Path(spec["path"])
        if sha(path) != spec["sha256"]:
            raise ValueError(f"Source CSV changed: {path}")
        with path.open("r", encoding="utf-8", newline="") as stream:
            csv.field_size_limit(sys.maxsize)
            rows = list(csv.reader(stream))
        language = spec["language"]
        for row in rows:
            if len(row) != 3:
                raise ValueError("Source CSV must have exactly id,masked_code,reference columns")
            first, code, reference = row
            key = uid(language, first)
            if key in found or not reference or MARKER not in code:
                raise ValueError("Duplicate/empty source reference or missing site")
            # DEV generation receives the frozen first-site visible crop. The
            # accepted formal TEST plans instead retain each entire original
            # source and all supplied sites, including sources beyond 16k.
            masked_code = visible_code(code) if phase == "E1" else code
            found[key] = {"language": language, "task_key": first, "masked_code": masked_code,
                          "reference_name": reference, "source_csv_sha256": spec["sha256"]}
    return found


def validate_eval_manifest(manifest: dict, phase: str) -> tuple[dict, dict[str, dict], dict[str, dict]]:
    if manifest.get("protocol_id") != PROTOCOL or manifest.get("protocol_sha256") != PROTOCOL_SHA:
        raise ValueError("Evaluation manifest protocol changed")
    if manifest.get("phase") != phase:
        raise ValueError("Evaluation manifest phase mismatch")
    if not isinstance(manifest.get("runner_sha256"), str) or len(manifest["runner_sha256"]) != 64:
        raise ValueError("Exact GPU runner source SHA required")
    sources = source_rows(manifest["source_files"], phase)
    tasks = manifest.get("tasks")
    n_per_language = 100 if phase == "E1" else 1000
    if not isinstance(tasks, list) or len(tasks) != 3 * n_per_language:
        raise ValueError("Frozen source denominator differs")
    by_key = {}
    for row in tasks:
        task_key = row.get("task_key")
        language = row.get("language")
        key = uid(language, task_key) if isinstance(language, str) and isinstance(task_key, str) else None
        if key in by_key or key not in sources or language not in LANGUAGES or sources[key]["language"] != language:
            raise ValueError("Evaluation task/source identity mismatch")
        source = sources[key]
        code = source["masked_code"]
        if (row.get("reference_name") != source["reference_name"]
                or row.get("masked_source_sha256") != hashlib.sha256(code.encode()).hexdigest()
                or row.get("expected_sites") != code.count(MARKER)
                or (row.get("evaluation_source_csv_sha256") is not None
                    and row["evaluation_source_csv_sha256"] != source["source_csv_sha256"])):
            raise ValueError(f"Evaluation reference/source/site identity changed: {key}")
        if not isinstance(row.get("source_csv_sha256"), str) or len(row["source_csv_sha256"]) != 64:
            raise ValueError("Generation input source CSV SHA missing")
        if type(row.get("source_index")) is not int or row["source_index"] < 0:
            raise ValueError("Task source index missing")
        if type(row.get("block_index")) is not int or row["block_index"] < 0:
            raise ValueError("Task block index missing")
        if phase == "E2" and (not isinstance(row.get("cluster_id"), str) or not row["cluster_id"]):
            raise ValueError("Held-out source-only cluster ID missing")
        by_key[key] = row
    if any(sum(t["language"] == lang for t in tasks) != n_per_language for lang in LANGUAGES):
        raise ValueError("Per-language frozen denominator changed")
    by_block = defaultdict(list)
    for row in tasks:
        by_block[(row["language"], row["block_index"])].append(row)
    if (len(by_block) != (6 if phase == "E1" else 60)
            or any(len(rows) != 50 for rows in by_block.values())):
        raise ValueError("Expected exactly 50 frozen tasks per block")
    journals = manifest.get("journals")
    if not isinstance(journals, list) or len(journals) != len(by_block):
        raise ValueError("One authenticated journal per block required")
    indexed = {}
    for spec in journals:
        block = (spec.get("language"), spec.get("block_index"))
        if block in indexed or block not in by_block or not isinstance(spec.get("plan_sha256"), str):
            raise ValueError("Missing/duplicate block journal identity")
        indexed[block] = spec
    if set(indexed) != set(by_block):
        raise ValueError("Journal block roster incomplete")
    if phase == "E2":
        ledger = manifest.get("cluster_ledger_path")
        expected_ledger_sha = manifest.get("cluster_ledger_sha256")
        if (not ledger or not isinstance(expected_ledger_sha, str)
                or sha(Path(ledger)) != expected_ledger_sha):
            raise ValueError("Accepted source-only cluster ledger path/SHA required")
    return sources, by_key, indexed


def repeat_subset(tasks: dict[str, dict]) -> set[str]:
    result = set()
    for language in LANGUAGES:
        keys = [key for key, row in tasks.items() if row["language"] == language]
        ranked = sorted(keys, key=lambda key: (hashlib.sha256(
            f"{PROTOCOL}:{language}:{tasks[key]['task_key']}".encode()).hexdigest(), tasks[key]["task_key"]))
        result.update(ranked[:100])
    if len(result) != 300:
        raise ValueError("Repeat subset is not 100 tasks per language")
    return result


def expected_cells(tasks: dict[str, dict], phase: str, selected: dict | None) -> set[tuple]:
    cells = set()
    repeat = repeat_subset(tasks) if phase == "E2" else set()
    for internal_key, task in tasks.items():
        key = task["task_key"]
        for model in MODELS:
            steps = GRID if phase == "E1" and model in FIXED else (
                (selected[model], 64) if phase == "E2" and model in FIXED else (None,))
            for step in steps:
                seeds = (42, 43, 44) if phase == "E2" and internal_key in repeat else (42,)
                for seed in seeds:
                    cells.add((task["language"], key, model, step, seed))
    expected = 4800 if phase == "E1" else 21600
    if len(cells) != expected:
        raise ValueError("Cartesian attempt count differs from frozen protocol")
    return cells


def decode_sites(record: dict, task: dict, code: str) -> dict:
    status = record.get("status")
    if status not in TERMINAL:
        raise ValueError("Nonterminal scientific attempt")
    expected = task["expected_sites"]
    names = record.get("names")
    complete = (status == "complete" and isinstance(names, list) and len(names) == expected
                and all(isinstance(name, str) and valid_identifier(name, task["language"]) for name in names))
    if status == "complete" and not complete:
        raise ValueError("Runner claimed complete with incomplete/illegal names")
    if complete:
        consistency = len(set(names)) == 1
        if record.get("complete_sites") is not True or record.get("consistent_names") is not consistency:
            raise ValueError("Runner reliability receipt differs from independent check")
        parts = code.split(MARKER)
        patch = parts[0] + "".join(name + part for name, part in zip(names, parts[1:]))
        if record.get("patched_code_sha256") != hashlib.sha256(patch.encode()).hexdigest():
            raise ValueError("Unrepaired patch SHA changed")
        reference = task["reference_name"]
        all_em = float(all(name == reference for name in names))
        f1 = sum(subtoken_scores(reference, name)["f1"] for name in names) / expected
        cvc = float(consistency)
        partial_site_f1 = f1
    else:
        all_em = f1 = cvc = 0.0
        raw_partial = record.get("partial_names")
        if isinstance(raw_partial, list) and len(raw_partial) == expected:
            partial_site_f1 = sum(subtoken_scores(task["reference_name"], name)["f1"]
                                  if isinstance(name, str) and valid_identifier(name, task["language"]) else 0.0
                                  for name in raw_partial) / expected
        else:
            partial_site_f1 = 0.0
    generation_called = record.get("generation_called")
    windows = record.get("windows", [])
    entered = sum("native_generation" in w.get("timing_s", {}) or (w.get("actual_nfe") or 0) > 0
                  for w in windows)
    if generation_called is not None and generation_called is not (entered > 0):
        raise ValueError("Generation-called receipt differs from observed native stages")
    resident = record.get("timing_s", {}).get("task_end_to_end")
    resident = float(resident) if entered > 0 and finite_nonnegative(resident) else None
    generation_times = [w.get("timing_s", {}).get("native_generation") for w in windows]
    generation = (float(sum(x for x in generation_times if finite_nonnegative(x)))
                  if entered > 0 and any(finite_nonnegative(x) for x in generation_times) else None)
    nfe = record.get("actual_nfe")
    if nfe is not None and (type(nfe) is not int or nfe < 0):
        raise ValueError("Actual forward count invalid")
    if status == "complete" and (entered == 0 or nfe is None or nfe <= 0):
        raise ValueError("Complete model attempt has no observed forward")
    if status in {"input_failure", "interrupted"} and resident is not None:
        raise ValueError("Uncalled/interrupted attempt has numeric resident time")
    peak = record.get("peak_memory_bytes") or {}
    allocated = peak.get("allocated")
    reserved = peak.get("reserved")
    if allocated is not None and (type(allocated) is not int or allocated < 0):
        raise ValueError("CUDA allocated peak invalid")
    if reserved is not None and (type(reserved) is not int or reserved < 0):
        raise ValueError("CUDA reserved peak invalid")
    return {"all_sites_exact_match": all_em,
            "mean_task_site_subtoken_f1": f1,
            "complete_valid_consistent": cvc,
            "partial_site_subtoken_f1_auxiliary": partial_site_f1,
            "complete_sites": complete, "site_consistency": bool(complete and cvc),
            "generation_entered_windows": entered, "generation_called": entered > 0,
            "resident_seconds": resident, "native_generation_seconds": generation,
            "actual_nfe": nfe, "cuda_allocator_peak_allocated_bytes": allocated,
            "cuda_allocator_peak_reserved_bytes": reserved}


def load_journals(manifest: dict, tasks: dict[str, dict], indexed: dict, phase: str,
                  selected: dict | None, sources: dict[str, dict]) -> list[dict]:
    expected = expected_cells(tasks, phase, selected)
    observed: dict[tuple, dict] = {}
    attempt_ids = set()
    for block, spec in indexed.items():
        path = Path(spec["path"])
        if sha(path) != spec["sha256"]:
            raise ValueError(f"Authenticated journal changed: {path}")
        raw = path.read_bytes()
        if not raw.endswith(b"\n"):
            raise ValueError(f"Truncated journal: {path}")
        rows = [json.loads(line) for line in raw.splitlines()]
        if not rows or rows[0].get("event") != "block_identity":
            raise ValueError("Journal lacks first identity receipt")
        identity = rows[0]["identity"]
        if (identity.get("protocol_id") != PROTOCOL or identity.get("protocol_sha256") != PROTOCOL_SHA
                or identity.get("phase") != phase or identity.get("language") != block[0]
                or identity.get("block_index") != block[1]
                or identity.get("plan_sha256") != spec["plan_sha256"]
                or identity.get("runner_sha256") != manifest["runner_sha256"]
                or identity.get("frozen_runner_sha256") != FROZEN_RUNNER_SHA
                or identity.get("frozen_shared_sha256") != FROZEN_SHARED_SHA
                or identity.get("dispatch_scope") != "scientific"):
            raise ValueError("Block identity/scope/plan changed")
        if not any(x.get("event") == "block_end" for x in rows):
            raise ValueError("Block has no complete terminal receipt")
        for row in rows:
            if row.get("event") != "attempt_end" or row.get("scientific") is not True:
                continue
            if row.get("dispatch_scope") != "scientific":
                raise ValueError("Technical smoke entered scientific journal")
            key = row.get("task_key")
            internal_key = uid(block[0], key) if isinstance(key, str) else None
            if internal_key not in tasks:
                raise ValueError("Unexpected scientific task")
            task = tasks[internal_key]
            if (row.get("language") != block[0] or row.get("block_index") != block[1]
                    or task["block_index"] != block[1] or row.get("source_index") != task["source_index"]
                    or row.get("phase") != phase or row.get("plan_sha256") != spec["plan_sha256"]
                    or row.get("masked_source_sha256") != task["masked_source_sha256"]
                    or row.get("source_csv_sha256") != task["source_csv_sha256"]
                    or row.get("protocol_sha256") != PROTOCOL_SHA):
                raise ValueError("Scientific task/plan/source receipt differs")
            if row.get("allocation_id") is None or row.get("gpu_uuid") is None or row.get("slurm_job_id") is None:
                raise ValueError("Paired allocation identity absent")
            cell = (block[0], key, row.get("model_key"), row.get("step_budget"), row.get("base_seed"))
            aid = row.get("attempt_id")
            if cell not in expected or cell in observed or not isinstance(aid, str) or aid in attempt_ids:
                raise ValueError("Missing/duplicate/unexpected scientific Cartesian identity")
            attempt_ids.add(aid)
            score = decode_sites(row, task, sources[internal_key]["masked_code"])
            observed[cell] = {"phase": phase, "language": block[0], "task_key": key,
                              "source_index": task["source_index"], "block_index": block[1],
                              "cluster_id": task.get("cluster_id"), "expected_sites": task["expected_sites"],
                              "model_key": cell[2], "step_budget": cell[3], "base_seed": cell[4],
                              "attempt_id": aid, "status": row["status"], "error": row.get("error"),
                              "allocation_id": row["allocation_id"], "gpu_uuid": row["gpu_uuid"],
                              "slurm_job_id": row["slurm_job_id"], "node": row.get("node"),
                              "source_csv_sha256": task["source_csv_sha256"],
                              "masked_source_sha256": task["masked_source_sha256"],
                              "model_receipt_sha256": row.get("model_receipt_sha256"),
                              "plan_sha256": spec["plan_sha256"], "journal_sha256": spec["sha256"],
                              **score}
    if set(observed) != expected:
        missing = sorted(expected - set(observed), key=str)
        raise ValueError(f"Missing {len(missing)} Cartesian attempts; examples: {missing[:3]}")
    return [observed[cell] for cell in sorted(observed, key=str)]


def score_command(args: argparse.Namespace) -> None:
    manifest = pinned_json(args.manifest, args.manifest_sha256)
    phase = manifest.get("phase")
    if phase not in {"E1", "E2"}:
        raise ValueError("score requires E1 or E2")
    sources, tasks, journals = validate_eval_manifest(manifest, phase)
    selected = None
    if phase == "E2":
        selection = pinned_json(Path(manifest["selection_receipt_path"]), manifest["selection_receipt_sha256"])
        audit = pinned_json(Path(manifest["independent_selection_receipt_path"]), manifest["independent_selection_receipt_sha256"])
        if (selection.get("status") != "complete" or selection.get("protocol_id") != PROTOCOL
                or selection.get("source_protocol_sha256") != PROTOCOL_SHA
                or selection.get("planned_model_task_records") != 4800
                or selection.get("observed_unique_model_task_records") != 4800
                or audit.get("status") != "pass" or audit.get("protocol_sha256") != PROTOCOL_SHA
                or audit.get("source_selection_sha256") != manifest["selection_receipt_sha256"]):
            raise ValueError("Held-out selection and independent audit are not frozen/accepted")
        selected = selection["selected_steps"]
        if set(selected) != set(FIXED) or any(type(x) is not int or x not in (1, 2, 4, 8, 16) for x in selected.values()):
            raise ValueError("Selected step map invalid")
    rows = load_journals(manifest, tasks, journals, phase, selected, sources)
    output = args.output_dir
    output.mkdir(mode=0o700, parents=True, exist_ok=False)
    scores = output / "scores.jsonl"
    with scores.open("x", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n")
    ordered_journals = sorted(({"language": j["language"], "block_index": j["block_index"],
                                "path": j["path"], "sha256": j["sha256"],
                                "plan_sha256": j["plan_sha256"]} for j in manifest["journals"]),
                              key=lambda x: (x["language"], x["block_index"]))
    summary = {"version": VERSION, "status": "complete", "phase": phase,
               "protocol_id": PROTOCOL, "protocol_sha256": PROTOCOL_SHA,
               "evaluation_manifest_sha256": args.manifest_sha256,
               "source_manifest_sha256": digest(ordered_journals),
               "input_journals": ordered_journals,
               "planned_model_task_records": len(rows),
               "observed_unique_model_task_records": len(rows),
               "planned_source_tasks": len(tasks),
               "repeat_subset_task_keys_sha256": digest(sorted((tasks[key]["language"], tasks[key]["task_key"])
                                                        for key in repeat_subset(tasks))) if phase == "E2" else None,
               "selection_receipt_sha256": manifest.get("selection_receipt_sha256"),
               "independent_selection_receipt_sha256": manifest.get("independent_selection_receipt_sha256"),
               "status_counts": dict(sorted(Counter(row["status"] for row in rows).items())),
               "numeric_resident_attempts": sum(row["resident_seconds"] is not None for row in rows),
               "scores_sha256": sha(scores), "scorer_sha256": sha(Path(__file__)),
               "generated_utc": now(),
               "interpretation": "Reference recovery and mechanical output reliability; not semantic naming, binding or behavior."}
    (output / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"status": "complete", "phase": phase, "rows": len(rows),
                      "scores_sha256": summary["scores_sha256"]}, sort_keys=True))


def read_scores(scores_path: Path, summary_path: Path, phase: str) -> tuple[list[dict], dict]:
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    if (summary.get("status") != "complete" or summary.get("phase") != phase
            or summary.get("protocol_sha256") != PROTOCOL_SHA
            or sha(scores_path) != summary.get("scores_sha256")):
        raise ValueError("Scored output incomplete or modified")
    raw = scores_path.read_bytes()
    if not raw.endswith(b"\n"):
        raise ValueError("Scored JSONL truncated")
    rows = [json.loads(line) for line in raw.splitlines()]
    if len(rows) != (4800 if phase == "E1" else 21600):
        raise ValueError("Scored Cartesian count differs")
    identities = [(r["language"], r["task_key"], r["model_key"], r["step_budget"], r["base_seed"]) for r in rows]
    if len(set(identities)) != len(rows):
        raise ValueError("Duplicate scored identities")
    return rows, summary


def aggregate_condition(rows: list[dict]) -> dict:
    n = len(rows)
    if not n:
        raise ValueError("Empty condition")
    timed = [r for r in rows if r["resident_seconds"] is not None]
    generated = [r["native_generation_seconds"] for r in rows if r["native_generation_seconds"] is not None]
    allocated = [r["cuda_allocator_peak_allocated_bytes"] for r in rows if r["cuda_allocator_peak_allocated_bytes"] is not None]
    reserved = [r["cuda_allocator_peak_reserved_bytes"] for r in rows if r["cuda_allocator_peak_reserved_bytes"] is not None]
    return {"planned_tasks": n,
            "status_counts": dict(sorted(Counter(r["status"] for r in rows).items())),
            **{metric: sum(r[metric] for r in rows) / n for metric in METRICS},
            "partial_site_subtoken_f1_auxiliary": sum(r["partial_site_subtoken_f1_auxiliary"] for r in rows) / n,
            "generation_called_tasks": sum(r["generation_called"] for r in rows),
            "numeric_resident_tasks": len(timed),
            "mean_resident_seconds_called": (sum(r["resident_seconds"] for r in timed) / len(timed)) if timed else None,
            "observed_resident_gpu_seconds": sum(r["resident_seconds"] for r in timed),
            "observed_resident_gpu_hours": sum(r["resident_seconds"] for r in timed) / 3600,
            "mean_native_generation_seconds": sum(generated) / len(generated) if generated else None,
            "mean_cuda_allocator_peak_allocated_bytes": sum(allocated) / len(allocated) if allocated else None,
            "mean_cuda_allocator_peak_reserved_bytes": sum(reserved) / len(reserved) if reserved else None,
            "mean_actual_nfe_known": (sum(r["actual_nfe"] for r in rows if r["actual_nfe"] is not None)
                                      / sum(r["actual_nfe"] is not None for r in rows))
                                     if any(r["actual_nfe"] is not None for r in rows) else None}


def select_command(args: argparse.Namespace) -> None:
    rows, score = read_scores(args.scores, args.summary, "E1")
    by_condition = defaultdict(list)
    for row in rows:
        if row["base_seed"] != 42:
            raise ValueError("E1 has unexpected repeat seed")
        by_condition[(row["language"], row["model_key"], row["step_budget"])].append(row)
    points = []
    for language in LANGUAGES:
        for model in MODELS:
            for step in (GRID if model in FIXED else (None,)):
                cell = by_condition[(language, model, step)]
                if len(cell) != 100 or len({r["task_key"] for r in cell}) != 100:
                    raise ValueError("E1 condition lacks 100 unique DEV tasks")
                points.append({"language": language, "model_key": model,
                               "step_budget": step, **aggregate_condition(cell)})
    if len(points) != 48:
        raise ValueError("Need 42 fixed grid + 6 AR points")
    lookup = {(p["language"], p["model_key"], p["step_budget"]): p for p in points}
    constraints = []
    selected = {}
    passed = {}
    for model in FIXED:
        qualified = []
        for step in (1, 2, 4, 8, 16):
            tests = []
            for language in LANGUAGES:
                base = lookup[(language, model, 64)]
                candidate = lookup[(language, model, step)]
                for metric in METRICS:
                    drop = base[metric] - candidate[metric]
                    tests.append({"language": language, "metric": metric, "reference64": base[metric],
                                  "candidate": candidate[metric], "absolute_drop": drop,
                                  "passed": drop <= .02 + 1e-12})
            okay = all(t["passed"] for t in tests)
            constraints.append({"model_key": model, "candidate_step": step,
                                "all_nine_passed": okay, "constraints": tests})
            if okay:
                qualified.append(step)
        selected[model] = min(qualified) if qualified else 16
        passed[model] = bool(qualified)
    ordered_journals = sorted(score["input_journals"], key=lambda x: (x["language"], x["block_index"]))
    selection = {"version": VERSION + "-selection", "status": "complete",
                 "protocol_id": PROTOCOL, "source_protocol_sha256": PROTOCOL_SHA,
                 "planned_model_task_records": 4800,
                 "observed_unique_model_task_records": len(rows),
                 "selected_steps": selected, "selection_passed": passed,
                 "evaluation_manifest_sha256": score["evaluation_manifest_sha256"],
                 "input_journals": ordered_journals,
                 "source_manifest_sha256": digest(ordered_journals),
                 "score_rows_sha256": score["scores_sha256"],
                 "score_summary_sha256": sha(args.summary),
                 "per_model_step_language_metrics": points,
                 "constraints_per_candidate": constraints,
                 "selection_rule": "smallest 1,2,4,8,16 passing every language x EM/F1/CVC <=0.02 drop vs own64; fallback16 diagnostic",
                 "selected_at_utc": now()}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(selection, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"selected_steps": selected, "selection_passed": passed,
                      "selection_sha256": sha(args.output)}, sort_keys=True))


def bootstrap_language(rows: list[dict], language: str, selected: dict,
                       selection_passed: dict[str, bool]) -> dict:
    import numpy as np

    primary = [r for r in rows if r["language"] == language and r["base_seed"] == 42]
    tasks = sorted({r["task_key"] for r in primary})
    if len(tasks) != 1000:
        raise ValueError("Held-out language does not have 1,000 primary tasks")
    by_cell = {(r["task_key"], r["model_key"], r["step_budget"]): r for r in primary}
    clusters_by_task = {}
    for row in primary:
        prior = clusters_by_task.setdefault(row["task_key"], row["cluster_id"])
        if prior != row["cluster_id"]:
            raise ValueError("Source cluster differs across paired model conditions")
    clusters = sorted(set(clusters_by_task.values()))
    cluster_index = {c: i for i, c in enumerate(clusters)}
    cidx = np.array([cluster_index[clusters_by_task[t]] for t in tasks], dtype=np.int32)
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    draws = rng.integers(0, len(clusters), size=(BOOTSTRAP_REPLICATES, len(clusters)), dtype=np.int32)
    flat = draws + (np.arange(BOOTSTRAP_REPLICATES, dtype=np.int32) * len(clusters))[:, None]
    draw_counts = np.bincount(flat.ravel(), minlength=BOOTSTRAP_REPLICATES * len(clusters))
    draw_counts = draw_counts.reshape(BOOTSTRAP_REPLICATES, len(clusters)).astype(np.int16)
    del flat
    cluster_sizes = np.bincount(cidx, minlength=len(clusters)).astype(float)
    draw_n = draw_counts @ cluster_sizes
    if np.any(draw_n <= 0):
        raise ValueError("Bootstrap drew no planned tasks")
    shared_draw_sha = hashlib.sha256(draws.tobytes()).hexdigest()
    contrasts = []
    roster = [(dllm, selected[dllm], ar, None, "low_vs_ar")
              for dllm in FIXED for ar in AR]
    roster += [(dllm, selected[dllm], dllm, 64, "low_vs_64") for dllm in FIXED]
    for left_model, left_step, right_model, right_step, kind in roster:
        left = [by_cell[(task, left_model, left_step)] for task in tasks]
        right = [by_cell[(task, right_model, right_step)] for task in tasks]
        metrics = {}
        for metric in METRICS:
            diff = np.array([a[metric] - b[metric] for a, b in zip(left, right)], dtype=float)
            cluster_sum = np.bincount(cidx, weights=diff, minlength=len(clusters))
            boot = (draw_counts @ cluster_sum) / draw_n
            point = float(np.mean(diff))
            lo, hi = np.quantile(boot, [.025, .975]).tolist()
            alpha = .05 / 36
            lower = float(np.quantile(boot, alpha)) if kind == "low_vs_ar" else None
            metrics[metric] = {"delta": point, "pointwise_95ci": [float(lo), float(hi)],
                               "simultaneous_one_sided_lower": lower,
                               "noninferior_margin_0_03": bool(lower is not None and lower > -.03),
                               "descriptive_margin_0": bool(lower is not None and lower > 0),
                               "descriptive_margin_0_01": bool(lower is not None and lower > -.01)}
        allocation_mismatch = sum(a["allocation_id"] != b["allocation_id"]
                                  or a["gpu_uuid"] != b["gpu_uuid"] for a, b in zip(left, right))
        pairs = [(a, b, i) for i, (a, b) in enumerate(zip(left, right))
                 if a["resident_seconds"] is not None and b["resident_seconds"] is not None]
        support = len(pairs)
        if support:
            td = np.array([a["resident_seconds"] - b["resident_seconds"] for a, b, _ in pairs])
            ta = np.array([a["resident_seconds"] for a, _, _ in pairs])
            tb = np.array([b["resident_seconds"] for _, b, _ in pairs])
            pair_cidx = np.array([cidx[i] for _, _, i in pairs], dtype=np.int32)
            time_sum = np.bincount(pair_cidx, weights=td, minlength=len(clusters))
            time_count = np.bincount(pair_cidx, minlength=len(clusters)).astype(float)
            boot_sum = draw_counts @ time_sum
            boot_count = draw_counts @ time_count
            valid = boot_count > 0
            boot_time = boot_sum[valid] / boot_count[valid]
            if len(boot_time):
                time_ci = [float(x) for x in np.quantile(boot_time, [.025, .975])]
                upper = float(np.quantile(boot_time, 1 - .05 / 12)) if kind == "low_vs_ar" else None
            else:
                time_ci = upper = None
            ratio_means = float(np.mean(ta) / np.mean(tb)) if np.mean(tb) > 0 else None
            positives = (ta > 0) & (tb > 0)
            geometric = float(np.exp(np.mean(np.log(ta[positives] / tb[positives])))) if positives.any() else None
            time = {"common_numeric_called_tasks": support, "missing_numeric_pairs": 1000 - support,
                    "bootstrap_empty_support_draws": int((~valid).sum()),
                    "mean_within_task_delta_seconds": float(np.mean(td)),
                    "pointwise_95ci_seconds": time_ci,
                    "simultaneous_one_sided_upper_seconds": upper,
                    "ratio_of_same_support_mean_seconds": ratio_means,
                    "paired_geometric_ratio_positive_support": geometric,
                    "paired_geometric_ratio_support": int(positives.sum()),
                    "left_common_mean_seconds": float(np.mean(ta)),
                    "right_common_mean_seconds": float(np.mean(tb)),
                    "left_common_median_seconds": float(np.median(ta)),
                    "right_common_median_seconds": float(np.median(tb)),
                    "left_common_p95_seconds": float(np.quantile(ta, .95)),
                    "right_common_p95_seconds": float(np.quantile(tb, .95)),
                    "latency_superior_bound_below_zero": bool(upper is not None and upper < 0),
                    "allocation_mismatch_tasks": allocation_mismatch,
                    "paired_hardware_gate": allocation_mismatch == 0}
        else:
            time = {"common_numeric_called_tasks": 0, "missing_numeric_pairs": 1000,
                    "bootstrap_empty_support_draws": BOOTSTRAP_REPLICATES,
                    "mean_within_task_delta_seconds": None, "pointwise_95ci_seconds": None,
                    "simultaneous_one_sided_upper_seconds": None,
                    "latency_superior_bound_below_zero": False,
                    "allocation_mismatch_tasks": allocation_mismatch,
                    "paired_hardware_gate": allocation_mismatch == 0}
        quality_pass = all(metrics[m]["noninferior_margin_0_03"] for m in METRICS)
        conditional_time_pass = bool(time["latency_superior_bound_below_zero"]
                                     and time["paired_hardware_gate"]
                                     and time["common_numeric_called_tasks"] > 0)
        complete_numeric_support = support == 1000
        time_pass = conditional_time_pass and complete_numeric_support
        conditional_joint_pass = bool(selection_passed[left_model] and quality_pass
                                      and conditional_time_pass)
        contrasts.append({"language": language, "kind": kind, "left_model": left_model,
                          "left_step": left_step, "right_model": right_model,
                          "right_step": right_step, "planned_paired_tasks": 1000,
                          "selected_on_dev": selection_passed[left_model],
                          "quality": metrics, "time": time,
                          "quality_gate_passed": quality_pass if kind == "low_vs_ar" else None,
                          "conditional_on_common_called_numeric_support": {
                              "support_tasks": support,
                              "planned_tasks": 1000,
                              "time_gate_passed": conditional_time_pass,
                              "joint_quality_time_claim_supported": conditional_joint_pass,
                          } if kind == "low_vs_ar" else None,
                          "numeric_support_complete": complete_numeric_support if kind == "low_vs_ar" else None,
                          "time_gate_passed": time_pass if kind == "low_vs_ar" else None,
                          "joint_quality_time_claim_supported": selection_passed[left_model] and quality_pass and time_pass if kind == "low_vs_ar" else None,
                          "unconditional_speed_claim_supported": time_pass if kind == "low_vs_ar" else None})
    return {"language": language, "cluster_count": len(clusters),
            "bootstrap_replicates": BOOTSTRAP_REPLICATES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "same_cluster_draws_sha256": shared_draw_sha,
            "contrasts": contrasts}


def summarize_repeats(rows: list[dict], selected: dict) -> dict:
    """Describe seeds 42/43/44 on the same fixed sources, without enlarging n."""
    import numpy as np

    source_tasks = {uid(r["language"], r["task_key"]):
                    {"language": r["language"], "task_key": r["task_key"]}
                    for r in rows if r["base_seed"] == 42}
    subset = repeat_subset(source_tasks)
    by_cell = {(r["language"], r["task_key"], r["model_key"], r["step_budget"], r["base_seed"]): r
               for r in rows}
    conditions = []
    for language in LANGUAGES:
        keys = sorted(source_tasks[key]["task_key"] for key in subset
                      if source_tasks[key]["language"] == language)
        if len(keys) != 100:
            raise ValueError("Repeat subset differs from 100 source tasks per language")
        for model in MODELS:
            steps = (selected[model], 64) if model in FIXED else (None,)
            for step in steps:
                triples = [[by_cell[(language, key, model, step, seed)]
                            for seed in (42, 43, 44)] for key in keys]
                per_seed = []
                for index, seed in enumerate((42, 43, 44)):
                    cell = [triple[index] for triple in triples]
                    if len({r["task_key"] for r in cell}) != 100:
                        raise ValueError("Repeat seed lacks the fixed 100-task subset")
                    per_seed.append({"seed": seed, **aggregate_condition(cell)})
                full_time = [[r["resident_seconds"] for r in triple] for triple in triples
                             if all(r["resident_seconds"] is not None for r in triple)]
                ranges = np.array([max(times) - min(times) for times in full_time], dtype=float)
                sds = np.array([np.std(times, ddof=1) for times in full_time], dtype=float)
                conditions.append({
                    "language": language, "model_key": model, "step_budget": step,
                    "independent_source_tasks": 100,
                    "seed_condition_metrics": per_seed,
                    "within_task_generation_variability": {
                        "tasks_with_status_change": sum(len({r["status"] for r in triple}) > 1
                                                        for triple in triples),
                        "tasks_with_any_primary_quality_metric_change": sum(
                            any(len({r[metric] for r in triple}) > 1 for metric in METRICS)
                            for triple in triples),
                    },
                    "within_task_resident_variability": {
                        "tasks_with_all_three_numeric": len(full_time),
                        "tasks_missing_at_least_one_numeric": 100 - len(full_time),
                        "mean_range_seconds_all_three": float(np.mean(ranges)) if len(ranges) else None,
                        "median_range_seconds_all_three": float(np.median(ranges)) if len(ranges) else None,
                        "p95_range_seconds_all_three": float(np.quantile(ranges, .95)) if len(ranges) else None,
                        "mean_sample_sd_seconds_all_three": float(np.mean(sds)) if len(sds) else None,
                    },
                })
    if len(conditions) != 18:
        raise ValueError("Expected six conditions in each of three languages for repeat analysis")
    return {"source_task_subset_sha256": digest(sorted((source_tasks[key]["language"],
                                                          source_tasks[key]["task_key"])
                                                         for key in subset)),
            "source_tasks_per_language": 100,
            "additional_seeds": [43, 44],
            "planned_additional_model_task_records": 3600,
            "independent_source_task_n_in_primary_analysis": 1000,
            "conditions": conditions}


def summarize_command(args: argparse.Namespace) -> None:
    rows, score = read_scores(args.scores, args.summary, "E2")
    selection = pinned_json(args.selection, args.selection_sha256)
    if score.get("selection_receipt_sha256") != args.selection_sha256:
        raise ValueError("Held-out scored inputs do not match frozen selection")
    selected = selection["selected_steps"]
    by_condition = defaultdict(list)
    for row in rows:
        if row["base_seed"] == 42:
            by_condition[(row["language"], row["model_key"], row["step_budget"])].append(row)
    condition_rows = []
    for language in LANGUAGES:
        for model in MODELS:
            steps = (selected[model], 64) if model in FIXED else (None,)
            for step in steps:
                cell = by_condition[(language, model, step)]
                if len(cell) != 1000 or len({r["task_key"] for r in cell}) != 1000:
                    raise ValueError("Held-out primary condition differs from 1,000-task denominator")
                condition_rows.append({"language": language, "model_key": model,
                                       "step_budget": step, **aggregate_condition(cell)})
    bootstrap = [bootstrap_language(rows, lang, selected, selection["selection_passed"])
                 for lang in LANGUAGES]
    repeat_check = summarize_repeats(rows, selected)
    ar = [c for block in bootstrap for c in block["contrasts"] if c["kind"] == "low_vs_ar"]
    if len(ar) != 12:
        raise ValueError("All twelve dLLM-vs-AR contrasts required")
    report = {"version": VERSION + "-heldout", "status": "complete",
              "protocol_id": PROTOCOL, "protocol_sha256": PROTOCOL_SHA,
              "evaluation_manifest_sha256": score["evaluation_manifest_sha256"],
              "score_rows_sha256": score["scores_sha256"],
              "selection_sha256": args.selection_sha256,
              "planned_primary_model_task_records": 18000,
              "planned_repeat_model_task_records": 3600,
              "selected_steps": selected, "selection_passed": selection["selection_passed"],
              "primary_conditions": condition_rows,
              "repeat_check": repeat_check,
              "bootstrap_by_language": bootstrap,
              "ar_contrasts_reported": len(ar),
              "conditional_joint_supported_contrasts": sum(
                  c["conditional_on_common_called_numeric_support"]["joint_quality_time_claim_supported"]
                  for c in ar),
              "joint_supported_contrasts": sum(c["joint_quality_time_claim_supported"] for c in ar),
              "all_twelve_jointly_supported": all(c["joint_quality_time_claim_supported"] for c in ar),
              "all_twelve_unconditional_speed_supported": all(c["unconditional_speed_claim_supported"] for c in ar),
              "limits": ["Reference agreement is not semantic naming quality.",
                         "Syntax validation is not binding/compile/behavior validation.",
                         "DEV step selection used frozen first-site 16k crops; original TEST retained full sources and all sites, so DEV source-length/site distribution differs from TEST.",
                         "Resident time excludes cold model loading and external workflow steps.",
                         "A resumed block with cross-allocation pairs cannot support a paired time gate."],
              "generated_utc": now(), "analyzer_sha256": sha(Path(__file__))}
    args.output_dir.mkdir(mode=0o700, parents=True, exist_ok=False)
    path = args.output_dir / "report.json"
    path.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"status": "complete", "ar_contrasts": len(ar),
                      "joint_supported": report["joint_supported_contrasts"],
                      "report_sha256": sha(path)}, sort_keys=True))


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    score = sub.add_parser("score")
    score.add_argument("--manifest", type=Path, required=True)
    score.add_argument("--manifest-sha256", required=True)
    score.add_argument("--output-dir", type=Path, required=True)
    select = sub.add_parser("select")
    select.add_argument("--scores", type=Path, required=True)
    select.add_argument("--summary", type=Path, required=True)
    select.add_argument("--output", type=Path, required=True)
    summarize = sub.add_parser("summarize")
    summarize.add_argument("--scores", type=Path, required=True)
    summarize.add_argument("--summary", type=Path, required=True)
    summarize.add_argument("--selection", type=Path, required=True)
    summarize.add_argument("--selection-sha256", required=True)
    summarize.add_argument("--output-dir", type=Path, required=True)
    args = p.parse_args(argv)
    os.umask(0o077)
    {"score": score_command, "select": select_command, "summarize": summarize_command}[args.command](args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
