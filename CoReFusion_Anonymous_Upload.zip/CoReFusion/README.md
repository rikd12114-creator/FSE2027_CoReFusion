# CoReFusion: Core Code

This package contains the core implementation for identifier recovery and
coordinated multi-location generation, matched adaptation, and evaluation.

- `experiments/rq1_empirical/`: task contracts, inference backends, and native multi-site generation.
- `evaluation/rq1_empirical/`: recovery, consistency, lexical, and machine-judge scoring.
- `experiments/protocol_verification_20260920/`: matched training and evaluation, with four training parameter configurations.
- Other retained Python modules provide the local dependencies of those implementations.

Datasets, predictions, result tables, figures, provenance records, model weights,
and operational launch/deployment scripts are excluded. Data-processing and
scoring implementations are source code, not bundled research data.

Use Python 3.10 or later. Supply your own input files, model/checkpoint locations,
and backend environment.
`requirements.txt` lists the imported third-party packages; it is not a locked
environment. Native-objective training also expects the upstream trainer
checkouts referenced by the implementation. Preserve the directory layout so
local module imports continue to resolve.

The source was checked for Python syntax and local import dependencies. Training
and inference were not rerun when preparing this code-only package.
