"""Independent, denominator-preserving scoring of fixed-canvas multisite S1.

The scorer checks each stored native input/output token sequence and exact
unmasked-context preservation. Token-to-text decoding remains bound to the
pinned model tokenizer used by the generation backend.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from experiments.rq1_empirical.legacy_diffusion_multisite_s1 import (
    DECODING, MASK_TOKENS, MODE, NATIVE_CONTEXT, VERSION, _digest,
)
from experiments.rq1_empirical.policy import valid_identifier
from experiments.rq1_empirical.schema import CONTEXT_CHARS, MARKER, load_tasks, visible_code


EVALUATOR_VERSION = "rq1-s1-native-multisite-static-v1-20260925"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _load_jsonl(path: Path) -> list[dict[str, Any]]:
    raw = path.read_bytes()
    if raw and not raw.endswith(b"\n"):
        raise ValueError("Incomplete final native multisite prediction row")
    return [json.loads(line) for line in raw.splitlines()]


def _independent_site_metrics(task: Any, names: list[str | None],
                              errors: list[str | None]) -> dict[str, Any]:
    """Recompute denominators without using the generation runner's metric code."""
    covered_indices = [index for index in range(task.sites)
                       if errors[index] is None and names[index] is not None
                       and valid_identifier(names[index], task.language)]
    covered = len(covered_indices)
    complete = covered == task.sites
    return {
        "expected_sites": task.sites,
        "visible_sites": sum(error != "outside_common_visible_code" for error in errors),
        "covered_sites": covered,
        "complete_site_coverage": complete,
        "consistent_nonempty": complete and len({names[index] for index in covered_indices}) == 1,
        "exact_sites": sum(names[index] == task.reference_name for index in covered_indices),
        "all_sites_exact": complete and all(name == task.reference_name for name in names),
        "error_sites": sum(error is not None for error in errors),
    }


def _independent_patch(code: str, names: list[str]) -> str:
    chunks = code.split(MARKER)
    if len(chunks) != len(names) + 1:
        raise ValueError("Unrepaired patch has a different number of sites")
    rendered = chunks[0]
    for name, suffix in zip(names, chunks[1:]):
        rendered += name + suffix
    return rendered


def _validate_windows(row: dict[str, Any], mask_id: int) -> None:
    plan = row["window_plan"]
    windows, outputs = plan["windows"], row["window_outputs"]
    if (plan["provided_mask_length"] != MASK_TOKENS
            or plan["occurrences"] != row["visible_sites"]
            or plan["input_plan_sha256"] != _digest(windows)
            or len(windows) != len(outputs) or row["native_sampler_calls"] != len(outputs)):
        raise ValueError("Native multisite window plan changed or incomplete")
    owned_all = []
    for window, output in zip(windows, outputs):
        ids, generated = window["input_ids"], output["output_ids"]
        owned = window["owned_site_indices"]
        if (window["index"] != output["window_index"]
                or owned != output["owned_site_indices"]
                or window["visible_site_indices"] != output["visible_site_indices"]
                or len(ids) > NATIVE_CONTEXT or len(generated) != len(ids) + 1
                or output["input_tokens"] != len(ids) or output["output_tokens"] != len(generated)
                or output["input_ids_sha256"] != _digest(ids)
                or output["output_ids_sha256"] != _digest(generated)
                or not isinstance(output["elapsed_s"], (int, float))
                or output["elapsed_s"] < 0):
            raise ValueError("Native multisite window token receipt mismatch")
        context_same = all(token == generated[pos] for pos, token in enumerate(ids) if token != mask_id)
        if output["context_unchanged"] is not (context_same and len(generated) == len(ids) + 1):
            raise ValueError("Native multisite context preservation receipt mismatch")
        if not context_same:
            raise ValueError("Native multisite changed unmasked context")
        if len(owned) != len(window["owned_token_spans"]):
            raise ValueError("Native multisite owned-site/span mapping changed")
        for site, (start, end) in zip(owned, window["owned_token_spans"]):
            if (not 0 <= start < end <= len(ids)
                    or any(token != mask_id for token in ids[start:end])
                    or row["site_token_ids"][site] != generated[start:end]):
                raise ValueError("Native multisite site output does not match its original mask span")
        owned_all.extend(owned)
    if sorted(owned_all) != list(range(row["visible_sites"])):
        raise ValueError("Native multisite windows did not own each visible site once")


def evaluate_run(run_dir: Path, data: Path, *, require_complete: bool = True) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    run_dir, data = Path(run_dir), Path(data)
    run_path, predictions_path, summary_path = (run_dir / name for name in
                                                ("run.json", "predictions.jsonl", "summary.json"))
    contract = json.loads(run_path.read_text(encoding="utf-8"))
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    rows = _load_jsonl(predictions_path)
    if (contract.get("schema_version") != 1 or contract.get("mode") != MODE
            or contract.get("version") != VERSION
            or contract.get("common_visible_code_char_limit") != CONTEXT_CHARS
            or contract.get("native_context_tokens") != NATIVE_CONTEXT
            or contract.get("mask_tokens_per_site") != MASK_TOKENS
            or contract.get("decoding") != DECODING
            or contract.get("source_sha256") != sha256(data)
            or contract.get("runtime_precision") != "torch.bfloat16"):
        raise ValueError("Native multisite model/data/protocol contract mismatch")
    tasks = load_tasks(data, dataset=contract["dataset"], language=contract["language"])
    by_key = {task.key: task for task in tasks}
    keys = contract["task_keys"]
    if (len(keys) != len(set(keys)) or any(key not in by_key for key in keys)
            or contract["task_identity_sha256"] != _digest([
                (by_key[key].key, by_key[key].code_masked, by_key[key].reference_name) for key in keys])):
        raise ValueError("Native multisite task identity changed")
    if (len(rows) > len(keys) or [row.get("task_key") for row in rows] != keys[:len(rows)]
            or (require_complete and len(rows) != len(keys))):
        raise ValueError("Native multisite prediction count or order differs from declared cohort")
    mask_id = contract["runtime"]["mask_token_id"]
    if not isinstance(mask_id, int):
        raise ValueError("Native multisite mask token identity missing")
    scored = []
    for task, row in zip((by_key[key] for key in keys), rows):
        names, errors, raw_names, site_ids = (row.get(name) for name in
                                              ("site_predictions", "site_errors", "site_raw_content", "site_token_ids"))
        if (row.get("dataset") != task.dataset or row.get("language") != task.language
                or row.get("id") != task.task_id or row.get("reference_name") != task.reference_name
                or row.get("expected_sites") != task.sites
                or row.get("visible_code_sha256") != hashlib.sha256(visible_code(task).encode()).hexdigest()
                or not all(isinstance(item, list) and len(item) == task.sites
                           for item in (names, errors, raw_names, site_ids))
                or row.get("visible_sites") != visible_code(task).count(MARKER)):
            raise ValueError("Native multisite task/site receipt mismatch")
        for index, (name, error, raw, ids) in enumerate(zip(names, errors, raw_names, site_ids)):
            if index >= row["visible_sites"]:
                if (name, error, raw, ids) != (None, "outside_common_visible_code", None, None):
                    raise ValueError("Site outside common crop was silently filled")
            elif (name is not None and not valid_identifier(name, task.language)) or (
                    error is None and name is None) or (error is not None and name is not None):
                raise ValueError("Native multisite invalid-name or error receipt mismatch")
        _validate_windows(row, mask_id)
        metrics = _independent_site_metrics(task, names, errors)
        if row.get("metrics") != metrics:
            raise ValueError("Native multisite runner metrics differ from independent recomputation")
        patch = (_independent_patch(task.code_masked, [name for name in names if name is not None])
                 if metrics["complete_site_coverage"] else None)
        expected_patch_sha = hashlib.sha256(patch.encode()).hexdigest() if patch is not None else None
        if row.get("patch_sha256") != expected_patch_sha:
            raise ValueError("Native multisite patch SHA differs from unrepaired site outputs")
        scored.append({"task_key": task.key, "reference_name": task.reference_name,
                       "expected_sites": task.sites, "site_predictions": names, "site_errors": errors,
                       "covered_sites": metrics["covered_sites"],
                       "exact_sites": metrics["exact_sites"],
                       "complete_site_coverage": metrics["complete_site_coverage"],
                       "consistent_nonempty": metrics["consistent_nonempty"],
                       "all_sites_exact": metrics["all_sites_exact"],
                       "native_sampler_calls": row["native_sampler_calls"]})
    expected_summary = {
        "planned_tasks": len(keys), "completed_tasks": len(rows),
        "expected_sites": sum(by_key[key].sites for key in keys),
        "covered_sites": sum(row["covered_sites"] for row in scored),
        "all_sites_exact_tasks": sum(row["all_sites_exact"] for row in scored),
        "consistent_nonempty_tasks": sum(row["consistent_nonempty"] for row in scored),
        "tasks_with_site_error": sum(any(error is not None for error in row["site_errors"])
                                     for row in scored),
        "native_sampler_calls": sum(row["native_sampler_calls"] for row in scored),
        "run_sha256": sha256(run_path), "predictions_sha256": sha256(predictions_path),
    }
    if any(summary.get(key) != value for key, value in expected_summary.items()):
        raise ValueError("Native multisite runner summary mismatch")
    denom_tasks, denom_sites = len(keys), expected_summary["expected_sites"]
    result = {
        "evaluator_version": EVALUATOR_VERSION, "run_mode": MODE,
        "dataset": contract["dataset"], "language": contract["language"],
        "planned_tasks": denom_tasks, "scored_tasks": len(scored),
        "expected_sites": denom_sites, "covered_sites": expected_summary["covered_sites"],
        "site_coverage": expected_summary["covered_sites"] / denom_sites,
        "exact_sites": sum(row["exact_sites"] for row in scored),
        "site_em_micro": sum(row["exact_sites"] for row in scored) / denom_sites,
        "all_sites_exact_tasks": expected_summary["all_sites_exact_tasks"],
        "all_sites_em_task_macro": expected_summary["all_sites_exact_tasks"] / denom_tasks,
        "consistent_nonempty_tasks": expected_summary["consistent_nonempty_tasks"],
        "tasks_with_site_error": expected_summary["tasks_with_site_error"],
        "native_sampler_calls": expected_summary["native_sampler_calls"],
        "integrity": {"source_sha256": sha256(data), "run_sha256": sha256(run_path),
                      "predictions_sha256": sha256(predictions_path),
                      "runner_summary_status": "verified", "stored_native_context": "exact_token_check",
                      "scorer_sha256": sha256(Path(__file__))},
        "interpretation": "Native per-site masked output; no forced propagation or repair. Token-to-text decoding uses the pinned generation tokenizer.",
    }
    return result, scored


def write_scores(output: Path, summary: dict[str, Any], rows: list[dict[str, Any]]) -> None:
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    (output / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    (output / "scores.jsonl").write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    summary, rows = evaluate_run(args.run, args.data)
    write_scores(args.output, summary, rows)
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
