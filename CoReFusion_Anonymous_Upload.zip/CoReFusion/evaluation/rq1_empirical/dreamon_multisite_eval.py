"""Independent, strict token alignment and scoring for DreamOn all-site canvases."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections.abc import Sequence
from functools import cache
from pathlib import Path

from experiments.rq1_empirical.policy import valid_identifier
from experiments.rq1_empirical.schema import (
    CONTEXT_CHARS,
    MARKER,
    load_tasks,
    visible_code,
)

VERSION = "rq1-s1-native-dreamon-multisite-static-v1-20260925"
RUN_MODE = "s1_native_dreamon_multisite_independent_sites"
RUN_VERSION = "s1-native-dreamon-variable-multisite-windowed-v1"
INPUT_LIMIT = 1988
NATIVE_CONTEXT = 2048
MASKS_PER_SITE = 4
GROWTH_TOKENS = 60
SEED = 42
DECODING = {
    "temperature": 0.2, "top_p": 0.9, "alg": "entropy", "alg_temp": 0.0,
    "number_transfer_tokens": 1, "pad_delete_to_right": False,
    "return_dict_in_generate": True, "output_history": True,
}


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _digest(value: object) -> str:
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def unique_canvas_spans(
    unmasked_segments: Sequence[Sequence[int]], generated: Sequence[int],
) -> tuple[list[tuple[int, int]] | None, str | None]:
    """Find exactly one ordered placement of every preserved source segment.

    The spans between those segments are the model's site canvases. Repeated
    context that admits more than one placement is an error, not a chance to
    choose the segmentation that yields a valid name.
    """
    segments = [tuple(part) for part in unmasked_segments]
    output = tuple(generated)
    if len(segments) < 2:
        return None, "missing_site_segments"
    if any(not segment for segment in segments[1:-1]):
        return None, "empty_inter_site_anchor"
    first, last = segments[0], segments[-1]
    if output[:len(first)] != first:
        return None, "native_prefix_changed"
    if last and output[-len(last):] != last:
        return None, "native_suffix_changed"
    suffix_start = len(output) - len(last)
    if suffix_start < len(first):
        return None, "native_context_shortened"

    @cache
    def paths(next_anchor: int, previous_end: int) -> tuple[tuple[tuple[int, int], ...], ...]:
        if next_anchor == len(segments) - 1:
            return (((previous_end, suffix_start),),) if previous_end <= suffix_start else ()
        anchor = segments[next_anchor]
        solutions: list[tuple[tuple[int, int], ...]] = []
        last_start = suffix_start - len(anchor)
        for start in range(previous_end, last_start + 1):
            if output[start:start + len(anchor)] != anchor:
                continue
            for remainder in paths(next_anchor + 1, start + len(anchor)):
                solutions.append(((previous_end, start),) + remainder)
                if len(solutions) >= 2:
                    return tuple(solutions)
        return tuple(solutions)

    matches = paths(1, len(first))
    if not matches:
        return None, "unmasked_context_not_preserved"
    if len(matches) > 1:
        return None, "ambiguous_context_alignment"
    spans = list(matches[0])
    if len(spans) != len(segments) - 1:
        return None, "invalid_canvas_count"
    return spans, None


def _site_metrics(task: object, names: list[str | None], errors: list[str | None]) -> dict:
    covered_indices = [index for index in range(task.sites)
                       if errors[index] is None and names[index] is not None
                       and valid_identifier(names[index], task.language)]
    covered = len(covered_indices)
    complete = covered == task.sites
    return {
        "expected_sites": task.sites,
        "visible_sites": sum(error != "outside_common_visible_code" for error in errors),
        "covered_sites": covered,
        "complete_site_coverage": complete,
        "consistent_nonempty": complete and len({names[index] for index in covered_indices}) == 1,
        "exact_sites": sum(names[index] == task.reference_name for index in covered_indices),
        "all_sites_exact": complete and all(name == task.reference_name for name in names),
        "error_sites": sum(error is not None for error in errors),
    }


def _patch(code: str, names: list[str]) -> str:
    parts = code.split(MARKER)
    if len(parts) != len(names) + 1:
        raise ValueError("Unrepaired patch has an unexpected number of sites")
    return parts[0] + "".join(name + part for name, part in zip(names, parts[1:]))


def _validate_windows(row: dict, task_key: str, mask_id: int) -> None:
    plan = row["window_plan"]
    windows, outputs = plan["windows"], row["window_outputs"]
    if (plan["provided_mask_length"] != MASKS_PER_SITE
            or plan["occurrences"] != row["visible_sites"]
            or plan["input_plan_sha256"] != _digest(windows)
            or len(windows) != len(outputs) or row["native_sampler_calls"] != len(outputs)):
        raise ValueError("Native DreamOn window plan or call count mismatch")
    owned_all: list[int] = []
    for window, output in zip(windows, outputs):
        ids = window["input_ids"]
        visible = window["visible_site_indices"]
        owned = window["owned_site_indices"]
        spans = window["visible_token_spans"]
        idx = window["index"]
        if (idx != output["window_index"] or owned != output["owned_site_indices"]
                or visible != output["visible_site_indices"]
                or len(ids) > INPUT_LIMIT or len(spans) != len(visible)
                or ids != output["input_ids"] or output["input_tokens"] != len(ids)
                or output["input_ids_sha256"] != _digest(ids)):
            raise ValueError("Native DreamOn window input identity mismatch")
        segments: list[list[int]] = []
        cursor = 0
        for start, end in spans:
            if (not cursor <= start < end <= len(ids) or end - start != MASKS_PER_SITE
                    or ids[start:end] != [mask_id] * MASKS_PER_SITE):
                raise ValueError("Native DreamOn window mask span changed")
            segment = ids[cursor:start]
            if mask_id in segment:
                raise ValueError("Unmapped native mask in unmasked source")
            segments.append(segment)
            cursor = end
        segments.append(ids[cursor:])
        if mask_id in segments[-1] or segments != window["unmasked_segments"] or segments != output["unmasked_segments"]:
            raise ValueError("Native DreamOn unmasked context segment mismatch")
        mask_count = MASKS_PER_SITE * len(visible)
        cap = len(ids) + GROWTH_TOKENS
        expected_seed = int.from_bytes(hashlib.sha256(
            f"{SEED}:{task_key}:{idx}".encode()).digest()[:4], "big")
        if (ids.count(mask_id) != mask_count
                or output["initial_mask_tokens"] != mask_count
                or output["max_new_tokens"] != mask_count + GROWTH_TOKENS
                or output["max_output_tokens"] != cap or cap > NATIVE_CONTEXT
                or output["window_seed"] != expected_seed
                or not isinstance(output["native_forward_calls"], int)
                or output["native_forward_calls"] < 0
                or not isinstance(output["elapsed_s"], (int, float))
                or output["elapsed_s"] < 0):
            raise ValueError("Native DreamOn sampler budget/seed receipt mismatch")
        generated = output["final_active_output_ids"]
        if generated is None:
            aligned, alignment_error = None, "native_history_missing"
            if output["output_tokens"] is not None or output["final_active_output_sha256"] is not None:
                raise ValueError("Missing history has a fabricated output hash")
        else:
            if (output["output_tokens"] != len(generated)
                    or output["final_active_output_sha256"] != _digest(generated)
                    or len(generated) > NATIVE_CONTEXT):
                raise ValueError("Native DreamOn final active sequence receipt mismatch")
            aligned, alignment_error = unique_canvas_spans(segments, generated)
        if output["context_unchanged"] is not (alignment_error is None):
            raise ValueError("Native DreamOn context preservation flag differs from independent alignment")
        if (output["alignment_error"] is None) != (alignment_error is None):
            raise ValueError("Native DreamOn alignment success differs from independent alignment")
        if aligned is None:
            if output["canvas_spans"] is not None:
                raise ValueError("Unalignable native output contains fabricated canvas positions")
        elif output["canvas_spans"] != [list(span) for span in aligned]:
            raise ValueError("Native DreamOn canvas positions differ from independent alignment")
        visible_offsets = {site: offset for offset, site in enumerate(visible)}
        if len(visible_offsets) != len(visible) or not set(owned).issubset(visible_offsets):
            raise ValueError("Native DreamOn window ownership changed")
        for site in owned:
            if row["site_window_indices"][site] != idx:
                raise ValueError("Native DreamOn site/window map changed")
            if aligned is None:
                if row["site_token_ids"][site] is not None or row["site_errors"][site] is None:
                    raise ValueError("Unalignable site was silently filled")
            else:
                start, end = aligned[visible_offsets[site]]
                if row["site_token_ids"][site] != generated[start:end]:
                    raise ValueError("Native DreamOn site tokens differ from original canvas")
        owned_all.extend(owned)
    if sorted(owned_all) != list(range(row["visible_sites"])):
        raise ValueError("Native DreamOn windows did not own every visible site once")


def evaluate_run(run_dir: Path, data: Path, *, require_complete: bool = True) -> tuple[dict, list[dict]]:
    run_dir, data = Path(run_dir), Path(data)
    run_path, predictions_path, summary_path = (run_dir / name for name in
                                                ("run.json", "predictions.jsonl", "summary.json"))
    contract = json.loads(run_path.read_text(encoding="utf-8"))
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    raw = predictions_path.read_bytes()
    if raw and not raw.endswith(b"\n"):
        raise ValueError("Incomplete final DreamOn native prediction row")
    rows = [json.loads(line) for line in raw.splitlines()]
    if (contract.get("schema_version") != 1 or contract.get("mode") != RUN_MODE
            or contract.get("version") != RUN_VERSION
            or contract.get("common_visible_code_char_limit") != CONTEXT_CHARS
            or contract.get("native_context_tokens") != NATIVE_CONTEXT
            or contract.get("native_input_limit") != INPUT_LIMIT
            or contract.get("mask_tokens_per_site") != MASKS_PER_SITE
            or contract.get("aggregate_growth_tokens_per_window") != GROWTH_TOKENS
            or contract.get("decoding") != DECODING
            or contract.get("runtime_precision") != "torch.bfloat16"
            or contract.get("source_sha256") != _sha(data)
            or contract.get("model_slug") != "dreamon-7b"
            or contract.get("seed") != SEED):
        raise ValueError("Native DreamOn model/data/protocol contract mismatch")
    tasks = load_tasks(data, dataset=contract["dataset"], language=contract["language"])
    by_key = {task.key: task for task in tasks}
    keys = contract["task_keys"]
    if (len(keys) != len(set(keys)) or any(key not in by_key for key in keys)
            or contract["task_identity_sha256"] != _digest([
                (by_key[key].key, by_key[key].code_masked, by_key[key].reference_name) for key in keys])):
        raise ValueError("Native DreamOn task identity mismatch")
    if (len(rows) > len(keys) or [row.get("task_key") for row in rows] != keys[:len(rows)]
            or (require_complete and len(rows) != len(keys))):
        raise ValueError("Native DreamOn row count or order mismatch")
    mask_id = contract["runtime"]["mask_token_id"]
    if not isinstance(mask_id, int):
        raise TypeError("Native DreamOn mask token receipt missing")
    scored = []
    for task, row in zip((by_key[key] for key in keys), rows):
        names, errors, raw_names, site_ids, site_windows = (row.get(name) for name in (
            "site_predictions", "site_errors", "site_raw_content", "site_token_ids",
            "site_window_indices"))
        if (row.get("dataset") != task.dataset or row.get("language") != task.language
                or row.get("id") != task.task_id or row.get("reference_name") != task.reference_name
                or row.get("expected_sites") != task.sites
                or row.get("visible_code_sha256") != hashlib.sha256(visible_code(task).encode()).hexdigest()
                or not all(isinstance(item, list) and len(item) == task.sites
                           for item in (names, errors, raw_names, site_ids, site_windows))
                or row.get("visible_sites") != visible_code(task).count(MARKER)):
            raise ValueError("Native DreamOn task/site receipt mismatch")
        for index, (name, error, raw_name, ids, site_window) in enumerate(
                zip(names, errors, raw_names, site_ids, site_windows)):
            if index >= row["visible_sites"]:
                if (name, error, raw_name, ids, site_window) != (
                        None, "outside_common_visible_code", None, None, None):
                    raise ValueError("Site outside common crop was silently filled")
            elif (name is not None and not valid_identifier(name, task.language)
                  or error is None and name is None
                  or error is not None and name is not None
                  or site_window is None
                  or name is not None and (not isinstance(raw_name, str)
                                           or raw_name.strip() != name)):
                raise ValueError("Native DreamOn site name/error receipt mismatch")
        _validate_windows(row, task.key, mask_id)
        metrics = _site_metrics(task, names, errors)
        if row["metrics"] != metrics:
            raise ValueError("Native DreamOn runner metrics differ from independent recomputation")
        patch = _patch(task.code_masked, [name for name in names if name is not None]) if (
            metrics["complete_site_coverage"]) else None
        patch_sha = hashlib.sha256(patch.encode()).hexdigest() if patch is not None else None
        if row["patch_sha256"] != patch_sha:
            raise ValueError("Native DreamOn unrepaired patch SHA mismatch")
        scored.append({
            "task_key": task.key, "reference_name": task.reference_name,
            "expected_sites": task.sites, "site_predictions": names, "site_errors": errors,
            "covered_sites": metrics["covered_sites"], "exact_sites": metrics["exact_sites"],
            "complete_site_coverage": metrics["complete_site_coverage"],
            "consistent_nonempty": metrics["consistent_nonempty"],
            "all_sites_exact": metrics["all_sites_exact"],
            "native_sampler_calls": row["native_sampler_calls"],
            "native_forward_calls": sum(w["native_forward_calls"] for w in row["window_outputs"]),
        })
    expected_summary = {
        "planned_tasks": len(keys), "completed_tasks": len(rows),
        "expected_sites": sum(by_key[key].sites for key in keys),
        "covered_sites": sum(row["covered_sites"] for row in scored),
        "all_sites_exact_tasks": sum(row["all_sites_exact"] for row in scored),
        "consistent_nonempty_tasks": sum(row["consistent_nonempty"] for row in scored),
        "tasks_with_site_error": sum(any(error is not None for error in row["site_errors"])
                                     for row in scored),
        "native_sampler_calls": sum(row["native_sampler_calls"] for row in scored),
        "native_forward_calls": sum(row["native_forward_calls"] for row in scored),
        "run_sha256": _sha(run_path), "predictions_sha256": _sha(predictions_path),
    }
    if any(summary.get(key) != value for key, value in expected_summary.items()):
        raise ValueError("Native DreamOn runner summary mismatch")
    n, sites = len(keys), expected_summary["expected_sites"]
    result = {
        "evaluator_version": VERSION, "run_mode": RUN_MODE,
        "dataset": contract["dataset"], "language": contract["language"],
        "planned_tasks": n, "scored_tasks": len(scored),
        "expected_sites": sites, "covered_sites": expected_summary["covered_sites"],
        "site_coverage": expected_summary["covered_sites"] / sites,
        "exact_sites": sum(row["exact_sites"] for row in scored),
        "site_em_micro": sum(row["exact_sites"] for row in scored) / sites,
        "all_sites_exact_tasks": expected_summary["all_sites_exact_tasks"],
        "all_sites_em_task_macro": expected_summary["all_sites_exact_tasks"] / n,
        "consistent_nonempty_tasks": expected_summary["consistent_nonempty_tasks"],
        "tasks_with_site_error": expected_summary["tasks_with_site_error"],
        "native_sampler_calls": expected_summary["native_sampler_calls"],
        "native_forward_calls": expected_summary["native_forward_calls"],
        "integrity": {
            "source_sha256": _sha(data), "run_sha256": _sha(run_path),
            "predictions_sha256": _sha(predictions_path),
            "runner_summary_status": "verified", "stored_native_context": "exact_token_alignment",
            "scorer_sha256": _sha(Path(__file__)),
        },
        "interpretation": "DreamOn native per-site masked output; no forced propagation or repair. Reference agreement is not naming quality or semantic correctness.",
    }
    return result, scored


def write_scores(output: Path, summary: dict, rows: list[dict]) -> None:
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    (output / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    (output / "scores.jsonl").write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    summary, rows = evaluate_run(args.run, args.data)
    write_scores(args.output, summary, rows)
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
