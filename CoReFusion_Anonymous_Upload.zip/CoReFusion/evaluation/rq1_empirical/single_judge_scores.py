"""Decode one blind judge's swapped pairs and matched four-dimensional scores.

This is an evaluator-side, private analysis. It reports model judgments before
human calibration, never treats the original spelling as a gold quality label,
and never removes generation or judge failures from the planned denominator.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
import os
from pathlib import Path
from statistics import median
from typing import Any, Mapping

from .aggregation import validate_judgment
from .judge_runtime import file_sha256, load_requests, select_requests
from .materials import DIMENSIONS, PROTOCOL_VERSION, canonical_hash
from .gpt_oss_20b_run import (
    MODEL_ID as GPT_OSS_MODEL_ID, REVISION as GPT_OSS_REVISION,
    _load_complete_attempts as load_gpt_oss_attempts,
)


VERSION = "single-blind-judge-matched-v1"


def _private_write(path: Path, value: Any, *, jsonl: bool = False) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
        if jsonl:
            for row in value:
                stream.write(json.dumps(row, sort_keys=True, ensure_ascii=False) + "\n")
        else:
            json.dump(value, stream, sort_keys=True, ensure_ascii=False, indent=2)
            stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def _judgment(attempt: Mapping[str, Any] | None, kind: str) -> tuple[dict[str, Any] | None, str]:
    if attempt is None:
        return None, "missing"
    if attempt["status"] != "valid":
        return None, attempt["status"]
    try:
        response = validate_judgment(kind, attempt["response"])
    except (ValueError, TypeError, KeyError, json.JSONDecodeError):
        return None, "invalid_response"
    if kind == "pairwise" and response["decision"] == "cannot_judge":
        return None, "cannot_judge"
    if kind == "pointwise" and response["cannot_judge"]:
        return None, "cannot_judge"
    return response, "valid"


def _pair_outcome(request: Mapping[str, Any], response: Mapping[str, Any]) -> str:
    decision = response["decision"]
    if decision == "tie":
        return "T"
    source = request["candidate_sources"].get(decision)
    if source == ["generated"]:
        return "W"
    if source == ["reference"]:
        return "L"
    raise ValueError("Unrecognized private candidate source")


def score(manifest: Mapping[str, Any], attempts: Mapping[str, Mapping[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if (manifest.get("private_only") is not True or manifest.get("protocol_version") != PROTOCOL_VERSION
            or manifest.get("planned_tasks") != len(manifest.get("tasks", {}))):
        raise ValueError("Expected a consistent private S1 material manifest")
    request_map = manifest["requests"]
    task_rows: list[dict[str, Any]] = []
    for task_key, task in sorted(manifest["tasks"].items()):
        language = task["language"]
        row: dict[str, Any] = {
            "task_key": task_key, "language": language,
            "reference_name": task["reference_name"], "predicted_name": task["predicted_name"],
            "source_sha256": task["source_sha256"],
            "prediction_record_sha256": task["prediction_record_sha256"],
            "generation_error": task["generation_error"],
            "pairwise_eligible": task["pairwise_eligible"],
            "identical_candidates": task["identical_candidates"],
            "context_redactions": task["context_redactions"],
            "pointwise": {}, "pairwise_orders": [], "delta": None,
        }
        for rid in task["pointwise_request_ids"]:
            request = request_map[rid]
            if request["kind"] != "pointwise" or request["task_key"] != task_key:
                raise ValueError("Mismatched private pointwise request")
            response, status = _judgment(attempts.get(rid), "pointwise")
            sources = request["candidate_sources"]["candidate"]
            for source in sources:
                if source in row["pointwise"]:
                    raise ValueError("Duplicate candidate-side pointwise score")
                row["pointwise"][source] = {
                    "request_id": rid, "status": status,
                    "scores": response["scores"] if response is not None else None,
                }
        if not task["pairwise_eligible"]:
            row["outcome"] = "U"
            row["reason"] = task["ineligible_reason"]
        elif task["identical_candidates"]:
            row["outcome"] = "T"
            row["reason"] = "identical_names"
        else:
            pair_ids = task["pairwise_request_ids"]
            if len(pair_ids) != 2:
                raise ValueError("A distinct pair must have both A/B orders")
            outcomes = []
            for rid in pair_ids:
                request = request_map[rid]
                if request["kind"] != "pairwise" or request["task_key"] != task_key:
                    raise ValueError("Mismatched private pairwise request")
                response, status = _judgment(attempts.get(rid), "pairwise")
                outcome = _pair_outcome(request, response) if response is not None else "U"
                outcomes.append(outcome)
                row["pairwise_orders"].append({"request_id": rid, "status": status, "outcome": outcome,
                                               "generated_slot": next(slot for slot, source in
                                                                      request["candidate_sources"].items()
                                                                      if source == ["generated"])})
            slots = {item["generated_slot"] for item in row["pairwise_orders"]}
            if slots != {"A", "B"}:
                raise ValueError("Pairwise requests are not swapped")
            if "U" in outcomes:
                row["outcome"] = "U"
                row["reason"] = "incomplete_or_abstained_orders"
            elif outcomes[0] != outcomes[1]:
                row["outcome"] = "U"
                row["reason"] = "order_disagreement"
            else:
                row["outcome"] = outcomes[0]
                row["reason"] = None
        if task["pairwise_eligible"]:
            original = row["pointwise"].get("reference")
            generated = row["pointwise"].get("generated")
            if (original is not None and generated is not None
                    and original["status"] == generated["status"] == "valid"):
                row["delta"] = {dimension: generated["scores"][dimension] - original["scores"][dimension]
                                for dimension in DIMENSIONS}
        if row["delta"] is None:
            row["score_dominance"] = None
        else:
            differences = list(row["delta"].values())
            row["score_dominance"] = (
                "generated" if all(value >= 0 for value in differences) and any(value > 0 for value in differences)
                else "original" if all(value <= 0 for value in differences) and any(value < 0 for value in differences)
                else "equal" if all(value == 0 for value in differences)
                else "tradeoff"
            )
        task_rows.append(row)
    by_language: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in task_rows:
        by_language[row["language"]].append(row)
    groups = {"ALL": task_rows, **dict(sorted(by_language.items()))}
    summary_groups: dict[str, Any] = {}
    for language, rows in groups.items():
        outcome_counts = Counter(row["outcome"] for row in rows)
        reasons = Counter(row["reason"] for row in rows if row["reason"])
        pair_status = Counter(item["status"] for row in rows for item in row["pairwise_orders"])
        point_status = Counter(item["status"] for row in rows for item in row["pointwise"].values())
        raw_position_choices = Counter()
        for row in rows:
            for item in row["pairwise_orders"]:
                response = attempts.get(item["request_id"], {}).get("response")
                if item["status"] == "valid" and isinstance(response, Mapping):
                    raw_position_choices[response["decision"]] += 1
        eligible = sum(row["pairwise_eligible"] for row in rows)
        decidable = sum(outcome_counts[key] for key in "WTL")
        matched = [row for row in rows if row["delta"] is not None]
        dominance = Counter(row["score_dominance"] for row in matched)
        dimensions: dict[str, Any] = {}
        for dimension in DIMENSIONS:
            changes = [row["delta"][dimension] for row in matched]
            original_scores = [row["pointwise"]["reference"]["scores"][dimension] for row in matched]
            generated_scores = [row["pointwise"]["generated"]["scores"][dimension] for row in matched]
            dimensions[dimension] = {
                "matched_tasks": len(changes),
                "improved": sum(value > 0 for value in changes),
                "unchanged": sum(value == 0 for value in changes),
                "degraded": sum(value < 0 for value in changes),
                "median_delta": median(changes) if changes else None,
                "mean_delta_descriptive": sum(changes) / len(changes) if changes else None,
                "mean_original_on_matched": sum(original_scores) / len(original_scores) if changes else None,
                "mean_generated_on_matched": sum(generated_scores) / len(generated_scores) if changes else None,
            }
        summary_groups[language] = {
            "planned_tasks": len(rows), "pairwise_eligible": eligible,
            "identical_candidates": sum(row["identical_candidates"] for row in rows),
            "decidable_tasks": decidable,
            "counts": {key: outcome_counts[key] for key in "WTLU"},
            "unresolved_reasons": dict(sorted(reasons.items())),
            "order_disagreements": reasons["order_disagreement"],
            "pairwise_request_statuses": dict(sorted(pair_status.items())),
            "pointwise_candidate_statuses": dict(sorted(point_status.items())),
            "raw_pairwise_position_choices": dict(sorted(raw_position_choices.items())),
            "matched_score_dominance": dict(sorted(dominance.items())),
            "pairwise_dominance_contradictions": sum(
                (row["outcome"] == "W" and row["score_dominance"] == "original")
                or (row["outcome"] == "L" and row["score_dominance"] == "generated")
                for row in matched),
            "tie_adjusted_preference_conditional":
                (outcome_counts["W"] + 0.5 * outcome_counts["T"]) / decidable if decidable else None,
            "decision_coverage_over_planned": decidable / len(rows) if rows else None,
            "dimensions": dimensions,
        }
    summary = {
        "version": VERSION, "judge_count": 1, "blind_swapped_orders_required": True,
        "planned_tasks": len(task_rows), "groups": summary_groups,
        "interpretation": "Provisional model judgments, pending independent human calibration. Ordinal score means are descriptive; every delta uses the same task/context.",
    }
    return task_rows, summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--private-manifest", type=Path, required=True)
    parser.add_argument("--requests", type=Path, required=True)
    parser.add_argument("--requests-sha256", required=True)
    parser.add_argument("--selection", type=Path)
    parser.add_argument("--ledger", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.private_manifest.read_text(encoding="utf-8"))
    requests = load_requests(args.requests, args.requests_sha256)
    if manifest["judge_requests_sha256"] != args.requests_sha256:
        raise ValueError("Private and public request hash differs")
    selection = json.loads(args.selection.read_text(encoding="utf-8")) if args.selection else None
    chosen = select_requests(requests, selection, expected_hash=args.requests_sha256)
    if set(manifest["requests"]) != {request["request_id"] for request in chosen}:
        raise ValueError("Private manifest must match exactly the selected judge requests")
    run_config = json.loads((args.ledger.parent / "run_config.json").read_text(encoding="utf-8"))
    version = run_config.get("version")
    if (run_config.get("requests_sha256") != args.requests_sha256
            or run_config.get("public_file_sha256") != file_sha256(args.requests)):
        raise ValueError("Judge run does not match selected public materials")
    if version == "gpt-oss-20b-harmony-blind-v1":
        if (run_config.get("model_id") != GPT_OSS_MODEL_ID
                or run_config.get("revision") != GPT_OSS_REVISION
                or run_config.get("selection_sha256") !=
                (canonical_hash(selection) if selection else None)):
            raise ValueError("GPT-OSS configuration differs from the frozen run")
        attempts = load_gpt_oss_attempts(args.ledger, chosen)
    elif version == "glm47-blind-dev56-json-prefill-v1":
        raise ValueError(
            "The legacy GLM 4.7 development ledger is outside this core-code package."
        )
    else:
        raise ValueError(f"Unsupported judge runner version: {version!r}")
    expected_ids = {request["request_id"] for request in chosen}
    if set(attempts) != expected_ids:
        raise ValueError(f"Incomplete judge ledger: {len(attempts)}/{len(expected_ids)} requests")
    rows, summary = score(manifest, attempts)
    summary["inputs"] = {
        "decoder_sha256": file_sha256(Path(__file__)),
        "private_manifest_sha256": file_sha256(args.private_manifest),
        "public_requests_sha256": file_sha256(args.requests),
        "selection_sha256": file_sha256(args.selection) if args.selection else None,
        "run_config_sha256": file_sha256(args.ledger.parent / "run_config.json"),
        "attempts_sha256": file_sha256(args.ledger),
        "judge_model_id": run_config.get("model_id"),
        "judge_revision": run_config.get("revision"),
        "runner_version": version,
        "prompt_version": run_config.get("prompt_version"),
        "parser_version": run_config.get("parser_version"),
        "reasoning_effort": run_config.get("reasoning_effort"),
        "adapter_sha256": (run_config.get("smoke_adapter_sha256")
                           or run_config.get("format_adapter_sha256")),
        "model_receipt_sha256": run_config.get("model_receipt", {}).get("receipt_sha256"),
        "max_total_tokens": run_config.get("max_total_tokens"),
        "max_new_tokens": run_config.get("max_new_tokens"),
    }
    args.output.mkdir(parents=True, exist_ok=False, mode=0o700)
    _private_write(args.output / "task_scores.jsonl", rows, jsonl=True)
    summary["task_scores_sha256"] = file_sha256(args.output / "task_scores.jsonl")
    _private_write(args.output / "summary.json", summary)
    print(json.dumps({"planned_tasks": len(rows), "counts": summary["groups"]["ALL"]["counts"],
                      "output": str(args.output)}, sort_keys=True))


if __name__ == "__main__":
    main()
