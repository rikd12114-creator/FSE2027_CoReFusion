"""Offline, source-blind naming-evaluation material and verdict contracts."""
