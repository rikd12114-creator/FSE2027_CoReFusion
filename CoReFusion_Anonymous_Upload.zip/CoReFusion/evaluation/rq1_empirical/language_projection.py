"""Verify a completed S1 run and score syntax on reconstructed source.

The Stack v3 release adds spaces around ``[MASK]``.  This evaluation restores
the SHA-verified original source and applies names at its original character
spans.  These *normalized source projections* are offline diagnostics, not the
masked-text patches produced by the S1 runner.  ReFineID Java has no original
source/provenance receipt, so its reconstruction is explicitly unverified.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
from typing import Any

from evaluation.rq1_empirical.static_eval import evaluate_run
from experiments.rq1_empirical.data_contract import restore_stack_snapshot, sha256_file
from experiments.rq1_empirical.language_eval import (
    canonical_language, dependency_receipt, evaluate_campaign,
    valid_identifier as language_valid_identifier,
)
from experiments.rq1_empirical.policy import apply_once, valid_identifier as runner_valid_identifier
from experiments.rq1_empirical.runner import PROMPT_VERSION
from experiments.rq1_empirical.schema import CONTEXT_CHARS, RenameTask, load_tasks


VERSION = "rq1-s1-language-projection-v1-20260924"
MODE = "s1_generate_once_propagate_all_supplied_sites"
FROZEN_CONFIG_SHA256 = "715cf4100af409c56ea87cdd68238ecf50789e3a0c8fb99a0f93e0807fcccfba"


def _digest(value: Any) -> str:
    data = json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _source_digest(source: str) -> str:
    return hashlib.sha256(source.encode("utf-8")).hexdigest()


def _json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def _jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("rb") as stream:
        content = stream.read()
    if content and not content.endswith(b"\n"):
        raise ValueError(f"Incomplete final JSONL line: {path}")
    records = [json.loads(line) for line in content.decode("utf-8").splitlines()]
    if any(not isinstance(row, dict) for row in records):
        raise ValueError(f"JSONL contains a non-object row: {path}")
    return records


def _contained(root: Path, relative: str) -> Path:
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise ValueError(f"Expected repository-relative input path: {relative!r}")
    root = root.resolve()
    path = (root / relative).resolve()
    if path != root and root not in path.parents:
        raise ValueError(f"Input path escapes repository root: {relative}")
    return path


def _frozen_spec(root: Path, config_path: Path, language: str) -> tuple[dict[str, Any], dict[str, Any]]:
    config = _json(config_path)
    if config.get("schema_version") != 1 or not isinstance(config.get("datasets"), list):
        raise ValueError("Unsupported frozen dataset configuration")
    matches = [spec for spec in config["datasets"]
               if isinstance(spec, dict) and canonical_language(spec.get("language")) ==
               canonical_language(language)]
    if len(matches) != 1:
        raise ValueError(f"Expected exactly one frozen dataset for {language}")
    spec = matches[0]
    if not isinstance(spec.get("expected_rows"), int) or not isinstance(spec.get("expected_sites"), int):
        raise ValueError("Frozen dataset lacks row/site denominators")
    csv_relative = (f"{spec['release_dir']}/test.csv" if spec.get("release_dir")
                    else spec.get("csv"))
    csv_path = _contained(root, csv_relative)
    if sha256_file(csv_path) != spec.get("csv_sha256"):
        raise ValueError("CSV SHA-256 differs from frozen dataset configuration")
    files: dict[str, Any] = {"csv_path": str(csv_path), "csv_sha256": sha256_file(csv_path)}
    if spec.get("release_dir"):
        release = spec["release_dir"]
        manifest_path = _contained(root, f"{release}/manifest.json")
        provenance_path = _contained(root, f"{release}/provenance.jsonl")
        if sha256_file(manifest_path) != spec.get("release_manifest_sha256"):
            raise ValueError("Release manifest SHA-256 differs from frozen configuration")
        if sha256_file(provenance_path) != spec.get("provenance_sha256"):
            raise ValueError("Provenance SHA-256 differs from frozen configuration")
        manifest = _json(manifest_path)
        if manifest.get("schema_version") != 1 or manifest.get("language") != spec["language"]:
            raise ValueError("Release manifest identity differs from frozen configuration")
        members = manifest.get("files")
        if not isinstance(members, dict) or not {"test.csv", "provenance.jsonl"} <= members.keys():
            raise ValueError("Release manifest omits required source members")
        for name, expected in members.items():
            path = _contained(root, f"{release}/{name}")
            if sha256_file(path) != expected:
                raise ValueError(f"Release member SHA-256 mismatch: {name}")
        files.update({"release_manifest_path": str(manifest_path),
                      "release_manifest_sha256": sha256_file(manifest_path),
                      "provenance_path": str(provenance_path),
                      "provenance_sha256": sha256_file(provenance_path),
                      "release_members_sha256_verified": True})
    elif canonical_language(language) != "java" or spec.get("dataset") != "refineid":
        raise ValueError("Only legacy ReFineID Java may omit release provenance")
    return spec, files


def _validate_provenance(tasks: list[RenameTask], spec: dict[str, Any],
                         files: dict[str, Any]) -> dict[str, dict[str, Any]]:
    if not spec.get("release_dir"):
        return {}
    rows = _jsonl(Path(files["provenance_path"]))
    if len(rows) != len(tasks):
        raise ValueError("Provenance row count differs from complete CSV cohort")
    by_key: dict[str, dict[str, Any]] = {}
    for task, row in zip(tasks, rows):
        if (row.get("id") != task.task_id or row.get("target") != task.reference_name
                or row.get("language") != task.language):
            raise ValueError(f"Provenance identity differs from CSV: {task.key}")
        if row.get("masked_sha256") != _source_digest(task.code_masked):
            raise ValueError(f"Masked source SHA-256 mismatch: {task.key}")
        if row.get("occurrence_count") != task.sites:
            raise ValueError(f"Provenance site count mismatch: {task.key}")
        restored = restore_stack_snapshot(task.code_masked, task.reference_name,
                                          row.get("target_spans"))
        if _source_digest(restored) != row.get("original_sha256"):
            raise ValueError(f"Restored original source SHA-256 mismatch: {task.key}")
        if len(restored.encode("utf-8")) != row.get("size_bytes"):
            raise ValueError(f"Restored original source byte length mismatch: {task.key}")
        by_key[task.key] = row
    if len(by_key) != len(tasks):
        raise ValueError("Provenance contains duplicate task identity")
    return by_key


def _validate_run(run_dir: Path, tasks: list[RenameTask], spec: dict[str, Any],
                  files: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any]]:
    contract_path = run_dir / "run.json"
    predictions_path = run_dir / "predictions.jsonl"
    summary_path = run_dir / "summary.json"
    contract = _json(contract_path)
    rows = _jsonl(predictions_path)
    runner_summary = _json(summary_path)
    if contract.get("schema_version") != 1 or contract.get("mode") != MODE:
        raise ValueError("Unsupported run schema or application mode")
    if contract.get("prompt_version") != PROMPT_VERSION or contract.get("context_char_limit") != CONTEXT_CHARS:
        raise ValueError("Run prompt version or context crop differs from current pinned protocol")
    if contract.get("source_sha256") != files["csv_sha256"]:
        raise ValueError("Run source SHA-256 differs from frozen CSV")
    keys = [task.key for task in tasks]
    if contract.get("task_keys") != keys:
        raise ValueError("Run task keys differ from complete frozen CSV cohort/order")
    identity = [(task.key, task.code_masked, task.reference_name) for task in tasks]
    if contract.get("task_identity_sha256") != _digest(identity):
        raise ValueError("Run task identity SHA-256 mismatch")
    if len(rows) != len(tasks):
        raise ValueError(f"Incomplete prediction run: {len(rows)}/{len(tasks)}")
    for task, row in zip(tasks, rows):
        if (row.get("task_key"), row.get("dataset"), row.get("language"), row.get("id"),
            row.get("reference_name"), row.get("expected_sites")) != (
                task.key, task.dataset, task.language, task.task_id,
                task.reference_name, task.sites):
            raise ValueError(f"Prediction identity/reference/site mismatch: {task.key}")
        name = row.get("predicted_name")
        if name is not None and not isinstance(name, str):
            raise ValueError(f"Prediction name must be string or null: {task.key}")
        metrics = row.get("metrics")
        if not isinstance(metrics, dict) or "error" not in metrics:
            raise ValueError(f"Prediction metrics absent: {task.key}")
        if metrics["error"] is not None and not isinstance(metrics["error"], str):
            raise ValueError(f"Prediction error must be string or null: {task.key}")
        applied = apply_once(task, name, error=metrics["error"])
        expected_metrics = {k: v for k, v in asdict(applied).items()
                            if k not in {"task_key", "patched_code", "predicted_name"}}
        if any(metrics.get(key) != value for key, value in expected_metrics.items()):
            raise ValueError(f"Prediction application receipt mismatch: {task.key}")
    checks = {
        "planned_tasks": len(tasks), "completed_tasks": len(rows),
        "expected_sites": sum(task.sites for task in tasks),
        "error_tasks": sum(row["metrics"]["error"] is not None for row in rows),
        "valid_name_tasks": sum(row["metrics"]["valid_name"] for row in rows),
        "all_sites_exact_tasks": sum(row["metrics"]["all_sites_exact"] for row in rows),
        "consistent_nonempty_tasks": sum(row["metrics"]["consistent_nonempty"] for row in rows),
        "predictions_sha256": sha256_file(predictions_path),
        "contract_sha256": sha256_file(contract_path),
    }
    if any(runner_summary.get(key) != value for key, value in checks.items()):
        raise ValueError("Runner summary count or SHA-256 receipt mismatch")
    # A second evaluator checks prompt hashes, backend status, site propagation,
    # and the original masked-text patch receipt without using prior scores.
    static_summary, _ = evaluate_run(run_dir, data=files["csv_path"], require_complete=True)
    if static_summary["integrity"]["runner_summary_status"] != "verified":
        raise ValueError("Static evaluator could not verify complete runner summary")
    return contract, rows, static_summary


def evaluate_projection(*, root: str | Path, run_dir: str | Path,
                        language: str, config: str | Path =
                        "configs/rq1_empirical/datasets.json",
                        rust_edition: int = 2024,
                        expected_config_sha256: str = FROZEN_CONFIG_SHA256,
                        ) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Return an audited campaign summary and one projection row per planned task."""
    root = Path(root).resolve()
    run_dir = Path(run_dir).resolve()
    config_path = Path(config)
    if not config_path.is_absolute():
        config_path = _contained(root, str(config_path))
    if sha256_file(config_path) != expected_config_sha256:
        raise ValueError("Dataset configuration SHA-256 differs from frozen study pin")
    spec, files = _frozen_spec(root, config_path, language)
    tasks = load_tasks(files["csv_path"], dataset=spec["dataset"], language=spec["language"])
    if len(tasks) != spec["expected_rows"] or sum(task.sites for task in tasks) != spec["expected_sites"]:
        raise ValueError("CSV row/site count differs from frozen dataset configuration")
    provenance = _validate_provenance(tasks, spec, files)
    contract, predictions, static_summary = _validate_run(run_dir, tasks, spec, files)
    by_key = {task.key: row for task, row in zip(tasks, predictions)}
    names = {key: row["predicted_name"] for key, row in by_key.items()}
    errors = {key: row["metrics"]["error"] for key, row in by_key.items()
              if row["metrics"]["error"] is not None}
    language_report = evaluate_campaign(tasks, names, provenance_by_key=provenance,
                                        errors_by_key=errors, rust_edition=rust_edition)
    records: list[dict[str, Any]] = []
    predicted_disagreements = reference_disagreements = 0
    runner_accepted_language_rejected = language_accepted_runner_rejected = 0
    projection_equals_runner = 0
    for task, language_row in zip(tasks, language_report["records"]):
        predicted = by_key[task.key]
        runner_valid = runner_valid_identifier(predicted["predicted_name"], task.language)
        language_valid = language_valid_identifier(predicted["predicted_name"], task.language,
                                                   rust_edition=rust_edition)
        runner_reference_valid = runner_valid_identifier(task.reference_name, task.language)
        language_reference_valid = language_valid_identifier(task.reference_name, task.language,
                                                             rust_edition=rust_edition)
        predicted_disagreements += runner_valid != language_valid
        reference_disagreements += runner_reference_valid != language_reference_valid
        runner_accepted_language_rejected += runner_valid and not language_valid
        language_accepted_runner_rejected += language_valid and not runner_valid
        row = dict(language_row)
        normalized_sha = row.pop("patch_sha256")
        row["normalized_projection_sha256"] = normalized_sha
        row["runner_masked_patch_sha256"] = predicted.get("patch_sha256")
        row["normalized_projection_equals_runner_masked_patch"] = (
            normalized_sha == predicted.get("patch_sha256") if normalized_sha is not None else None)
        projection_equals_runner += row["normalized_projection_equals_runner_masked_patch"] is True
        row["runner_identifier_lexically_valid"] = runner_valid
        row["language_identifier_lexically_valid"] = language_valid
        row["identifier_policy_disagrees"] = runner_valid != language_valid
        row["reference_identifier_policy_disagrees"] = (
            runner_reference_valid != language_reference_valid)
        row["original_source_sha_verified"] = bool(spec.get("release_dir"))
        row["projection_kind"] = ("sha_verified_original_span_projection" if spec.get("release_dir")
                                  else "legacy_java_literal_marker_projection_no_original_sha")
        row["record_sha256"] = _digest(row)
        records.append(row)
    summary = {
        "evaluator_version": VERSION, "dataset": spec["dataset"],
        "language": spec["language"], "model_id": contract.get("backend_spec", {}).get("model_id"),
        "model_revision": contract.get("backend_spec", {}).get("revision"),
        "run_mode": MODE, "planned_tasks": len(tasks),
        "expected_sites": sum(task.sites for task in tasks),
        "projection_kind": ("sha_verified_original_span_projection" if spec.get("release_dir")
                            else "legacy_java_literal_marker_projection_no_original_sha"),
        "original_source_sha_verified": bool(spec.get("release_dir")),
        "language_evaluation": language_report["summary"],
        "lexical_policy_differences": {
            "predicted_name_disagreement_tasks": predicted_disagreements,
            "runner_accepts_language_rejects_tasks": runner_accepted_language_rejected,
            "language_accepts_runner_rejects_tasks": language_accepted_runner_rejected,
            "reference_name_disagreement_tasks": reference_disagreements,
        },
        "normalized_projection_equals_runner_masked_patch_tasks": projection_equals_runner,
        "integrity": {
            "config_path": str(config_path.resolve()), "config_sha256": sha256_file(config_path),
            "frozen_config_sha256": expected_config_sha256,
            **files,
            "run_contract_path": str(run_dir / "run.json"),
            "run_contract_sha256": sha256_file(run_dir / "run.json"),
            "predictions_path": str(run_dir / "predictions.jsonl"),
            "predictions_sha256": sha256_file(run_dir / "predictions.jsonl"),
            "runner_summary_path": str(run_dir / "summary.json"),
            "runner_summary_sha256": sha256_file(run_dir / "summary.json"),
            "runner_summary_status": "verified",
            "static_evaluator_summary_sha256": _digest(static_summary),
            "static_evaluator_code_sha256": sha256_file(Path(evaluate_run.__code__.co_filename)),
            "language_evaluator_code_sha256": sha256_file(
                Path(evaluate_campaign.__code__.co_filename)),
            "projection_evaluator_code_sha256": sha256_file(Path(__file__)),
            "parser_runtime_receipt_path": str(
                Path(evaluate_campaign.__code__.co_filename).with_name("dependency_receipt.json")),
            "parser_runtime_receipt_sha256": sha256_file(
                Path(evaluate_campaign.__code__.co_filename).with_name("dependency_receipt.json")),
            "parser_runtime": dependency_receipt(),
        },
        "interpretation": (
            "Offline syntax/AST evaluation of normalized source projections. "
            "These are not the runner's masked-text patches; successful parsing "
            "does not prove shared binding, compilation, tests, or behavior. "
            "Legacy ReFineID Java lacks verified original source, character spans, "
            "and per-row provenance."
        ),
    }
    return summary, records


def write_projection(output_dir: str | Path, summary: dict[str, Any],
                     records: list[dict[str, Any]]) -> None:
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=False)
    with (destination / "records.jsonl").open("x", encoding="utf-8") as stream:
        for row in records:
            stream.write(json.dumps(row, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False) + "\n")
    summary = {**summary, "integrity": {**summary["integrity"],
                                        "records_sha256": sha256_file(destination / "records.jsonl")}}
    summary_path = destination / "summary.json"
    with summary_path.open("x", encoding="utf-8") as stream:
        json.dump(summary, stream, sort_keys=True, ensure_ascii=False,
                  indent=2, allow_nan=False)
        stream.write("\n")
    (destination / "summary.sha256").write_text(
        f"{sha256_file(summary_path)}  summary.json\n", encoding="ascii")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--language", required=True)
    parser.add_argument("--config", type=Path,
                        default=Path("configs/rq1_empirical/datasets.json"))
    parser.add_argument("--expected-config-sha256", default=FROZEN_CONFIG_SHA256,
                        help="Frozen dataset-config SHA-256; change only for a new audited study")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--rust-edition", type=int, default=2024,
                        choices=(2015, 2018, 2021, 2024))
    args = parser.parse_args(argv)
    summary, records = evaluate_projection(
        root=args.root, run_dir=args.run_dir, language=args.language,
        config=args.config, rust_edition=args.rust_edition,
        expected_config_sha256=args.expected_config_sha256)
    write_projection(args.output_dir, summary, records)
    print(json.dumps({
        "output_dir": str(args.output_dir.resolve()),
        "language": summary["language"], "planned_tasks": summary["planned_tasks"],
        "syntax_eligible_tasks": summary["language_evaluation"]["parse_eligibility"]["eligible_tasks"],
        "patch_parse_success_tasks": summary["language_evaluation"]["patch_parse_success"]["numerator"],
        "lexical_policy_disagreement_tasks": summary["lexical_policy_differences"]["predicted_name_disagreement_tasks"],
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
