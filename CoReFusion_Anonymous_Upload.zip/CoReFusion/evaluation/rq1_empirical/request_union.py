"""Deduplicate identical blind judge requests across generator conditions.

This runs on evaluator-side private manifests, but writes only anonymous public
requests to the judge input file. A fixed task-key selection may be supplied
for the same source-row sample across models. No judge or test call is made.
"""

from __future__ import annotations

import argparse
from collections import Counter
import json
import os
from pathlib import Path
from typing import Any

from .judge_runtime import file_sha256, load_requests
from .materials import PROTOCOL_VERSION, canonical_hash


def _path(index: Path, value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else index.parent / path


def build(index_path: Path, task_selection_path: Path | None = None
          ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    index = json.loads(index_path.read_text(encoding="utf-8"))
    cells = index.get("cells")
    if (index.get("schema_version") != 1 or not isinstance(cells, list) or not cells
            or len({cell.get("cell_id") for cell in cells}) != len(cells)):
        raise ValueError("Expected unique cells in versioned request-union index")
    selection = None
    if task_selection_path is not None:
        selected = json.loads(task_selection_path.read_text(encoding="utf-8"))
        if (selected.get("schema_version") != 1 or not isinstance(selected.get("task_keys"), list)
                or not selected["task_keys"]
                or any(not isinstance(key, str) or not key for key in selected["task_keys"])
                or len(set(selected["task_keys"])) != len(selected["task_keys"])):
            raise ValueError("Expected frozen nonempty unique task-key selection")
        selection = set(selected["task_keys"])
    union: dict[str, dict[str, Any]] = {}
    task_sources: dict[str, tuple[Any, ...]] = {}
    seen_tasks: set[str] = set()
    cell_receipts = []
    common_seed = None
    common_context_limit = None
    duplicate_memberships = 0
    planned_rows = 0
    selected_rows = 0
    request_memberships = 0
    for cell in cells:
        if not isinstance(cell, dict) or set(cell) != {"cell_id", "public_requests", "private_manifest"}:
            raise ValueError("Cell needs id, public request file and private manifest")
        cell_id = cell["cell_id"]
        if not isinstance(cell_id, str) or not cell_id:
            raise ValueError("Invalid cell ID")
        public_path = _path(index_path, cell["public_requests"])
        private_path = _path(index_path, cell["private_manifest"])
        manifest = json.loads(private_path.read_text(encoding="utf-8"))
        if (manifest.get("private_only") is not True
                or manifest.get("protocol_version") != PROTOCOL_VERSION
                or manifest.get("planned_tasks") != len(manifest.get("tasks", {}))):
            raise ValueError(f"Invalid private material manifest: {cell_id}")
        seed = manifest.get("seed")
        context_limit = manifest.get("context_char_limit")
        if not isinstance(seed, str) or not seed or type(context_limit) is not int or context_limit < 1:
            raise ValueError(f"Missing frozen seed or context limit: {cell_id}")
        if common_seed is None:
            common_seed, common_context_limit = seed, context_limit
        if seed != common_seed or context_limit != common_context_limit:
            raise ValueError("All cells must use the same frozen seed and context limit")
        public = load_requests(public_path, manifest["judge_requests_sha256"])
        public_ids = {request["request_id"] for request in public}
        if public_ids != set(manifest["requests"]):
            raise ValueError(f"Public/private request IDs differ: {cell_id}")
        selected_tasks = set(manifest["tasks"]) if selection is None else set(manifest["tasks"]) & selection
        planned_rows += manifest["planned_tasks"]
        selected_rows += len(selected_tasks)
        seen_tasks.update(selected_tasks)
        for task_key, task in manifest["tasks"].items():
            if task_key not in selected_tasks:
                continue
            identity = (task["language"], task["source_sha256"], task["context_sha256"],
                        task["reference_name"], task["expected_sites"], task["visible_sites"])
            previous = task_sources.setdefault(task_key, identity)
            if previous != identity:
                raise ValueError(f"Source/context drift across cells for task {task_key}")
        per_cell = Counter()
        for request in public:
            rid = request["request_id"]
            private = manifest["requests"][rid]
            if private["task_key"] not in selected_tasks:
                continue
            if private["kind"] != request["kind"] or private["task_key"] not in manifest["tasks"]:
                raise ValueError("Private request kind or task mismatch")
            request_memberships += 1
            per_cell[request["kind"]] += 1
            earlier = union.setdefault(rid, request)
            if earlier != request:
                raise ValueError(f"Duplicate request ID has changed public content: {rid}")
            if earlier is not request:
                duplicate_memberships += 1
        cell_receipts.append({
            "cell_id": cell_id, "planned_tasks": manifest["planned_tasks"],
            "selected_tasks": len(selected_tasks), "selected_request_memberships": sum(per_cell.values()),
            "selected_requests_by_kind": dict(sorted(per_cell.items())),
            "public_file_sha256": file_sha256(public_path),
            "private_manifest_sha256": file_sha256(private_path),
            "public_canonical_sha256": manifest["judge_requests_sha256"],
        })
    if selection is not None and seen_tasks != selection:
        raise ValueError("Task selection contains unknown source rows")
    requests = [union[rid] for rid in sorted(union)]
    counts = Counter(request["kind"] for request in requests)
    receipt = {
        "version": "blind-request-union-v1", "protocol_version": PROTOCOL_VERSION,
        "cells": cell_receipts, "cells_count": len(cell_receipts),
        "shared_seed": common_seed, "shared_context_char_limit": common_context_limit,
        "planned_model_task_rows": planned_rows,
        "selected_model_task_rows": selected_rows,
        "selected_distinct_source_tasks": len(seen_tasks),
        "request_memberships_before_dedup": request_memberships,
        "duplicate_request_memberships": duplicate_memberships,
        "unique_requests": len(requests),
        "unique_requests_by_kind": dict(sorted(counts.items())),
        "public_canonical_sha256": canonical_hash(requests),
        "task_selection_file_sha256": file_sha256(task_selection_path) if task_selection_path else None,
        "interpretation": "Exact public-request deduplication only. One judge response may be reused for byte-identical task/context/candidate requests across generator conditions; every model-task denominator remains in its own private manifest.",
    }
    return requests, receipt


def write(requests: list[dict[str, Any]], receipt: dict[str, Any], output: Path,
          *, shards: int) -> None:
    if shards < 1 or shards > len(requests):
        raise ValueError("Shard count must be 1 through number of unique requests")
    output.mkdir(parents=True, exist_ok=False, mode=0o700)
    public_path = output / "judge_requests.jsonl"
    with public_path.open("x", encoding="utf-8", newline="\n") as stream:
        for request in requests:
            stream.write(json.dumps(request, sort_keys=True, ensure_ascii=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    public_path.chmod(0o600)
    receipt["public_file_sha256"] = file_sha256(public_path)
    buckets = [[] for _ in range(shards)]
    for request in requests:
        rid = request["request_id"]
        buckets[int(rid, 16) % shards].append(rid)
    if any(not bucket for bucket in buckets):
        raise ValueError("Hash sharding produced an empty shard; use fewer shards")
    shard_dir = output / "shards"
    shard_dir.mkdir(mode=0o700)
    shard_receipts = []
    for index, ids in enumerate(buckets):
        path = shard_dir / f"selection-{index:04d}.json"
        selection = {"protocol_version": PROTOCOL_VERSION,
                     "requests_sha256": receipt["public_canonical_sha256"],
                     "selection_policy": "request_id_integer_modulo_shard_count",
                     "shard_index": index, "shards": shards,
                     "request_ids": ids}
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(selection, stream, sort_keys=True, ensure_ascii=False, indent=2)
            stream.write("\n")
        shard_receipts.append({"shard_index": index, "requests": len(ids),
                               "file_sha256": file_sha256(path)})
    receipt["shards"] = shard_receipts
    descriptor = os.open(output / "union_receipt.json", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(receipt, stream, sort_keys=True, ensure_ascii=False, indent=2)
        stream.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--task-selection", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--shards", type=int, default=128)
    args = parser.parse_args()
    requests, receipt = build(args.index, args.task_selection)
    write(requests, receipt, args.output, shards=args.shards)
    print(json.dumps({"unique_requests": receipt["unique_requests"],
                      "selected_model_task_rows": receipt["selected_model_task_rows"],
                      "request_memberships_before_dedup": receipt["request_memberships_before_dedup"],
                      "output": str(args.output)}, sort_keys=True))


if __name__ == "__main__":
    main()
