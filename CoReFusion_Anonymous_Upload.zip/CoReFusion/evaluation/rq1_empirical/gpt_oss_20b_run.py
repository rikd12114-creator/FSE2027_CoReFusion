"""Offline GPT-OSS blind naming judge with the checkpoint's Harmony protocol.

Only public, anonymous requests enter this process. The private candidate map is
decoded later by ``single_judge_scores``. A synthetic smoke is a prerequisite
for using this on dev or test data; this module does not declare that gate met.
"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from typing import Any

from evaluation.rq1_empirical.aggregation import validate_judgment
from evaluation.rq1_empirical.judge_runtime import (
    file_sha256, load_requests, select_requests, verify_receipt,
)
from evaluation.rq1_empirical.materials import canonical_hash
from experiments.rq1_empirical.gpt_oss_20b_judge_smoke_v2 import (
    REASONING_EFFORT, _encode, _messages, extract_harmony_final,
)
from experiments.rq1_empirical.gpt_oss_20b_integrity import MODEL_ID, REVISION


VERSION = "gpt-oss-20b-harmony-blind-v1"


def _write_json(path: Path, value: Any) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, sort_keys=True, ensure_ascii=False, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def _append_jsonl(path: Path, row: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(row, sort_keys=True, ensure_ascii=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def _load_complete_attempts(path: Path, chosen: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """Reject incomplete tails and unexpected request/prompt identities on resume."""
    if not path.exists():
        return {}
    raw = path.read_bytes()
    if raw and not raw.endswith(b"\n"):
        raise ValueError("Incomplete attempt ledger tail; preserve and investigate before resume")
    expected = {request["request_id"]: request for request in chosen}
    rows: dict[str, dict[str, Any]] = {}
    for line_number, line in enumerate(raw.decode("utf-8").splitlines(), 1):
        row = json.loads(line)
        request = expected.get(row.get("request_id"))
        if (request is None or row["request_id"] in rows or row.get("kind") != request["kind"]
                or row.get("request_sha256") != canonical_hash(request)
                or row.get("messages_sha256") != canonical_hash(_messages(request))
                or row.get("status") not in {"valid", "invalid", "over_budget", "backend_error"}):
            raise ValueError(f"Attempt ledger identity mismatch at line {line_number}")
        raw_output = row.get("raw")
        if (not isinstance(raw_output, str)
                or row.get("raw_sha256") != hashlib.sha256(raw_output.encode("utf-8")).hexdigest()):
            raise ValueError(f"Attempt ledger raw-output SHA-256 mismatch at line {line_number}")
        if row["status"] == "valid":
            try:
                validated = validate_judgment(request["kind"], extract_harmony_final(raw_output))
            except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
                raise ValueError(f"Recorded valid response no longer validates at line {line_number}") from exc
            if validated != row.get("response"):
                raise ValueError(f"Recorded parsed response differs from raw output at line {line_number}")
        rows[row["request_id"]] = row
    return rows


def _model_and_tokenizer(model_dir: Path):
    import torch
    import transformers
    from transformers import AutoModelForCausalLM, AutoTokenizer

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU required for the pinned GPT-OSS judge")
    tokenizer = AutoTokenizer.from_pretrained(model_dir, local_files_only=True,
                                               trust_remote_code=False)
    model = AutoModelForCausalLM.from_pretrained(
        model_dir, local_files_only=True, trust_remote_code=False,
        dtype="auto", device_map="auto",
    ).eval()
    raw_map = getattr(model, "hf_device_map", None)
    device_map = ({str(key): str(value) for key, value in raw_map.items()}
                  if isinstance(raw_map, dict) else None)
    if device_map and any(value in {"cpu", "disk", "meta"} for value in device_map.values()):
        raise RuntimeError(f"Checkpoint offloaded according to device map: {device_map}")
    parameter_devices = Counter(str(parameter.device) for parameter in model.parameters())
    if not parameter_devices or any(not name.startswith("cuda") for name in parameter_devices):
        raise RuntimeError(f"Checkpoint parameters are not entirely on CUDA: {dict(parameter_devices)}")
    device = next(model.parameters()).device
    placement = {"hf_device_map": device_map,
                 "parameter_device_counts": dict(sorted(parameter_devices.items())),
                 "allocated_cuda_bytes": torch.cuda.memory_allocated(device)}
    return torch, transformers, tokenizer, model, device, placement


def run(args: argparse.Namespace) -> dict[str, Any]:
    if args.max_total_tokens <= args.max_new_tokens or args.max_new_tokens < 1:
        raise ValueError("Invalid frozen token budget")
    requests = load_requests(args.requests, args.requests_sha256)
    selection = json.loads(args.selection.read_text(encoding="utf-8")) if args.selection else None
    chosen = select_requests(requests, selection, expected_hash=args.requests_sha256)
    receipt = verify_receipt(args.model_dir, model_id=MODEL_ID, revision=REVISION,
                             receipt_path=args.receipt, expected_receipt_sha256=args.receipt_sha256)
    config = {
        "version": VERSION, "model_id": MODEL_ID, "revision": REVISION,
        "reasoning_effort": REASONING_EFFORT, "decode": "greedy",
        "model_dir": str(args.model_dir.resolve()), "model_receipt": receipt,
        "public_file_sha256": file_sha256(args.requests),
        "requests_sha256": args.requests_sha256,
        "selection_sha256": canonical_hash(selection) if selection is not None else None,
        "selected_requests": len(chosen),
        "max_total_tokens": args.max_total_tokens,
        "max_new_tokens": args.max_new_tokens,
        "script_sha256": file_sha256(Path(__file__)),
        "smoke_adapter_sha256": file_sha256(Path(sys.modules[extract_harmony_final.__module__].__file__)),
    }
    args.output.mkdir(parents=True, exist_ok=True)
    config_path = args.output / "run_config.json"
    if config_path.exists():
        if json.loads(config_path.read_text(encoding="utf-8")) != config:
            raise ValueError("Cannot resume with changed judge configuration")
    else:
        if any(args.output.iterdir()):
            raise ValueError("Output directory is not empty")
        _write_json(config_path, config)
    ledger_path = args.output / "attempts.jsonl"
    completed = _load_complete_attempts(ledger_path, chosen)
    if len(completed) < len(chosen):
        torch, transformers, tokenizer, model, device, placement = _model_and_tokenizer(args.model_dir)
        environment = {
            "torch": torch.__version__, "transformers": transformers.__version__,
            "python": sys.version.split()[0], "gpu": torch.cuda.get_device_name(device),
            "model_dtype": str(next(model.parameters()).dtype),
            "placement": placement,
        }
        env_path = args.output / "runtime_environment.json"
        if env_path.exists():
            if json.loads(env_path.read_text(encoding="utf-8")) != environment:
                raise ValueError("Cannot resume under a changed runtime environment")
        else:
            _write_json(env_path, environment)
        eos = model.generation_config.eos_token_id
        eos_ids = set(eos if isinstance(eos, list) else [eos])
        for request in chosen:
            rid = request["request_id"]
            if rid in completed:
                continue
            started = time.perf_counter()
            row: dict[str, Any] = {
                "request_id": rid, "kind": request["kind"],
                "request_sha256": canonical_hash(request),
                "messages_sha256": canonical_hash(_messages(request)),
                "status": "backend_error", "response": None, "raw": "",
                "error": None, "input_tokens": None, "output_tokens": None,
            }
            try:
                batch, input_tokens = _encode(tokenizer, request)
                row["input_tokens"] = input_tokens
                if input_tokens + args.max_new_tokens > args.max_total_tokens:
                    row["status"] = "over_budget"
                    row["error"] = "prompt_exceeds_frozen_token_budget"
                else:
                    inputs = {key: value.to(device) for key, value in batch.items()
                              if key in {"input_ids", "attention_mask"} and hasattr(value, "to")}
                    with torch.inference_mode():
                        generated = model.generate(
                            **inputs, max_new_tokens=args.max_new_tokens,
                            do_sample=False, pad_token_id=tokenizer.pad_token_id,
                        )
                    tail = generated[0, input_tokens:].tolist()
                    row["output_tokens"] = len(tail)
                    row["raw"] = tokenizer.decode(tail, skip_special_tokens=False,
                                                  clean_up_tokenization_spaces=False)
                    if len(tail) >= args.max_new_tokens and (not tail or tail[-1] not in eos_ids):
                        row["status"] = "invalid"
                        row["error"] = "truncated_generation"
                    else:
                        try:
                            final = extract_harmony_final(row["raw"])
                            row["response"] = validate_judgment(request["kind"], final)
                            row["status"] = "valid"
                        except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
                            row["status"] = "invalid"
                            row["error"] = f"{type(exc).__name__}: {exc}"[:250]
            except Exception as exc:
                row["status"] = "backend_error"
                row["error"] = f"{type(exc).__name__}: {exc}"[:250]
            row["raw_sha256"] = hashlib.sha256(row["raw"].encode("utf-8")).hexdigest()
            row["elapsed_s"] = round(time.perf_counter() - started, 6)
            _append_jsonl(ledger_path, row)
            completed[rid] = row
            print(json.dumps({"completed": len(completed), "planned": len(chosen),
                              "request_id": rid, "status": row["status"]}), flush=True)
    counts = Counter(row["status"] for row in completed.values())
    summary = {
        "version": VERSION, "model_id": MODEL_ID, "revision": REVISION,
        "planned_requests": len(chosen), "attempted_requests": len(completed),
        "counts": dict(sorted(counts.items())),
        "config_sha256": file_sha256(config_path),
        "ledger_sha256": file_sha256(ledger_path) if ledger_path.exists() else None,
        "complete": len(completed) == len(chosen),
        "interpretation": "Anonymous model judgments; validity and calibration require separate review.",
    }
    summary_path = args.output / "coverage.json"
    if summary_path.exists():
        if json.loads(summary_path.read_text(encoding="utf-8")) != summary:
            raise ValueError("Existing coverage receipt differs from ledger")
    else:
        _write_json(summary_path, summary)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--requests", type=Path, required=True)
    parser.add_argument("--requests-sha256", required=True)
    parser.add_argument("--selection", type=Path)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--receipt-sha256", required=True)
    parser.add_argument("--max-total-tokens", type=int, default=8192)
    parser.add_argument("--max-new-tokens", type=int, default=512)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args), sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
