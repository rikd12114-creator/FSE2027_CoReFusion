"""Paired, SHA-audited relative naturalness change for Stack-v3 dev S1.

This is an auxiliary code-naturalness proxy. It applies the published RNC
formula to a fixed first-site source window, not a claim about human naming
quality or a reproduction of the original program-repair experiment.
"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
import os
from pathlib import Path
import re
import statistics
from typing import Any

VERSION = "stack-v3-dev-rnc-cropped-v1"
DEFAULT_CONTEXT_CHARS = 4096
DEFAULT_MAX_TOKENS = 2048
MIN_BASELINE_CE = 1e-6
_HEX40 = re.compile(r"[0-9a-f]{40}\Z")
LANGUAGE_SLUGS = {
    "Java": "java", "Python": "python", "JavaScript": "javascript",
    "TypeScript": "typescript", "Go": "go", "Rust": "rust", "C++": "cpp",
}


def digest(data: str | bytes) -> str:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def _read_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"Expected object: {path}")
    return data


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    data = path.read_bytes()
    if data and not data.endswith(b"\n"):
        raise ValueError(f"Incomplete JSONL tail: {path}")
    rows = [json.loads(line) for line in data.decode("utf-8").splitlines()]
    if any(not isinstance(row, dict) for row in rows):
        raise ValueError(f"Non-object JSONL row: {path}")
    return rows


def _write_private_json(path: Path, value: Any) -> None:
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    fd = os.open(path, flags, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def _write_private_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            for row in rows:
                stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def _source_and_spans(task: Any, provenance: dict[str, Any]) -> tuple[str, list[tuple[int, int]]]:
    from experiments.rq1_empirical.data_contract import restore_stack_snapshot
    if (provenance.get("id") != task.task_id
            or provenance.get("language") != task.language
            or provenance.get("target") != task.reference_name
            or provenance.get("occurrence_count") != task.sites
            or provenance.get("masked_sha256") != digest(task.code_masked)):
        raise ValueError(f"Source/provenance mismatch: {task.key}")
    source = restore_stack_snapshot(task.code_masked, task.reference_name,
                                    provenance.get("target_spans"))
    if (digest(source) != provenance.get("original_sha256")
            or len(source.encode("utf-8")) != provenance.get("size_bytes")):
        raise ValueError(f"Original-source receipt mismatch: {task.key}")
    spans = [tuple(pair) for pair in provenance["target_spans"]]
    if any(source[start:end] != task.reference_name for start, end in spans):
        raise ValueError(f"Target span mismatch: {task.key}")
    return source, spans


def paired_window(source: str, spans: list[tuple[int, int]], original: str,
                  candidate: str, *, context_chars: int = DEFAULT_CONTEXT_CHARS,
                  ) -> dict[str, Any]:
    """Project both names into identical original character boundaries.

    A boundary is moved only if it would bisect a target. The window is
    selected before looking at the candidate; no token truncation is allowed.
    """
    if not spans or context_chars < 64 or not candidate:
        raise ValueError("Missing spans, candidate, or sufficient context")
    first_start, first_end = spans[0]
    if first_end - first_start != len(original):
        raise ValueError("First span does not match original name length")
    if len(source) <= context_chars:
        left, right = 0, len(source)
    else:
        left = max(0, min(first_start - context_chars // 2,
                          len(source) - context_chars))
        right = left + context_chars
    for start, end in spans:
        if start < left < end:
            left = start
        if start < right < end:
            right = end
    if not (left <= first_start and first_end <= right):
        raise AssertionError("First target site was omitted")
    before = source[left:right]
    pieces: list[str] = []
    cursor = left
    visible_sites = 0
    for start, end in spans:
        if start < left or end > right:
            continue
        if source[start:end] != original:
            raise ValueError("Target span no longer points to original name")
        pieces.extend((source[cursor:start], candidate))
        cursor = end
        visible_sites += 1
    pieces.append(source[cursor:right])
    after = "".join(pieces)
    if visible_sites < 1:
        raise AssertionError("No target site in selected window")
    return {"code_before": before, "code_after": after,
            "original_char_window": [left, right],
            "visible_sites": visible_sites,
            "outside_window_sites": len(spans) - visible_sites,
            "before_sha256": digest(before), "after_sha256": digest(after)}


def load_verified_dev_run(dev_root: Path, audit: Path, run_dir: Path,
                          language: str) -> list[tuple[Any, dict[str, Any], dict[str, Any]]]:
    """Require a complete, pinned 100-row dev run and return aligned rows."""
    from evaluation.rq1_empirical.dev_judge_calibration import verify_frozen_dev
    from evaluation.rq1_empirical.static_eval import evaluate_run
    from experiments.rq1_empirical.schema import load_tasks
    cohorts, _ = verify_frozen_dev(dev_root, audit)
    if language not in LANGUAGE_SLUGS:
        raise ValueError(f"Unknown frozen language: {language}")
    frozen_tasks = cohorts[language]
    data_path = dev_root / LANGUAGE_SLUGS[language] / "dev.csv"
    summary, _ = evaluate_run(run_dir, data=data_path, require_complete=True)
    if (summary["integrity"]["runner_summary_status"] != "verified"
            or summary["integrity"]["prompt_sha256_validation"] != "verified_current_template"
            or summary["cohort"] != "full_source"
            or summary["planned_tasks"] != 100
            or summary["language"] != language):
        raise ValueError("Dev run failed complete current-template receipt checks")
    contract = _read_json(run_dir / "run.json")
    tasks = load_tasks(data_path, dataset=summary["dataset"], language=language)
    if [(task.task_id, task.code_masked, task.reference_name) for task in tasks] != [
            (task.task_id, task.code_masked, task.reference_name) for task in frozen_tasks]:
        raise ValueError("Run task contents differ from frozen dev rows")
    spec = contract.get("backend_spec", {})
    if (contract.get("source_sha256") != sha256_file(data_path)
            or contract.get("task_keys") != [task.key for task in tasks]
            or not isinstance(spec.get("model_id"), str)
            or not _HEX40.fullmatch(str(spec.get("revision", "")))):
        raise ValueError("Dev run source, task order, or generator revision changed")
    predictions = _read_jsonl(run_dir / "predictions.jsonl")
    provenance = _read_jsonl(dev_root / LANGUAGE_SLUGS[language] / "provenance.jsonl")
    if len(predictions) != len(tasks) or len(provenance) != len(tasks):
        raise ValueError("Incomplete dev prediction or provenance rows")
    for task, prediction, source in zip(tasks, predictions, provenance, strict=True):
        if (prediction.get("task_key") != task.key
                or prediction.get("reference_name") != task.reference_name
                or prediction.get("expected_sites") != task.sites):
            raise ValueError(f"Prediction identity changed: {task.key}")
        _source_and_spans(task, source)
    return list(zip(tasks, predictions, provenance, strict=True))


def prepare_dev(dev_root: Path, audit: Path, run_dir: Path, language: str,
                output: Path, *, context_chars: int = DEFAULT_CONTEXT_CHARS) -> dict[str, Any]:
    from experiments.rq1_empirical.language_eval import evaluate_task
    aligned = load_verified_dev_run(dev_root, audit, run_dir, language)
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True, mode=0o700)
    rows: list[dict[str, Any]] = []
    for task, prediction, provenance in aligned:
        source, spans = _source_and_spans(task, provenance)
        candidate = prediction.get("predicted_name")
        metrics = prediction.get("metrics")
        error = metrics.get("error") if isinstance(metrics, dict) else "missing_metrics"
        structural = evaluate_task(task, candidate, provenance=provenance,
                                   backend_error=error)
        if error is not None:
            status = "generation_or_application_failed"
        elif not structural["valid_identifier"]:
            status = "invalid_candidate"
        elif structural["patch_structure_preserved"] is not True:
            status = "invalid_or_unverified_patch_structure"
        else:
            status = "eligible"
        row: dict[str, Any] = {
            "task_key": task.key, "language": language, "status": status,
            "generation_error": error, "original_name": task.reference_name,
            "candidate_name": candidate, "identifier_kind": provenance.get("identifier_kind"),
            "original_source_sha256": provenance["original_sha256"],
            "prediction_record_sha256": digest(json.dumps(prediction, ensure_ascii=False,
                                                          sort_keys=True, separators=(",", ":"))),
            "expected_sites": task.sites, "patch_structure_preserved": structural["patch_structure_preserved"],
        }
        if status == "eligible":
            row.update(paired_window(source, spans, task.reference_name, candidate,
                                     context_chars=context_chars))
        rows.append(row)
    pairs = output / "pairs.jsonl"
    _write_private_jsonl(pairs, rows)
    statuses = Counter(row["status"] for row in rows)
    receipt = {
        "version": VERSION, "purpose": "private_dev_auxiliary_rnc_pilot",
        "language": language, "planned_tasks": len(rows),
        "planned_sites": sum(row["expected_sites"] for row in rows),
        "status_counts": dict(sorted(statuses.items())),
        "visible_sites_scored_pairs": sum(row.get("visible_sites", 0) for row in rows),
        "outside_window_sites_scored_pairs": sum(row.get("outside_window_sites", 0) for row in rows),
        "identical_eligible_pairs": sum(row.get("before_sha256") == row.get("after_sha256")
                                        for row in rows if row["status"] == "eligible"),
        "context_chars": context_chars,
        "window_policy": "first_target_site_centered_original_character_window",
        "source_boundary_policy": "identical_original_char_boundaries_before_candidate_projection",
        "overflow_policy": "both_tokenized_sides_must_fit_no_truncation",
        "dev_manifest_sha256": sha256_file(dev_root / "manifest.json"),
        "dev_audit_sha256": sha256_file(audit),
        "run_contract_sha256": sha256_file(run_dir / "run.json"),
        "predictions_sha256": sha256_file(run_dir / "predictions.jsonl"),
        "pairs_sha256": sha256_file(pairs),
        "module_sha256": sha256_file(Path(__file__)),
        "interpretation": "Formula-adapted RNC on fixed code windows, not human naming quality.",
    }
    _write_private_json(output / "prepare_receipt.json", receipt)
    return receipt


def rnc_value(before_ce: float, after_ce: float) -> float | None:
    if (not math.isfinite(before_ce) or not math.isfinite(after_ce)
            or before_ce <= MIN_BASELINE_CE or after_ce < 0):
        return None
    return (after_ce - before_ce) / before_ce


def _score_text(model: Any, tokenizer: Any, torch: Any, source: str,
                max_tokens: int) -> dict[str, Any]:
    ids = tokenizer(source, add_special_tokens=True, return_tensors="pt")["input_ids"]
    count = ids.shape[1]
    if count < 2 or count > max_tokens:
        return {"status": "token_count_out_of_range", "tokens": count,
                "cross_entropy": None, "token_ids_sha256": None}
    token_hash = digest(ids.cpu().numpy().astype("<i8", copy=False).tobytes())
    ids = ids.to(next(model.parameters()).device)
    with torch.inference_mode():
        logits = model(input_ids=ids, use_cache=False).logits
        ce = torch.nn.functional.cross_entropy(
            logits[:, :-1, :].float().reshape(-1, logits.shape[-1]),
            ids[:, 1:].reshape(-1), reduction="mean")
    value = float(ce.item())
    return {"status": "ok" if math.isfinite(value) else "nonfinite_cross_entropy",
            "tokens": count, "cross_entropy": value if math.isfinite(value) else None,
            "token_ids_sha256": token_hash}


def score(prepared: Path, model_dir: Path, receipt_path: Path, output: Path, *,
          model_id: str, revision: str, max_tokens: int = DEFAULT_MAX_TOKENS,
          max_tasks: int | None = None,
          selection_manifest: Path | None = None) -> dict[str, Any]:
    if output.exists():
        raise FileExistsError(output)
    prep = _read_json(prepared / "prepare_receipt.json")
    pairs_path = prepared / "pairs.jsonl"
    if prep.get("version") != VERSION or sha256_file(pairs_path) != prep.get("pairs_sha256"):
        raise ValueError("Prepared pair receipt changed")
    rows = _read_jsonl(pairs_path)
    if len(rows) != prep["planned_tasks"] or len({row["task_key"] for row in rows}) != len(rows):
        raise ValueError("Prepared pair denominator or task keys changed")
    if max_tasks is not None and not 1 <= max_tasks <= len(rows):
        raise ValueError("max_tasks must be within the planned task denominator")
    if max_tasks is not None and selection_manifest is not None:
        raise ValueError("Choose either prefix smoke or prespecified pilot manifest")
    selected_rows = rows[:max_tasks]
    selection_sha256 = None
    if selection_manifest is not None:
        pilot = _read_json(selection_manifest)
        tasks = pilot.get("tasks")
        if (pilot.get("private_only") is not True or not isinstance(tasks, dict)
                or pilot.get("planned_tasks") != len(tasks)):
            raise ValueError("Invalid private pilot task manifest")
        selection_sha256 = sha256_file(selection_manifest)
        selected_keys = {key for key, info in tasks.items()
                         if info.get("language") == prep["language"]}
        selected_rows = [row for row in rows if row["task_key"] in selected_keys]
        if not selected_keys or len(selected_rows) != len(selected_keys):
            raise ValueError("Pilot task keys do not match this frozen dev language")
    if not _HEX40.fullmatch(revision) or model_dir.name != revision:
        raise ValueError("Evaluator model directory must be the pinned revision snapshot")
    model_receipt = _read_json(receipt_path)
    if (model_receipt.get("verified") is not True
            or model_receipt.get("model_id") != model_id
            or model_receipt.get("revision") != revision
            or Path(model_receipt.get("model_path", "")).resolve() != model_dir.resolve()):
        raise ValueError("Evaluator model identity differs from verified receipt")
    for name in ("config.json", "tokenizer.json", "tokenizer_config.json"):
        expected = [f["sha256"] for f in model_receipt["files"] if f["path"] == name]
        if len(expected) != 1 or sha256_file(model_dir / name) != expected[0]:
            raise ValueError(f"Evaluator config/tokenizer receipt mismatch: {name}")
    import torch
    import transformers
    tokenizer = transformers.AutoTokenizer.from_pretrained(
        model_dir, local_files_only=True, trust_remote_code=False, use_fast=True)
    model = transformers.AutoModelForCausalLM.from_pretrained(
        model_dir, local_files_only=True, trust_remote_code=False,
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32)
    model.to("cuda" if torch.cuda.is_available() else "cpu")
    model.eval()
    output.mkdir(parents=True, mode=0o700)
    run = {"version": VERSION, "prepared_pairs_sha256": prep["pairs_sha256"],
           "prepared_receipt_sha256": sha256_file(prepared / "prepare_receipt.json"),
           "planned_tasks": len(rows), "attempted_tasks": len(selected_rows),
           "selection_manifest_sha256": selection_sha256,
           "model_id": model_id, "revision": revision,
           "model_receipt_sha256": sha256_file(receipt_path),
           "model_config_sha256": sha256_file(model_dir / "config.json"),
           "tokenizer_sha256": sha256_file(model_dir / "tokenizer.json"),
           "tokenizer_config_sha256": sha256_file(model_dir / "tokenizer_config.json"),
           "torch": torch.__version__, "transformers": transformers.__version__,
           "device": str(next(model.parameters()).device), "dtype": str(next(model.parameters()).dtype),
           "max_tokens": max_tokens, "token_policy": "add_special_tokens_true_no_truncation_mean_next_token_ce",
           "min_baseline_ce": MIN_BASELINE_CE,
           "module_sha256": sha256_file(Path(__file__))}
    _write_private_json(output / "run.json", run)
    scored: list[dict[str, Any]] = []
    score_fd = os.open(output / "scores.jsonl", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(score_fd, "w", encoding="utf-8") as stream:
        for row in selected_rows:
            result: dict[str, Any] = {
                "task_key": row["task_key"], "language": row["language"],
                "pair_status": row["status"],
                "before_sha256": row.get("before_sha256"),
                "after_sha256": row.get("after_sha256"),
                "before": None, "after": None, "rnc": None,
            }
            if row["status"] != "eligible":
                result["status"] = "unscored_pair_ineligible"
            else:
                try:
                    before = _score_text(model, tokenizer, torch, row["code_before"], max_tokens)
                    after = (before.copy() if row["before_sha256"] == row["after_sha256"]
                             else _score_text(model, tokenizer, torch, row["code_after"], max_tokens))
                    result["before"], result["after"] = before, after
                    if before["status"] != "ok" or after["status"] != "ok":
                        result["status"] = "token_count_or_ce_failure"
                    else:
                        result["rnc"] = rnc_value(before["cross_entropy"], after["cross_entropy"])
                        result["status"] = "scored" if result["rnc"] is not None else "small_baseline_ce"
                except Exception as exc:
                    result["status"] = "model_scoring_error"
                    result["error"] = f"{type(exc).__name__}: {exc}"
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
            stream.write(json.dumps(result, ensure_ascii=False, sort_keys=True) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
            scored.append(result)
    vals = [row["rnc"] for row in scored if row["status"] == "scored"]
    status_counts = Counter(row["status"] for row in scored)
    summary = {"version": VERSION, "planned_tasks": len(rows),
               "attempted_tasks": len(scored), "unattempted_tasks": len(rows) - len(scored),
               "status_counts": dict(sorted(status_counts.items())),
               "scored_tasks": len(vals), "negative_rnc": sum(v < 0 for v in vals),
               "zero_rnc": sum(v == 0 for v in vals), "positive_rnc": sum(v > 0 for v in vals),
               "median_rnc": statistics.median(vals) if vals else None,
               "mean_rnc": statistics.mean(vals) if vals else None,
               "run_sha256": sha256_file(output / "run.json"),
               "scores_sha256": sha256_file(output / "scores.jsonl"),
               "scores_file_mode_observed": oct((output / "scores.jsonl").stat().st_mode & 0o777),
               "filesystem_note": "Requested 0600 on creation; NFS ACL may override POSIX mode and deny chmod.",
               "interpretation": "Negative RNC means lower fixed-model code cross entropy, not human naming improvement."}
    _write_private_json(output / "summary.json", summary)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare")
    prep.add_argument("--dev-root", type=Path, required=True)
    prep.add_argument("--dev-audit", type=Path, required=True)
    prep.add_argument("--run-dir", type=Path, required=True)
    prep.add_argument("--language", choices=tuple(LANGUAGE_SLUGS), required=True)
    prep.add_argument("--output", type=Path, required=True)
    prep.add_argument("--context-chars", type=int, default=DEFAULT_CONTEXT_CHARS)
    run = sub.add_parser("score")
    run.add_argument("--prepared", type=Path, required=True)
    run.add_argument("--model-dir", type=Path, required=True)
    run.add_argument("--model-receipt", type=Path, required=True)
    run.add_argument("--model-id", required=True)
    run.add_argument("--revision", required=True)
    run.add_argument("--output", type=Path, required=True)
    run.add_argument("--max-tokens", type=int, default=DEFAULT_MAX_TOKENS)
    run.add_argument("--max-tasks", type=int)
    run.add_argument("--selection-manifest", type=Path,
                     help="Private 56-task judge pilot manifest; score its matching language tasks")
    args = parser.parse_args()
    if args.command == "prepare":
        result = prepare_dev(args.dev_root, args.dev_audit, args.run_dir,
                             args.language, args.output, context_chars=args.context_chars)
    else:
        result = score(args.prepared, args.model_dir, args.model_receipt,
                       args.output, model_id=args.model_id, revision=args.revision,
                       max_tokens=args.max_tokens, max_tasks=args.max_tasks,
                       selection_manifest=args.selection_manifest)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
