"""Independent source/token/canvas scoring for Sumi native all-site dev runs."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from experiments.refineid_comparison.data import build_masked_windows
from experiments.rq1_empirical.policy import valid_identifier
from experiments.rq1_empirical.schema import (
    CONTEXT_CHARS,
    MARKER,
    load_tasks,
    visible_code,
)

VERSION = "rq1-s1-native-sumi-multisite-static-v1-20260925"
RUN_MODE = "s1_native_sumi_multisite_independent_sites"
RUN_VERSION = "s1-native-sumi-fixed4-multisite-windowed-dev-v1"
MODEL_ID = "tohoku-nlp/sumi-7b"
REVISION = "0d20f7becf84340b8a8d71a8dda577a502a5c8dd"
MODEL_LFS_SHA = "f7a548e291a472e17b3888dfb663df2b1da0bc8d6746853f3a2729b7fb4229d6"
SITE_WIDTH = 4
NATIVE_CONTEXT = 2048
SEED = 42
DECODING = {
    "sampler": "adaptive", "num_denoising_steps": 64,
    "temperature": 0.7, "tokens_per_step": 1,
    "anchor_eosbos": False, "trim_at_eos": False,
}
ANCESTRAL_VERSION = "s1-native-sumi-fixed4-multisite-windowed-ancestral-dev-v1"
ANCESTRAL_DECODING = {**DECODING, "sampler": "ancestral"}
FULL_ANCESTRAL_VERSION = "s1-native-sumi-fixed4-multisite-windowed-ancestral-full-v1"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(value: object) -> str:
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode()).hexdigest()


def expected_seed(task_key: str, window_index: int) -> int:
    return int.from_bytes(hashlib.sha256(
        f"{SEED}:{task_key}:{window_index}".encode()).digest()[:4], "big")


def metrics(task: object, names: list[str | None], errors: list[str | None]) -> dict:
    covered_indices = [index for index in range(task.sites)
                       if errors[index] is None and names[index] is not None
                       and valid_identifier(names[index], task.language)]
    complete = len(covered_indices) == task.sites
    return {
        "expected_sites": task.sites,
        "visible_sites": sum(error != "outside_common_visible_code" for error in errors),
        "covered_sites": len(covered_indices),
        "complete_site_coverage": complete,
        "consistent_nonempty": complete and len({names[index] for index in covered_indices}) == 1,
        "exact_sites": sum(names[index] == task.reference_name for index in covered_indices),
        "all_sites_exact": complete and all(name == task.reference_name for name in names),
        "error_sites": sum(error is not None for error in errors),
    }


def patch(code: str, names: list[str]) -> str:
    parts = code.split(MARKER)
    if len(parts) != len(names) + 1:
        raise ValueError("Unrepaired patch site count mismatch")
    return parts[0] + "".join(name + part for name, part in zip(names, parts[1:]))


def evaluate_run(run_dir: Path, data: Path, tokenizer_dir: Path,
                 *, require_complete: bool = True,
                 sampler: str = "adaptive", scope: str = "dev2",
                 language: str = "Java") -> tuple[dict, list[dict]]:
    import transformers
    from transformers import AutoTokenizer

    if transformers.__version__ != "5.8.1":
        raise ValueError("Sumi independent scorer requires Transformers 5.8.1")

    if sampler not in ("adaptive", "ancestral"):
        raise ValueError("Sumi independent scorer requires a frozen native sampler")
    if scope not in ("dev2", "full") or (scope == "full" and sampler != "ancestral"):
        raise ValueError("Sumi independent scorer requires the ancestral full protocol")
    if scope == "dev2" and language != "Java":
        raise ValueError("Sumi dev2 is pinned to the Java holdout")
    expected_version = (FULL_ANCESTRAL_VERSION if scope == "full" else
                        RUN_VERSION if sampler == "adaptive" else ANCESTRAL_VERSION)
    expected_decoding = DECODING if sampler == "adaptive" else ANCESTRAL_DECODING
    expected_dataset = ("stack_v3_refineid_20260924" if scope == "full" else
                        "stack_v3_refineid_dev_20260924")
    expected_tasks = 1000 if scope == "full" else 2

    run_dir, data, tokenizer_dir = Path(run_dir), Path(data), Path(tokenizer_dir)
    contract = json.loads((run_dir / "run.json").read_text(encoding="utf-8"))
    runner_summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
    raw = (run_dir / "predictions.jsonl").read_bytes()
    if raw and not raw.endswith(b"\n"):
        raise ValueError("Incomplete final Sumi native prediction row")
    rows = [json.loads(line) for line in raw.splitlines()]
    if (contract.get("schema_version") != 1 or contract.get("mode") != RUN_MODE
            or contract.get("version") != expected_version
            or contract.get("source_sha256") != sha256(data)
            or contract.get("dataset") != expected_dataset
            or contract.get("language") != language
            or contract.get("model_id") != MODEL_ID or contract.get("revision") != REVISION
            or contract.get("model_weight_sha256") != MODEL_LFS_SHA
            or contract.get("common_visible_code_char_limit") != CONTEXT_CHARS
            or contract.get("native_context_tokens") != NATIVE_CONTEXT
            or contract.get("site_width_tokens") != SITE_WIDTH
            or contract.get("decoding") != expected_decoding
            or contract.get("seed") != SEED
            or contract.get("runtime_precision") != "torch.bfloat16"
            or contract.get("runtime", {}).get("transformers") != "5.8.1"
            or "A40" not in str(contract.get("runtime", {}).get("gpu", ""))):
        raise ValueError("Sumi native run/model/data/protocol contract mismatch")
    tasks = load_tasks(data, dataset=contract["dataset"], language=contract["language"])
    by_key = {task.key: task for task in tasks}
    keys = contract["task_keys"]
    if (len(keys) != expected_tasks or len(set(keys)) != expected_tasks
            or [key.rsplit(":", 1)[-1] for key in keys]
            != [str(index) for index in range(expected_tasks)]
            or any(key not in by_key for key in keys)
            or contract.get("task_identity_sha256") != digest([
                (by_key[key].key, by_key[key].code_masked, by_key[key].reference_name)
                for key in keys])):
        raise ValueError("Sumi frozen dev task identity mismatch")
    if ([row.get("task_key") for row in rows] != keys[:len(rows)]
            or len(rows) > len(keys) or require_complete and len(rows) != len(keys)):
        raise ValueError("Sumi native row order/count mismatch")
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_dir, trust_remote_code=True,
                                               local_files_only=True)
    if (tokenizer.mask_token_id is not None
            or tokenizer.bos_token_id != contract["runtime"]["bos_token_id"]
            or tokenizer.eos_token_id != contract["runtime"]["eos_token_id"]
            or tokenizer.pad_token_id != contract["runtime"]["pad_token_id"]):
        raise ValueError("Pinned Sumi tokenizer/runtime mismatch")
    scored = []
    preserved_windows = 0
    active_slots_across_windows = 0
    owned_site_slots = 0
    position_update_attempts = 0
    for task, row in zip((by_key[key] for key in keys), rows):
        visible = visible_code(task)
        names, errors, raw_names, site_ids, site_windows = (row.get(name) for name in (
            "site_predictions", "site_errors", "site_raw_content", "site_token_ids",
            "site_window_indices"))
        if (row.get("dataset") != task.dataset or row.get("language") != task.language
                or row.get("id") != task.task_id or row.get("reference_name") != task.reference_name
                or row.get("expected_sites") != task.sites
                or row.get("visible_code_sha256") != hashlib.sha256(visible.encode()).hexdigest()
                or not all(isinstance(value, list) and len(value) == task.sites
                           for value in (names, errors, raw_names, site_ids, site_windows))
                or row.get("visible_sites") != visible.count(MARKER)):
            raise ValueError("Sumi native task/site receipt mismatch")
        plan = build_masked_windows(visible, tokenizer, mask_length=SITE_WIDTH,
                                    max_length=NATIVE_CONTEXT)
        if row.get("window_plan") != plan:
            raise ValueError("Sumi native model-visible source window differs from independent tokenizer")
        windows, outputs = plan["windows"], row["window_outputs"]
        if len(windows) != len(outputs) or row["native_sampler_calls"] != len(outputs):
            raise ValueError("Sumi native window/sampler call count mismatch")
        owned_all = []
        for window, output in zip(windows, outputs):
            ids = window["input_ids"]
            spans = window["visible_token_spans"]
            index = window["index"]
            canvas = output["canvas_ids"]
            if (output["window_index"] != index
                    or output["visible_site_indices"] != window["visible_site_indices"]
                    or output["owned_site_indices"] != window["owned_site_indices"]
                    or output["window_seed"] != expected_seed(task.key, index)
                    or output["denoise_end"] != len(ids)
                    or output["canvas_length"] != NATIVE_CONTEXT
                    or len(canvas) != NATIVE_CONTEXT or output["canvas_sha256"] != digest(canvas)
                    or output["native_forward_calls"] != expected_decoding["num_denoising_steps"]
                    or not isinstance(output["elapsed_s"], (int, float))
                    or output["elapsed_s"] < 0
                    or not isinstance(output["gpu_peak_allocated_bytes"], int)
                    or output["gpu_peak_allocated_bytes"] <= 0):
                raise ValueError("Sumi native sampler/window receipt mismatch")
            if scope == "full":
                active_slots = SITE_WIDTH * len(window["visible_site_indices"])
                owned_slots = SITE_WIDTH * len(window["owned_site_indices"])
                expected_attempts = active_slots * expected_decoding["num_denoising_steps"]
                if (output.get("active_site_slots") != active_slots
                        or output.get("owned_site_slots") != owned_slots
                        or output.get("native_position_update_attempts") != expected_attempts):
                    raise ValueError("Sumi ancestral active-slot/step receipt mismatch")
                active_slots_across_windows += active_slots
                owned_site_slots += owned_slots
                position_update_attempts += expected_attempts
            site_positions = set()
            for a, b in spans:
                if b - a != SITE_WIDTH or ids[a:b] != [None] * SITE_WIDTH:
                    raise ValueError("Sumi native four-token source site changed")
                if any(pos in site_positions for pos in range(a, b)):
                    raise ValueError("Sumi native site spans overlap")
                site_positions.update(range(a, b))
            expected_anchors = [[pos, token] for pos, token in enumerate(ids[1:], 1)
                                if pos not in site_positions]
            if (output["frozen_anchors"] != expected_anchors
                    or output["frozen_anchors_sha256"] != digest(expected_anchors)
                    or canvas[0] != tokenizer.bos_token_id
                    or any(canvas[pos] != token for pos, token in expected_anchors)
                    or output["context_unchanged"] is not True):
                raise ValueError("Sumi native frozen source context changed")
            preserved_windows += 1
            offsets = {site: n for n, site in enumerate(window["visible_site_indices"])}
            if len(offsets) != len(window["visible_site_indices"]):
                raise ValueError("Sumi native window has duplicate visible site indices")
            for site in window["owned_site_indices"]:
                a, b = spans[offsets[site]]
                tokens = canvas[a:b]
                if site_windows[site] != index or site_ids[site] != tokens:
                    raise ValueError("Sumi native site output was repaired or propagated")
                raw_text = tokenizer.decode(tokens, skip_special_tokens=False,
                                            clean_up_tokenization_spaces=False)
                if raw_names[site] != raw_text:
                    raise ValueError("Sumi native site raw text differs from original tokens")
                expected_name = raw_text.strip()
                if any(token in tokenizer.all_special_ids for token in tokens):
                    expected_name, expected_error = None, "special_native_site_output"
                elif valid_identifier(expected_name, task.language):
                    expected_error = None
                else:
                    expected_name, expected_error = None, "invalid_native_name_output"
                if names[site] != expected_name or errors[site] != expected_error:
                    raise ValueError("Sumi native parsed name/error differs from raw site")
            owned_all.extend(window["owned_site_indices"])
        if sorted(owned_all) != list(range(row["visible_sites"])):
            raise ValueError("Sumi native windows did not own every visible site once")
        for site in range(row["visible_sites"], task.sites):
            if (names[site], errors[site], raw_names[site], site_ids[site], site_windows[site]) != (
                    None, "outside_common_visible_code", None, None, None):
                raise ValueError("Sumi site outside common crop was silently filled")
        site_score = metrics(task, names, errors)
        if row["metrics"] != site_score:
            raise ValueError("Sumi native runner site metrics differ from independent score")
        source_patch = patch(task.code_masked, [name for name in names if name is not None]) if (
            site_score["complete_site_coverage"]) else None
        patch_sha = hashlib.sha256(source_patch.encode()).hexdigest() if source_patch is not None else None
        if row["patch_sha256"] != patch_sha:
            raise ValueError("Sumi unrepaired full-source patch SHA mismatch")
        scored.append({
            "task_key": task.key, "reference_name": task.reference_name,
            "expected_sites": task.sites, "site_predictions": names, "site_errors": errors,
            "covered_sites": site_score["covered_sites"], "exact_sites": site_score["exact_sites"],
            "complete_site_coverage": site_score["complete_site_coverage"],
            "consistent_nonempty": site_score["consistent_nonempty"],
            "all_sites_exact": site_score["all_sites_exact"],
            "native_sampler_calls": row["native_sampler_calls"],
            "native_forward_calls": sum(w["native_forward_calls"] for w in outputs),
        })
    expected_summary = {
        "planned_tasks": len(keys), "completed_tasks": len(rows),
        "expected_sites": sum(by_key[key].sites for key in keys),
        "covered_sites": sum(row["covered_sites"] for row in scored),
        "exact_sites": sum(row["exact_sites"] for row in scored),
        "all_sites_exact_tasks": sum(row["all_sites_exact"] for row in scored),
        "consistent_nonempty_tasks": sum(row["consistent_nonempty"] for row in scored),
        "tasks_with_site_error": sum(any(error is not None for error in row["site_errors"])
                                     for row in scored),
        "native_sampler_calls": sum(row["native_sampler_calls"] for row in scored),
        "native_forward_calls": sum(row["native_forward_calls"] for row in scored),
        "run_sha256": sha256(run_dir / "run.json"),
        "predictions_sha256": sha256(run_dir / "predictions.jsonl"),
    }
    if scope == "full":
        expected_summary.update({
            "active_site_slots_across_windows": active_slots_across_windows,
            "owned_site_slots": owned_site_slots,
            "native_position_update_attempts": position_update_attempts,
        })
    if any(runner_summary.get(key) != value for key, value in expected_summary.items()):
        raise ValueError("Sumi native runner summary differs from independent recomputation")
    n, sites = len(keys), expected_summary["expected_sites"]
    result = {
        "evaluator_version": VERSION, "run_mode": RUN_MODE,
        "native_sampler": sampler, "scope": scope,
        "dataset": contract["dataset"], "language": contract["language"],
        "planned_tasks": n, "scored_tasks": len(scored),
        "expected_sites": sites, "covered_sites": expected_summary["covered_sites"],
        "site_coverage": expected_summary["covered_sites"] / sites,
        "exact_sites": expected_summary["exact_sites"],
        "site_em_micro": expected_summary["exact_sites"] / sites,
        "all_sites_exact_tasks": expected_summary["all_sites_exact_tasks"],
        "all_sites_em_task_macro": expected_summary["all_sites_exact_tasks"] / n,
        "consistent_nonempty_tasks": expected_summary["consistent_nonempty_tasks"],
        "tasks_with_site_error": expected_summary["tasks_with_site_error"],
        "native_sampler_calls": expected_summary["native_sampler_calls"],
        "native_forward_calls": expected_summary["native_forward_calls"],
        "context_preserved_windows": preserved_windows,
        "integrity": {
            "source_sha256": sha256(data), "run_sha256": expected_summary["run_sha256"],
            "predictions_sha256": expected_summary["predictions_sha256"],
            "runner_summary_status": "verified", "stored_native_context": "exact_frozen_token_check",
            "scorer_sha256": sha256(Path(__file__)),
        },
        "interpretation": "Sumi native per-site frozen-source canvas; no propagation or repair. Reference agreement is not semantic naming quality.",
    }
    if scope == "full":
        result.update({
            "active_site_slots_across_windows": active_slots_across_windows,
            "owned_site_slots": owned_site_slots,
            "native_position_update_attempts": position_update_attempts,
        })
    return result, scored


def write_scores(output: Path, summary: dict, rows: list[dict]) -> None:
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    (output / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    with (output / "scores.jsonl").open("x", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--data", required=True, type=Path)
    parser.add_argument("--tokenizer-dir", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--sampler", choices=("adaptive", "ancestral"),
                        default="adaptive")
    parser.add_argument("--scope", choices=("dev2", "full"), default="dev2")
    parser.add_argument("--language", default="Java")
    args = parser.parse_args()
    summary, rows = evaluate_run(args.run, args.data, args.tokenizer_dir,
                                 sampler=args.sampler, scope=args.scope,
                                 language=args.language)
    write_scores(args.output, summary, rows)
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
