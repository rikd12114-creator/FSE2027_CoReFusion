"""Offline, resumable Hugging Face judge for frozen blind RQ1 requests.

The run command sees only public requests and a verified local checkpoint. The
private answer map is used solely by ``select-calibration`` and the separate
aggregator. No API, network download, reference label, or silent truncation is
part of this runtime. A prepared run is not evidence that a model was GPU-smoked.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Mapping, Protocol, Sequence

from .aggregation import validate_judgment
from .materials import PROTOCOL_VERSION, canonical_hash, response_schema


RUNTIME_VERSION = "hf-local-blind-judge-v1"
SUPPORTED_MODELS = {
    "glm47_flash": "zai-org/GLM-4.7-Flash",
    "gpt_oss_20b": "openai/gpt-oss-20b",
    "devstral_small2": "mistralai/Devstral-Small-2-24B-Instruct-2512",
}
_HEX40 = re.compile(r"[0-9a-f]{40}\Z")
_HEX64 = re.compile(r"[0-9a-f]{64}\Z")
_TERMINATORS = ("<|fim_suffix|>", "<|im_end|>", "<|eot_id|>", "<|endoftext|>", "</s>")


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json_exclusive(path: Path, value: Any) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def load_requests(path: Path, expected_hash: str) -> list[dict[str, Any]]:
    """Check the *entire* public request cohort before selecting a shard."""
    if not _HEX64.fullmatch(expected_hash):
        raise ValueError("Expected canonical request hash must be SHA-256")
    requests: list[dict[str, Any]] = []
    seen: set[str] = set()
    with path.open(encoding="utf-8") as stream:
        for number, line in enumerate(stream, 1):
            row = json.loads(line)
            if not isinstance(row, dict) or set(row) != {"request_id", "kind", "messages", "response_schema"}:
                raise ValueError(f"Invalid public request keys at line {number}")
            rid, kind = row["request_id"], row["kind"]
            if not isinstance(rid, str) or not _HEX64.fullmatch(rid) or rid in seen:
                raise ValueError(f"Invalid or duplicate request ID at line {number}")
            if kind not in ("pairwise", "pointwise") or row["response_schema"] != response_schema(kind):
                raise ValueError(f"Changed judgment schema at line {number}")
            messages = row["messages"]
            if (not isinstance(messages, list) or len(messages) != 2
                    or [item.get("role") for item in messages if isinstance(item, dict)] != ["system", "user"]
                    or any(set(item) != {"role", "content"} or not isinstance(item["content"], str)
                           for item in messages if isinstance(item, dict))
                    or any(not isinstance(item, dict) for item in messages)):
                raise ValueError(f"Invalid public messages at line {number}")
            seen.add(rid)
            requests.append(row)
    if not requests or canonical_hash(requests) != expected_hash:
        raise ValueError("Frozen request cohort/hash mismatch")
    return requests


def select_requests(requests: Sequence[dict[str, Any]], selection: Mapping[str, Any] | None,
                    *, expected_hash: str) -> list[dict[str, Any]]:
    if selection is None:
        return list(requests)
    if selection.get("protocol_version") != PROTOCOL_VERSION or selection.get("requests_sha256") != expected_hash:
        raise ValueError("Calibration selection is for another frozen request cohort")
    ids = selection.get("request_ids")
    if (not isinstance(ids, list) or not ids or any(not isinstance(value, str) for value in ids)
            or len(set(ids)) != len(ids)):
        raise ValueError("Selection needs unique public request IDs")
    chosen = set(ids)
    if not chosen <= {row["request_id"] for row in requests}:
        raise ValueError("Selection includes an unknown request ID")
    return [row for row in requests if row["request_id"] in chosen]


def calibration_selection(manifest: Mapping[str, Any], *, per_language: int,
                          seed: str, include_pointwise: bool = True) -> dict[str, Any]:
    """Select whole reversed A/B pairs, stratified by language, before judge calls.

    The output contains only opaque public request IDs. Use a separate dev or
    calibration manifest; a test manifest must not be used to tune the rubric.
    """
    if per_language < 1 or not seed or manifest.get("protocol_version") != PROTOCOL_VERSION:
        raise ValueError("Invalid frozen manifest, seed or per-language quota")
    groups: dict[str, list[tuple[str, Mapping[str, Any]]]] = defaultdict(list)
    request_map = manifest["requests"]
    for key, task in manifest["tasks"].items():
        if task["pairwise_eligible"] and not task["identical_candidates"]:
            pair_ids = task["pairwise_request_ids"]
            if (len(pair_ids) != 2 or any(request_map[rid]["task_key"] != key
                                           or request_map[rid]["kind"] != "pairwise" for rid in pair_ids)):
                raise ValueError("Manifest lacks a complete pairwise swap")
            groups[task["language"]].append((key, task))
    if not groups:
        raise ValueError("No eligible nonidentical pairs")
    selected: set[str] = set()
    counts: dict[str, int] = {}
    for language, options in sorted(groups.items()):
        ranked = sorted(options, key=lambda item: hashlib.sha256(
            f"{seed}\0{item[0]}".encode("utf-8")).hexdigest())
        if len(ranked) < per_language:
            raise ValueError(f"Only {len(ranked)} eligible {language} pairs; quota is {per_language}")
        counts[language] = per_language
        for _, task in ranked[:per_language]:
            selected.update(task["pairwise_request_ids"])
            if include_pointwise:
                if any(request_map[rid]["kind"] != "pointwise" for rid in task["pointwise_request_ids"]):
                    raise ValueError("Manifest pointwise list contains another request kind")
                selected.update(task["pointwise_request_ids"])
    return {
        "protocol_version": PROTOCOL_VERSION,
        "requests_sha256": manifest["judge_requests_sha256"],
        "selection_policy": "sha256(seed,task_key)_language_stratified_complete_swapped_pairs",
        "selection_seed_sha256": hashlib.sha256(seed.encode("utf-8")).hexdigest(),
        "include_pointwise": include_pointwise,
        "selected_tasks_by_language": counts,
        "request_ids": sorted(selected),
    }


def effective_messages(request: Mapping[str, Any], profile: str) -> list[dict[str, str]]:
    if profile not in SUPPORTED_MODELS:
        raise ValueError("Unknown pinned judge profile")
    schema = json.dumps(request["response_schema"], sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    system = request["messages"][0]["content"] + "\nResponse schema: " + schema
    if profile == "gpt_oss_20b":
        system = "Reasoning: low\n" + system
    return [{"role": "system", "content": system}, dict(request["messages"][1])]


def extract_final_json(raw: str, profile: str) -> str:
    """Return only the final answer channel; never repair prose/Markdown JSON."""
    if profile == "gpt_oss_20b":
        marker = "<|final|>"
        if marker not in raw:
            raise ValueError("missing_harmony_final_channel")
        content = raw.rsplit(marker, 1)[1]
    elif profile in {"glm47_flash", "devstral_small2"}:
        if "<think>" in raw and "</think>" not in raw:
            raise ValueError("unfinished_glm_thinking")
        content = raw.rsplit("</think>", 1)[-1]
    else:
        raise ValueError("Unknown judge profile")
    content = content.strip()
    for token in _TERMINATORS:
        if content.endswith(token):
            content = content[:-len(token)].strip()
            break
    if not content.startswith("{") or not content.endswith("}"):
        raise ValueError("final_answer_not_bare_json")
    return content


class JudgeBackend(Protocol):
    def generate(self, messages: list[dict[str, str]], *, max_total_tokens: int,
                 max_new_tokens: int) -> Mapping[str, Any]: ...


class LocalHFJudge:
    """Pinned model-only Transformers backend. This constructor needs a CUDA GPU."""

    def __init__(self, model_dir: Path, profile: str):
        import torch
        import transformers
        from transformers import AutoModelForCausalLM, AutoTokenizer

        if not torch.cuda.is_available():
            raise RuntimeError("CUDA GPU required for a local HF judge")
        self.profile = profile
        self.torch = torch
        self.transformers_version = transformers.__version__
        self.torch_version = torch.__version__
        if profile == "devstral_small2":
            from transformers import FineGrainedFP8Config, Mistral3ForConditionalGeneration, MistralCommonBackend
            self.tokenizer = MistralCommonBackend.from_pretrained(model_dir, local_files_only=True)
            quant_values = json.loads((model_dir / "config.json").read_text(encoding="utf-8"))["quantization_config"]
            if quant_values.get("quant_method") != "fp8" or quant_values.get("dequantize") is not False:
                raise ValueError("Unexpected Devstral FP8 checkpoint configuration")
            quantization = FineGrainedFP8Config(**{**quant_values, "dequantize": True})
            self.model = Mistral3ForConditionalGeneration.from_pretrained(
                model_dir, local_files_only=True, trust_remote_code=False,
                device_map="auto", low_cpu_mem_usage=True, dtype=torch.bfloat16,
                quantization_config=quantization,
            ).eval()
            if any(str(parameter.dtype).startswith("torch.float8") for parameter in self.model.parameters()):
                raise RuntimeError("Devstral FP8 weights did not dequantize to BF16")
            self.precision = "fp8_checkpoint_dequantized_to_bf16_on_load"
        else:
            self.tokenizer = AutoTokenizer.from_pretrained(model_dir, local_files_only=True,
                                                           trust_remote_code=False)
            self.model = AutoModelForCausalLM.from_pretrained(
                model_dir, local_files_only=True, trust_remote_code=False,
                dtype="auto", device_map="auto",
            ).eval()
            self.precision = "checkpoint_auto"
        placement = {str(device) for device in getattr(self.model, "hf_device_map", {}).values()}
        if any(value in {"cpu", "disk"} for value in placement):
            raise RuntimeError("GPU allocation insufficient: judge model offloaded")
        self.device = next(self.model.parameters()).device
        if self.device.type != "cuda":
            raise RuntimeError("Judge model is not on CUDA")
        self.gpu = torch.cuda.get_device_name(self.device)

    def generate(self, messages: list[dict[str, str]], *, max_total_tokens: int,
                 max_new_tokens: int) -> Mapping[str, Any]:
        if self.profile == "devstral_small2":
            batch = self.tokenizer.apply_chat_template(
                conversation=messages, tokenize=True, add_generation_prompt=True,
                return_tensors="pt", return_dict=True,
            )
            prompt_tokens = int(batch["input_ids"].shape[-1])
            inputs = {key: value.to(self.device) for key, value in batch.items()
                      if key in {"input_ids", "attention_mask"} and hasattr(value, "to")}
        else:
            # Current GLM tokenizers return BatchEncoding even without
            # return_dict; request tensors explicitly rather than assuming a
            # bare list of token IDs from older tokenizer implementations.
            batch = self.tokenizer.apply_chat_template(
                messages, tokenize=True, add_generation_prompt=True,
                enable_thinking=False, return_dict=True, return_tensors="pt",
            )
            input_ids = batch.get("input_ids") if hasattr(batch, "get") else None
            if (not isinstance(input_ids, self.torch.Tensor)
                    or input_ids.ndim != 2 or input_ids.shape[0] != 1):
                raise RuntimeError("Unexpected chat-template tokenization")
            prompt_tokens = int(input_ids.shape[-1])
            inputs = {"input_ids": input_ids.to(self.device)}
            attention_mask = batch.get("attention_mask")
            if isinstance(attention_mask, self.torch.Tensor):
                if attention_mask.shape != input_ids.shape:
                    raise RuntimeError("Unexpected chat-template attention mask")
                inputs["attention_mask"] = attention_mask.to(self.device)
            else:
                inputs["attention_mask"] = self.torch.ones_like(inputs["input_ids"])
        if prompt_tokens + max_new_tokens > max_total_tokens:
            return {"status": "over_budget", "raw": "", "input_tokens": prompt_tokens,
                    "output_tokens": 0, "truncated": False}
        eos = self.model.generation_config.eos_token_id
        eos_ids = set(eos if isinstance(eos, list) else [eos])
        with self.torch.inference_mode():
            generated = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens, do_sample=False,
                pad_token_id=self.tokenizer.pad_token_id or self.tokenizer.eos_token_id,
            )
        tail = generated[0, prompt_tokens:].tolist()
        return {
            "status": "generated",
            "raw": self.tokenizer.decode(tail, skip_special_tokens=False,
                                         clean_up_tokenization_spaces=False),
            "input_tokens": prompt_tokens, "output_tokens": len(tail),
            "truncated": len(tail) >= max_new_tokens and (not tail or tail[-1] not in eos_ids),
        }


def verify_receipt(model_dir: Path, *, model_id: str, revision: str,
                   receipt_path: Path, expected_receipt_sha256: str) -> dict[str, Any]:
    if not _HEX40.fullmatch(revision) or not _HEX64.fullmatch(expected_receipt_sha256):
        raise ValueError("Pinned model revision and receipt SHA-256 are required")
    if not model_dir.is_dir() or not (model_dir / "config.json").is_file():
        raise FileNotFoundError("Local model snapshot/config.json is missing")
    if file_sha256(receipt_path) != expected_receipt_sha256:
        raise ValueError("Pinned model receipt hash mismatch")
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    receipt_model_path = receipt.get("model_path", receipt.get("model_dir"))
    if (receipt.get("verified") is not True or receipt.get("model_id") != model_id
            or receipt.get("revision") != revision or not isinstance(receipt_model_path, str)
            or Path(receipt_model_path).resolve() != model_dir.resolve()):
        raise ValueError("Verified model receipt identity mismatch")
    files = receipt.get("files")
    if not isinstance(files, list) or not files:
        raise ValueError("Verified receipt must enumerate snapshot files")
    for item in files:
        if not isinstance(item, dict) or not isinstance(item.get("path"), str) or type(item.get("size")) is not int:
            raise ValueError("Invalid checkpoint file receipt")
        target = (model_dir / item["path"]).resolve()
        if not target.is_relative_to(model_dir.resolve()) or not target.is_file() or target.stat().st_size != item["size"]:
            raise ValueError(f"Missing or size-changed checkpoint file: {item['path']}")
    return {"receipt_sha256": expected_receipt_sha256,
            "config_sha256": file_sha256(model_dir / "config.json"),
            "receipt_files": len(files),
            "runtime_file_check": "existence_and_size; cryptographic file hashes certified by receipt creation"}


def _recover_incomplete_tail(path: Path) -> None:
    if not path.exists():
        return
    with path.open("rb+") as stream:
        stream.seek(0, os.SEEK_END)
        size = stream.tell()
        if not size:
            return
        stream.seek(-1, os.SEEK_END)
        if stream.read(1) == b"\n":
            return
        stream.seek(0)
        data = stream.read()
        boundary = data.rfind(b"\n") + 1
        tail = data[boundary:]
        backup = path.with_name(f"{path.name}.incomplete-{hashlib.sha256(tail).hexdigest()[:16]}")
        if not backup.exists():
            with backup.open("xb") as copy:
                copy.write(tail)
                copy.flush()
                os.fsync(copy.fileno())
        stream.truncate(boundary)
        stream.flush()
        os.fsync(stream.fileno())


def load_ledger(path: Path, selected_ids: set[str]) -> dict[str, list[dict[str, Any]]]:
    _recover_incomplete_tail(path)
    result: dict[str, list[dict[str, Any]]] = defaultdict(list)
    if not path.exists():
        return result
    with path.open(encoding="utf-8") as stream:
        for line_no, line in enumerate(stream, 1):
            row = json.loads(line)
            rid = row.get("request_id")
            if rid not in selected_ids or row.get("attempt") != len(result[rid]) + 1:
                raise ValueError(f"Ledger identity/attempt mismatch at line {line_no}")
            if row.get("status") not in {"ok", "invalid", "error", "over_budget"}:
                raise ValueError(f"Ledger status invalid at line {line_no}")
            result[rid].append(row)
    return result


def _append_attempt(path: Path, row: Mapping[str, Any]) -> None:
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def run_requests(requests: Sequence[dict[str, Any]], *, backend: JudgeBackend, profile: str,
                 ledger_path: Path, max_total_tokens: int, max_new_tokens: int,
                 max_attempts: int = 2) -> dict[str, int]:
    """Run at most once per pending request per invocation; resume only errors."""
    if max_total_tokens <= max_new_tokens or max_new_tokens < 1 or max_attempts < 1:
        raise ValueError("Invalid judge token budget or retry limit")
    ledger = load_ledger(ledger_path, {row["request_id"] for row in requests})
    for request in requests:
        rid = request["request_id"]
        previous = ledger.get(rid, [])
        expected_request_sha = canonical_hash(request)
        messages = effective_messages(request, profile)
        expected_messages_sha = canonical_hash(messages)
        if any(item.get("request_sha256") != expected_request_sha
               or item.get("effective_messages_sha256") != expected_messages_sha
               or item.get("kind") != request["kind"] for item in previous):
            raise ValueError(f"Ledger does not match the frozen request and prompt: {rid}")
        if previous and (previous[-1]["status"] in {"ok", "invalid", "over_budget"}
                         or len(previous) >= max_attempts):
            continue
        started = time.perf_counter()
        row: dict[str, Any] = {
            "request_id": rid, "request_sha256": expected_request_sha,
            "effective_messages_sha256": expected_messages_sha,
            "attempt": len(previous) + 1, "kind": request["kind"],
            "status": "error", "response": None, "raw": None,
            "error_code": None, "input_tokens": None, "output_tokens": None,
        }
        try:
            generated = backend.generate(messages, max_total_tokens=max_total_tokens,
                                         max_new_tokens=max_new_tokens)
            row.update(raw=generated.get("raw"), input_tokens=generated.get("input_tokens"),
                       output_tokens=generated.get("output_tokens"))
            if generated.get("status") == "over_budget":
                row.update(status="over_budget", error_code="prompt_exceeds_frozen_token_budget")
            elif generated.get("status") != "generated":
                raise ValueError("backend_did_not_generate")
            elif generated.get("truncated"):
                row.update(status="invalid", error_code="truncated_generation")
            else:
                try:
                    final = extract_final_json(generated["raw"], profile)
                    row.update(status="ok", response=validate_judgment(request["kind"], final))
                except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
                    row.update(status="invalid", error_code=f"invalid_final_json:{type(exc).__name__}:{exc}"[:250])
        except Exception as exc:
            row["error_code"] = f"backend_error:{type(exc).__name__}:{exc}"[:250]
        row["elapsed_s"] = round(time.perf_counter() - started, 6)
        _append_attempt(ledger_path, row)
        ledger[rid].append(row)
    return Counter(items[-1]["status"] for items in ledger.values()) | {"selected": len(requests)}


def export_judgments(requests: Sequence[dict[str, Any]], ledger_path: Path, *,
                     judge_id: str, output_dir: Path) -> dict[str, Any]:
    if not judge_id or any(character.isspace() for character in judge_id):
        raise ValueError("Judge ID must be a stable nonempty token")
    config_path = ledger_path.parent / "run_config.json"
    if not config_path.is_file():
        raise ValueError("Missing pinned run configuration for judge export")
    run_config = json.loads(config_path.read_text(encoding="utf-8"))
    expected_judge_id = run_config.get("model_id", "") + "@" + run_config.get("revision", "")
    if judge_id != expected_judge_id:
        raise ValueError(f"Judge ID must be the pinned model@revision: {expected_judge_id}")
    if run_config.get("selected_requests") != len(requests):
        raise ValueError("Export selection differs from pinned run configuration")
    ledger = load_ledger(ledger_path, {row["request_id"] for row in requests})
    judgments, counts, missing = [], Counter(), []
    for request in requests:
        rid = request["request_id"]
        attempts = ledger.get(rid, [])
        if not attempts:
            counts["missing"] += 1
            missing.append(rid)
            continue
        row = attempts[-1]
        if (row["request_sha256"] != canonical_hash(request) or row["kind"] != request["kind"]
                or row.get("effective_messages_sha256") != canonical_hash(
                    effective_messages(request, run_config["profile"]))):
            raise ValueError(f"Ledger/public request mismatch: {rid}")
        counts[row["status"]] += 1
        if row["status"] == "ok":
            response = validate_judgment(request["kind"], row["response"])
            judgments.append({"judge_id": judge_id, "request_id": rid, "response": response})
    output_dir.mkdir(parents=True, exist_ok=False)
    with (output_dir / "judgments.jsonl").open("x", encoding="utf-8", newline="\n") as stream:
        for row in judgments:
            stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    summary = {"runtime_version": RUNTIME_VERSION, "judge_id": judge_id,
               "planned_requests": len(requests), "valid_judgments": len(judgments),
               "counts": dict(counts), "missing_request_ids": missing,
               "run_config_sha256": file_sha256(config_path),
               "ledger_sha256": file_sha256(ledger_path) if ledger_path.exists() else None,
               "interpretation": "Missing, invalid, over-budget, and failed requests remain in the denominator."}
    _write_json_exclusive(output_dir / "coverage.json", summary)
    return summary


def _run_cli(args: argparse.Namespace) -> None:
    if args.model_id != SUPPORTED_MODELS.get(args.profile):
        raise ValueError("Judge profile/model ID mismatch")
    requests = load_requests(args.requests, args.requests_sha256)
    selection = json.loads(args.selection.read_text(encoding="utf-8")) if args.selection else None
    chosen = select_requests(requests, selection, expected_hash=args.requests_sha256)
    receipt = verify_receipt(args.model_dir, model_id=args.model_id, revision=args.revision,
                             receipt_path=args.model_receipt, expected_receipt_sha256=args.model_receipt_sha256)
    config = {"runtime_version": RUNTIME_VERSION, "profile": args.profile,
              "model_id": args.model_id, "revision": args.revision,
              "model_dir": str(args.model_dir.resolve()), "model_receipt": receipt,
              "public_file_sha256": file_sha256(args.requests),
              "requests_sha256": args.requests_sha256,
              "selection_sha256": canonical_hash(selection) if selection else None,
              "selected_requests": len(chosen),
              "max_total_tokens": args.max_total_tokens, "max_new_tokens": args.max_new_tokens,
              "max_attempts": args.max_attempts,
              "decoding": "greedy; exact final JSON; no repair/no crop"}
    args.output.mkdir(parents=True, exist_ok=True)
    config_path = args.output / "run_config.json"
    if config_path.exists():
        if json.loads(config_path.read_text(encoding="utf-8")) != config:
            raise ValueError("Cannot resume with a changed frozen run configuration")
    else:
        if any(args.output.iterdir()):
            raise ValueError("Output directory contains unrelated files")
        _write_json_exclusive(config_path, config)
    try:
        backend = LocalHFJudge(args.model_dir, args.profile)
        runtime = {"transformers": backend.transformers_version, "torch": backend.torch_version,
                   "gpu": backend.gpu, "python": sys.version.split()[0],
                   "inference_precision": backend.precision}
        runtime_path = args.output / "runtime_environment.json"
        if runtime_path.exists():
            if json.loads(runtime_path.read_text(encoding="utf-8")) != runtime:
                raise ValueError("Cannot resume under a changed runtime/GPU environment")
        else:
            _write_json_exclusive(runtime_path, runtime)
    except Exception as exc:
        failure = {"error_type": type(exc).__name__, "error": str(exc)[:1000],
                   "stage": "judge_model_startup", "attempted_requests": 0}
        _write_json_exclusive(args.output / f"startup_failure_{time.time_ns()}.json", failure)
        raise
    counts = run_requests(chosen, backend=backend, profile=args.profile,
                          ledger_path=args.output / "attempts.jsonl",
                          max_total_tokens=args.max_total_tokens,
                          max_new_tokens=args.max_new_tokens, max_attempts=args.max_attempts)
    print(json.dumps(counts, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    select = sub.add_parser("select-calibration", help="Create public IDs for complete swapped pairs from dev manifest")
    select.add_argument("--private-manifest", type=Path, required=True)
    select.add_argument("--per-language", type=int, required=True)
    select.add_argument("--seed", required=True)
    select.add_argument("--pairwise-only", action="store_true")
    select.add_argument("--output", type=Path, required=True)
    run = sub.add_parser("run", help="Evaluate frozen public requests with an offline local HF model")
    run.add_argument("--requests", type=Path, required=True)
    run.add_argument("--requests-sha256", required=True)
    run.add_argument("--selection", type=Path)
    run.add_argument("--profile", choices=sorted(SUPPORTED_MODELS), required=True)
    run.add_argument("--model-id", required=True)
    run.add_argument("--revision", required=True)
    run.add_argument("--model-dir", type=Path, required=True)
    run.add_argument("--model-receipt", type=Path, required=True)
    run.add_argument("--model-receipt-sha256", required=True)
    run.add_argument("--max-total-tokens", type=int, default=8192)
    run.add_argument("--max-new-tokens", type=int, default=512)
    run.add_argument("--max-attempts", type=int, default=2)
    run.add_argument("--output", type=Path, required=True)
    export = sub.add_parser("export", help="Export only validated responses plus full failure coverage")
    export.add_argument("--requests", type=Path, required=True)
    export.add_argument("--requests-sha256", required=True)
    export.add_argument("--selection", type=Path)
    export.add_argument("--ledger", type=Path, required=True)
    export.add_argument("--judge-id", required=True)
    export.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "select-calibration":
        manifest = json.loads(args.private_manifest.read_text(encoding="utf-8"))
        selection = calibration_selection(manifest, per_language=args.per_language,
                                          seed=args.seed, include_pointwise=not args.pairwise_only)
        _write_json_exclusive(args.output, selection)
    elif args.command == "run":
        _run_cli(args)
    else:
        requests = load_requests(args.requests, args.requests_sha256)
        selection = json.loads(args.selection.read_text(encoding="utf-8")) if args.selection else None
        chosen = select_requests(requests, selection, expected_hash=args.requests_sha256)
        config = json.loads((args.ledger.parent / "run_config.json").read_text(encoding="utf-8"))
        if (config.get("requests_sha256") != args.requests_sha256
                or config.get("selection_sha256") != (canonical_hash(selection) if selection else None)
                or config.get("public_file_sha256") != file_sha256(args.requests)):
            raise ValueError("Export public input/selection differs from pinned run")
        print(json.dumps(export_judgments(chosen, args.ledger, judge_id=args.judge_id,
                                         output_dir=args.output), sort_keys=True))


if __name__ == "__main__":
    main()
