"""Validate offline judgments and aggregate swapped, anonymous pair comparisons."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
import os
from pathlib import Path
import re
from statistics import median
from typing import Any, Mapping, Sequence

from .materials import DIMENSIONS, PROTOCOL_VERSION


_HEX64 = re.compile(r"[0-9a-f]{64}\Z")
_HEX40 = re.compile(r"[0-9a-f]{40}\Z")


def validate_judgment(kind: str, response: Any) -> dict[str, Any]:
    """Reject extra answer keys, partial scores, noninteger scores and invalid enums."""
    if isinstance(response, str):
        def unique_keys(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError("Duplicate JSON response key")
                result[key] = value
            return result
        response = json.loads(response, object_pairs_hook=unique_keys)
    if not isinstance(response, dict):
        raise ValueError("Judgment must be a JSON object")
    if kind == "pairwise":
        if (set(response) != {"decision", "rationale"}
                or not isinstance(response.get("decision"), str)
                or response["decision"] not in {"A", "B", "tie", "cannot_judge"}):
            raise ValueError("Invalid pairwise response keys or decision")
    elif kind == "pointwise":
        if set(response) != {"scores", "cannot_judge", "rationale"} or type(response["cannot_judge"]) is not bool:
            raise ValueError("Invalid pointwise response keys")
        scores = response["scores"]
        if not isinstance(scores, dict) or set(scores) != set(DIMENSIONS):
            raise ValueError("Pointwise dimensions must match the frozen rubric")
        if response["cannot_judge"]:
            if any(value is not None for value in scores.values()):
                raise ValueError("Abstention must have only null scores")
        elif any(type(value) is not int or not 1 <= value <= 5 for value in scores.values()):
            raise ValueError("All nonabstaining scores must be integers from 1 to 5")
    else:
        raise ValueError("Unknown judgment kind")
    if not isinstance(response["rationale"], str):
        raise ValueError("Rationale must be text")
    return response


def aggregate_pairwise(
    manifest: Mapping[str, Any], judgments: Sequence[Mapping[str, Any]], *,
    expected_judges: Sequence[str],
) -> dict[str, Any]:
    """Return task-level W/T/L/U, preserving missing/invalid/conflicting data as U.

    W/L are always relative to the generated name after privately decoding A/B.
    All expected judges and both orders are required. No majority vote, filtering
    of inconvenient judges, or counting repeat judgments as independent tasks.
    """
    judges = tuple(expected_judges)
    if len(judges) < 2 or any(not isinstance(judge, str) or not judge for judge in judges) or len(set(judges)) != len(judges):
        raise ValueError("Need at least two unique, nonempty expected judge IDs")
    if manifest.get("protocol_version") != PROTOCOL_VERSION or manifest.get("private_only") is not True:
        raise ValueError("Wrong or nonprivate material manifest")
    request_map = manifest["requests"]
    if manifest.get("planned_tasks") != len(manifest["tasks"]):
        raise ValueError("Manifest planned-task denominator mismatch")
    indexed: dict[tuple[str, str], Mapping[str, Any]] = {}
    for row in judgments:
        if not isinstance(row, Mapping) or set(row) != {"judge_id", "request_id", "response"}:
            raise ValueError("Judgment row requires exactly judge_id, request_id, response")
        judge, request_id = row["judge_id"], row["request_id"]
        if (not isinstance(judge, str) or not isinstance(request_id, str)
                or judge not in judges or request_id not in request_map):
            raise ValueError("Unknown judge or request ID")
        identity = (judge, request_id)
        if identity in indexed:
            raise ValueError("Duplicate judgment; adjudicate retries before aggregation")
        indexed[identity] = row

    def for_judge(judge: str, request_ids: list[str]) -> dict[str, Any]:
        if len(request_ids) != 2:
            raise ValueError("Nonidentical eligible pair must have exactly two orders")
        outcomes, details = [], []
        for request_id in request_ids:
            request = request_map[request_id]
            if request["kind"] != "pairwise":
                raise ValueError("Manifest pairwise list contains another request kind")
            row = indexed.get((judge, request_id))
            reason = None
            if row is None:
                outcome, reason = "U", "missing_judgment"
            else:
                try:
                    response = validate_judgment("pairwise", row["response"])
                    decision = response["decision"]
                    if decision == "cannot_judge":
                        outcome, reason = "U", "judge_abstention"
                    elif decision == "tie":
                        outcome = "T"
                    else:
                        sources = request["candidate_sources"][decision]
                        if sources not in (["generated"], ["reference"]):
                            raise ValueError("Invalid private slot mapping")
                        outcome = "W" if sources == ["generated"] else "L"
                except (ValueError, TypeError, KeyError):
                    outcome, reason = "U", "invalid_judgment"
            outcomes.append(outcome)
            details.append({"request_id": request_id, "outcome": outcome, "reason": reason})
        if "U" in outcomes:
            return {"outcome": "U", "reason": "incomplete_or_abstained_orders", "orders": details}
        if outcomes[0] != outcomes[1]:
            return {"outcome": "U", "reason": "order_disagreement", "orders": details}
        return {"outcome": outcomes[0], "reason": None, "orders": details}

    tasks, counts = {}, {key: 0 for key in "WTLU"}
    for task_key, task in manifest["tasks"].items():
        per_judge = {}
        if not task["pairwise_eligible"]:
            outcome, reason = "U", task["ineligible_reason"]
        elif task["identical_candidates"]:
            outcome, reason = "T", "identical_names_not_a_quality_score"
        else:
            requests = [request_map[rid] for rid in task["pairwise_request_ids"]]
            if (len(requests) != 2 or any(request["task_key"] != task_key for request in requests)
                    or {tuple(request["candidate_sources"].get(slot, [])) for request in requests for slot in ("A", "B")}
                    != {("reference",), ("generated",)}
                    or requests[0]["candidate_sources"].get("A") != requests[1]["candidate_sources"].get("B")
                    or requests[0]["candidate_sources"].get("B") != requests[1]["candidate_sources"].get("A")
                    or requests[0]["candidate_sources"].get("A") == requests[0]["candidate_sources"].get("B")):
                raise ValueError("Manifest does not contain the two reversed anonymous orders")
            per_judge = {judge: for_judge(judge, task["pairwise_request_ids"]) for judge in judges}
            values = [result["outcome"] for result in per_judge.values()]
            if "U" in values:
                outcome, reason = "U", "unresolved_judge"
            elif len(set(values)) != 1:
                outcome, reason = "U", "judge_disagreement"
            else:
                outcome, reason = values[0], None
        counts[outcome] += 1
        tasks[task_key] = {"outcome": outcome, "reason": reason, "judges": per_judge,
                           "pairwise_eligible": task["pairwise_eligible"]}
    planned = len(tasks)
    eligible = sum(task["pairwise_eligible"] for task in tasks.values())
    decidable = counts["W"] + counts["T"] + counts["L"]
    return {
        "protocol_version": PROTOCOL_VERSION, "expected_judges": list(judges),
        "planned_tasks": planned, "pairwise_eligible_tasks": eligible,
        "ineligible_tasks": planned - eligible, "decidable_tasks": decidable,
        "counts": counts,
        "tie_adjusted_preference": (counts["W"] + 0.5 * counts["T"]) / decidable if decidable else None,
        "decision_coverage_over_planned": decidable / planned if planned else None,
        "decision_coverage_over_eligible": decidable / eligible if eligible else None,
        "tasks": tasks,
        "interpretation": "Conditional naming preference, not end-to-end rename success or proof of semantic correctness. U includes separately recorded generation ineligibility and unresolved judgment.",
    }


def aggregate_pointwise(
    manifest: Mapping[str, Any], judgments: Sequence[Mapping[str, Any]], *,
    expected_judges: Sequence[str], judge_provenance: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    """Preserve per-judge, same-task four-dimensional generated-minus-original scores.

    ``judgments`` contains one normalized raw-ledger row per attempted request:
    ``{judge_id, request_id, status, response, raw_sha256}``. Missing rows are
    retained as missing. Pointwise requests have no A/B order; the private
    source mapping pairs the two candidates, while swapped A/B comparisons are
    handled by ``aggregate_pairwise`` on the same task manifest.
    """
    judges = tuple(expected_judges)
    if (len(judges) < 2 or any(not isinstance(j, str) or not j for j in judges)
            or len(set(judges)) != len(judges)):
        raise ValueError("Pointwise consensus audit requires two distinct judge families")
    if (manifest.get("protocol_version") != PROTOCOL_VERSION
            or manifest.get("private_only") is not True
            or manifest.get("planned_tasks") != len(manifest.get("tasks", {}))):
        raise ValueError("Wrong or inconsistent private material manifest")
    if set(judge_provenance) != set(judges):
        raise ValueError("Provenance must cover exactly the expected judges")
    for judge in judges:
        receipt = judge_provenance[judge]
        if (not isinstance(receipt, Mapping)
                or not isinstance(receipt.get("model_id"), str) or not receipt["model_id"]
                or not isinstance(receipt.get("revision"), str)
                or not _HEX40.fullmatch(receipt["revision"])
                or any(not isinstance(receipt.get(field), str)
                       or not _HEX64.fullmatch(receipt[field])
                       for field in ("run_config_sha256", "attempts_sha256"))):
            raise ValueError(f"Missing pinned judge provenance: {judge}")
    request_map = manifest["requests"]
    indexed: dict[tuple[str, str], Mapping[str, Any]] = {}
    for row in judgments:
        if (not isinstance(row, Mapping)
                or set(row) != {"judge_id", "request_id", "status", "response", "raw_sha256"}):
            raise ValueError("Judgment row needs judge_id, request_id, status, response, raw_sha256")
        judge, rid = row["judge_id"], row["request_id"]
        if judge not in judges or rid not in request_map or (judge, rid) in indexed:
            raise ValueError("Unknown or duplicate judge/request identity")
        if row["status"] not in {"valid", "invalid", "over_budget", "backend_error"}:
            raise ValueError("Unknown raw-ledger status")
        if not isinstance(row["raw_sha256"], str) or not _HEX64.fullmatch(row["raw_sha256"]):
            raise ValueError("Raw response SHA-256 is required")
        if row["status"] != "valid" and row["response"] is not None:
            raise ValueError("Only valid attempts may contain parsed responses")
        indexed[(judge, rid)] = row

    tasks: dict[str, Any] = {}
    for task_key, task in sorted(manifest["tasks"].items()):
        point_ids = task["pointwise_request_ids"]
        if not point_ids:
            raise ValueError("Every planned task needs its original-name pointwise request")
        sources_by_id = {}
        for rid in point_ids:
            private = request_map.get(rid)
            if private is None or private["task_key"] != task_key or private["kind"] != "pointwise":
                raise ValueError("Pointwise request does not belong to its task")
            sources = private["candidate_sources"]["candidate"]
            if sources not in (["reference"], ["generated"], ["reference", "generated"]):
                raise ValueError("Invalid pointwise candidate source map")
            sources_by_id[rid] = sources
        original_ids = [rid for rid, sources in sources_by_id.items() if "reference" in sources]
        generated_ids = [rid for rid, sources in sources_by_id.items() if "generated" in sources]
        if (len(original_ids) != 1
                or (len(generated_ids) != 1 if task["pairwise_eligible"] else bool(generated_ids))
                or (task["identical_candidates"] !=
                    (bool(task["pairwise_eligible"]) and original_ids == generated_ids))):
            raise ValueError("Candidate mapping does not match task eligibility/identity")
        per_judge: dict[str, Any] = {}
        for judge in judges:
            candidates = {}
            for source, ids in (("reference", original_ids), ("generated", generated_ids)):
                if not ids:
                    candidates[source] = {"request_id": None, "status": "ineligible",
                                          "scores": None, "raw_sha256": None}
                    continue
                rid = ids[0]
                attempt = indexed.get((judge, rid))
                if attempt is None:
                    candidates[source] = {"request_id": rid, "status": "missing",
                                          "scores": None, "raw_sha256": None}
                    continue
                status = attempt["status"]
                scores = None
                if status == "valid":
                    response = validate_judgment("pointwise", attempt["response"])
                    if response["cannot_judge"]:
                        status = "cannot_judge"
                    else:
                        scores = response["scores"]
                candidates[source] = {"request_id": rid, "status": status,
                                      "scores": scores, "raw_sha256": attempt["raw_sha256"]}
            original, generated = candidates["reference"], candidates["generated"]
            delta = None
            if original["status"] == generated["status"] == "valid":
                delta = {dimension: generated["scores"][dimension] - original["scores"][dimension]
                         for dimension in DIMENSIONS}
            per_judge[judge] = {"candidates": candidates, "delta": delta}
        tasks[task_key] = {
            "language": task["language"], "source_sha256": task["source_sha256"],
            "prediction_record_sha256": task["prediction_record_sha256"],
            "pairwise_eligible": task["pairwise_eligible"],
            "identical_candidates": task["identical_candidates"],
            "pairwise_request_ids": task["pairwise_request_ids"],
            "judges": per_judge,
        }
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for task in tasks.values():
        grouped[task["language"]].append(task)
    grouped["ALL"] = list(tasks.values())
    summaries = {}
    for language, rows in sorted(grouped.items()):
        judge_summaries = {}
        for judge in judges:
            statuses = {source: Counter(row["judges"][judge]["candidates"][source]["status"]
                                        for row in rows) for source in ("reference", "generated")}
            matched = [row["judges"][judge]["delta"] for row in rows
                       if row["judges"][judge]["delta"] is not None]
            dimensions = {}
            for dimension in DIMENSIONS:
                values = [delta[dimension] for delta in matched]
                dimensions[dimension] = {
                    "matched_tasks": len(values), "improved": sum(v > 0 for v in values),
                    "unchanged": sum(v == 0 for v in values),
                    "degraded": sum(v < 0 for v in values),
                    "median_delta": median(values) if values else None,
                    "mean_delta_descriptive": sum(values) / len(values) if values else None,
                }
            judge_summaries[judge] = {
                "planned_tasks": len(rows), "pairwise_eligible_tasks": sum(r["pairwise_eligible"] for r in rows),
                "matched_delta_tasks": len(matched),
                "candidate_statuses": {source: dict(sorted(counts.items())) for source, counts in statuses.items()},
                "dimensions": dimensions,
            }
        between_judges = {}
        if len(judges) == 2:
            left, right = judges
            for dimension in DIMENSIONS:
                signs = []
                for row in rows:
                    a = row["judges"][left]["delta"]
                    b = row["judges"][right]["delta"]
                    if a is not None and b is not None:
                        signs.append(((a[dimension] > 0) - (a[dimension] < 0),
                                      (b[dimension] > 0) - (b[dimension] < 0)))
                between_judges[dimension] = {"both_matched_tasks": len(signs),
                                             "same_delta_sign": sum(a == b for a, b in signs)}
        summaries[language] = {"planned_tasks": len(rows), "judges": judge_summaries,
                               "cross_judge_delta_sign": between_judges}
    return {
        "protocol_version": PROTOCOL_VERSION,
        "version": "matched-pointwise-by-judge-v1",
        "expected_judges": list(judges),
        "judge_provenance": {judge: dict(judge_provenance[judge]) for judge in judges},
        "public_requests_sha256": manifest["judge_requests_sha256"],
        "planned_tasks": len(tasks), "groups": summaries, "tasks": tasks,
        "interpretation": "Within-task original/generated ordinal-score differences by judge. Missing, invalid, over-budget, backend-error, abstained and ineligible tasks stay in planned denominators; repeated requests do not increase task N. A/B order is evaluated separately by the pairwise aggregator. No cross-judge ordinal-score average or calibrated test quality claim.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--judgments", required=True)
    parser.add_argument("--judge", action="append", required=True, dest="judges")
    parser.add_argument("--metric", choices=("pairwise", "pointwise"), default="pairwise")
    parser.add_argument("--judge-provenance")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    with Path(args.judgments).open(encoding="utf-8") as stream:
        rows = [json.loads(line) for line in stream]
    if args.metric == "pairwise":
        summary = aggregate_pairwise(manifest, rows, expected_judges=args.judges)
    else:
        if not args.judge_provenance:
            parser.error("Pointwise aggregation requires --judge-provenance")
        provenance = json.loads(Path(args.judge_provenance).read_text(encoding="utf-8"))
        summary = aggregate_pointwise(manifest, rows, expected_judges=args.judges,
                                      judge_provenance=provenance)
    descriptor = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(summary, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


if __name__ == "__main__":
    main()
