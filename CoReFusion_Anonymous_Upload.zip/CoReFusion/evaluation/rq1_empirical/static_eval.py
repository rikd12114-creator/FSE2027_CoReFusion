"""Audit and score S1 runs without dropping missing or failed tasks.

This scorer reads the runner's frozen task contract and the original CSV. It
recomputes reference agreement and application diagnostics from predictions;
the runner's reported metrics are checked as an integrity receipt, not used as
the evaluation source. Optional Java syntax checks use the earlier paper
revision's tree-sitter checker. Syntax is not binding, compilation, or behavior.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
import unicodedata
from typing import Any

from experiments.paper_revision_20260917.metrics import JavaStructureChecker, subtoken_scores
from experiments.rq1_empirical.policy import apply_once, valid_identifier
from experiments.rq1_empirical.runner import PROMPT_VERSION
from experiments.rq1_empirical.schema import CONTEXT_CHARS, RenameTask, build_messages, load_tasks

VERSION = "rq1-s1-static-eval-v1-20260924"
MODE = "s1_generate_once_propagate_all_supplied_sites"
ZERO_SUBTOKENS = {"precision": 0.0, "recall": 0.0, "f1": 0.0, "ordered_accuracy": 0.0}


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _digest(value: Any) -> str:
    data = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def _records(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8") as stream:
        lines = stream.readlines()
    if lines and not lines[-1].endswith("\n"):
        raise ValueError("Incomplete final predictions.jsonl line")
    rows = [json.loads(line) for line in lines]
    if any(not isinstance(row, dict) for row in rows):
        raise ValueError("Every prediction row must be a JSON object")
    return rows


def _task_namespace(key: str) -> tuple[str, str]:
    fields = key.split(":", 2)
    if len(fields) != 3 or not all(fields):
        raise ValueError(f"Invalid composite task key: {key!r}")
    return fields[0], fields[1]


def _validate_contract(contract: dict[str, Any], data: Path) -> tuple[list[RenameTask], int, str]:
    if contract.get("schema_version") != 1 or contract.get("mode") != MODE:
        raise ValueError("Unsupported runner contract version or mode")
    keys = contract.get("task_keys")
    if not isinstance(keys, list) or not keys or any(not isinstance(k, str) for k in keys) or len(set(keys)) != len(keys):
        raise ValueError("Task keys must be a nonempty unique list")
    dataset, language = _task_namespace(keys[0])
    if any(_task_namespace(key) != (dataset, language) for key in keys):
        raise ValueError("One S1 run must use a single dataset and language")
    if contract.get("source_sha256") != _sha(data):
        raise ValueError("Source CSV SHA-256 differs from run contract")
    if contract.get("context_char_limit") != CONTEXT_CHARS:
        raise ValueError("Unsupported context crop size")
    source = load_tasks(data, dataset=dataset, language=language)
    by_key = {task.key: task for task in source}
    if any(key not in by_key for key in keys):
        raise ValueError("Run refers to a task absent from its source CSV")
    cohort = [by_key[key] for key in keys]
    identity = [(task.key, task.code_masked, task.reference_name) for task in cohort]
    if contract.get("task_identity_sha256") != _digest(identity):
        raise ValueError("Cohort identity SHA-256 differs from run contract")
    spec = contract.get("backend_spec")
    if not isinstance(spec, dict) or spec.get("output_format", "plain") not in {"plain", "json"}:
        raise ValueError("Unsupported backend output format")
    return cohort, len(source), spec.get("output_format", "plain")


def _validate_prediction(
    row: dict[str, Any], task: RenameTask, *, output_format: str,
    check_prompt: bool,
) -> None:
    identity = (row.get("task_key"), row.get("dataset"), row.get("language"), row.get("id"))
    if identity != (task.key, task.dataset, task.language, task.task_id):
        raise ValueError(f"Prediction identity mismatch for {task.key}")
    if row.get("reference_name") != task.reference_name or row.get("expected_sites") != task.sites:
        raise ValueError(f"Prediction source/reference mismatch for {task.key}")
    if check_prompt and row.get("prompt_sha256") != _digest(build_messages(task, output_format=output_format)):
        raise ValueError(f"Prompt SHA-256 mismatch for {task.key}")
    name = row.get("predicted_name")
    if name is not None and not isinstance(name, str):
        raise ValueError(f"Predicted name must be string or null for {task.key}")
    actual_sites = row.get("site_predictions")
    if not isinstance(actual_sites, list) or any(not isinstance(value, str) for value in actual_sites):
        raise ValueError(f"Site predictions must be a list of names for {task.key}")
    metrics = row.get("metrics")
    if not isinstance(metrics, dict) or "error" not in metrics:
        raise ValueError(f"Missing runner metrics receipt for {task.key}")
    backend = row.get("backend")
    if not isinstance(backend, dict) or not isinstance(backend.get("status"), str):
        raise ValueError(f"Missing backend status for {task.key}")
    raw_error = backend.get("error")
    if backend["status"] == "ok":
        backend_error = None
    elif isinstance(raw_error, dict):
        backend_error = str(raw_error.get("code") or "backend_failed")
    else:
        backend_error = str(raw_error or "backend_failed")
    applied = apply_once(task, name, error=backend_error)
    expected_metrics = {k: v for k, v in asdict(applied).items()
                        if k not in {"task_key", "patched_code", "predicted_name"}}
    if any(metrics.get(key) != value for key, value in expected_metrics.items()):
        raise ValueError(f"Runner application receipt mismatch for {task.key}")
    expected_sites = [name] * task.sites if applied.complete_site_coverage else []
    if actual_sites != expected_sites:
        raise ValueError(f"Site propagation mismatch for {task.key}")
    patch_sha = hashlib.sha256(applied.patched_code.encode("utf-8")).hexdigest() if applied.patched_code is not None else None
    if row.get("patch_sha256") != patch_sha:
        raise ValueError(f"Patched source SHA-256 mismatch for {task.key}")
    if backend["status"] != "ok" and metrics["error"] is None:
        raise ValueError(f"Uncounted backend error for {task.key}")


def _validate_runner_summary(
    path: Path, contract_path: Path, predictions_path: Path,
    tasks: list[RenameTask], rows: list[dict[str, Any]],
) -> str:
    if not path.exists():
        return "absent_incomplete_or_unfinalized"
    summary = _json(path)
    expected = {
        "planned_tasks": len(tasks),
        "completed_tasks": len(rows),
        "expected_sites": sum(task.sites for task in tasks),
        "error_tasks": sum(row["metrics"]["error"] is not None for row in rows),
        "valid_name_tasks": sum(row["metrics"]["valid_name"] for row in rows),
        "all_sites_exact_tasks": sum(row["metrics"]["all_sites_exact"] for row in rows),
        "consistent_nonempty_tasks": sum(row["metrics"]["consistent_nonempty"] for row in rows),
        "predictions_sha256": _sha(predictions_path),
        "contract_sha256": _sha(contract_path),
    }
    if any(summary.get(key) != value for key, value in expected.items()):
        raise ValueError("Runner summary or SHA-256 receipt mismatch")
    if len(rows) != len(tasks):
        raise ValueError("Runner summary exists for an incomplete prediction file")
    return "verified"


def evaluate_run(
    run_dir: str | Path, *, data: str | Path | None = None,
    checker: JavaStructureChecker | None = None, require_complete: bool = False,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Return an auditable aggregate and one score row per *planned* task."""
    run_dir = Path(run_dir)
    contract_path = run_dir / "run.json"
    predictions_path = run_dir / "predictions.jsonl"
    contract = _json(contract_path)
    data_path = Path(data if data is not None else contract["source_path"])
    tasks, source_count, output_format = _validate_contract(contract, data_path)
    if checker is not None and tasks[0].language.casefold() != "java":
        raise ValueError("Java syntax checker can only score Java tasks")
    rows = _records(predictions_path)
    if len(rows) > len(tasks):
        raise ValueError("More predictions than planned tasks")
    if [row.get("task_key") for row in rows] != contract["task_keys"][:len(rows)]:
        raise ValueError("Prediction rows must be the unique declared task prefix")
    if require_complete and len(rows) != len(tasks):
        raise ValueError(f"Incomplete run: {len(rows)}/{len(tasks)} predictions")
    check_prompt = contract.get("prompt_version") == PROMPT_VERSION
    for task, row in zip(tasks, rows):
        _validate_prediction(row, task, output_format=output_format, check_prompt=check_prompt)
    runner_summary_status = _validate_runner_summary(
        run_dir / "summary.json", contract_path, predictions_path, tasks, rows,
    )

    scored: list[dict[str, Any]] = []
    for index, task in enumerate(tasks):
        row = rows[index] if index < len(rows) else None
        name = row.get("predicted_name") if row is not None else None
        error = row["metrics"]["error"] if row is not None else "missing_result"
        applied = apply_once(task, name, error=error)
        usable = applied.patched_code is not None
        lexical_valid = valid_identifier(name, task.language) if name is not None else False
        lexical = subtoken_scores(task.reference_name, name) if usable else ZERO_SUBTOKENS.copy()
        entry = {
            "task_key": task.key, "dataset": task.dataset, "language": task.language,
            "id": task.task_id, "reference_name": task.reference_name,
            "predicted_name": name, "expected_sites": task.sites,
            "covered_sites": task.sites if usable else 0,
            "missing_result": row is None, "error": error,
            "backend_status": row["backend"]["status"] if row is not None else None,
            "reference_valid_identifier": valid_identifier(task.reference_name, task.language),
            "valid_identifier": lexical_valid,
            "complete_site_coverage": usable,
            "site_consistency": usable,
            "name_em": bool(usable and name == task.reference_name),
            "all_sites_em": bool(usable and name == task.reference_name),
            "subtoken_precision": lexical["precision"],
            "subtoken_recall": lexical["recall"],
            "subtoken_f1": lexical["f1"],
            "ordered_subtoken_accuracy": lexical["ordered_accuracy"],
            "patch_sha256": row.get("patch_sha256") if row is not None else None,
        }
        if checker is not None:
            entry.update(checker.score(task.code_masked, task.reference_name,
                                       [name] * task.sites if usable else [], usable))
        scored.append(entry)

    n = len(scored)
    sites = sum(row["expected_sites"] for row in scored)
    eligible = [row for row in scored if row.get("parse_eligible")]
    parse = {
        "requested": checker is not None,
        "parser_versions": checker.versions if checker is not None else None,
        "reference_parseable_tasks": sum(row.get("reference_parseable") is True for row in scored) if checker else None,
        "reference_unparseable_tasks": sum(row.get("reference_parseable") is False for row in scored) if checker else None,
        "eligible_tasks": len(eligible) if checker else None,
        "patch_parse_success_tasks": sum(row["patch_parse_success"] for row in eligible) if checker else None,
        "patch_structure_preserved_tasks": sum(row["patch_structure_preserved"] for row in eligible) if checker else None,
        "patch_parse_success_rate_among_eligible":
            sum(row["patch_parse_success"] for row in eligible) / len(eligible) if eligible else None,
        "patch_structure_preserved_rate_among_eligible":
            sum(row["patch_structure_preserved"] for row in eligible) / len(eligible) if eligible else None,
        "meaning": "Tree-sitter syntax and masked-target AST shape; no binding, compilation, or behavioral proof.",
    }
    summary = {
        "evaluator_version": VERSION, "run_mode": MODE,
        "dataset": tasks[0].dataset, "language": tasks[0].language,
        "cohort": "full_source" if len(tasks) == source_count else "declared_subset_or_pilot",
        "source_tasks": source_count, "planned_tasks": n,
        "returned_prediction_rows": len(rows),
        "missing_result_tasks": sum(row["missing_result"] for row in scored),
        "generation_error_tasks": sum(row["error"] is not None and not row["missing_result"] for row in scored),
        "invalid_identifier_tasks": sum(row["error"] == "invalid_identifier" for row in scored),
        "valid_identifier_tasks": sum(row["valid_identifier"] for row in scored),
        "reference_valid_identifier_tasks": sum(row["reference_valid_identifier"] for row in scored),
        "complete_patch_tasks": sum(row["complete_site_coverage"] for row in scored),
        "consistent_patch_tasks": sum(row["site_consistency"] for row in scored),
        "expected_sites": sites,
        "covered_sites": sum(row["covered_sites"] for row in scored),
        "site_coverage": sum(row["covered_sites"] for row in scored) / sites,
        "name_em_tasks": sum(row["name_em"] for row in scored),
        "name_em_task_macro": sum(row["name_em"] for row in scored) / n,
        "all_sites_em_tasks": sum(row["all_sites_em"] for row in scored),
        "all_sites_em_task_macro": sum(row["all_sites_em"] for row in scored) / n,
        "site_em_micro": sum(row["expected_sites"] for row in scored if row["all_sites_em"]) / sites,
        "subtoken_precision_task_macro": sum(row["subtoken_precision"] for row in scored) / n,
        "subtoken_recall_task_macro": sum(row["subtoken_recall"] for row in scored) / n,
        "subtoken_f1_task_macro": sum(row["subtoken_f1"] for row in scored) / n,
        "subtoken_f1_site_micro": sum(row["subtoken_f1"] * row["expected_sites"] for row in scored) / sites,
        "ordered_subtoken_accuracy_task_macro": sum(row["ordered_subtoken_accuracy"] for row in scored) / n,
        "parse": parse,
        "integrity": {
            "source_path_scored": str(data_path.resolve()), "source_sha256": _sha(data_path),
            "run_contract_path": str(contract_path.resolve()), "run_contract_sha256": _sha(contract_path),
            "predictions_path": str(predictions_path.resolve()),
            "predictions_sha256": _sha(predictions_path) if predictions_path.exists() else None,
            "runner_summary_status": runner_summary_status,
            "prompt_sha256_validation": "verified_current_template" if check_prompt else "unavailable_for_older_prompt_template",
            "scorer_sha256": _sha(Path(__file__)),
            "python_version": sys.version.split()[0],
            "unicode_version": unicodedata.unidata_version,
        },
        "interpretation": "Reference agreement and mechanical application diagnostics. The reference can be one of multiple good names; these scores do not establish naming quality or semantic correctness.",
    }
    return summary, scored


def write_scores(output_dir: str | Path, summary: dict[str, Any], scored: list[dict[str, Any]]) -> None:
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=False)
    with (destination / "scores.jsonl").open("x", encoding="utf-8") as stream:
        for row in scored:
            stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n")
    scores_sha = _sha(destination / "scores.jsonl")
    summary = {**summary, "integrity": {**summary["integrity"], "scores_sha256": scores_sha}}
    with (destination / "summary.json").open("x", encoding="utf-8") as stream:
        json.dump(summary, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", required=True, type=Path)
    parser.add_argument("--data", type=Path, help="Source CSV; defaults to the run contract's source path")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--parse-java", action="store_true", help="Require tree-sitter and tree-sitter-java")
    parser.add_argument("--require-complete", action="store_true")
    args = parser.parse_args(argv)
    checker = JavaStructureChecker() if args.parse_java else None
    summary, scored = evaluate_run(args.run_dir, data=args.data, checker=checker,
                                   require_complete=args.require_complete)
    write_scores(args.output_dir, summary, scored)
    print(json.dumps({"planned_tasks": summary["planned_tasks"],
                      "returned_prediction_rows": summary["returned_prediction_rows"],
                      "all_sites_em_task_macro": summary["all_sites_em_task_macro"],
                      "parse_eligible_tasks": summary["parse"]["eligible_tasks"],
                      "output_dir": str(args.output_dir.resolve())}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
