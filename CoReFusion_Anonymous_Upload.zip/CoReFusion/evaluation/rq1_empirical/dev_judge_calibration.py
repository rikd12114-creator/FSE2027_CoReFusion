"""Prepare a small blind judge pilot from the frozen Stack v3 dev cohort.

Requires seven complete, independently scored dev runs from one pinned generator.
No model is called. The public files contain opaque IDs and candidate spellings,
never source labels, reference identity, or the private answer map.
"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
from typing import Any, Mapping

from evaluation.rq1_empirical.judge_runtime import calibration_selection, file_sha256
from evaluation.rq1_empirical.materials import (
    PROTOCOL_VERSION, build_materials, canonical_hash, write_materials,
)
from evaluation.rq1_empirical.static_eval import evaluate_run
from experiments.rq1_empirical.data_contract import restore_stack_snapshot
from experiments.rq1_empirical.runner import PROMPT_VERSION
from experiments.rq1_empirical.schema import RenameTask, load_tasks


VERSION = "stack-v3-dev-judge-pilot-v1"
DEV_MANIFEST_SHA256 = "d3f22eadb1d9df0530f9e4b5afb9f663ce26f0fb1b073efc49034fb2aa4ad71c"
DEV_AUDIT_SHA256 = "a91960fbf99d60e544fd07c70d648a872a2fd4245be07f3d8880c097a45075ec"
LANGUAGE_SLUGS = {
    "Java": "java", "Python": "python", "JavaScript": "javascript",
    "TypeScript": "typescript", "Go": "go", "Rust": "rust", "C++": "cpp",
}
_HEX40 = re.compile(r"[0-9a-f]{40}\Z")


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    content = path.read_bytes()
    if content and not content.endswith(b"\n"):
        raise ValueError(f"Incomplete JSONL tail: {path}")
    rows = [json.loads(line) for line in content.decode("utf-8").splitlines()]
    if any(not isinstance(row, dict) for row in rows):
        raise ValueError(f"Non-object JSONL row: {path}")
    return rows


def verify_frozen_dev(dev_root: Path, audit_path: Path) -> tuple[dict[str, list[RenameTask]], dict[str, Any]]:
    """Check the pinned dev release, original-source restoration, and test disjointness receipt."""
    manifest_path = dev_root / "manifest.json"
    if file_sha256(manifest_path) != DEV_MANIFEST_SHA256 or file_sha256(audit_path) != DEV_AUDIT_SHA256:
        raise ValueError("Frozen Stack v3 dev manifest/audit SHA-256 changed")
    manifest, audit = _read_json(manifest_path), _read_json(audit_path)
    if (manifest.get("purpose") != "private_stack_v3_dev_calibration_only"
            or audit.get("status") != "passed" or audit.get("manifest_sha256") != DEV_MANIFEST_SHA256
            or set(manifest.get("files", {})) != set(LANGUAGE_SLUGS)
            or any(manifest.get(field) != 0 for field in (
                "test_content_overlap", "test_repo_overlap", "test_source_hash_overlap"))):
        raise ValueError("Dev cohort identity or test-disjointness receipt is invalid")
    cohorts: dict[str, list[RenameTask]] = {}
    site_count = 0
    repositories: set[str] = set()
    for language, slug in LANGUAGE_SLUGS.items():
        spec = manifest["files"][language]
        folder = dev_root / slug
        csv_path, provenance_path = folder / "dev.csv", folder / "provenance.jsonl"
        if (file_sha256(csv_path) != spec["csv_sha256"]
                or file_sha256(provenance_path) != spec["provenance_sha256"]):
            raise ValueError(f"Frozen dev source SHA-256 mismatch: {language}")
        tasks = load_tasks(csv_path, dataset="stack_v3_dev_20260924", language=language)
        provenance = _read_jsonl(provenance_path)
        if len(tasks) != len(provenance) or len(tasks) != spec["rows"] or len(tasks) != 100:
            raise ValueError(f"Dev row denominator changed: {language}")
        sites = 0
        for task, source in zip(tasks, provenance, strict=True):
            if (source.get("id") != task.task_id or source.get("language") != language
                    or source.get("target") != task.reference_name
                    or source.get("occurrence_count") != task.sites
                    or hashlib.sha256(task.code_masked.encode("utf-8")).hexdigest()
                    != source.get("masked_sha256")):
                raise ValueError(f"Dev row/provenance mismatch: {task.key}")
            restored = restore_stack_snapshot(task.code_masked, task.reference_name,
                                              source.get("target_spans"))
            if hashlib.sha256(restored.encode("utf-8")).hexdigest() != source.get("original_sha256"):
                raise ValueError(f"Dev original-source SHA-256 mismatch: {task.key}")
            repositories.add(source["repo_path"])
            sites += task.sites
        if sites != spec["sites"] or sites != audit["files"][language]["restored_sites"]:
            raise ValueError(f"Dev site denominator changed: {language}")
        site_count += sites
        cohorts[language] = tasks
    if (sum(map(len, cohorts.values())) != 700 or site_count != 2222 or len(repositories) != 700
            or audit.get("checks", {}).get("rows") != 700
            or audit.get("checks", {}).get("source_restore_passed") != 700):
        raise ValueError("Frozen dev cohort totals changed")
    return cohorts, {"manifest_sha256": DEV_MANIFEST_SHA256,
                     "audit_sha256": DEV_AUDIT_SHA256, "tasks": 700,
                     "sites": site_count, "repositories": len(repositories),
                     "test_overlap": {key: manifest[key] for key in (
                         "test_content_overlap", "test_repo_overlap", "test_source_hash_overlap")}}


def human_assignment(manifest: Mapping[str, Any], selection: Mapping[str, Any], *, seed: str) -> dict[str, Any]:
    """Choose one blind order per task, balanced within each language for human review."""
    if not seed or selection.get("protocol_version") != PROTOCOL_VERSION or (
            selection.get("requests_sha256") != manifest.get("judge_requests_sha256")):
        raise ValueError("Human assignment differs from frozen materials/selection")
    selected = set(selection.get("request_ids", []))
    groups: dict[str, list[tuple[str, Mapping[str, Any]]]] = {}
    for key, task in manifest["tasks"].items():
        pair_ids = task["pairwise_request_ids"]
        if set(pair_ids) <= selected and len(pair_ids) == 2:
            if not task["pairwise_eligible"] or task["identical_candidates"]:
                raise ValueError("Human assignment includes an ineligible pair")
            groups.setdefault(task["language"], []).append((key, task))
        elif set(pair_ids) & selected:
            raise ValueError("Human assignment has an incomplete swapped pair")
    if not groups or set(groups) != set(selection["selected_tasks_by_language"]):
        raise ValueError("Human assignment lacks a selected language")
    request_ids: list[str] = []
    counts: dict[str, int] = {}
    for language, options in sorted(groups.items()):
        options.sort(key=lambda item: hashlib.sha256(
            f"{seed}\0{item[0]}".encode("utf-8")).hexdigest())
        quota = selection["selected_tasks_by_language"][language]
        if len(options) != quota or quota % 2:
            raise ValueError("Human pilot needs an even complete-pair quota per language")
        counts[language] = quota
        for index, (_, task) in enumerate(options):
            desired_reference_slot = "A" if index < quota // 2 else "B"
            matches = [rid for rid in task["pairwise_request_ids"] if
                       manifest["requests"][rid]["candidate_sources"][desired_reference_slot]
                       == ["reference"]]
            if len(matches) != 1:
                raise ValueError("Private A/B order mapping is not reversible")
            request_ids.extend(matches)
    return {"protocol_version": PROTOCOL_VERSION,
            "requests_sha256": manifest["judge_requests_sha256"],
            "selection_sha256": canonical_hash(selection),
            "assignment_policy": "one_pairwise_order_per_task_balanced_within_language",
            "assignment_seed_sha256": hashlib.sha256(seed.encode("utf-8")).hexdigest(),
            "selected_tasks_by_language": counts, "request_ids": sorted(request_ids)}


def pilot_denominators(manifest: Mapping[str, Any], selection: Mapping[str, Any]) -> dict[str, Any]:
    selected = set(selection["request_ids"])
    planned = Counter(task["language"] for task in manifest["tasks"].values())
    ineligible = Counter(task["language"] for task in manifest["tasks"].values()
                         if not task["pairwise_eligible"])
    ineligible_reasons: dict[str, Counter[str]] = {}
    for task in manifest["tasks"].values():
        if not task["pairwise_eligible"]:
            ineligible_reasons.setdefault(task["language"], Counter())[task["ineligible_reason"]] += 1
    identical = Counter(task["language"] for task in manifest["tasks"].values()
                        if task["identical_candidates"])
    selected_pairs = Counter(task["language"] for task in manifest["tasks"].values()
                             if len(task["pairwise_request_ids"]) == 2
                             and set(task["pairwise_request_ids"]) <= selected)
    languages = sorted(planned)
    return {"planned_tasks_by_language": {lang: planned[lang] for lang in languages},
            "pairwise_ineligible_by_language": {lang: ineligible[lang] for lang in languages},
            "ineligible_reason_counts_by_language": {
                lang: dict(sorted(ineligible_reasons.get(lang, {}).items())) for lang in languages},
            "identical_candidates_by_language": {lang: identical[lang] for lang in languages},
            "selected_nonidentical_pairs_by_language": {lang: selected_pairs[lang] for lang in languages},
            "selected_judge_requests": len(selected),
            "error_policy": "Generation failures stay in 700-task denominators; judge invalid, over-budget, backend-error, missing, and cannot_judge remain unresolved U."}


def selected_private_manifest(manifest: Mapping[str, Any], selection: Mapping[str, Any]) -> dict[str, Any]:
    """Make a 56-task denominator for pilot-only swapped-order aggregation."""
    ids = set(selection["request_ids"])
    tasks = {key: task for key, task in manifest["tasks"].items()
             if len(task["pairwise_request_ids"]) == 2
             and set(task["pairwise_request_ids"]) <= ids}
    if len(tasks) != sum(selection["selected_tasks_by_language"].values()):
        raise ValueError("Selected pilot task count differs from frozen selection")
    return {"schema_version": manifest["schema_version"],
            "protocol_version": manifest["protocol_version"],
            "private_only": True, "planned_tasks": len(tasks),
            "judge_requests_sha256": manifest["judge_requests_sha256"],
            "selection_sha256": canonical_hash(selection),
            "tasks": tasks,
            "requests": {rid: manifest["requests"][rid] for rid in sorted(ids)},
            "interpretation": "Pilot subset only; full dev generation failures remain in calibration_contract.json."}


def prepare(dev_root: Path, audit_path: Path, runs_file: Path, output: Path, *,
            seed: str, per_language: int) -> dict[str, Any]:
    if per_language < 2 or per_language % 2:
        raise ValueError("Pilot quota must be even and at least two per language")
    cohorts, dev_receipt = verify_frozen_dev(dev_root, audit_path)
    run_map = _read_json(runs_file)
    if run_map.get("schema_version") != 1 or set(run_map.get("runs", {})) != set(LANGUAGE_SLUGS):
        raise ValueError("Need one complete dev prediction run per frozen language")
    all_tasks: list[RenameTask] = []
    all_predictions: list[dict[str, Any]] = []
    run_receipts: dict[str, dict[str, Any]] = {}
    generator_identity: tuple[str, str] | None = None
    for language, slug in LANGUAGE_SLUGS.items():
        run_dir = Path(run_map["runs"][language]).resolve()
        data = dev_root / slug / "dev.csv"
        contract = _read_json(run_dir / "run.json")
        spec = contract.get("backend_spec", {})
        model_id, revision = spec.get("model_id"), spec.get("revision")
        if (not isinstance(model_id, str) or not model_id
                or not isinstance(revision, str) or not _HEX40.fullmatch(revision)):
            raise ValueError(f"Generator identity is not pinned: {language}")
        identity = (model_id, revision)
        if generator_identity is not None and identity != generator_identity:
            raise ValueError("Dev pilot mixes generator models or revisions")
        generator_identity = identity
        if contract.get("prompt_version") != PROMPT_VERSION:
            raise ValueError(f"Dev run uses another prompt template: {language}")
        summary, _ = evaluate_run(run_dir, data=data, require_complete=True)
        if (summary["integrity"]["runner_summary_status"] != "verified"
                or summary["integrity"]["prompt_sha256_validation"] != "verified_current_template"
                or summary["cohort"] != "full_source" or summary["planned_tasks"] != 100
                or summary["language"] != language
                or summary["expected_sites"] != sum(task.sites for task in cohorts[language])):
            raise ValueError(f"Dev run is not a complete verified cohort: {language}")
        tasks = load_tasks(data, dataset=summary["dataset"], language=language)
        if contract.get("task_keys") != [task.key for task in tasks]:
            raise ValueError(f"Dev run task order differs: {language}")
        predictions = _read_jsonl(run_dir / "predictions.jsonl")
        if len(predictions) != 100:
            raise ValueError(f"Dev predictions are incomplete: {language}")
        all_tasks.extend(tasks)
        all_predictions.extend(predictions)
        run_receipts[language] = {
            "run_contract_sha256": file_sha256(run_dir / "run.json"),
            "predictions_sha256": file_sha256(run_dir / "predictions.jsonl"),
            "runner_summary_sha256": file_sha256(run_dir / "summary.json"),
            "source_csv_sha256": file_sha256(data),
        }
    bundle = build_materials(all_tasks, all_predictions, seed=seed)
    selection = calibration_selection(bundle.private_manifest, per_language=per_language,
                                      seed=f"{seed}:selection", include_pointwise=True)
    assignment = human_assignment(bundle.private_manifest, selection, seed=f"{seed}:human")
    denominators = pilot_denominators(bundle.private_manifest, selection)
    pilot_manifest = selected_private_manifest(bundle.private_manifest, selection)
    if (len(selection["request_ids"]) != 4 * per_language * len(LANGUAGE_SLUGS)
            or len(assignment["request_ids"]) != per_language * len(LANGUAGE_SLUGS)):
        raise ValueError("Unexpected judge/human pilot request denominator")
    contract = {"version": VERSION, "purpose": "small_dev_format_and_rubric_pilot_only",
                "generator_model_id": generator_identity[0],
                "generator_revision": generator_identity[1],
                "dev": dev_receipt, "runs": run_receipts,
                "materials_protocol": PROTOCOL_VERSION,
                "requests_sha256": bundle.private_manifest["judge_requests_sha256"],
                "selection_sha256": canonical_hash(selection),
                "human_assignment_sha256": canonical_hash(assignment),
                "denominators": denominators,
                "interpretation": "No judge or human outputs; this pilot cannot establish naming quality."}
    write_materials(bundle, output)
    private_path = output / "pilot_private_manifest.json"
    descriptor = os.open(private_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
        json.dump(pilot_manifest, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
    human_ids = set(assignment["request_ids"])
    with (output / "human_requests.jsonl").open("x", encoding="utf-8", newline="\n") as stream:
        for request in bundle.public_requests:
            if request["request_id"] in human_ids:
                stream.write(json.dumps(request, ensure_ascii=False, sort_keys=True) + "\n")
    contract["output_sha256"] = {
        "judge_requests_jsonl": file_sha256(output / "judge_requests.jsonl"),
        "private_manifest_json": file_sha256(output / "private_manifest.json"),
        "pilot_private_manifest_json": file_sha256(private_path),
        "human_requests_jsonl": file_sha256(output / "human_requests.jsonl"),
    }
    for name, value in (("judge_selection.json", selection),
                        ("human_assignment.json", assignment),
                        ("calibration_contract.json", contract)):
        with (output / name).open("x", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
            stream.write("\n")
    return contract


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dev-root", type=Path, default=Path("data/stack_v3_dev_20260924/holdout"))
    parser.add_argument("--dev-audit", type=Path,
                        default=Path("results/rq1_empirical/audit/stack_v3_dev_20260924.json"))
    parser.add_argument("--runs", type=Path, required=True,
                        help="JSON mapping the seven languages to complete local dev run directories")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", required=True)
    parser.add_argument("--per-language", type=int, default=8)
    args = parser.parse_args()
    result = prepare(args.dev_root, args.dev_audit, args.runs, args.output,
                     seed=args.seed, per_language=args.per_language)
    print(json.dumps({"output": str(args.output.resolve()),
                      "selected_judge_requests": result["denominators"]["selected_judge_requests"],
                      "selected_human_requests": sum(result["denominators"][
                          "selected_nonidentical_pairs_by_language"].values())}, sort_keys=True))


if __name__ == "__main__":
    main()
